import { query, withTransaction } from '../db/pool.js';
import { logAuditEvent } from '../services/audit.service.js';

const RANGE_VALUE = /^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?$/;

function requireOwner(req, res) {
  if (req.user?.role === 'OWNER') return true;
  res.status(403).json({ error: 'Solo el dueño puede confirmar recogidas de efectivo' });
  return false;
}

function normalizeRangeValue(value, label, { endOfMinute = false } = {}) {
  const normalized = String(value || '').trim();
  if (!RANGE_VALUE.test(normalized)) {
    const error = new Error(`${label} inválida`);
    error.status = 400;
    throw error;
  }
  if (/^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d$/.test(normalized)) {
    return `${normalized}:${endOfMinute ? '59.999' : '00'}`;
  }
  return normalized;
}

function normalizeRange(source = {}) {
  const periodStart = normalizeRangeValue(source.periodStart || source.startAt, 'Fecha inicial');
  const periodEnd = normalizeRangeValue(source.periodEnd || source.endAt, 'Fecha final', { endOfMinute: true });
  if (new Date(periodEnd).getTime() <= new Date(periodStart).getTime()) {
    const error = new Error('La fecha final debe ser posterior a la fecha inicial');
    error.status = 400;
    throw error;
  }
  return { periodStart, periodEnd };
}

function toNumber(value) {
  return Number(value || 0);
}

async function calculateCollectionPreview(client, periodStart, periodEnd) {
  const totalsResult = await client.query(
    `WITH range_sales AS (
       SELECT
         COALESCE(SUM(CASE WHEN payment_method = 'CASH' THEN total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN payment_method = 'TRANSFER' THEN total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales
       FROM sales
       WHERE status IN ('PAID', 'REFUNDED')
         AND created_at >= $1::timestamptz
         AND created_at <= $2::timestamptz
     ), range_refunds AS (
       SELECT COALESCE(SUM(amount), 0)::numeric(12,2) AS cash_refunds
       FROM sale_refunds
       WHERE refund_kind = 'REFUND'
         AND payment_method = 'CASH'
         AND created_at >= $1::timestamptz
         AND created_at <= $2::timestamptz
     ), range_movements AS (
       SELECT
         COALESCE(SUM(CASE WHEN type = 'IN' THEN amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
         COALESCE(SUM(CASE WHEN type = 'OUT' THEN amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
       FROM drawer_movements
       WHERE created_at >= $1::timestamptz
         AND created_at <= $2::timestamptz
     )
     SELECT rs.cash_sales, rs.transfer_sales, rr.cash_refunds, rm.drawer_in, rm.drawer_out
     FROM range_sales rs
     CROSS JOIN range_refunds rr
     CROSS JOIN range_movements rm`,
    [periodStart, periodEnd]
  );

  const overlapResult = await client.query(
    `SELECT id, period_start, period_end, amount_collected, collected_at
     FROM cash_collections
     WHERE status = 'CONFIRMED'
       AND period_start <= $2::timestamptz
       AND period_end >= $1::timestamptz
     ORDER BY period_end DESC
     LIMIT 1`,
    [periodStart, periodEnd]
  );

  const lastResult = await client.query(
    `SELECT id, period_end, amount_collected, collected_at
     FROM cash_collections
     WHERE status = 'CONFIRMED'
     ORDER BY period_end DESC
     LIMIT 1`
  );

  const openDrawerResult = await client.query(
    `SELECT id, opened_at
     FROM cash_drawers
     WHERE status = 'OPEN'
       AND opened_at <= $2::timestamptz
       AND NOW() >= $1::timestamptz
     ORDER BY opened_at DESC
     LIMIT 1`,
    [periodStart, periodEnd]
  );

  const row = totalsResult.rows[0] || {};
  const cashSales = toNumber(row.cash_sales);
  const cashRefunds = toNumber(row.cash_refunds);
  const drawerIn = toNumber(row.drawer_in);
  const drawerOut = toNumber(row.drawer_out);
  const cashPosition = Number((cashSales + drawerIn - cashRefunds - drawerOut).toFixed(2));
  const expectedAmount = Math.max(0, cashPosition);

  return {
    periodStart,
    periodEnd,
    cashSales,
    cashRefunds,
    drawerIn,
    drawerOut,
    expectedAmount,
    cashPosition,
    transferSales: toNumber(row.transfer_sales),
    overlappingCollection: overlapResult.rows[0] || null,
    lastCollection: lastResult.rows[0] || null,
    openDrawer: openDrawerResult.rows[0] || null,
    canConfirm: overlapResult.rowCount === 0 && openDrawerResult.rowCount === 0
  };
}

export async function previewCashCollection(req, res) {
  if (!requireOwner(req, res)) return;
  try {
    const { periodStart, periodEnd } = normalizeRange(req.query);
    const preview = await calculateCollectionPreview({ query }, periodStart, periodEnd);
    res.json({ preview });
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message || 'No se pudo calcular la recogida' });
  }
}

export async function listCashCollections(req, res) {
  if (!requireOwner(req, res)) return;
  try {
    const { rows } = await query(
      `SELECT c.*, u.full_name AS collected_by_name
       FROM cash_collections c
       JOIN users u ON u.id = c.collected_by_user_id
       ORDER BY c.collected_at DESC
       LIMIT 50`
    );
    res.json({ collections: rows });
  } catch (error) {
    res.status(500).json({ error: error.message || 'No se pudo cargar el historial de recogidas' });
  }
}

export async function createCashCollection(req, res) {
  if (!requireOwner(req, res)) return;
  try {
    const { periodStart, periodEnd } = normalizeRange(req.body);
    const countedAmount = Number(req.body?.countedAmount);
    const notes = String(req.body?.notes || '').trim().slice(0, 500) || null;
    if (!Number.isFinite(countedAmount) || countedAmount < 0) {
      return res.status(400).json({ error: 'Indica el efectivo contado' });
    }

    const collection = await withTransaction(async (client) => {
      await client.query(`SELECT pg_advisory_xact_lock(hashtext('stationcore_cash_collections'))`);
      const preview = await calculateCollectionPreview(client, periodStart, periodEnd);
      if (preview.openDrawer) {
        const error = new Error('El período seleccionado incluye el turno de caja abierto. Cambia “Hasta” para terminar antes de que ese turno comenzara o cierra la caja.');
        error.status = 409;
        throw error;
      }
      if (preview.overlappingCollection) {
        const error = new Error('Ese período ya toca una recogida confirmada. Empieza después de la última fecha recogida.');
        error.status = 409;
        error.lastCollection = preview.lastCollection;
        throw error;
      }

      const differenceAmount = Number((countedAmount - preview.expectedAmount).toFixed(2));
      const inserted = await client.query(
        `INSERT INTO cash_collections (
           period_start, period_end, cash_sales, cash_refunds, drawer_in, drawer_out,
           expected_amount, counted_amount, difference_amount, amount_collected,
           transfer_sales, status, notes, collected_by_user_id, collected_at
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $8, $10, 'CONFIRMED', $11, $12, NOW())
         RETURNING *`,
        [
          periodStart, periodEnd, preview.cashSales, preview.cashRefunds,
          preview.drawerIn, preview.drawerOut, preview.expectedAmount,
          countedAmount, differenceAmount, preview.transferSales, notes, req.user.id
        ]
      );
      const saved = inserted.rows[0];

      await logAuditEvent(client, {
        eventType: 'CASH_COLLECTION_CONFIRMED',
        userId: req.user.id,
        entityType: 'cash_collection',
        entityId: saved.id,
        metadata: {
          periodStart,
          periodEnd,
          expectedAmount: preview.expectedAmount,
          countedAmount,
          differenceAmount
        }
      });

      return { ...saved, collected_by_name: req.user.full_name || req.user.name || 'Dueño' };
    });

    res.status(201).json({ collection });
  } catch (error) {
    res.status(error.status || 500).json({
      error: error.message || 'No se pudo confirmar la recogida',
      lastCollection: error.lastCollection || undefined
    });
  }
}
