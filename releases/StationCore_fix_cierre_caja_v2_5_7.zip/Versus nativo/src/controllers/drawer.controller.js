import { query, withTransaction } from '../db/pool.js';
import { validatePaymentAuthorizationCode } from './authorizationCodes.controller.js';
import { logAuditEvent } from '../services/audit.service.js';

function toNumber(value) {
  return Number(value || 0);
}

function normalizeBooleanSetting(value, fallback = true) {
  if (value === false || value === 'false' || value === 'FALSE' || value === 0 || value === '0') return false;
  if (value === true || value === 'true' || value === 'TRUE' || value === 1 || value === '1') return true;
  if (typeof value === 'string') {
    const cleaned = value.trim().replace(/^\"|\"$/g, '').toLowerCase();
    if (cleaned === 'false') return false;
    if (cleaned === 'true') return true;
  }
  return fallback;
}


async function isDrawerWorkflowEnabled(client = { query }) {
  try {
    const result = await client.query(
      `SELECT value FROM app_settings WHERE key = 'drawer_workflow_enabled' LIMIT 1`
    );
    if (!result.rowCount) return true;
    return normalizeBooleanSetting(result.rows[0].value, true);
  } catch (error) {
    if (error.code === '42P01') return true;
    throw error;
  }
}

export async function getDrawerSettings(_req, res) {
  const drawerWorkflowEnabled = await isDrawerWorkflowEnabled();
  res.json({ settings: { drawerWorkflowEnabled } });
}

export async function updateDrawerSettings(req, res) {
  if (!['OWNER', 'MANAGER'].includes(req.user?.role)) {
    return res.status(403).json({ error: 'No tienes permiso' });
  }

  const drawerWorkflowEnabled = normalizeBooleanSetting(req.body?.drawerWorkflowEnabled, true);
  await query(
    `INSERT INTO app_settings (key, value, updated_by_user_id, updated_at)
     VALUES ('drawer_workflow_enabled', $1::jsonb, $2, NOW())
     ON CONFLICT (key) DO UPDATE
     SET value = EXCLUDED.value,
         updated_by_user_id = EXCLUDED.updated_by_user_id,
         updated_at = NOW()`,
    [JSON.stringify(drawerWorkflowEnabled), req.user.id]
  );

  res.json({ settings: { drawerWorkflowEnabled } });
}


async function getDrawerWithUserNames(drawerId) {
  const { rows } = await query(
    `SELECT d.*, u.full_name AS opened_by_name, cu.full_name AS closed_by_name
     FROM cash_drawers d
     LEFT JOIN users u ON u.id = d.opened_by_user_id
     LEFT JOIN users cu ON cu.id = d.closed_by_user_id
     WHERE d.id = $1
     LIMIT 1`,
    [drawerId]
  );
  return rows[0] || null;
}

async function buildDrawerSummary(drawer) {
  if (!drawer) return null;

  const salesResult = await query(
    `SELECT
       COALESCE(SUM(CASE WHEN payment_method = 'CASH' THEN total ELSE 0 END), 0) AS cash_sales,
       COALESCE(SUM(CASE WHEN payment_method = 'TRANSFER' THEN total ELSE 0 END), 0) AS transfer_sales,
       COALESCE(SUM(total), 0) AS total_sales
     FROM sales
     WHERE status = 'PAID'
       AND created_at >= $1
       AND ($2::timestamptz IS NULL OR created_at <= $2)`,
    [drawer.opened_at, drawer.closed_at || null]
  );

  const movementsResult = await query(
    `SELECT
       COALESCE(SUM(CASE WHEN type = 'IN' THEN amount ELSE 0 END), 0) AS drawer_in,
       COALESCE(SUM(CASE WHEN type = 'OUT' THEN amount ELSE 0 END), 0) AS drawer_out
     FROM drawer_movements
     WHERE drawer_id = $1`,
    [drawer.id]
  );

  const movementsList = await query(
    `SELECT m.*, u.full_name AS user_name
     FROM drawer_movements m
     JOIN users u ON u.id = m.user_id
     WHERE m.drawer_id = $1
     ORDER BY m.created_at DESC
     LIMIT 30`,
    [drawer.id]
  );

  const sales = salesResult.rows[0] || {};
  const movements = movementsResult.rows[0] || {};
  const expectedCash = toNumber(drawer.opening_amount) + toNumber(sales.cash_sales) + toNumber(movements.drawer_in) - toNumber(movements.drawer_out);

  return {
    cash_sales: toNumber(sales.cash_sales),
    transfer_sales: toNumber(sales.transfer_sales),
    total_sales: toNumber(sales.total_sales),
    drawer_in: toNumber(movements.drawer_in),
    drawer_out: toNumber(movements.drawer_out),
    expected_cash: expectedCash,
    movements: movementsList.rows
  };
}

export async function getDrawerStatus(_req, res) {
  const { rows } = await query(`
    SELECT d.*, u.full_name AS opened_by_name, cu.full_name AS closed_by_name
    FROM cash_drawers d
    JOIN users u ON u.id = d.opened_by_user_id
    LEFT JOIN users cu ON cu.id = d.closed_by_user_id
    WHERE d.status = 'OPEN'
    ORDER BY d.opened_at DESC
    LIMIT 1
  `);

  const drawer = rows[0] || null;
  const summary = await buildDrawerSummary(drawer);
  res.json({ drawer: drawer ? { ...drawer, summary } : null });
}

export async function openDrawer(req, res) {
  const { openingAmount = 0, openingBreakdown = {} } = req.body;
  const existing = await query(`SELECT id FROM cash_drawers WHERE status = 'OPEN' LIMIT 1`);
  if (existing.rowCount > 0) return res.status(409).json({ error: 'Caja ya está abierta' });

  const { rows } = await query(
    `INSERT INTO cash_drawers (opened_by_user_id, opening_amount, opening_breakdown, status)
     VALUES ($1, $2, $3, 'OPEN')
     RETURNING *`,
    [req.user.id, Number(openingAmount || 0), openingBreakdown]
  );

  await logAuditEvent({ query }, {
    eventType: 'DRAWER_OPENED',
    userId: req.user.id,
    entityType: 'cash_drawer',
    entityId: rows[0].id,
    drawerId: rows[0].id,
    metadata: { openingAmount: Number(openingAmount || 0) }
  });

  const drawerWithNames = await getDrawerWithUserNames(rows[0].id) || rows[0];
  const summary = await buildDrawerSummary(drawerWithNames);
  res.status(201).json({ drawer: { ...drawerWithNames, summary } });
}

export async function closeDrawer(req, res) {
  const { closingAmount = 0, closingBreakdown = {}, closingNote = '' } = req.body;
  const openResult = await query(
    `SELECT * FROM cash_drawers WHERE status = 'OPEN' ORDER BY opened_at DESC LIMIT 1`
  );

  const openDrawer = openResult.rows[0];
  if (!openDrawer) return res.status(404).json({ error: 'No hay caja abierta' });

  const summary = await buildDrawerSummary(openDrawer);
  const expectedCash = toNumber(summary?.expected_cash);
  const countedCash = Number(closingAmount || 0);
  const difference = countedCash - expectedCash;

  const { rows } = await query(
    `UPDATE cash_drawers
     SET closed_by_user_id = $1,
         closing_amount = $2,
         closing_breakdown = $3,
         expected_cash = $4,
         cash_difference = $5,
         closing_note = $6,
         closed_at = NOW(),
         status = 'CLOSED'
     WHERE id = $7
     RETURNING *`,
    [req.user.id, countedCash, closingBreakdown, expectedCash, difference, closingNote, openDrawer.id]
  );

  await logAuditEvent({ query }, {
    eventType: 'DRAWER_CLOSED',
    userId: req.user.id,
    entityType: 'cash_drawer',
    entityId: rows[0].id,
    drawerId: rows[0].id,
    metadata: { expectedCash, countedCash, difference, closingNote }
  });

  const drawerWithNames = await getDrawerWithUserNames(rows[0].id) || rows[0];
  res.json({
    drawer: {
      ...drawerWithNames,
      summary: { ...summary, expected_cash: expectedCash, cash_difference: difference },
      receipt_ready: true
    }
  });
}

export async function addDrawerMovement(req, res) {
  const { type, amount = 0, reason = '', authorizationCode = '' } = req.body;
  const movementType = String(type || '').toUpperCase();
  const amountNumber = Number(amount || 0);
  const cleanReason = String(reason || '').trim();
  if (!['IN', 'OUT'].includes(movementType)) return res.status(400).json({ error: 'Tipo inválido' });
  if (amountNumber <= 0) return res.status(400).json({ error: 'Monto requerido' });
  if (movementType === 'OUT' && cleanReason.length < 3) return res.status(400).json({ error: 'Razón del pago requerida' });

  const movement = await withTransaction(async (client) => {
    const openResult = await client.query(
      `SELECT id FROM cash_drawers WHERE status = 'OPEN' ORDER BY opened_at DESC LIMIT 1 FOR UPDATE`
    );
    const drawer = openResult.rows[0];
    if (!drawer) {
      const error = new Error('No hay caja abierta');
      error.status = 404;
      throw error;
    }

    let authorization = null;
    if (movementType === 'OUT') {
      authorization = await validatePaymentAuthorizationCode(client, authorizationCode, req.user.id);
    }

    const { rows } = await client.query(
      `INSERT INTO drawer_movements (drawer_id, user_id, type, amount, reason)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [drawer.id, req.user.id, movementType, amountNumber, cleanReason]
    );

    await logAuditEvent(client, {
      eventType: movementType === 'OUT' ? 'DRAWER_PAYOUT' : 'DRAWER_MOVEMENT_IN',
      userId: req.user.id,
      entityType: 'drawer_movement',
      entityId: rows[0].id,
      drawerId: drawer.id,
      metadata: {
        type: movementType,
        amount: amountNumber,
        reason: cleanReason,
        authorizationCodeType: authorization?.code_type || null,
        authorizationCodeId: authorization?.id || null
      }
    });

    return rows[0];
  });

  res.status(201).json({ movement });
}
