(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};
  window.ClubVersusModules.drawer = window.ClubVersusModules.drawer || {};
})();

// Módulo de Caja / cuadre tipo JK POS.
// Mantiene funciones globales usadas por app.js y botones existentes.

const DRAWER_DENOMINATIONS = {
  bills: [2000, 1000, 500, 200, 100, 50],
  coins: [25, 10, 5, 1]
};

function openDrawerModule() {
  if (!requirePermission('drawer')) return;
  closeModuleHub();
  openDenominationCounter(state.drawer ? 'close' : 'open');
}

function closeDrawerModule() {
  closeConfigModule('#drawerModuleModal');
}

function renderDrawerModule() {
  const label = $('#drawerModuleStatus');
  const openBtn = $('#drawerOpenActionBtn');
  const closeBtn = $('#drawerCloseActionBtn');
  const paymentBtn = $('#drawerPaymentActionBtn');
  const quickPaymentBtn = $('#quickDrawerPaymentActionBtn');
  if (!label || !openBtn || !closeBtn) return;

  const drawer = state.drawer;
  const summary = drawer?.summary || {};
  const isOpen = Boolean(drawer);

  if (isOpen) {
    label.textContent = `Abierta · ${formatTime(drawer.opened_at)}`;
  } else {
    label.textContent = 'Cerrada';
  }

  openBtn.disabled = isOpen;
  closeBtn.disabled = !isOpen;
  if (paymentBtn) paymentBtn.disabled = !isOpen;
  if (quickPaymentBtn) {
    quickPaymentBtn.disabled = !isOpen;
    quickPaymentBtn.classList.toggle('is-disabled', !isOpen);
    quickPaymentBtn.title = isOpen ? 'Registrar salida de efectivo autorizada' : 'Abre la caja antes de registrar un pago';
  }
  setDrawerText('#drawerOpeningAmount', money(drawer?.opening_amount || 0));
  setDrawerText('#drawerCashSales', money(summary.cash_sales || 0));
  setDrawerText('#drawerTransferSales', money(summary.transfer_sales || 0));
  setDrawerText('#drawerCashIn', money(summary.drawer_in || 0));
  setDrawerText('#drawerCashOut', money(summary.drawer_out || 0));
  setDrawerText('#drawerExpectedCash', money(summary.expected_cash || 0));

  const movements = Array.isArray(summary.movements) ? summary.movements : [];
  const movementsList = $('#drawerMovementsList');
  if (movementsList) {
    movementsList.innerHTML = movements.length
      ? movements.map((movement) => `
        <div class="drawer-movement-row ${String(movement.type || '').toLowerCase()}">
          <span>
            <strong>${movement.type === 'OUT' ? 'Pago' : 'Entrada'}</strong>
            <small>${formatDateTime(movement.created_at)} · ${movement.user_name || 'Usuario'}</small>
            <em>${movement.reason || 'Sin razón'}</em>
          </span>
          <b>${movement.type === 'OUT' ? '-' : '+'}${money(movement.amount)}</b>
        </div>
      `).join('')
      : '<div class="empty-state compact">Sin movimientos de caja.</div>';
  }
  setDrawerText('#drawerMovementsCount', movements.length ? `${movements.length} movimiento(s)` : 'Sin movimientos');
}


function getDrawerUserName(drawer = state.drawer) {
  return drawer?.opened_by_name || drawer?.closed_by_name || state.user?.full_name || state.user?.name || state.user?.username || 'Usuario';
}

async function printDrawerReceipt(type, drawerPayload = null) {
  const desktopApi = window.clubVersusDesktop || window.ClubVersusDesktop || window.desktopAPI || null;
  if (!desktopApi?.printReceipt) return;
  const drawer = drawerPayload || state.drawer || {};
  const summary = drawer.summary || state.drawer?.summary || {};
  const openingAmount = Number(drawer.opening_amount || 0);
  const expectedCash = Number(summary.expected_cash ?? drawer.expected_cash ?? 0);
  const closingAmount = Number(drawer.closing_amount ?? expectedCash);
  const cashDifference = Number(summary.cash_difference ?? drawer.cash_difference ?? (closingAmount - expectedCash));
  const payload = {
    type,
    businessName: 'Club Versus',
    cashier: type === 'DRAWER_CLOSE' ? (drawer.closed_by_name || getDrawerUserName(drawer)) : (drawer.opened_by_name || getDrawerUserName(drawer)),
    openedAt: drawer.opened_at || null,
    closedAt: drawer.closed_at || null,
    openingAmount,
    cashSales: Number(summary.cash_sales || 0),
    drawerIn: Number(summary.drawer_in || 0),
    drawerOut: Number(summary.drawer_out || 0),
    cashRefunds: Number(summary.cash_refunds || 0),
    expectedCash,
    closingAmount,
    cashDifference,
    moneyToDeliver: Math.max(0, expectedCash - openingAmount)
  };
  try {
    await desktopApi.printReceipt({ receipt: payload });
  } catch (error) {
    console.warn('No se pudo imprimir recibo de caja:', error?.message || error);
    showToast('Caja guardada, pero no se pudo imprimir el recibo de cuadre. Revisa impresora.');
  }
}

function setDrawerText(selector, value) {
  const el = $(selector);
  if (el) el.textContent = value;
}

function openDenominationCounter(mode) {
  state.denominationMode = mode;

  if (mode !== 'collection' && window.ClubVersusHardware?.kickCashDrawerForEvent) {
    window.ClubVersusHardware.kickCashDrawerForEvent(mode === 'close' ? 'drawer-close-count' : 'drawer-open-count');
  }

  const isClose = mode === 'close';
  const isCollection = mode === 'collection';
  const usesClosingCount = isClose || isCollection;
  const modal = $('#denominationModal');
  const title = $('#denominationTitle');
  const subtitle = $('#denominationSubtitle');
  const note = $('#denominationNote');
  const confirmBtn = $('#confirmDenominationBtn');
  const openingPanel = $('#openingCountPanel');
  const closingPanel = $('#closingCountPanel');
  const closingTitle = $('#closingCountTitle');

  if (title) title.textContent = isCollection ? 'Dinero a recoger' : (isClose ? 'Cerrar caja' : 'Apertura de caja');
  if (subtitle) subtitle.textContent = isCollection ? 'Coloca la cantidad de cada billete y moneda.' : (isClose ? 'Cuenta el efectivo final.' : 'Cuenta el efectivo inicial.');
  if (closingTitle) closingTitle.textContent = isCollection ? 'Conteo del dinero' : 'Cierre de caja';
  modal?.classList.toggle('drawer-count-closing', isClose);
  modal?.classList.toggle('drawer-count-opening', !usesClosingCount);
  modal?.classList.toggle('drawer-count-collection', isCollection);
  if (note) {
    note.value = '';
    note.placeholder = isCollection ? 'Nota de la recogida (opcional)' : 'Nota';
    note.classList.toggle('hidden', !usesClosingCount);
  }
  if (confirmBtn) confirmBtn.textContent = isCollection ? 'Confirmar recogida e imprimir' : (isClose ? 'Cerrar caja' : 'Abrir caja');

  const openingBreakdown = isClose ? normalizeDenominationBreakdown(state.drawer?.opening_breakdown) : {};
  renderDenominationRows('billsList', DRAWER_DENOMINATIONS.bills, 'opening', { values: openingBreakdown, readonly: isClose });
  renderDenominationRows('coinsList', DRAWER_DENOMINATIONS.coins, 'opening', { values: openingBreakdown, readonly: isClose });
  setDenominationOther('opening', openingBreakdown.other || 0, isClose);

  renderDenominationRows('closingBillsList', DRAWER_DENOMINATIONS.bills, 'closing', { values: {}, readonly: !usesClosingCount });
  renderDenominationRows('closingCoinsList', DRAWER_DENOMINATIONS.coins, 'closing', { values: {}, readonly: !usesClosingCount });
  setDenominationOther('closing', 0, !usesClosingCount);

  if (openingPanel) {
    openingPanel.classList.toggle('drawer-count-reference', isClose);
    openingPanel.classList.toggle('drawer-count-active', !usesClosingCount);
    openingPanel.classList.toggle('hidden', isCollection);
  }
  if (closingPanel) {
    closingPanel.classList.toggle('drawer-count-disabled', !usesClosingCount);
    closingPanel.classList.toggle('drawer-count-active', usesClosingCount);
    closingPanel.classList.toggle('hidden', !usesClosingCount);
  }

  const expectedCard = $('#denominationExpectedCard');
  const differenceCard = $('#denominationDifferenceCard');
  expectedCard?.classList.toggle('hidden', !usesClosingCount);
  differenceCard?.classList.toggle('hidden', !usesClosingCount);

  updateDenominationTotal();
  modal?.classList.remove('hidden');
  modal?.setAttribute('aria-hidden', 'false');
  document.body.classList.add('drawer-count-open');
  document.body.classList.toggle('drawer-count-closing-open', isClose);
  document.body.classList.toggle('drawer-count-opening-open', !usesClosingCount);
  document.body.classList.toggle('drawer-count-collection-open', isCollection);

  const firstInput = usesClosingCount
    ? modal?.querySelector('[data-denomination-scope="closing"]:not([disabled])')
    : modal?.querySelector('[data-denomination-scope="opening"]:not([disabled])');
  setTimeout(() => firstInput?.focus(), 50);
}

function closeDenominationCounter(options = {}) {
  $('#denominationModal')?.classList.add('hidden');
  $('#denominationModal')?.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('drawer-count-open', 'drawer-count-closing-open', 'drawer-count-opening-open', 'drawer-count-collection-open');
  $('#denominationModal')?.classList.remove('drawer-count-opening', 'drawer-count-closing', 'drawer-count-collection');
  state.denominationMode = null;
  if (!options.keepPendingLogout) state.logoutAfterDrawerClose = false;
}

function normalizeDenominationBreakdown(value) {
  if (!value) return {};
  if (typeof value === 'object') return value;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (_error) {
    return {};
  }
}

function renderDenominationRows(containerId, values, scope, options = {}) {
  const container = $(`#${containerId}`);
  if (!container) return;
  const breakdown = options.values || {};
  const readonly = Boolean(options.readonly);

  container.innerHTML = values.map((value) => {
    const count = Math.max(0, Number(breakdown[String(value)] || 0));
    const rowTotal = count * Number(value);
    return `
      <label class="denomination-row ${readonly ? 'readonly' : ''}">
        <span>RD$${value}</span>
        <input type="number" min="0" step="1" value="${count}" data-denomination="${value}" data-denomination-scope="${scope}" ${readonly ? 'disabled' : ''} />
        <strong data-denomination-total="${scope}-${value}">${money(rowTotal)}</strong>
      </label>
    `;
  }).join('');

  container.querySelectorAll('input').forEach((input) => {
    input.addEventListener('input', updateDenominationTotal);
    input.addEventListener('focus', () => input.select());
  });
}

function setDenominationOther(scope, value = 0, readonly = false) {
  const input = scope === 'closing' ? $('#closingDenominationOtherInput') : $('#denominationOtherInput');
  const total = scope === 'closing' ? $('#closingDenominationOtherTotal') : $('#denominationOtherTotal');
  if (!input) return;
  input.value = String(Math.max(0, Number(value || 0)));
  input.disabled = readonly;
  input.dataset.denominationScope = scope;
  input.classList.toggle('readonly', readonly);
  if (total) total.textContent = money(Number(input.value || 0));
  input.removeEventListener?.('input', updateDenominationTotal);
  input.addEventListener('input', updateDenominationTotal);
}

function getDenominationData(scope = null) {
  const activeScope = scope || (['close', 'collection'].includes(state.denominationMode) ? 'closing' : 'opening');
  const counts = {};
  let total = 0;

  document.querySelectorAll(`[data-denomination-scope="${activeScope}"][data-denomination]`).forEach((input) => {
    const value = Number(input.dataset.denomination);
    const count = Math.max(0, Number(input.value || 0));
    const rowTotal = value * count;
    counts[String(value)] = count;
    total += rowTotal;

    const totalLabel = document.querySelector(`[data-denomination-total="${activeScope}-${value}"]`);
    if (totalLabel) totalLabel.textContent = money(rowTotal);
  });

  const otherInput = activeScope === 'closing' ? $('#closingDenominationOtherInput') : $('#denominationOtherInput');
  const otherTotal = activeScope === 'closing' ? $('#closingDenominationOtherTotal') : $('#denominationOtherTotal');
  const other = Math.max(0, Number(otherInput?.value || 0));
  total += other;
  counts.other = other;
  if (otherTotal) otherTotal.textContent = money(other);

  return { counts, total };
}

function updateDenominationTotal() {
  const opening = getDenominationData('opening');
  const closing = getDenominationData('closing');
  const isClose = state.denominationMode === 'close';
  const isCollection = state.denominationMode === 'collection';
  const usesClosingCount = isClose || isCollection;
  const active = usesClosingCount ? closing : opening;

  setDrawerText('#openingCountTotalLabel', money(opening.total));
  setDrawerText('#closingCountTotalLabel', usesClosingCount ? money(closing.total) : 'Pendiente');
  setDrawerText('#denominationTotal', money(active.total));

  if (usesClosingCount) {
    const expected = isCollection
      ? Number(state.cashCollectionPreview?.expectedAmount || 0)
      : Number(state.drawer?.summary?.expected_cash || 0);
    const difference = active.total - expected;
    const differenceLabel = $('#denominationDifferenceCard span');
    let resultLabel = 'Cuadre exacto';
    let resultAmount = 0;
    if (difference < -0.005) {
      resultLabel = 'Faltante';
      resultAmount = Math.abs(difference);
    } else if (difference > 0.005) {
      resultLabel = 'Sobrante';
      resultAmount = difference;
    }
    setDrawerText('#denominationExpected', money(expected));
    if (differenceLabel) differenceLabel.textContent = resultLabel;
    setDrawerText('#denominationDifference', money(resultAmount));
    $('#denominationDifference')?.classList.toggle('positive', difference >= -0.005);
    $('#denominationDifference')?.classList.toggle('negative', difference < -0.005);
    setDrawerText('#denominationSubtitle', `${resultLabel}: ${money(resultAmount)}`);
  } else {
    setDrawerText('#denominationSubtitle', money(active.total));
  }
}

function showDrawerPaymentError(message = '') {
  const box = $('#drawerPaymentError');
  if (!box) return;
  box.textContent = message || '';
  box.classList.toggle('hidden', !message);
}

function openDrawerPaymentModal() {
  if (!state.drawer) return showToast('Abre la caja antes de registrar un pago');
  $('#drawerPaymentAmountInput').value = '';
  $('#drawerPaymentReasonInput').value = '';
  $('#drawerPaymentAuthorizationCodeInput').value = '';
  showDrawerPaymentError('');
  const modal = $('#drawerPaymentModal');
  modal?.classList.remove('hidden');
  modal?.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('#drawerPaymentAmountInput')?.focus(), 50);
}

function closeDrawerPaymentModal() {
  $('#drawerPaymentModal')?.classList.add('hidden');
  $('#drawerPaymentModal')?.setAttribute('aria-hidden', 'true');
  showDrawerPaymentError('');
}

async function confirmDrawerPayment() {
  const amount = Number($('#drawerPaymentAmountInput')?.value || 0);
  const reason = $('#drawerPaymentReasonInput')?.value?.trim() || '';
  const authorizationCode = $('#drawerPaymentAuthorizationCodeInput')?.value?.trim() || '';
  const button = $('#confirmDrawerPaymentBtn');
  showDrawerPaymentError('');

  if (!state.drawer) return showDrawerPaymentError('No hay caja abierta.');
  if (!Number.isFinite(amount) || amount <= 0) return showDrawerPaymentError('Ingresa un monto válido.');
  if (reason.length < 3) return showDrawerPaymentError('Escribe la razón del pago.');
  if (!/^\d{6}$/.test(authorizationCode)) return showDrawerPaymentError('Ingresa el código de autorización de 6 dígitos.');

  if (button) button.disabled = true;
  try {
    await api('/drawer/movement', {
      method: 'POST',
      body: JSON.stringify({ type: 'OUT', amount, reason, authorizationCode })
    });

    let drawerOpened = true;
    if (window.ClubVersusHardware?.kickCashDrawerForEvent) {
      try {
        await window.ClubVersusHardware.kickCashDrawerForEvent('cash-payment', { toast: true });
      } catch (drawerError) {
        drawerOpened = false;
        console.warn('Pago registrado, pero no se pudo abrir la caja:', drawerError?.message || drawerError);
      }
    }

    showToast(drawerOpened ? 'Pago registrado. Caja abierta.' : 'Pago registrado, pero no se pudo abrir la caja. Revisa Configuración > Hardware.');
    closeDrawerPaymentModal();
    await loadDrawer();
    renderDrawerModule();
  } catch (error) {
    showDrawerPaymentError(error.message || 'No se pudo registrar el pago.');
  } finally {
    if (button) button.disabled = false;
  }
}

async function confirmDenominationCounter() {
  const mode = state.denominationMode;
  const { counts, total } = getDenominationData(['close', 'collection'].includes(mode) ? 'closing' : 'opening');

  try {
    if (mode === 'collection') {
      const confirmButton = $('#confirmDenominationBtn');
      if (confirmButton) confirmButton.disabled = true;
      const result = await window.ClubVersusModules?.reports?.confirmCashCollectionFromCounter?.({
        countedAmount: total,
        breakdown: counts,
        notes: $('#denominationNote')?.value.trim() || ''
      });
      if (result?.confirmed) closeDenominationCounter();
      else if (confirmButton) confirmButton.disabled = false;
      return;
    }

    let drawerReceiptPayload = null;
    let drawerReceiptType = '';

    if (mode === 'open') {
      const response = await api('/drawer/open', {
        method: 'POST',
        body: JSON.stringify({ openingAmount: total, openingBreakdown: counts })
      });
      drawerReceiptPayload = response.drawer || null;
      drawerReceiptType = 'DRAWER_OPEN';

      showToast('Caja abierta');
    }

    if (mode === 'close') {
      const response = await api('/drawer/close', {
        method: 'POST',
        body: JSON.stringify({
          closingAmount: total,
          closingBreakdown: counts,
          closingNote: $('#denominationNote')?.value.trim() || ''
        })
      });
      drawerReceiptPayload = response.drawer || null;
      drawerReceiptType = 'DRAWER_CLOSE';

      showToast('Caja cerrada');
    }

    const shouldLogoutAfterClose = mode === 'close' && Boolean(state.logoutAfterDrawerClose);
    closeDenominationCounter({ keepPendingLogout: shouldLogoutAfterClose });
    if (drawerReceiptPayload && drawerReceiptType) await printDrawerReceipt(drawerReceiptType, drawerReceiptPayload);
    await loadDrawer();

    if (shouldLogoutAfterClose && typeof performLogout === 'function') {
      if (typeof closeCurrentEmployeeSection === 'function') await closeCurrentEmployeeSection();
      performLogout();
    }
  } catch (error) {
    showToast(error.message);
  }
}
