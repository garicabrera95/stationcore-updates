-- v2.7.6: anulaciones/devoluciones auditables y recogidas de efectivo.
-- El runner de StationCore ejecuta el archivo completo dentro de una transacción.
-- No se modifica ningún CHECK existente: se reutilizan sales.status y los tipos
-- actuales de inventario para evitar repetir el incidente de v2.7.1.

CREATE TABLE IF NOT EXISTS sale_refunds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  refund_kind TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL,
  reason TEXT NOT NULL,
  inventory_restored BOOLEAN NOT NULL DEFAULT FALSE,
  print_supplies_restored BOOLEAN NOT NULL DEFAULT FALSE,
  drawer_id UUID REFERENCES cash_drawers(id) ON DELETE SET NULL,
  authorization_code_id UUID,
  created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE sale_refunds
  ADD COLUMN IF NOT EXISTS sale_id UUID,
  ADD COLUMN IF NOT EXISTS refund_kind TEXT,
  ADD COLUMN IF NOT EXISTS amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS payment_method TEXT,
  ADD COLUMN IF NOT EXISTS reason TEXT,
  ADD COLUMN IF NOT EXISTS inventory_restored BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS print_supplies_restored BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS drawer_id UUID,
  ADD COLUMN IF NOT EXISTS authorization_code_id UUID,
  ADD COLUMN IF NOT EXISTS created_by_user_id UUID,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

CREATE UNIQUE INDEX IF NOT EXISTS idx_sale_refunds_one_per_sale
  ON sale_refunds(sale_id);
CREATE INDEX IF NOT EXISTS idx_sale_refunds_created_at
  ON sale_refunds(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sale_refunds_drawer
  ON sale_refunds(drawer_id, created_at DESC);

DO $$
BEGIN
  IF to_regclass('public.admin_one_time_codes') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conrelid = 'sale_refunds'::regclass
         AND conname = 'sale_refunds_authorization_code_id_fkey'
     ) THEN
    ALTER TABLE sale_refunds
      ADD CONSTRAINT sale_refunds_authorization_code_id_fkey
      FOREIGN KEY (authorization_code_id)
      REFERENCES admin_one_time_codes(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS cash_collections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  cash_sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  cash_refunds NUMERIC(12,2) NOT NULL DEFAULT 0,
  drawer_in NUMERIC(12,2) NOT NULL DEFAULT 0,
  drawer_out NUMERIC(12,2) NOT NULL DEFAULT 0,
  expected_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  counted_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  difference_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  amount_collected NUMERIC(12,2) NOT NULL DEFAULT 0,
  transfer_sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'CONFIRMED',
  notes TEXT,
  collected_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reversed_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  reversed_at TIMESTAMPTZ,
  reversal_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE cash_collections
  ADD COLUMN IF NOT EXISTS period_start TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS period_end TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS cash_sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS cash_refunds NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS drawer_in NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS drawer_out NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS expected_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS counted_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS difference_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS amount_collected NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS transfer_sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'CONFIRMED',
  ADD COLUMN IF NOT EXISTS notes TEXT,
  ADD COLUMN IF NOT EXISTS collected_by_user_id UUID,
  ADD COLUMN IF NOT EXISTS collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS reversed_by_user_id UUID,
  ADD COLUMN IF NOT EXISTS reversed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS reversal_reason TEXT,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

CREATE INDEX IF NOT EXISTS idx_cash_collections_period
  ON cash_collections(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_cash_collections_status_date
  ON cash_collections(status, collected_at DESC);

ALTER TABLE IF EXISTS print_jobs
  ADD COLUMN IF NOT EXISTS refunded_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS refund_id UUID,
  ADD COLUMN IF NOT EXISTS supplies_restored_at TIMESTAMPTZ;

DO $$
BEGIN
  IF to_regclass('public.print_jobs') IS NOT NULL THEN
    CREATE INDEX IF NOT EXISTS idx_print_jobs_refunded_at
      ON print_jobs(refunded_at)
      WHERE refunded_at IS NOT NULL;
  END IF;
END $$;
