-- v2.7.5: perfiles Epson L3250, cálculo automático e historial de mantenimiento.
-- El runner de StationCore ejecuta este archivo completo dentro de una transacción.

-- La 089 ya creó estas tablas. Estas comprobaciones permiten reintentar la
-- migración en instalaciones cuyo historial no sea idéntico.
ALTER TABLE IF EXISTS print_supply_settings
  ADD COLUMN IF NOT EXISTS media_profile TEXT,
  ADD COLUMN IF NOT EXISTS paper_size TEXT,
  ADD COLUMN IF NOT EXISTS sheet_width_mm NUMERIC(8,2),
  ADD COLUMN IF NOT EXISTS sheet_height_mm NUMERIC(8,2),
  ADD COLUMN IF NOT EXISTS paper_brand TEXT,
  ADD COLUMN IF NOT EXISTS official_profile BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE print_supply_settings
SET media_profile = COALESCE(NULLIF(media_profile, ''), 'PLAIN_PAPER'),
    paper_size = COALESCE(NULLIF(paper_size, ''), 'LETTER'),
    sheet_width_mm = COALESCE(sheet_width_mm, 215.90),
    sheet_height_mm = COALESCE(sheet_height_mm, 279.40),
    official_profile = CASE WHEN COALESCE(NULLIF(media_profile, ''), 'PLAIN_PAPER') = 'PLAIN_PAPER' THEN TRUE ELSE official_profile END
WHERE supply_type = 'PAPER'
  AND supply_group = 'PAPER'
  AND (media_profile IS NULL OR media_profile = '' OR paper_size IS NULL OR paper_size = ''
       OR sheet_width_mm IS NULL OR sheet_height_mm IS NULL);

UPDATE print_supply_settings
SET media_profile = COALESCE(NULLIF(media_profile, ''), 'CUSTOM_COMPATIBLE'),
    paper_size = COALESCE(NULLIF(paper_size, ''), 'LETTER'),
    sheet_width_mm = COALESCE(sheet_width_mm, 215.90),
    sheet_height_mm = COALESCE(sheet_height_mm, 279.40)
WHERE supply_group = 'PAPER';

ALTER TABLE IF EXISTS print_service_recipes
  ADD COLUMN IF NOT EXISTS output_type TEXT,
  ADD COLUMN IF NOT EXISTS color_mode TEXT,
  ADD COLUMN IF NOT EXISTS print_quality TEXT,
  ADD COLUMN IF NOT EXISTS coverage_profile TEXT,
  ADD COLUMN IF NOT EXISTS borderless BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS auto_ink_estimate BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS estimate_source TEXT;

UPDATE print_service_recipes
SET output_type = COALESCE(NULLIF(output_type, ''), CASE
      WHEN service_code = 'PRINT-ID' THEN 'ID_COPY'
      ELSE 'DOCUMENT'
    END),
    color_mode = COALESCE(NULLIF(color_mode, ''), CASE
      WHEN service_code = 'PRINT-BW' THEN 'BW'
      ELSE 'COLOR'
    END),
    print_quality = COALESCE(NULLIF(print_quality, ''), 'STANDARD'),
    coverage_profile = COALESCE(NULLIF(coverage_profile, ''), CASE
      WHEN service_code = 'PRINT-BW' THEN 'TEXT'
      WHEN service_code = 'PRINT-COLOR-LIGHT' THEN 'LIGHT'
      WHEN service_code = 'PRINT-COLOR-FULL' THEN 'HIGH'
      WHEN service_code = 'PRINT-ID' THEN 'LIGHT'
      ELSE 'MEDIUM'
    END),
    estimate_source = COALESCE(NULLIF(estimate_source, ''), 'LEGACY_PRESERVED')
WHERE output_type IS NULL
   OR color_mode IS NULL
   OR print_quality IS NULL
   OR coverage_profile IS NULL
   OR estimate_source IS NULL;

ALTER TABLE IF EXISTS print_service_recipes
  ALTER COLUMN output_type SET DEFAULT 'DOCUMENT',
  ALTER COLUMN output_type SET NOT NULL,
  ALTER COLUMN color_mode SET DEFAULT 'COLOR',
  ALTER COLUMN color_mode SET NOT NULL,
  ALTER COLUMN print_quality SET DEFAULT 'STANDARD',
  ALTER COLUMN print_quality SET NOT NULL,
  ALTER COLUMN coverage_profile SET DEFAULT 'MEDIUM',
  ALTER COLUMN coverage_profile SET NOT NULL;

CREATE TABLE IF NOT EXISTS printer_maintenance_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  printer_model TEXT NOT NULL DEFAULT 'Epson L3250',
  event_type TEXT NOT NULL,
  result TEXT,
  printer_sheet_counter BIGINT,
  stationcore_sheet_count NUMERIC(14,2) NOT NULL DEFAULT 0,
  notes TEXT,
  performed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by_user_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE printer_maintenance_events
  ADD COLUMN IF NOT EXISTS printer_model TEXT NOT NULL DEFAULT 'Epson L3250',
  ADD COLUMN IF NOT EXISTS event_type TEXT,
  ADD COLUMN IF NOT EXISTS result TEXT,
  ADD COLUMN IF NOT EXISTS printer_sheet_counter BIGINT,
  ADD COLUMN IF NOT EXISTS stationcore_sheet_count NUMERIC(14,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS notes TEXT,
  ADD COLUMN IF NOT EXISTS performed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS created_by_user_id UUID,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'printer_maintenance_events'::regclass
      AND conname = 'printer_maintenance_events_created_by_user_id_fkey'
  ) THEN
    ALTER TABLE printer_maintenance_events
      ADD CONSTRAINT printer_maintenance_events_created_by_user_id_fkey
      FOREIGN KEY (created_by_user_id)
      REFERENCES users(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_printer_maintenance_events_model_date
  ON printer_maintenance_events(printer_model, performed_at DESC);

INSERT INTO app_settings (key, value, updated_at)
VALUES (
  'printing_maintenance_settings',
  '{"printerModel":"Epson L3250","nozzleCheckDays":30,"nozzleCheckSheets":500,"inactivityDays":14,"exteriorCleaningDays":120}'::jsonb,
  NOW()
)
ON CONFLICT (key) DO NOTHING;
