-- v2.7.4: papeles especiales/fotográficos administrables.
-- El runner de StationCore ejecuta este archivo dentro de una transacción.

CREATE TABLE IF NOT EXISTS print_supply_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supply_type TEXT NOT NULL UNIQUE,
  purchase_quantity NUMERIC(12,2) NOT NULL DEFAULT 1,
  purchase_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  yield_units NUMERIC(12,2) NOT NULL DEFAULT 1,
  remaining_units NUMERIC(12,2) NOT NULL DEFAULT 0,
  low_level_units NUMERIC(12,2) NOT NULL DEFAULT 10,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Instalaciones antiguas tienen un CHECK que solo permite PAPER/BLACK_INK/COLOR_INK.
-- Se elimina antes de insertar cualquier tipo nuevo de papel.
DO $$
DECLARE constraint_name TEXT;
BEGIN
  FOR constraint_name IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'print_supply_settings'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%supply_type%'
  LOOP
    EXECUTE format('ALTER TABLE print_supply_settings DROP CONSTRAINT %I', constraint_name);
  END LOOP;
END $$;

ALTER TABLE print_supply_settings
  ADD COLUMN IF NOT EXISTS display_name TEXT,
  ADD COLUMN IF NOT EXISTS supply_group TEXT NOT NULL DEFAULT 'PAPER',
  ADD COLUMN IF NOT EXISTS unit_label TEXT NOT NULL DEFAULT 'hojas',
  ADD COLUMN IF NOT EXISTS is_system BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

UPDATE print_supply_settings
SET display_name = CASE supply_type
  WHEN 'PAPER' THEN 'Papel carta'
  WHEN 'BLACK_INK' THEN 'Tinta negra T544'
  WHEN 'COLOR_INK' THEN 'Juego de tintas color T544'
  ELSE COALESCE(NULLIF(display_name, ''), INITCAP(REPLACE(supply_type, '_', ' ')))
END,
supply_group = CASE WHEN supply_type IN ('BLACK_INK', 'COLOR_INK') THEN 'INK' ELSE 'PAPER' END,
unit_label = CASE WHEN supply_type IN ('BLACK_INK', 'COLOR_INK') THEN 'páginas estimadas' ELSE 'hojas' END,
is_system = supply_type IN ('PAPER', 'BLACK_INK', 'COLOR_INK')
WHERE display_name IS NULL
   OR display_name = ''
   OR supply_type IN ('PAPER', 'BLACK_INK', 'COLOR_INK');

ALTER TABLE print_supply_settings
  ALTER COLUMN display_name SET NOT NULL;

INSERT INTO print_supply_settings (
  supply_type, display_name, supply_group, unit_label, is_system, is_active,
  purchase_quantity, purchase_cost, yield_units, remaining_units, low_level_units
) VALUES
  ('PAPER', 'Papel carta', 'PAPER', 'hojas', true, true, 500, 0, 500, 0, 50),
  ('BLACK_INK', 'Tinta negra T544', 'INK', 'páginas estimadas', true, true, 1, 0, 4500, 0, 300),
  ('COLOR_INK', 'Juego de tintas color T544', 'INK', 'páginas estimadas', true, true, 1, 0, 7500, 0, 500)
ON CONFLICT (supply_type) DO NOTHING;

CREATE TABLE IF NOT EXISTS print_service_recipes (
  product_id UUID PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  paper_sheets NUMERIC(8,3) NOT NULL DEFAULT 1,
  black_ink_units NUMERIC(8,3) NOT NULL DEFAULT 0,
  color_ink_units NUMERIC(8,3) NOT NULL DEFAULT 0,
  waste_percent NUMERIC(6,2) NOT NULL DEFAULT 15,
  service_code TEXT NOT NULL UNIQUE
);

ALTER TABLE print_service_recipes
  ADD COLUMN IF NOT EXISTS paper_supply_type TEXT;

UPDATE print_service_recipes
SET paper_supply_type = 'PAPER'
WHERE paper_supply_type IS NULL OR paper_supply_type = '';

ALTER TABLE print_service_recipes
  ALTER COLUMN paper_supply_type SET DEFAULT 'PAPER',
  ALTER COLUMN paper_supply_type SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conrelid = 'print_service_recipes'::regclass
      AND conname = 'print_service_recipes_paper_supply_type_fkey'
  ) THEN
    ALTER TABLE print_service_recipes
      ADD CONSTRAINT print_service_recipes_paper_supply_type_fkey
      FOREIGN KEY (paper_supply_type)
      REFERENCES print_supply_settings(supply_type)
      ON UPDATE CASCADE
      ON DELETE RESTRICT;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_print_supply_settings_group_active
  ON print_supply_settings(supply_group, is_active);

ALTER TABLE sale_items
  ADD COLUMN IF NOT EXISTS printing_details JSONB;

CREATE TABLE IF NOT EXISTS print_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  sale_item_id UUID NOT NULL REFERENCES sale_items(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  service_code TEXT NOT NULL,
  printed_pages NUMERIC(12,2) NOT NULL,
  paper_sheets NUMERIC(12,2) NOT NULL,
  paper_cost NUMERIC(12,4) NOT NULL DEFAULT 0,
  ink_cost NUMERIC(12,4) NOT NULL DEFAULT 0,
  estimated_cost NUMERIC(12,4) NOT NULL DEFAULT 0,
  revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION stationcore_record_print_job() RETURNS TRIGGER AS $$
DECLARE
  r print_service_recipes%ROWTYPE;
  paper print_supply_settings%ROWTYPE;
  black print_supply_settings%ROWTYPE;
  color print_supply_settings%ROWTYPE;
  pc NUMERIC := 0;
  ic NUMERIC := 0;
  factor NUMERIC := 1;
  sheets NUMERIC := 0;
BEGIN
  SELECT * INTO r FROM print_service_recipes WHERE product_id = NEW.product_id;
  IF NOT FOUND THEN RETURN NEW; END IF;

  SELECT * INTO paper
  FROM print_supply_settings
  WHERE supply_type = COALESCE(NULLIF(r.paper_supply_type, ''), 'PAPER')
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'El papel % no está configurado para este servicio', r.paper_supply_type;
  END IF;

  SELECT * INTO black FROM print_supply_settings WHERE supply_type = 'BLACK_INK' FOR UPDATE;
  SELECT * INTO color FROM print_supply_settings WHERE supply_type = 'COLOR_INK' FOR UPDATE;

  factor := 1 + (r.waste_percent / 100.0);
  sheets := COALESCE(
    NULLIF(NEW.printing_details->>'physicalPaperSheets', '')::numeric,
    NULLIF(NEW.printing_details->>'paperSheets', '')::numeric,
    NEW.quantity * r.paper_sheets
  );
  pc := sheets * factor * (paper.purchase_cost / NULLIF(paper.yield_units, 0));
  ic := NEW.quantity * factor * (
    (r.black_ink_units * black.purchase_cost / NULLIF(black.yield_units, 0)) +
    (r.color_ink_units * color.purchase_cost / NULLIF(color.yield_units, 0))
  );

  UPDATE print_supply_settings
  SET remaining_units = GREATEST(0, remaining_units - (sheets * factor)), updated_at = NOW()
  WHERE supply_type = paper.supply_type;

  UPDATE print_supply_settings
  SET remaining_units = GREATEST(0, remaining_units - (NEW.quantity * r.black_ink_units * factor)), updated_at = NOW()
  WHERE supply_type = 'BLACK_INK';

  UPDATE print_supply_settings
  SET remaining_units = GREATEST(0, remaining_units - (NEW.quantity * r.color_ink_units * factor)), updated_at = NOW()
  WHERE supply_type = 'COLOR_INK';

  UPDATE sale_items
  SET unit_cost = (pc + ic) / NULLIF(NEW.quantity, 0), cost_total = pc + ic
  WHERE id = NEW.id;

  INSERT INTO print_jobs (
    sale_id, sale_item_id, product_id, service_code, printed_pages, paper_sheets,
    paper_cost, ink_cost, estimated_cost, revenue
  ) VALUES (
    NEW.sale_id, NEW.id, NEW.product_id, r.service_code, NEW.quantity, sheets,
    pc, ic, pc + ic, NEW.total
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_record_print_job ON sale_items;
CREATE TRIGGER trg_record_print_job
AFTER INSERT ON sale_items
FOR EACH ROW EXECUTE FUNCTION stationcore_record_print_job();
