import { withTransaction, query } from '../db/pool.js';
import { validatePaymentAuthorizationCode, validateTransferAuthorizationCode } from './authorizationCodes.controller.js';
import { logAuditEvent } from '../services/audit.service.js';
import { awardTournamentParticipationPoints } from '../services/tournament-ranking.service.js';
import { recordMemberPointMovement } from '../services/member-points.service.js';
import { syncMemberAchievements } from '../services/member-achievements.service.js';
import { calculatePrintingPrice, loadPrintingPricingRules } from '../services/printing-pricing.service.js';
function normalizeBooleanSetting(value, fallback = true) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  const normalized = String(value).trim().toLowerCase();
  if (['false', '0', 'no', 'off', 'disabled', 'inactive'].includes(normalized)) return false;
  if (['true', '1', 'yes', 'on', 'enabled', 'active'].includes(normalized)) return true;
  return fallback;
}


function getMembershipTier(product) {
  const planCode = String(product.membership_plan_code || '').trim().toUpperCase();
  if (planCode) return planCode;

  const sku = String(product.sku || '').toUpperCase();
  const name = String(product.name || '').toUpperCase();

  if (sku.includes('CHAMPION') || name.includes('CHAMPION')) return 'CHAMPION';
  if (sku.includes('GAMER-PRO') || sku.includes('GAMER_PRO') || name.includes('GAMER PRO')) return 'GAMER_PRO';
  if (sku.includes('GAMER') || name.includes('GAMER')) return 'GAMER';

  return null;
}

async function getActiveBonusRule(client, ruleKey) {
  const { rows } = await client.query(
    `SELECT *
     FROM bonus_rules
     WHERE rule_key = $1
       AND is_active = true
     LIMIT 1`,
    [ruleKey]
  );
  return rows[0] || null;
}

function tierMatchesBonusRule(rule, member) {
  if (!rule || rule.applies_to_tier === 'ALL') return true;
  if (rule.applies_to_tier === 'GENERAL') return !member?.membership_active;
  if (rule.applies_to_tier === 'PAID_MEMBERS') return Boolean(member?.membership_active);
  return Boolean(member?.membership_active) && member?.membership_tier === rule.applies_to_tier;
}


function normalizePaymentMethod(value) {
  const method = String(value || 'CASH').toUpperCase();
  if (!['CASH', 'TRANSFER'].includes(method)) {
    const error = new Error('Método de pago inválido');
    error.status = 400;
    throw error;
  }
  return method;
}

function buildSaleNotes(paymentMethod, paymentReference, baseNote = '') {
  const reference = String(paymentReference || '').trim();

  if (paymentMethod === 'TRANSFER') {
    const transferNote = reference ? `Transferencia confirmada: ${reference}` : 'Transferencia confirmada';
    return baseNote ? `${baseNote} · ${transferNote}` : transferNote;
  }

  if (paymentMethod === 'CASH' && reference) {
    return baseNote ? `${baseNote} · ${reference}` : reference;
  }

  return baseNote || null;
}


function normalizeModifierOptionIds(value) {
  const source = Array.isArray(value) ? value : [];
  return [...new Set(source.map((item) => String(item || '').trim()).filter(Boolean))];
}

async function resolveProductModifiers(client, productId, modifierOptionIds = []) {
  const selectedIds = normalizeModifierOptionIds(modifierOptionIds);

  const groupsResult = await client.query(
    `SELECT pmg.*
     FROM product_modifier_assignments pma
     JOIN product_modifier_groups pmg ON pmg.id = pma.group_id
     WHERE pma.product_id = $1
       AND pmg.is_active = true
     ORDER BY pma.sort_order, pmg.sort_order, pmg.name`,
    [productId]
  ).catch(() => ({ rows: [] }));

  const groups = groupsResult.rows || [];
  if (!groups.length) return { modifiers: [], priceDelta: 0, descriptionSuffix: '' };

  const optionsResult = await client.query(
    `SELECT pmo.*, pmg.name AS group_name, pmg.is_required, pmg.allow_multiple
     FROM product_modifier_options pmo
     JOIN product_modifier_groups pmg ON pmg.id = pmo.group_id
     JOIN product_modifier_assignments pma ON pma.group_id = pmg.id AND pma.product_id = $1
     WHERE pmo.is_active = true
       AND pmg.is_active = true
     ORDER BY pmg.sort_order, pmo.sort_order, pmo.name`,
    [productId]
  ).catch(() => ({ rows: [] }));

  const options = optionsResult.rows || [];
  const selected = selectedIds.length
    ? options.filter((option) => selectedIds.includes(String(option.id)))
    : [];

  if (selected.length !== selectedIds.length) {
    const error = new Error('Modificador inválido para este producto');
    error.status = 400;
    throw error;
  }

  for (const group of groups) {
    const groupOptions = options.filter((option) => String(option.group_id) === String(group.id));
    if (!groupOptions.length) continue;
    const selectedForGroup = selected.filter((option) => String(option.group_id) === String(group.id));
    if (group.is_required && selectedForGroup.length === 0) {
      const error = new Error(`Selecciona ${group.name}`);
      error.status = 400;
      throw error;
    }
    if (!group.allow_multiple && selectedForGroup.length > 1) {
      const error = new Error(`Solo una opción en ${group.name}`);
      error.status = 400;
      throw error;
    }
  }

  const modifiers = selected.map((option) => ({
    groupId: option.group_id,
    groupName: option.group_name,
    optionId: option.id,
    optionName: option.name,
    priceDelta: Number(option.price_delta || 0)
  }));
  const priceDelta = modifiers.reduce((sum, modifier) => sum + Number(modifier.priceDelta || 0), 0);
  const descriptionSuffix = modifiers.length ? ` (${modifiers.map((modifier) => modifier.optionName).join(', ')})` : '';

  return { modifiers, priceDelta, descriptionSuffix };
}

async function ensureOpenDrawer(client) {
  try {
    const settings = await client.query(`SELECT value FROM app_settings WHERE key = 'drawer_workflow_enabled' LIMIT 1`);
    if (settings.rowCount && normalizeBooleanSetting(settings.rows[0].value, true) === false) return;
  } catch (error) {
    if (error.code !== '42P01') throw error;
  }

  const { rowCount } = await client.query(`SELECT id FROM cash_drawers WHERE status = 'OPEN' LIMIT 1`);
  if (rowCount === 0) {
    const error = new Error('Debes abrir la caja antes de iniciar ventas.');
    error.status = 409;
    throw error;
  }
}

function getRewardRemaining(reward, totalKey, usedKey) {
  if (!reward) return 0;
  return Math.max(0, Number(reward[totalKey] || 0) - Number(reward[usedKey] || 0));
}

function isRewardFullyUsed(reward) {
  if (!reward) return false;
  return Number(reward.reward_minutes || 0) <= Number(reward.used_reward_minutes || 0)
    && Number(reward.prize_snack_qty || 0) <= Number(reward.used_prize_snack_qty || 0)
    && Number(reward.prize_drink_qty || 0) <= Number(reward.used_prize_drink_qty || 0)
    && Number(reward.prize_product_qty || 0) <= Number(reward.used_prize_product_qty || 0);
}

async function getValidVisitReward(client, memberId, rewardId) {
  if (!memberId || !rewardId) return null;
  const result = await client.query(
    `SELECT *
     FROM member_rewards
     WHERE id = $1
       AND member_id = $2
       AND status = 'AVAILABLE'
       AND expires_at >= NOW()
     FOR UPDATE`,
    [rewardId, memberId]
  );
  if (result.rowCount === 0) {
    const error = new Error('Bono no disponible o vencido');
    error.status = 409;
    throw error;
  }
  return result.rows[0];
}

async function applyRewardToQuickSaleLines({ productLines, visitReward, requestedSnackQty = 0, requestedDrinkQty = 0, requestedProductId = null, requestedProductQty = 0 }) {
  if (!visitReward || (requestedSnackQty <= 0 && requestedDrinkQty <= 0 && requestedProductQty <= 0)) {
    return { requestedSnackQty: 0, requestedDrinkQty: 0, requestedProductQty: 0, rewardDiscount: 0 };
  }

  const snackAvailable = getRewardRemaining(visitReward, 'prize_snack_qty', 'used_prize_snack_qty');
  const drinkAvailable = getRewardRemaining(visitReward, 'prize_drink_qty', 'used_prize_drink_qty');
  const productAvailable = getRewardRemaining(visitReward, 'prize_product_qty', 'used_prize_product_qty');

  if (requestedSnackQty > snackAvailable) {
    const error = new Error('No tienes suficientes bonos de snack disponibles');
    error.status = 409;
    throw error;
  }
  if (requestedDrinkQty > drinkAvailable) {
    const error = new Error('No tienes suficientes bonos de bebida disponibles');
    error.status = 409;
    throw error;
  }
  if (requestedProductQty > 0) {
    if (!requestedProductId || String(visitReward.prize_product_id || '') !== String(requestedProductId)) {
      const error = new Error('Ese bono no corresponde a este producto');
      error.status = 409;
      throw error;
    }
    if (requestedProductQty > productAvailable) {
      const error = new Error('No tienes suficientes bonos de producto disponibles');
      error.status = 409;
      throw error;
    }
    let remainingProduct = requestedProductQty;
    for (const line of productLines) {
      if (String(line.product.id) !== String(requestedProductId) || remainingProduct <= 0) continue;
      const freeQty = Math.min(line.quantity, remainingProduct);
      line.freeQuantity += freeQty;
      line.paidQuantity = Math.max(0, line.quantity - line.freeQuantity);
      line.paidTotal = Number((line.paidQuantity * line.unitPrice).toFixed(2));
      remainingProduct -= freeQty;
    }
    if (remainingProduct > 0) {
      const error = new Error('Agrega el producto del bono a la orden');
      error.status = 400;
      throw error;
    }
  }

  const requestedByCategory = { SNACK: requestedSnackQty, DRINK: requestedDrinkQty };
  for (const category of ['SNACK', 'DRINK']) {
    let remaining = requestedByCategory[category];
    if (remaining <= 0) continue;
    for (const line of productLines) {
      if (line.product.category !== category || remaining <= 0) continue;
      const freeQty = Math.min(line.quantity - line.freeQuantity, remaining);
      if (freeQty <= 0) continue;
      line.freeQuantity += freeQty;
      line.paidQuantity = Math.max(0, line.quantity - line.freeQuantity);
      line.paidTotal = Number((line.paidQuantity * line.unitPrice).toFixed(2));
      remaining -= freeQty;
    }
    if (remaining > 0) {
      const error = new Error(category === 'SNACK' ? 'Agrega snacks para aplicar el bono' : 'Agrega bebidas para aplicar el bono');
      error.status = 400;
      throw error;
    }
  }

  const rewardDiscount = productLines.reduce((sum, line) => sum + Math.max(0, Number(line.total || 0) - Number(line.paidTotal || 0)), 0);
  return { requestedSnackQty, requestedDrinkQty, requestedProductQty, rewardDiscount: Number(rewardDiscount.toFixed(2)) };
}

async function markRewardUsage(client, { visitReward, requestedSnackQty = 0, requestedDrinkQty = 0, requestedProductQty = 0, saleId = null }) {
  if (!visitReward || (requestedSnackQty <= 0 && requestedDrinkQty <= 0 && requestedProductQty <= 0)) return null;
  const updatedRewardResult = await client.query(
    `UPDATE member_rewards
     SET used_prize_snack_qty = LEAST(prize_snack_qty, COALESCE(used_prize_snack_qty, 0) + $2),
         used_prize_drink_qty = LEAST(prize_drink_qty, COALESCE(used_prize_drink_qty, 0) + $3),
         used_prize_product_qty = LEAST(prize_product_qty, COALESCE(used_prize_product_qty, 0) + $4),
         used_sale_id = COALESCE(used_sale_id, $5),
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [visitReward.id, requestedSnackQty, requestedDrinkQty, requestedProductQty, saleId]
  );
  const updatedReward = updatedRewardResult.rows[0];
  if (updatedReward && isRewardFullyUsed(updatedReward)) {
    await client.query(
      `UPDATE member_rewards
       SET status = 'USED', used_at = COALESCE(used_at, NOW()), updated_at = NOW()
       WHERE id = $1`,
      [visitReward.id]
    );
  }
  return updatedReward;
}


function sendControllerError(res, error) {
  const status = error.status || 500;
  if (status >= 500) console.error(error);
  else console.warn(error.message);
  return res.status(status).json({
    error: status === 500 ? 'Error interno del servidor' : error.message
  });
}

async function applyMembershipSale(client, { memberId, saleId, line }) {
  const tier = getMembershipTier(line.product);
  if (!tier) return;

  const historyResult = await client.query(
    `SELECT id FROM member_membership_history WHERE member_id = $1 LIMIT 1`,
    [memberId]
  );
  const isRenewal = historyResult.rowCount > 0;

  await client.query(
    `INSERT INTO member_membership_history (member_id, sale_id, tier, amount, is_renewal)
     VALUES ($1, $2, $3, $4, $5)`,
    [memberId, saleId, tier, line.total, isRenewal]
  );

  await client.query(
    `UPDATE members
     SET membership_tier = $1,
         membership_active = true,
         membership_started_at = COALESCE(membership_started_at, NOW()),
         membership_updated_at = NOW(),
         updated_at = NOW()
     WHERE id = $2`,
    [tier, memberId]
  );

  if (!isRenewal) {
    const welcomeRule = await getActiveBonusRule(client, 'WELCOME_MEMBERSHIP');
    if (welcomeRule && Number(welcomeRule.reward_minutes || 0) > 0) {
      const memberInfo = await client.query(
        `SELECT id, membership_tier, membership_active FROM members WHERE id = $1`,
        [memberId]
      );

      if (tierMatchesBonusRule(welcomeRule, memberInfo.rows[0])) {
        await client.query(
          `INSERT INTO member_bonuses (member_id, source_sale_id, bonus_type, bonus_minutes, status, expires_at, source_rule_id)
           VALUES ($1, $2, 'WELCOME_MEMBERSHIP', $3, 'AVAILABLE', NOW() + ($4 || ' days')::interval, $5)
           ON CONFLICT (member_id, bonus_type) DO NOTHING`,
          [memberId, saleId, Number(welcomeRule.reward_minutes || 0), Number(welcomeRule.expires_days || 0), welcomeRule.id]
        );
      }
    }
  }
}


async function deductInventoryForLine(client, line, userId, saleId) {
  const product = line.product;
  const quantity = Number(line.quantity || 1);

  if (product.is_combo) {
    const componentResult = await client.query(
      `SELECT pcc.quantity AS component_qty, p.*
       FROM product_combo_components pcc
       JOIN products p ON p.id = pcc.component_product_id
       WHERE pcc.combo_product_id = $1`,
      [product.id]
    );

    if (componentResult.rowCount > 0) {
      for (const component of componentResult.rows) {
        if (!component.track_stock) continue;
        const requiredQty = Math.max(1, Number(component.component_qty || 1)) * quantity;
        const lockedResult = await client.query(`SELECT * FROM products WHERE id = $1 FOR UPDATE`, [component.id]);
        const locked = lockedResult.rows[0];
        const before = Number(locked.stock_qty || 0);
        const after = before - requiredQty;

        if (after < 0) {
          const error = new Error(`Inventario insuficiente para ${locked.name}`);
          error.status = 409;
          throw error;
        }

        await client.query(`UPDATE products SET stock_qty = $2, updated_at = NOW() WHERE id = $1`, [component.id, after]);
        await client.query(
          `INSERT INTO inventory_movements (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reference_id, reason)
           VALUES ($1, $2, 'COMBO_COMPONENT', $3, $4, $5, 'SALE', $6, $7)`,
          [component.id, userId, -requiredQty, before, after, saleId, `Combo ${product.name}`]
        );
      }
      return;
    }
  }

  if (!product.track_stock) return;

  const lockedResult = await client.query(`SELECT * FROM products WHERE id = $1 FOR UPDATE`, [product.id]);
  const locked = lockedResult.rows[0];
  const before = Number(locked.stock_qty || 0);
  const after = before - quantity;

  if (after < 0) {
    const error = new Error(`Inventario insuficiente para ${locked.name}`);
    error.status = 409;
    throw error;
  }

  await client.query(`UPDATE products SET stock_qty = $2, updated_at = NOW() WHERE id = $1`, [product.id, after]);
  await client.query(
    `INSERT INTO inventory_movements (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reference_id, reason)
     VALUES ($1, $2, 'SALE', $3, $4, $5, 'SALE', $6, $7)`,
    [product.id, userId, -quantity, before, after, saleId, product.name]
  );
}

export async function listRecentSales(_req, res) {
  try {
    const { rows } = await query(`
      SELECT s.*, u.full_name AS cashier_name, m.full_name AS member_name
      FROM sales s
      JOIN users u ON u.id = s.user_id
      LEFT JOIN members m ON m.id = s.member_id
      ORDER BY s.created_at DESC
      LIMIT 25
    `);
    res.json({ sales: rows });

  } catch (error) {
    return sendControllerError(res, error);
  }
}

function normalizeSaleRangeValue(value, { endOfMinute = false } = {}) {
  const text = String(value || '').trim();
  if (!text) return null;
  if (!/^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?$/.test(text)) return null;
  if (/^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d$/.test(text)) {
    return `${text}:${endOfMinute ? '59.999' : '00'}`;
  }
  return text;
}

function getRefundRestriction(row = {}) {
  if (row.has_membership) return 'Las membresías requieren reversión especializada';
  if (row.has_tournament_entry) return 'Las inscripciones de torneo se cancelan desde Torneos';
  if (row.has_station_items || row.has_game_time) return 'Los consumos de estación se ajustan desde la cuenta de estación';
  if (row.has_reward_usage) return 'La venta usó una recompensa y requiere ajuste especializado';
  return null;
}

export async function listRefundableSales(req, res) {
  try {
    const startAt = normalizeSaleRangeValue(req.query.startAt);
    const endAt = normalizeSaleRangeValue(req.query.endAt, { endOfMinute: true });
    const { rows } = await query(
      `SELECT s.*, u.full_name AS cashier_name, COALESCE(m.full_name, 'General') AS member_name,
              COALESCE(items.items, '[]'::json) AS items,
              COALESCE(items.has_membership, false) AS has_membership,
              COALESCE(items.has_tournament_entry, false) AS has_tournament_entry,
              COALESCE(items.has_game_time, false) AS has_game_time,
              EXISTS (SELECT 1 FROM station_session_items ssi WHERE ssi.sale_id = s.id) AS has_station_items,
              EXISTS (SELECT 1 FROM member_rewards mr WHERE mr.used_sale_id = s.id) AS has_reward_usage
       FROM sales s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN members m ON m.id = s.member_id
       LEFT JOIN LATERAL (
         SELECT
           json_agg(json_build_object(
             'id', si.id,
             'description', si.description,
             'quantity', si.quantity,
             'unit_price', si.unit_price,
             'total', si.total,
             'item_type', si.item_type,
             'product_id', si.product_id,
             'product_category', p.category
           ) ORDER BY si.created_at, si.id) AS items,
           BOOL_OR(p.category = 'MEMBERSHIP') AS has_membership,
           BOOL_OR(si.item_type = 'TOURNAMENT_ENTRY') AS has_tournament_entry,
           BOOL_OR(si.item_type = 'GAME_TIME') AS has_game_time
         FROM sale_items si
         LEFT JOIN products p ON p.id = si.product_id
         WHERE si.sale_id = s.id
       ) items ON true
       WHERE s.status IN ('PAID', 'VOID', 'REFUNDED')
         AND s.created_at >= COALESCE($1::timestamptz, NOW() - INTERVAL '30 days')
         AND s.created_at <= COALESCE($2::timestamptz, NOW())
       ORDER BY s.created_at DESC
       LIMIT 100`,
      [startAt, endAt]
    );

    res.json({
      sales: rows.map((row) => ({
        ...row,
        refund_restriction: getRefundRestriction(row),
        can_refund: row.status === 'PAID' && !getRefundRestriction(row)
      }))
    });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

async function restoreSaleInventory(client, saleId, userId, reason) {
  const movementResult = await client.query(
    `SELECT product_id, ABS(SUM(quantity_change))::int AS quantity_to_restore
     FROM inventory_movements
     WHERE reference_type = 'SALE'
       AND reference_id = $1
       AND quantity_change < 0
     GROUP BY product_id`,
    [saleId]
  );

  for (const movement of movementResult.rows) {
    const quantity = Number(movement.quantity_to_restore || 0);
    if (quantity <= 0) continue;
    const productResult = await client.query(
      `SELECT id, name, stock_qty FROM products WHERE id = $1 FOR UPDATE`,
      [movement.product_id]
    );
    const product = productResult.rows[0];
    if (!product) continue;
    const before = Number(product.stock_qty || 0);
    const after = before + quantity;
    await client.query(
      `UPDATE products SET stock_qty = $2, updated_at = NOW() WHERE id = $1`,
      [product.id, after]
    );
    await client.query(
      `INSERT INTO inventory_movements
         (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reference_id, reason)
       VALUES ($1, $2, 'ADJUSTMENT_IN', $3, $4, $5, 'SALE_REFUND', $6, $7)`,
      [product.id, userId, quantity, before, after, saleId, reason]
    );
  }
  return movementResult.rowCount > 0;
}

async function markAndOptionallyRestorePrintJobs(client, saleId, refundId, restoreSupplies) {
  const jobsResult = await client.query(
    `SELECT pj.id, pj.printed_pages, pj.paper_sheets,
            COALESCE(r.paper_supply_type, 'PAPER') AS paper_supply_type,
            COALESCE(r.black_ink_units, 0) AS black_ink_units,
            COALESCE(r.color_ink_units, 0) AS color_ink_units,
            COALESCE(r.waste_percent, 0) AS waste_percent
     FROM print_jobs pj
     LEFT JOIN print_service_recipes r ON r.product_id = pj.product_id
     WHERE pj.sale_id = $1
       AND pj.refunded_at IS NULL
     FOR UPDATE OF pj`,
    [saleId]
  );

  if (restoreSupplies) {
    for (const job of jobsResult.rows) {
      const factor = 1 + (Number(job.waste_percent || 0) / 100);
      const paperUnits = Number(job.paper_sheets || 0) * factor;
      const blackUnits = Number(job.printed_pages || 0) * Number(job.black_ink_units || 0) * factor;
      const colorUnits = Number(job.printed_pages || 0) * Number(job.color_ink_units || 0) * factor;
      if (paperUnits > 0) {
        await client.query(
          `UPDATE print_supply_settings SET remaining_units = remaining_units + $2, updated_at = NOW() WHERE supply_type = $1`,
          [job.paper_supply_type, paperUnits]
        );
      }
      if (blackUnits > 0) {
        await client.query(
          `UPDATE print_supply_settings SET remaining_units = remaining_units + $1, updated_at = NOW() WHERE supply_type = 'BLACK_INK'`,
          [blackUnits]
        );
      }
      if (colorUnits > 0) {
        await client.query(
          `UPDATE print_supply_settings SET remaining_units = remaining_units + $1, updated_at = NOW() WHERE supply_type = 'COLOR_INK'`,
          [colorUnits]
        );
      }
    }
  }

  await client.query(
    `UPDATE print_jobs
     SET refunded_at = NOW(),
         refund_id = $2,
         supplies_restored_at = CASE WHEN $3::boolean THEN NOW() ELSE supplies_restored_at END
     WHERE sale_id = $1 AND refunded_at IS NULL`,
    [saleId, refundId, Boolean(restoreSupplies)]
  );
  return jobsResult.rowCount > 0 && Boolean(restoreSupplies);
}

export async function refundSale(req, res) {
  try {
    const saleId = String(req.params.saleId || '').trim();
    const refundKind = String(req.body?.refundKind || 'REFUND').trim().toUpperCase();
    const reason = String(req.body?.reason || '').trim().slice(0, 500);
    const restoreInventory = req.body?.restoreInventory !== false;
    const restorePrintSupplies = req.body?.restorePrintSupplies === true;
    if (!['VOID', 'REFUND'].includes(refundKind)) return res.status(400).json({ error: 'Tipo de reversión inválido' });
    if (reason.length < 5) return res.status(400).json({ error: 'Explica la razón de la anulación o devolución' });

    const result = await withTransaction(async (client) => {
      const saleResult = await client.query(
        `SELECT s.*, u.full_name AS cashier_name, COALESCE(m.full_name, 'General') AS member_name
         FROM sales s
         JOIN users u ON u.id = s.user_id
         LEFT JOIN members m ON m.id = s.member_id
         WHERE s.id = $1
         FOR UPDATE OF s`,
        [saleId]
      );
      const sale = saleResult.rows[0];
      if (!sale) {
        const error = new Error('Venta no encontrada');
        error.status = 404;
        throw error;
      }
      if (sale.status !== 'PAID') {
        const error = new Error('La venta ya fue anulada o devuelta');
        error.status = 409;
        throw error;
      }

      const restrictionResult = await client.query(
        `SELECT
           EXISTS (
             SELECT 1 FROM sale_items si JOIN products p ON p.id = si.product_id
             WHERE si.sale_id = $1 AND p.category = 'MEMBERSHIP'
           ) AS has_membership,
           EXISTS (SELECT 1 FROM sale_items WHERE sale_id = $1 AND item_type = 'TOURNAMENT_ENTRY') AS has_tournament_entry,
           EXISTS (SELECT 1 FROM sale_items WHERE sale_id = $1 AND item_type = 'GAME_TIME') AS has_game_time,
           EXISTS (SELECT 1 FROM station_session_items WHERE sale_id = $1) AS has_station_items,
           EXISTS (SELECT 1 FROM member_rewards WHERE used_sale_id = $1) AS has_reward_usage`,
        [saleId]
      );
      const restriction = getRefundRestriction(restrictionResult.rows[0] || {});
      if (restriction) {
        const error = new Error(restriction);
        error.status = 409;
        throw error;
      }

      let authorization = null;
      if (!['OWNER', 'MANAGER'].includes(req.user?.role)) {
        authorization = await validatePaymentAuthorizationCode(client, req.body?.authorizationCode, req.user.id);
      }

      let drawer = null;
      if (refundKind === 'VOID' || sale.payment_method === 'CASH') {
        const drawerResult = await client.query(
          `SELECT id, opened_at FROM cash_drawers WHERE status = 'OPEN' ORDER BY opened_at DESC LIMIT 1 FOR UPDATE`
        );
        drawer = drawerResult.rows[0] || null;
      }
      if (refundKind === 'REFUND' && sale.payment_method === 'CASH' && !drawer) {
        const error = new Error('Abre la caja antes de devolver efectivo al cliente');
        error.status = 409;
        throw error;
      }
      if (refundKind === 'VOID' && (!drawer || new Date(sale.created_at) < new Date(drawer.opened_at))) {
        const error = new Error('Solo puedes anular una venta del turno de caja actual. Para una venta anterior usa Devolución.');
        error.status = 409;
        throw error;
      }

      const inserted = await client.query(
        `INSERT INTO sale_refunds
           (sale_id, refund_kind, amount, payment_method, reason, inventory_restored,
            print_supplies_restored, drawer_id, authorization_code_id, created_by_user_id)
         VALUES ($1, $2, $3, $4, $5, false, false, $6, $7, $8)
         RETURNING *`,
        [sale.id, refundKind, sale.total, sale.payment_method, reason, drawer?.id || null, authorization?.id || null, req.user.id]
      );
      const refund = inserted.rows[0];

      const inventoryRestored = restoreInventory
        ? await restoreSaleInventory(client, sale.id, req.user.id, `${refundKind === 'VOID' ? 'Anulación' : 'Devolución'}: ${reason}`)
        : false;
      const printSuppliesRestored = await markAndOptionallyRestorePrintJobs(
        client,
        sale.id,
        refund.id,
        restorePrintSupplies
      );

      await client.query(
        `UPDATE sale_refunds
         SET inventory_restored = $2, print_supplies_restored = $3
         WHERE id = $1`,
        [refund.id, inventoryRestored, printSuppliesRestored]
      );
      await client.query(
        `UPDATE sales SET status = $2 WHERE id = $1`,
        [sale.id, refundKind === 'VOID' ? 'VOID' : 'REFUNDED']
      );

      if (sale.member_id) {
        const pointResult = await client.query(
          `SELECT id FROM member_points_ledger
           WHERE source_key = $1 AND points > 0
           LIMIT 1`,
          [`sale:${sale.id}:member:${sale.member_id}:points`]
        );
        if (pointResult.rowCount > 0) {
          await client.query(
            `UPDATE members SET reward_points = GREATEST(0, reward_points - 1), updated_at = NOW() WHERE id = $1`,
            [sale.member_id]
          );
          await recordMemberPointMovement(client, {
            memberId: sale.member_id,
            points: -1,
            category: 'SALE_REFUND',
            reason: refundKind === 'VOID' ? 'Punto revertido por anulación' : 'Punto revertido por devolución',
            affectsRanking: false,
            referenceType: 'SALE_REFUND',
            referenceId: refund.id,
            sourceKey: `sale-refund:${refund.id}:member:${sale.member_id}:points`,
            userId: req.user.id
          });
        }
      }

      const itemsResult = await client.query(
        `SELECT id, product_id, item_type, description, quantity, unit_price, total
         FROM sale_items WHERE sale_id = $1 ORDER BY created_at, id`,
        [sale.id]
      );

      await logAuditEvent(client, {
        eventType: refundKind === 'VOID' ? 'SALE_VOIDED' : 'SALE_REFUNDED',
        userId: req.user.id,
        entityType: 'sale_refund',
        entityId: refund.id,
        saleId: sale.id,
        drawerId: drawer?.id || null,
        metadata: {
          amount: Number(sale.total || 0),
          paymentMethod: sale.payment_method,
          reason,
          inventoryRestored,
          printSuppliesRestored,
          authorizationCodeId: authorization?.id || null
        }
      });

      return {
        refund: { ...refund, inventory_restored: inventoryRestored, print_supplies_restored: printSuppliesRestored },
        sale: { ...sale, status: refundKind === 'VOID' ? 'VOID' : 'REFUNDED', items: itemsResult.rows }
      };
    });

    res.status(201).json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}


async function getMemberForTournamentDiscount(client, memberId) {
  if (!memberId) return null;
  const { rows } = await client.query('SELECT id, full_name, membership_tier, membership_active FROM members WHERE id = $1 LIMIT 1', [memberId]);
  return rows[0] || null;
}

async function calculateTournamentEntryPrice(client, tournament, memberId, participant = null) {
  const baseAmount = Number(tournament.entry_fee || 0);
  if (participant && participant.entry_fee_amount !== null && participant.entry_fee_amount !== undefined) {
    const storedTotal = Number(participant.entry_fee_amount || 0);
    const storedDiscount = Number(participant.entry_discount_amount || Math.max(0, baseAmount - storedTotal));
    return { baseAmount, total: storedTotal, discountAmount: storedDiscount, discountType: participant.entry_discount_type || 'NONE', label: participant.entry_discount_label || '' };
  }
  const effectiveMemberId = memberId || participant?.member_id || null;
  const member = await getMemberForTournamentDiscount(client, effectiveMemberId);
  if (!member?.membership_active || !member.membership_tier) {
    return { baseAmount, total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  }
  const tier = String(member.membership_tier || '').toUpperCase();
  const { rows } = await client.query('SELECT * FROM tournament_entry_discounts WHERE membership_tier = $1 AND is_active = true LIMIT 1', [tier]);
  const rule = rows[0];
  if (!rule || rule.discount_type === 'NONE') return { baseAmount, total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  let total = baseAmount;
  if (rule.discount_type === 'PERCENT') total = baseAmount - (baseAmount * Number(rule.discount_value || 0) / 100);
  if (rule.discount_type === 'FIXED_AMOUNT') total = baseAmount - Number(rule.discount_value || 0);
  if (rule.discount_type === 'FREE') total = 0;
  total = Math.max(0, Number(total.toFixed(2)));
  const discountAmount = Math.max(0, Number((baseAmount - total).toFixed(2)));
  const label = rule.discount_type === 'FREE' ? `${tier} gratis` : rule.discount_type === 'PERCENT' ? `${tier} ${Number(rule.discount_value || 0)}%` : `${tier} -RD$${Number(rule.discount_value || 0).toFixed(2)}`;
  return { baseAmount, total, discountAmount, discountType: rule.discount_type, label };
}

export async function createSale(req, res) {
  try {
    const {
      memberId = null,
      paymentMethod = 'CASH',
      paymentReference = '',
      transferAuthorizationCode = '',
      visitRewardId = null,
      rewardSnackQty = 0,
      rewardDrinkQty = 0,
      rewardProductId = null,
      rewardProductQty = 0,
      items = [],
      tournamentEntries = []
    } = req.body;
    const normalizedPaymentMethod = normalizePaymentMethod(paymentMethod);
    const safeTournamentEntries = Array.isArray(tournamentEntries) ? tournamentEntries : [];
    if ((!Array.isArray(items) || items.length === 0) && safeTournamentEntries.length === 0) {
      return res.status(400).json({ error: 'Agrega artículos o inscripción de torneo' });
    }

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);
      if (normalizedPaymentMethod === 'TRANSFER') {
        await validateTransferAuthorizationCode(client, transferAuthorizationCode, req.user.id);
      }

      let subtotal = 0;
      const normalizedItems = [];
      const tournamentLines = [];
      const membershipLines = [];
      let discountTotal = 0;
      const requestedSnackQty = Math.max(0, Number.parseInt(String(rewardSnackQty || 0), 10) || 0);
      const requestedDrinkQty = Math.max(0, Number.parseInt(String(rewardDrinkQty || 0), 10) || 0);
      const requestedProductId = rewardProductId || null;
      const requestedProductQty = Math.max(0, Number.parseInt(String(rewardProductQty || 0), 10) || 0);
      const visitReward = await getValidVisitReward(client, memberId, visitRewardId);
      const printingPricingRules = await loadPrintingPricingRules(client).catch(() => ({}));

      for (const item of items) {
        const productResult = await client.query(
          `SELECT p.id, p.name, p.sku, p.price, p.stock_qty, p.track_stock, p.category,
                  p.is_combo, p.product_kind, p.membership_plan_code,
                  p.combo_included_minutes, p.combo_player_count,
                  COALESCE(r.paper_sheets, 1) AS print_paper_sheets,
                  COALESCE(r.paper_supply_type, 'PAPER') AS print_paper_supply_type,
                  COALESCE(r.waste_percent, 0) AS print_waste_percent
           FROM products p
           LEFT JOIN print_service_recipes r ON r.product_id = p.id
           WHERE p.id = $1 AND p.is_active = true`,
          [item.productId]
        );
        if (productResult.rowCount === 0) {
          const error = new Error(`Product not found: ${item.productId}`);
          error.status = 404;
          throw error;
        }

        const product = productResult.rows[0];
        let quantity = Math.max(1, Number(item.quantity || 1));
        let printDetails = null;
        let printingPrice = null;
        if (product.product_kind === 'PRINT_SERVICE' && item.printDetails && typeof item.printDetails === 'object') {
          const documentPages = Math.max(1, Math.floor(Number(item.printDetails.documentPages || 1)));
          const copies = Math.max(1, Math.floor(Number(item.printDetails.copies || 1)));
          const doubleSided = item.printDetails.doubleSided === true;
          quantity = documentPages * copies;
          const basePaperSheets = (doubleSided ? Math.ceil(documentPages / 2) : documentPages) * copies;
          const physicalPaperSheets = Number((basePaperSheets * Number(product.print_paper_sheets || 1)).toFixed(3));
          printingPrice = calculatePrintingPrice(product, quantity, printingPricingRules);
          printDetails = {
            documentPages,
            copies,
            doubleSided,
            paperSheets: physicalPaperSheets,
            physicalPaperSheets,
            paperSupplyType: product.print_paper_supply_type
          };
        }
        const modifierInfo = await resolveProductModifiers(client, product.id, item.modifierOptionIds || item.modifiers || []);
        const unitPrice = printingPrice
          ? printingPrice.unitPrice
          : Number((Number(product.price) + Number(modifierInfo.priceDelta || 0)).toFixed(2));
        const total = Number((quantity * unitPrice).toFixed(2));
        const comboTimeSuffix = product.is_combo && Number(product.combo_included_minutes || 0) > 0 ? ` · ${Number(product.combo_included_minutes || 0)} min` : '';
        const printSuffix = printDetails ? ` · ${printDetails.documentPages} pág. × ${printDetails.copies}${printDetails.doubleSided ? ' · Doble cara' : ''}` : '';
        const description = `${product.name}${modifierInfo.descriptionSuffix}${comboTimeSuffix}${printSuffix}`;
        if (product.category === 'MEMBERSHIP' && !memberId) {
          const error = new Error('Selecciona o crea un miembro para vender una membresía');
          error.status = 400;
          throw error;
        }

        if (product.category === 'MEMBERSHIP' && quantity > 1) {
          const error = new Error('Solo puedes vender una membresía por miembro en la misma orden');
          error.status = 400;
          throw error;
        }

        subtotal += total;

        if (product.track_stock && !product.is_combo && Number(product.stock_qty) < quantity) {
          const error = new Error(`Inventario insuficiente para ${product.name}`);
          error.status = 409;
          throw error;
        }

        const line = { product, quantity, unitPrice, total, description, modifiers: modifierInfo.modifiers, printDetails, paidQuantity: quantity, freeQuantity: 0, paidTotal: total };
        normalizedItems.push(line);

        if (product.category === 'MEMBERSHIP') {
          membershipLines.push(line);
        }
      }



      for (const entry of safeTournamentEntries) {
        const tournamentId = entry.tournamentId || entry.tournament_id;
        if (!tournamentId) {
          const error = new Error('Torneo requerido');
          error.status = 400;
          throw error;
        }
        const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [tournamentId]);
        if (tournamentResult.rowCount === 0) {
          const error = new Error('Torneo no encontrado');
          error.status = 404;
          throw error;
        }
        const tournament = tournamentResult.rows[0];
        if (!['SCHEDULED', 'ACTIVE'].includes(tournament.status)) {
          const error = new Error('Este torneo no acepta inscripción');
          error.status = 409;
          throw error;
        }
        const entryFee = Number(tournament.entry_fee || 0);
        let participant = null;
        const participantId = entry.participantId || entry.participant_id;
        if (participantId) {
          const participantResult = await client.query(
            `SELECT * FROM tournament_participants
             WHERE id = $1 AND tournament_id = $2 FOR UPDATE`,
            [participantId, tournamentId]
          );
          if (participantResult.rowCount === 0) {
            const error = new Error('Participante no encontrado');
            error.status = 404;
            throw error;
          }
          participant = participantResult.rows[0];
          if (participant.is_paid) {
            const error = new Error('Ese participante ya pagó inscripción');
            error.status = 409;
            throw error;
          }
          if (participant.payment_status === 'EXPIRED') {
            const error = new Error('Inscripción vencida. Requiere autorización admin.');
            error.status = 409;
            throw error;
          }
        } else {
          const playerName = String(entry.playerName || entry.player_name || '').trim();
          if (!playerName) {
            const error = new Error('Nombre del participante requerido');
            error.status = 400;
            throw error;
          }
          const count = await client.query(
            `SELECT COUNT(*)::int AS total
             FROM tournament_participants
             WHERE tournament_id = $1
               AND COALESCE(payment_status, CASE WHEN is_paid THEN 'PAID' ELSE 'PENDING' END) <> 'CANCELLED'`,
            [tournamentId]
          );
          if (tournament.max_players && Number(count.rows[0].total || 0) >= Number(tournament.max_players)) {
            const error = new Error('El torneo llegó al máximo de jugadores');
            error.status = 409;
            throw error;
          }
          const pricing = await calculateTournamentEntryPrice(client, tournament, entry.memberId || entry.member_id || null, null);
          const created = await client.query(
            `INSERT INTO tournament_participants (tournament_id, member_id, player_name, phone, nickname, payment_deadline_at, payment_status, entry_fee_amount, entry_discount_amount, entry_discount_type, entry_discount_label)
             VALUES ($1, $2, $3, $4, $5, $6, 'PENDING', $7, $8, $9, $10)
             RETURNING *`,
            [tournamentId, entry.memberId || entry.member_id || null, playerName, String(entry.phone || '').trim() || null, String(entry.nickname || '').trim() || null, tournament.payment_deadline_at || null, pricing.total, pricing.discountAmount, pricing.discountType, pricing.label]
          );
          participant = created.rows[0];
        }

        const pricing = await calculateTournamentEntryPrice(client, tournament, entry.memberId || entry.member_id || participant.member_id || null, participant);
        const description = `Inscripción torneo · ${tournament.name} · ${participant.player_name}${pricing.label ? ' · ' + pricing.label : ''}`;
        subtotal += pricing.baseAmount;
        discountTotal += pricing.discountAmount;
        tournamentLines.push({ tournament, participant, unitPrice: pricing.baseAmount, total: pricing.total, description });
      }

      if (membershipLines.length > 1) {
        const error = new Error('Solo puedes seleccionar una membresía por orden');
        error.status = 400;
        throw error;
      }

      const rewardUsage = await applyRewardToQuickSaleLines({
        productLines: normalizedItems,
        visitReward,
        requestedSnackQty,
        requestedDrinkQty,
        requestedProductId,
        requestedProductQty
      });
      discountTotal += Number(rewardUsage.rewardDiscount || 0);
      const totalAfterDiscount = Number((subtotal - discountTotal).toFixed(2));
      const hasRewardUsage = Boolean(visitReward && (requestedSnackQty > 0 || requestedDrinkQty > 0 || requestedProductQty > 0));
      if (totalAfterDiscount <= 0 && !hasRewardUsage && tournamentLines.length === 0) {
        const error = new Error('Hay artículos en RD$0 sin bono aplicado. Revisa la orden.');
        error.status = 400;
        throw error;
      }

      const saleResult = await client.query(
        `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
         VALUES ($1, $2, $3, 0, $4, $5, $6, 'PAID', $7)
         RETURNING *`,
        [req.user.id, memberId, subtotal.toFixed(2), discountTotal.toFixed(2), totalAfterDiscount.toFixed(2), normalizedPaymentMethod, buildSaleNotes(normalizedPaymentMethod, paymentReference, hasRewardUsage ? 'Canje por bono' : '')]
      );

      const sale = saleResult.rows[0];

      for (const item of normalizedItems) {
        await client.query(
          `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total, printing_details)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [sale.id, item.product.id, item.product.is_combo ? 'COMBO' : 'PRODUCT', item.description || item.product.name, item.quantity, item.unitPrice, Number(item.paidTotal || 0).toFixed(2), item.printDetails ? JSON.stringify(item.printDetails) : null]
        );

        await deductInventoryForLine(client, item, req.user.id, sale.id);
      }

      for (const line of tournamentLines) {
        await client.query(
          `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, NULL, 'TOURNAMENT_ENTRY', $2, 1, $3, $4)`,
          [sale.id, line.description, line.unitPrice, line.total]
        );
        await client.query(
          `UPDATE tournament_participants
           SET is_paid = true, payment_status = 'PAID', paid_at = NOW(), paid_by_user_id = $3, sale_id = $4, updated_at = NOW()
           WHERE id = $1 AND tournament_id = $2`,
          [line.participant.id, line.tournament.id, req.user.id, sale.id]
        );
        await awardTournamentParticipationPoints(client, {
          memberId: line.participant.member_id,
          tournamentId: line.tournament.id,
          participantId: line.participant.id,
          tournamentName: line.tournament.name,
          userId: req.user.id
        });
        await logAuditEvent(client, {
          eventType: 'TOURNAMENT_ENTRY_SOLD',
          userId: req.user.id,
          entityType: 'tournament_participant',
          entityId: line.participant.id,
          saleId: sale.id,
          tournamentId: line.tournament.id,
          metadata: { playerName: line.participant.player_name, amount: Number(line.total || 0), paymentMethod: normalizedPaymentMethod }
        });
      }

      if (hasRewardUsage) {
        await markRewardUsage(client, {
          visitReward,
          requestedSnackQty,
          requestedDrinkQty,
          requestedProductQty,
          saleId: sale.id
        });
      }

      for (const line of membershipLines) {
        await applyMembershipSale(client, { memberId, saleId: sale.id, line });
      }

      if (memberId && Number(sale.total || 0) > 0) {
        await client.query(
          `UPDATE members SET reward_points = reward_points + 1, updated_at = NOW() WHERE id = $1`,
          [memberId]
        );
        await recordMemberPointMovement(client, {
          memberId,
          points: 1,
          category: 'SALE',
          reason: '1 punto por compra en POS',
          affectsRanking: false,
          referenceType: 'SALE',
          referenceId: sale.id,
          sourceKey: `sale:${sale.id}:member:${memberId}:points`,
          userId: req.user?.id || null
        });
      }

      const achievementMemberIds = new Set();
      if (memberId) achievementMemberIds.add(String(memberId));
      for (const line of tournamentLines) {
        if (line.participant?.member_id) achievementMemberIds.add(String(line.participant.member_id));
      }
      for (const syncMemberId of achievementMemberIds) {
        await syncMemberAchievements(client, { memberId: syncMemberId, userId: req.user?.id || null });
      }

      const productCount = normalizedItems.filter((line) => !line.product.is_combo).reduce((sum, line) => sum + Number(line.quantity || 0), 0);
      const comboCount = normalizedItems.filter((line) => line.product.is_combo).reduce((sum, line) => sum + Number(line.quantity || 0), 0);
      await logAuditEvent(client, {
        eventType: 'QUICK_SALE_PAID',
        userId: req.user.id,
        entityType: 'sale',
        entityId: sale.id,
        saleId: sale.id,
        metadata: {
          memberId,
          paymentMethod: normalizedPaymentMethod,
          total: Number(sale.total || 0),
          productCount,
          comboCount,
          tournamentEntryCount: tournamentLines.length
        }
      });

      return sale;
    });

    res.status(201).json({ sale: result });

  } catch (error) {
    return sendControllerError(res, error);
  }
}
