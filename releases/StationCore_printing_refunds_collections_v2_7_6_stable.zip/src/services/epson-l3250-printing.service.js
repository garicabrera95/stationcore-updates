const round = (value, decimals = 3) => Number(Number(value || 0).toFixed(decimals));

const PAPER_SIZES = {
  LETTER: { code: 'LETTER', label: 'Carta (8.5 × 11)', widthMm: 215.9, heightMm: 279.4 },
  A4: { code: 'A4', label: 'A4 (210 × 297 mm)', widthMm: 210, heightMm: 297 },
  LEGAL: { code: 'LEGAL', label: 'Legal (8.5 × 14)', widthMm: 215.9, heightMm: 355.6 },
  EXECUTIVE: { code: 'EXECUTIVE', label: 'Ejecutivo (7.25 × 10.5)', widthMm: 184.15, heightMm: 266.7 },
  HALF_LETTER: { code: 'HALF_LETTER', label: 'Media carta (5.5 × 8.5)', widthMm: 139.7, heightMm: 215.9 },
  A5: { code: 'A5', label: 'A5 (148 × 210 mm)', widthMm: 148, heightMm: 210 },
  A6: { code: 'A6', label: 'A6 (105 × 148 mm)', widthMm: 105, heightMm: 148 },
  PHOTO_4X6: { code: 'PHOTO_4X6', label: 'Foto 4 × 6', widthMm: 101.6, heightMm: 152.4 },
  PHOTO_5X7: { code: 'PHOTO_5X7', label: 'Foto 5 × 7', widthMm: 127, heightMm: 177.8 },
  PHOTO_8X10: { code: 'PHOTO_8X10', label: 'Foto 8 × 10', widthMm: 203.2, heightMm: 254 }
};

const PROFILE_ROWS = [
  ['PLAIN_PAPER', 'Papel normal / papel de copia', ['LETTER', 'A4', 'LEGAL', 'EXECUTIVE', 'HALF_LETTER', 'A5', 'A6'], 1],
  ['HIGH_QUALITY_INKJET', 'Epson High Quality Ink Jet Paper', ['LETTER', 'A4'], 1.05],
  ['PHOTO_GLOSSY', 'Epson Photo Paper Glossy', ['PHOTO_4X6', 'LETTER', 'A4'], 1.18],
  ['PREMIUM_PHOTO_GLOSSY', 'Epson Premium Photo Paper Glossy', ['PHOTO_4X6', 'PHOTO_5X7', 'PHOTO_8X10', 'LETTER'], 1.22],
  ['ULTRA_PREMIUM_PHOTO_GLOSSY', 'Epson Ultra Premium Photo Paper Glossy', ['PHOTO_4X6', 'PHOTO_5X7', 'PHOTO_8X10', 'LETTER'], 1.25],
  ['PREMIUM_PHOTO_SEMIGLOSS', 'Epson Premium Photo Paper Semi-gloss', ['PHOTO_4X6', 'LETTER'], 1.2],
  ['PRESENTATION_MATTE', 'Epson Presentation Paper Matte', ['LETTER'], 1.08],
  ['PREMIUM_PRESENTATION_MATTE', 'Epson Premium Presentation Paper Matte', ['PHOTO_8X10', 'LETTER'], 1.14],
  ['PREMIUM_PRESENTATION_MATTE_DS', 'Epson Premium Presentation Paper Matte doble cara', ['LETTER'], 1.14],
  ['VALUE_PHOTO_GLOSSY', 'Epson Value Photo Paper Glossy', ['PHOTO_4X6', 'LETTER'], 1.15],
  ['CUSTOM_COMPATIBLE', 'Otro papel compatible', Object.keys(PAPER_SIZES), 1.1]
];

const PAPER_PROFILES = Object.fromEntries(PROFILE_ROWS.map(([code, label, sizeCodes, inkMultiplier]) => [code, {
  code,
  label,
  inkMultiplier,
  official: code !== 'CUSTOM_COMPATIBLE',
  sizeCodes,
  borderlessSizeCodes: code.includes('PHOTO') || code === 'VALUE_PHOTO_GLOSSY' ? ['PHOTO_4X6'] : []
}]));

const QUALITY_MULTIPLIERS = { DRAFT: 0.72, STANDARD: 1, HIGH: 1.3 };
// Una página carta/A4 de documento normal equivale a una unidad de los
// rendimientos publicados por Epson (4,500 negro / 7,500 color).
const COVERAGE_MULTIPLIERS = { TEXT: 1, LIGHT: 0.65, MEDIUM: 1, HIGH: 1.75, FULL_PHOTO: 6 };

export const DEFAULT_PRINTER_MAINTENANCE_SETTINGS = Object.freeze({
  printerModel: 'Epson L3250',
  nozzleCheckDays: 30,
  nozzleCheckSheets: 500,
  inactivityDays: 14,
  exteriorCleaningDays: 120
});

export const PRINTER_MAINTENANCE_EVENT_TYPES = Object.freeze([
  'NOZZLE_CHECK',
  'HEAD_CLEANING',
  'POWER_CLEANING',
  'HEAD_ALIGNMENT',
  'EXTERIOR_CLEANING',
  'INK_VISUAL_CHECK'
]);

export function getEpsonL3250Catalog() {
  return {
    printerModel: 'Epson L3250',
    source: 'Manual oficial Epson L3250/L3251',
    publishedReplacementYield: { blackPages: 4500, colorPages: 7500, testPattern: 'ISO/IEC 24712' },
    disclaimer: 'Los rendimientos son estimados; Epson indica que varían según imagen, configuración, papel, frecuencia de uso y ambiente.',
    paperProfiles: Object.values(PAPER_PROFILES).map((profile) => ({
      code: profile.code,
      label: profile.label,
      official: profile.official,
      borderlessSizeCodes: [...profile.borderlessSizeCodes],
      sizes: profile.sizeCodes.map((code) => ({ ...PAPER_SIZES[code] }))
    })),
    outputTypes: [
      { code: 'DOCUMENT', label: 'Documento' },
      { code: 'PHOTO', label: 'Fotografía' },
      { code: 'ID_COPY', label: 'Copia de documento o cédula' },
      { code: 'GRAPHIC', label: 'Volante, diseño o gráfico' }
    ],
    colorModes: [
      { code: 'BW', label: 'Blanco y negro' },
      { code: 'COLOR', label: 'Color' },
      { code: 'GRAYSCALE', label: 'Escala de grises' }
    ],
    qualities: [
      { code: 'DRAFT', label: 'Borrador' },
      { code: 'STANDARD', label: 'Normal' },
      { code: 'HIGH', label: 'Alta / fotografía' }
    ],
    coverages: [
      { code: 'TEXT', label: 'Texto principalmente' },
      { code: 'LIGHT', label: 'Color liviano' },
      { code: 'MEDIUM', label: 'Documento mixto' },
      { code: 'HIGH', label: 'Color intenso' },
      { code: 'FULL_PHOTO', label: 'Fotografía completa' }
    ]
  };
}

export function resolveEpsonPaperSelection(mediaProfile = 'CUSTOM_COMPATIBLE', paperSize = 'LETTER') {
  const profile = PAPER_PROFILES[String(mediaProfile || '').trim().toUpperCase()] || PAPER_PROFILES.CUSTOM_COMPATIBLE;
  const requestedSize = String(paperSize || '').trim().toUpperCase();
  const sizeCode = profile.sizeCodes.includes(requestedSize) ? requestedSize : profile.sizeCodes[0];
  const size = PAPER_SIZES[sizeCode];
  return {
    mediaProfile: profile.code,
    mediaLabel: profile.label,
    officialProfile: profile.official,
    paperSize: size.code,
    sizeLabel: size.label,
    widthMm: size.widthMm,
    heightMm: size.heightMm,
    supportsBorderless: profile.borderlessSizeCodes.includes(size.code),
    inkMultiplier: profile.inkMultiplier
  };
}

export function buildPaperDisplayName(selection, brand = '', customName = '') {
  const explicitName = String(customName || '').trim();
  if (explicitName) return explicitName;
  const brandLabel = String(brand || '').trim();
  return `${selection.mediaLabel} · ${selection.sizeLabel}${brandLabel ? ` · ${brandLabel}` : ''}`;
}

function defaultCoverage(outputType, colorMode) {
  if (outputType === 'PHOTO') return 'FULL_PHOTO';
  if (outputType === 'ID_COPY') return colorMode === 'BW' ? 'TEXT' : 'LIGHT';
  if (outputType === 'GRAPHIC') return 'HIGH';
  return colorMode === 'BW' ? 'TEXT' : 'MEDIUM';
}

export function estimateEpsonL3250Ink(payload = {}, paperSupply = {}) {
  const outputType = ['DOCUMENT', 'PHOTO', 'ID_COPY', 'GRAPHIC'].includes(String(payload.outputType || '').toUpperCase())
    ? String(payload.outputType).toUpperCase() : 'DOCUMENT';
  const colorMode = ['BW', 'COLOR', 'GRAYSCALE'].includes(String(payload.colorMode || '').toUpperCase())
    ? String(payload.colorMode).toUpperCase() : 'COLOR';
  const quality = QUALITY_MULTIPLIERS[String(payload.quality || '').toUpperCase()] ? String(payload.quality).toUpperCase() : 'STANDARD';
  const requestedCoverage = String(payload.coverageProfile || '').toUpperCase();
  const coverageProfile = COVERAGE_MULTIPLIERS[requestedCoverage] ? requestedCoverage : defaultCoverage(outputType, colorMode);
  const selection = resolveEpsonPaperSelection(paperSupply.media_profile || 'CUSTOM_COMPATIBLE', paperSupply.paper_size || 'LETTER');
  const widthMm = Number(paperSupply.sheet_width_mm || selection.widthMm);
  const heightMm = Number(paperSupply.sheet_height_mm || selection.heightMm);
  const letterArea = PAPER_SIZES.LETTER.widthMm * PAPER_SIZES.LETTER.heightMm;
  const areaRatio = Math.max(0.05, (widthMm * heightMm) / letterArea);
  const borderless = Boolean(payload.borderless) && selection.supportsBorderless;
  const baseUnits = areaRatio
    * COVERAGE_MULTIPLIERS[coverageProfile]
    * QUALITY_MULTIPLIERS[quality]
    * selection.inkMultiplier
    * (borderless ? 1.1 : 1);

  let blackInkUnits = 0;
  let colorInkUnits = 0;
  if (colorMode === 'BW') {
    blackInkUnits = baseUnits;
    colorInkUnits = outputType === 'PHOTO' || quality === 'HIGH' ? baseUnits * 0.12 : baseUnits * 0.03;
  } else if (colorMode === 'GRAYSCALE') {
    blackInkUnits = baseUnits * 0.9;
    colorInkUnits = baseUnits * 0.15;
  } else {
    blackInkUnits = baseUnits * (outputType === 'PHOTO' ? 0.18 : 0.25);
    colorInkUnits = baseUnits;
  }

  return {
    outputType,
    colorMode,
    quality,
    coverageProfile,
    borderless,
    blackInkUnits: round(blackInkUnits),
    colorInkUnits: round(colorInkUnits),
    estimateSource: 'EPSON_L3250_PROFILE_V1'
  };
}

export function calculatePrintRecipeEconomics(recipe = {}, supplyMap = {}) {
  const factor = 1 + (Number(recipe.waste_percent || 0) / 100);
  const paper = supplyMap[String(recipe.paper_supply_type || 'PAPER')];
  const black = supplyMap.BLACK_INK;
  const color = supplyMap.COLOR_INK;
  const paperSheets = Number(recipe.paper_sheets || 0);
  const blackUnits = Number(recipe.black_ink_units || 0);
  const colorUnits = Number(recipe.color_ink_units || 0);
  const unitCost = (supply, units) => units * factor * (Number(supply?.purchase_cost || 0) / Math.max(1, Number(supply?.yield_units || 1)));
  const limits = [];
  if (paper && paperSheets > 0) limits.push({ key: paper.supply_type, label: paper.display_name, units: Number(paper.remaining_units || 0) / (paperSheets * factor) });
  if (black && blackUnits > 0) limits.push({ key: 'BLACK_INK', label: black.display_name, units: Number(black.remaining_units || 0) / (blackUnits * factor) });
  if (color && colorUnits > 0) limits.push({ key: 'COLOR_INK', label: color.display_name, units: Number(color.remaining_units || 0) / (colorUnits * factor) });
  limits.sort((a, b) => a.units - b.units);
  const paperCost = unitCost(paper, paperSheets);
  const inkCost = unitCost(black, blackUnits) + unitCost(color, colorUnits);
  return {
    paperCost: round(paperCost, 4),
    inkCost: round(inkCost, 4),
    estimatedUnitCost: round(paperCost + inkCost, 4),
    estimatedCapacity: limits.length ? Math.max(0, Math.floor(limits[0].units)) : 0,
    limitingSupply: limits[0]?.label || null
  };
}

function dateValue(value) {
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? date : null;
}

function daysBetween(earlier, later) {
  if (!earlier) return Number.POSITIVE_INFINITY;
  return Math.floor((later.getTime() - earlier.getTime()) / 86400000);
}

export function buildPrinterMaintenanceSummary({ events = [], printStats = {}, settings = {}, now = new Date() } = {}) {
  const config = { ...DEFAULT_PRINTER_MAINTENANCE_SETTINGS, ...(settings || {}) };
  const ordered = [...events].sort((a, b) => new Date(b.performed_at) - new Date(a.performed_at));
  const lastByType = (type) => ordered.find((event) => event.event_type === type);
  const lastNozzle = lastByType('NOZZLE_CHECK');
  const lastExterior = lastByType('EXTERIOR_CLEANING');
  const lastPrintAt = dateValue(printStats.last_print_at);
  const totalSheets = Number(printStats.total_sheets || 0);
  const sheetsAtCheck = Number(lastNozzle?.stationcore_sheet_count || 0);
  const sheetsSinceCheck = Math.max(0, totalSheets - sheetsAtCheck);
  const daysSinceCheck = daysBetween(dateValue(lastNozzle?.performed_at), now);
  const daysSinceExterior = daysBetween(dateValue(lastExterior?.performed_at), now);
  const daysInactive = lastPrintAt ? daysBetween(lastPrintAt, now) : 0;
  const cleaningBoundary = dateValue(lastNozzle?.performed_at)?.getTime() || 0;
  const cleaningsSinceCheck = ordered.filter((event) => event.event_type === 'HEAD_CLEANING' && new Date(event.performed_at).getTime() >= cleaningBoundary);
  const lastCleaning = cleaningsSinceCheck[0];
  const waitUntil = cleaningsSinceCheck.length >= 3 && lastCleaning
    ? new Date(new Date(lastCleaning.performed_at).getTime() + (12 * 60 * 60 * 1000)) : null;
  const alerts = [];

  if (!lastNozzle || daysSinceCheck >= Number(config.nozzleCheckDays) || sheetsSinceCheck >= Number(config.nozzleCheckSheets)) {
    alerts.push({ code: 'NOZZLE_CHECK_DUE', level: 'WARNING', title: 'Revisión de inyectores pendiente', detail: `${Math.round(sheetsSinceCheck)} hojas desde la última revisión.` });
  }
  if (lastPrintAt && daysInactive >= Number(config.inactivityDays)) {
    alerts.push({ code: 'INACTIVITY_CHECK', level: 'INFO', title: 'Impresora sin uso reciente', detail: `${daysInactive} días sin impresiones registradas. Haz una prueba antes del próximo trabajo.` });
  }
  if (lastNozzle?.result === 'GAPS') {
    alerts.push({ code: 'HEAD_CLEANING_RECOMMENDED', level: 'WARNING', title: 'Limpieza normal recomendada', detail: 'El último patrón registró espacios o líneas tenues.' });
  }
  if (lastNozzle?.result === 'MOSTLY_MISSING') {
    alerts.push({ code: 'POWER_CLEANING_REVIEW', level: 'DANGER', title: 'Patrón casi ausente', detail: 'Revisa el procedimiento Epson antes de una limpieza a fondo.' });
  }
  if (waitUntil && waitUntil > now) {
    alerts.push({ code: 'WAIT_12_HOURS', level: 'DANGER', title: 'No continúes limpiando', detail: `Espera hasta ${waitUntil.toLocaleString('es-DO')} antes de otra limpieza.` });
  }
  if (!lastExterior || daysSinceExterior >= Number(config.exteriorCleaningDays)) {
    alerts.push({ code: 'EXTERIOR_CLEANING_DUE', level: 'INFO', title: 'Limpieza exterior pendiente', detail: 'Epson recomienda limpiar el equipo varias veces al año.' });
  }

  return {
    settings: config,
    alerts,
    dueCount: alerts.length,
    totalSheets: round(totalSheets, 2),
    sheetsSinceCheck: round(sheetsSinceCheck, 2),
    daysSinceCheck: Number.isFinite(daysSinceCheck) ? daysSinceCheck : null,
    daysInactive,
    consecutiveCleanings: cleaningsSinceCheck.length,
    waitUntil: waitUntil?.toISOString() || null,
    lastNozzleCheck: lastNozzle || null,
    lastHeadCleaning: lastByType('HEAD_CLEANING') || null,
    lastPowerCleaning: lastByType('POWER_CLEANING') || null,
    lastAlignment: lastByType('HEAD_ALIGNMENT') || null,
    lastExteriorCleaning: lastExterior || null,
    recentEvents: ordered.slice(0, 20)
  };
}
