export const PRINTING_PRICING_SETTINGS_KEY = 'printing_pricing_rules';

function nonNegativeNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : fallback;
}

function quantityThreshold(value, fallback = 0) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 2) return fallback;
  return parsed;
}

export function defaultPrintingPricingRule(product = {}) {
  const sku = String(product.sku || product.service_code || '').trim().toUpperCase();
  const regularPrice = nonNegativeNumber(product.price, 0);

  if (sku === 'PRINT-BW') {
    return {
      regularPrice,
      bulkFrom: 2,
      bulkPrice: 10,
      paperMode: 'STANDARD',
      materialCostPerSheet: 0
    };
  }

  if (sku === 'PRINT-COLOR-FULL') {
    return {
      regularPrice,
      bulkFrom: 2,
      bulkPrice: 15,
      paperMode: 'STANDARD',
      materialCostPerSheet: 0
    };
  }

  return {
    regularPrice,
    bulkFrom: 0,
    bulkPrice: regularPrice,
    paperMode: 'STANDARD',
    materialCostPerSheet: 0
  };
}

export function normalizePrintingPricingRule(rule = {}, product = {}) {
  const defaults = defaultPrintingPricingRule(product);
  const regularPrice = nonNegativeNumber(rule.regularPrice ?? rule.regular_price, defaults.regularPrice);
  const bulkFrom = quantityThreshold(rule.bulkFrom ?? rule.bulk_from, defaults.bulkFrom);
  const bulkPrice = bulkFrom
    ? nonNegativeNumber(rule.bulkPrice ?? rule.bulk_price, defaults.bulkPrice)
    : regularPrice;
  const paperMode = String(rule.paperMode ?? rule.paper_mode ?? defaults.paperMode).trim().toUpperCase() === 'SPECIAL'
    ? 'SPECIAL'
    : 'STANDARD';

  return {
    regularPrice,
    bulkFrom,
    bulkPrice,
    paperMode,
    materialCostPerSheet: paperMode === 'SPECIAL'
      ? nonNegativeNumber(rule.materialCostPerSheet ?? rule.material_cost_per_sheet, defaults.materialCostPerSheet)
      : 0
  };
}

export function resolvePrintingPricingRule(product = {}, storedRules = {}) {
  const stored = storedRules && typeof storedRules === 'object'
    ? storedRules[String(product.id || '')]
    : null;
  return normalizePrintingPricingRule(stored || {}, product);
}

export function calculatePrintingPrice(product = {}, printedUnits = 1, storedRules = {}) {
  const quantity = Math.max(1, Math.floor(Number(printedUnits || 1)));
  const rule = resolvePrintingPricingRule(product, storedRules);
  const usesBulkPrice = rule.bulkFrom >= 2 && quantity >= rule.bulkFrom;
  const unitPrice = usesBulkPrice ? rule.bulkPrice : rule.regularPrice;

  return {
    quantity,
    unitPrice: Number(unitPrice.toFixed(2)),
    total: Number((quantity * unitPrice).toFixed(2)),
    usesBulkPrice,
    rule
  };
}

export async function loadPrintingPricingRules(client, options = {}) {
  const lockClause = options.forUpdate ? ' FOR UPDATE' : '';
  const result = await client.query(
    `SELECT value FROM app_settings WHERE key = $1${lockClause}`,
    [PRINTING_PRICING_SETTINGS_KEY]
  );
  const value = result.rows[0]?.value;
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

export async function savePrintingPricingRules(client, rules = {}, userId = null) {
  await client.query(
    `INSERT INTO app_settings (key, value, updated_by_user_id, updated_at)
     VALUES ($1, $2::jsonb, $3, NOW())
     ON CONFLICT (key) DO UPDATE
     SET value = EXCLUDED.value,
         updated_by_user_id = EXCLUDED.updated_by_user_id,
         updated_at = NOW()`,
    [PRINTING_PRICING_SETTINGS_KEY, JSON.stringify(rules || {}), userId]
  );
}

export function publicPrintingPricing(product = {}, storedRules = {}) {
  const rule = resolvePrintingPricingRule(product, storedRules);
  return {
    regular_price: rule.regularPrice,
    bulk_from: rule.bulkFrom,
    bulk_price: rule.bulkPrice
  };
}
