import { Router } from 'express';
import { getDrawerStatus, getDrawerSettings, updateDrawerSettings, openDrawer, closeDrawer, addDrawerMovement } from '../controllers/drawer.controller.js';
import { createCashCollection, listCashCollections, previewCashCollection } from '../controllers/cashCollections.controller.js';

const router = Router();
router.get('/status', getDrawerStatus);
router.get('/settings', getDrawerSettings);
router.put('/settings', updateDrawerSettings);
router.post('/open', openDrawer);
router.post('/close', closeDrawer);
router.post('/movement', addDrawerMovement);
router.get('/collections', listCashCollections);
router.get('/collections/preview', previewCashCollection);
router.post('/collections', createCashCollection);
export default router;
