import { Router } from 'express';
import { createSale, listRecentSales, listRefundableSales, refundSale } from '../controllers/sales.controller.js';

const router = Router();
router.get('/recent', listRecentSales);
router.get('/refundable', listRefundableSales);
router.post('/:saleId/refund', refundSale);
router.post('/', createSale);
export default router;
