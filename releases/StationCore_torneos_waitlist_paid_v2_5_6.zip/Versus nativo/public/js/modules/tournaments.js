(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

function ensureTournamentDeliveryState() {
  const appState = window.state || (typeof state !== 'undefined' ? state : null);
  if (!appState) return null;
  appState.tournamentAwardsDelivery = appState.tournamentAwardsDelivery || { tournamentId: null, awards: [], tournament: null };
  appState.tournamentMemberConversion = appState.tournamentMemberConversion || { isOpen: false, context: null, isBusy: false };
  return appState;
}

async function loadPosTournaments() {
  try {
    const result = await api('/tournaments/pos/active');
    state.posTournaments = result.tournaments || [];
    state.posTournamentParticipants = result.participants || [];
    renderTournamentDayPanel();
    renderMenuCategoryTabs();
    window.ClubVersusStations?.renderVersusBoard?.();
  } catch (error) {
    state.posTournaments = [];
    state.posTournamentParticipants = [];
    renderTournamentDayPanel();
    window.ClubVersusStations?.renderVersusBoard?.();
  }
}


function getTournamentStartDate(tournament = {}) {
  return parseAppDate(tournament?.scheduled_at || tournament?.created_at);
}

function canStartTournamentNow(tournament = {}) {
  const date = getTournamentStartDate(tournament);
  if (!date) return true;
  return Date.now() >= date.getTime();
}

function getTournamentStartLockLabel(tournament = {}) {
  const date = getTournamentStartDate(tournament);
  if (!date) return 'Disponible al iniciar';
  return `Disponible ${formatTournamentDate(date)}`;
}

function isTodayTournament(tournament) {
  const date = parseAppDate(tournament?.scheduled_at || tournament?.created_at);
  if (!date) return false;
  const now = new Date();
  return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate();
}

function isClosedFinishedTournament(tournament) {
  return String(tournament?.status || '').toUpperCase() === 'FINISHED' && Boolean(tournament?.versus_closed_at);
}

function getVisiblePosTournaments() {
  return (state.posTournaments || []).filter((tournament) => !isClosedFinishedTournament(tournament));
}

function getPrimaryPosTournament() {
  const tournaments = getVisiblePosTournaments();
  return tournaments.find((t) => t.status === 'ACTIVE')
    || tournaments.find((t) => t.status === 'FINISHED' && (t.winner_name || t.winner_participant_id))
    || tournaments.find(isTodayTournament)
    || tournaments[0]
    || null;
}

function getTournamentEntryFee(tournamentId) {
  const tournament = (state.posTournaments || []).find((item) => String(item.id) === String(tournamentId));
  return Number(tournament?.entry_fee || 0);
}

function getPendingTournamentParticipants(tournamentId = null) {
  return (state.posTournamentParticipants || []).filter((participant) => {
    if (tournamentId && String(participant.tournament_id) !== String(tournamentId)) return false;
    return !participant.is_paid && ['PENDING', 'EXPIRED', undefined, null, ''].includes(participant.payment_status);
  });
}

function isTournamentAwardPending(award) {
  return ['cash_status', 'membership_status', 'bonus_status', 'goods_status'].some((key) => award?.[key] === 'PENDING');
}

function getTournamentAwardPrizeParts(award) {
  const parts = [];
  if (Number(award?.cash_amount || 0) > 0) parts.push(`Efectivo ${money(award.cash_amount)}`);
  if (award?.membership_tier) parts.push(`Membresía ${getMembershipTierLabel(award.membership_tier)}`);
  if (Number(award?.free_minutes || 0) > 0) parts.push(`${award.free_minutes} min gratis`);
  if (Number(award?.snack_qty || 0) > 0) parts.push(`${award.snack_qty} snack(s)`);
  if (Number(award?.drink_qty || 0) > 0) parts.push(`${award.drink_qty} bebida(s)`);
  return parts;
}

function closeTournamentAwardsDeliveryModal() {
  ensureTournamentDeliveryState();
  const modal = $('#tournamentAwardsDeliveryModal');
  window.ClubVersusCore?.modalManager?.close?.(modal);
  modal?.classList.add('hidden');
  modal?.setAttribute('aria-hidden', 'true');
  state.tournamentAwardsDelivery = { tournamentId: null, awards: [], tournament: null };
  state.tournamentMemberConversion = { isOpen: false, context: null, isBusy: false };
}


function getDefaultTournamentRenewalDate() {
  const date = new Date();
  date.setDate(date.getDate() + 30);
  return date.toISOString().slice(0, 10);
}

function getConversionUsernameSuggestion(info = {}) {
  const base = String(info.nickname || info.fullName || info.player_name || 'Jugador')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9._-]/g, '')
    .slice(0, 18);
  return base || `Jugador${Math.floor(10 + Math.random() * 89)}`;
}

function setTournamentMemberConversionError(message = '') {
  const box = $('#tournamentMemberConversionError');
  if (!box) return;
  box.textContent = message;
  box.classList.toggle('hidden', !message);
}

function closeTournamentMemberConversionModal() {
  ensureTournamentDeliveryState();
  const modal = $('#tournamentMemberConversionModal');
  window.ClubVersusCore?.modalManager?.close?.(modal);
  modal?.classList.add('hidden');
  modal?.setAttribute('aria-hidden', 'true');
  state.tournamentMemberConversion = { isOpen: false, context: null, isBusy: false };
  setTournamentMemberConversionError('');
}

function openTournamentMemberConversionModal(error, context = {}) {
  ensureTournamentDeliveryState();
  const modal = $('#tournamentMemberConversionModal');
  if (!modal) return showToast('No se encontró el modal de crear miembro');
  const participant = error?.participant || context.award || {};
  const award = error?.award || context.award || {};
  state.tournamentMemberConversion = {
    isOpen: true,
    isBusy: false,
    context: {
      tournamentId: context.tournamentId,
      awardId: context.awardId,
      source: context.source || 'admin',
      deliverAll: context.deliverAll !== false,
      award: { ...context.award, ...award },
      participant
    }
  };
  const tierLabel = getMembershipTierLabel(award.membershipTier || award.membership_tier || context.award?.membership_tier);
  setText('#tournamentMemberConversionMeta', `Membresía ganada: ${tierLabel}`);
  const fullName = participant.fullName || participant.player_name || context.award?.player_name || '';
  const phone = participant.phone || context.award?.phone || '';
  const nickname = participant.nickname || context.award?.nickname || fullName;
  const fullNameInput = $('#tournamentConversionFullName');
  const phoneInput = $('#tournamentConversionPhone');
  const usernameInput = $('#tournamentConversionUsername');
  const renewalInput = $('#tournamentConversionRenewalDate');
  const pinInput = $('#tournamentConversionPin');
  const confirmInput = $('#tournamentConversionPinConfirm');
  if (fullNameInput) fullNameInput.value = fullName;
  if (phoneInput) phoneInput.value = phone;
  if (usernameInput) usernameInput.value = getConversionUsernameSuggestion({ nickname, fullName });
  if (renewalInput) renewalInput.value = getDefaultTournamentRenewalDate();
  if (pinInput) pinInput.value = '';
  if (confirmInput) confirmInput.value = '';
  setTournamentMemberConversionError('');
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
  window.ClubVersusCore?.modalManager?.open?.(modal, { base: 9550 });
  setTimeout(() => fullNameInput?.focus?.(), 40);
}

function getTournamentMemberConversionPayload() {
  return {
    fullName: $('#tournamentConversionFullName')?.value?.trim() || '',
    phone: $('#tournamentConversionPhone')?.value?.trim() || '',
    portalUsername: $('#tournamentConversionUsername')?.value?.trim() || '',
    renewalDate: $('#tournamentConversionRenewalDate')?.value || '',
    portalPin: $('#tournamentConversionPin')?.value?.trim() || '',
    portalPinConfirm: $('#tournamentConversionPinConfirm')?.value?.trim() || ''
  };
}

function validateTournamentMemberConversionPayload(payload) {
  if (!payload.fullName) return 'Ingresa el nombre del ganador';
  if (!payload.portalUsername) return 'Ingresa el usuario/nickname';
  if (!/^[a-zA-Z0-9._-]{3,24}$/.test(payload.portalUsername)) return 'El usuario debe tener 3 a 24 caracteres válidos';
  if (!payload.renewalDate) return 'Selecciona la fecha de renovación';
  if (!/^\d{4,6}$/.test(payload.portalPin)) return 'El PIN debe tener de 4 a 6 números';
  if (payload.portalPin !== payload.portalPinConfirm) return 'El PIN y la confirmación no coinciden';
  return '';
}

async function submitTournamentMemberConversion(event) {
  ensureTournamentDeliveryState();
  event?.preventDefault?.();
  const conversionState = state.tournamentMemberConversion || {};
  const context = conversionState.context || {};
  if (!context.tournamentId || !context.awardId || conversionState.isBusy) return;
  const payload = getTournamentMemberConversionPayload();
  const validation = validateTournamentMemberConversionPayload(payload);
  if (validation) return setTournamentMemberConversionError(validation);
  state.tournamentMemberConversion.isBusy = true;
  const saveBtn = $('#saveTournamentMemberConversionBtn');
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.textContent = 'Guardando...';
  }
  try {
    const response = await api(`/tournaments/${context.tournamentId}/awards/${context.awardId}/deliver`, {
      method: 'PATCH',
      body: JSON.stringify({ deliverAll: true, memberConversion: payload })
    });
    closeTournamentMemberConversionModal();
    if (context.source === 'pos') {
      state.tournamentAwardsDelivery.awards = response.awards || state.tournamentAwardsDelivery.awards || [];
      await finishTournamentAwardDelivery('Miembro creado y premio entregado');
      renderTournamentAwardsDeliveryModal();
    } else {
      showToast('Miembro creado y premio entregado');
      await loadDrawer().catch(() => {});
      await loadTournaments();
      await loadTournamentDetail(context.tournamentId);
    }
  } catch (error) {
    setTournamentMemberConversionError(error.message || 'No se pudo crear el miembro');
  } finally {
    state.tournamentMemberConversion.isBusy = false;
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Crear y entregar';
    }
  }
}

function renderTournamentAwardsDeliveryModal() {
  ensureTournamentDeliveryState();
  const modalState = state.tournamentAwardsDelivery || {};
  const tournament = modalState.tournament || {};
  const awards = Array.isArray(modalState.awards) ? modalState.awards : [];
  const pendingAwards = awards.filter(isTournamentAwardPending);
  const isBusy = Boolean(modalState.isBusy);
  const activeAwardId = modalState.activeAwardId ? String(modalState.activeAwardId) : null;
  setText('#tournamentAwardsDeliveryTitle', tournament.name || 'Premios del torneo');
  const metaText = `${tournament.game || ''}${tournament.platform ? ` · ${tournament.platform}` : ''}`.replace(/^ · /, '');
  setText('#tournamentAwardsDeliveryMeta', metaText);
  const metaEl = $('#tournamentAwardsDeliveryMeta');
  if (metaEl) metaEl.classList.toggle('hidden', !metaText);

  if (modalState.statusMessage) {
    setText('#tournamentAwardsDeliveryMeta', modalState.statusMessage);
    $('#tournamentAwardsDeliveryMeta')?.classList.remove('hidden');
    $('#tournamentAwardsDeliveryMeta')?.classList.toggle('error', Boolean(modalState.statusIsError));
  }

  const summary = $('#tournamentAwardsDeliverySummary');
  if (summary) {
    summary.innerHTML = `
      <article><span>Pendientes</span><strong>${pendingAwards.length}</strong></article>
      <article><span>Total premios</span><strong>${awards.length}</strong></article>
      <article><span>Campeón</span><strong>${escapeHtml(tournament.winner_name || '—')}</strong></article>
    `;
  }

  const list = $('#tournamentAwardsDeliveryList');
  if (list) {
    if (!awards.length) {
      list.innerHTML = '<div class="empty-row">No hay premios configurados para entregar.</div>';
    } else {
      list.innerHTML = awards.map((award) => {
        const pending = isTournamentAwardPending(award);
        const prizeParts = getTournamentAwardPrizeParts(award);
        const hasCash = Number(award.cash_amount || 0) > 0 && award.cash_status === 'PENDING';
        return `
          <article class="tournament-awards-delivery-row ${pending ? 'pending' : 'delivered'}">
            <div>
              <strong>${escapeHtml(getPositionLabel(award.position))} · ${escapeHtml(award.player_name || 'Jugador')}</strong>
              <small>${escapeHtml(prizeParts.join(' · ') || 'Sin premio configurado')}</small>
              <small>${escapeHtml(getAwardPendingLabel(award))}</small>
            </div>
            ${pending ? `<button type="button" data-pos-deliver-award="${escapeAttr(award.id)}" onclick="window.deliverTournamentAwardFromPos && window.deliverTournamentAwardFromPos('${escapeAttr(award.id)}')" ${isBusy ? 'disabled' : ''}>${isBusy && activeAwardId === String(award.id) ? 'Entregando...' : 'Entregar'}</button>` : '<span class="payment-pill paid">Entregado</span>'}
          </article>
        `;
      }).join('');
      list.querySelectorAll('[data-pos-deliver-award]').forEach((btn) => {
        btn.onclick = () => deliverTournamentAwardFromPos(btn.dataset.posDeliverAward);
      });
    }
  }

  const deliverAllBtn = $('#deliverAllTournamentAwardsBtn');
  if (deliverAllBtn) {
    deliverAllBtn.disabled = pendingAwards.length === 0 || isBusy;
    deliverAllBtn.onclick = () => deliverAllTournamentAwardsFromPos();
    deliverAllBtn.textContent = isBusy && activeAwardId === 'all' ? 'Entregando...' : (pendingAwards.length > 1 ? `Entregar ${pendingAwards.length} premios pendientes` : 'Entregar todo pendiente');
  }
}

async function refreshTournamentAwardsDelivery(tournamentId) {
  ensureTournamentDeliveryState();
  const detail = await api(`/tournaments/${tournamentId}`);
  const currentState = state.tournamentAwardsDelivery || {};
  state.tournamentAwardsDelivery = {
    ...currentState,
    tournamentId,
    tournament: detail.tournament || null,
    awards: detail.awards || [],
    isBusy: false,
    activeAwardId: null
  };
  renderTournamentAwardsDeliveryModal();
}

async function openTournamentAwardsDelivery(tournamentId) {
  ensureTournamentDeliveryState();
  if (!tournamentId) return showToast('Selecciona un torneo');
  const modal = $('#tournamentAwardsDeliveryModal');
  if (!modal) return showToast('No se encontró el modal de premios');
  try {
    setTournamentAwardsDeliveryStatus('', false);
    await api(`/tournaments/${tournamentId}/awards/auto`, { method: 'POST' }).catch((error) => {
      if (String(error.message || '').includes('No se pudieron determinar')) throw error;
    });
    await refreshTournamentAwardsDelivery(tournamentId);
    window.ClubVersusCore?.modalManager?.open?.(modal, { base: 9400 });
  } catch (error) {
    showToast(error.message || 'No se pudieron preparar los premios');
  }
}
window.openTournamentAwardsDelivery = openTournamentAwardsDelivery;

function setTournamentAwardsDeliveryBusy(isBusy, activeAwardId = null) {
  ensureTournamentDeliveryState();
  state.tournamentAwardsDelivery = state.tournamentAwardsDelivery || {};
  state.tournamentAwardsDelivery.isBusy = Boolean(isBusy);
  state.tournamentAwardsDelivery.activeAwardId = isBusy && activeAwardId ? String(activeAwardId) : null;
  const modal = $('#tournamentAwardsDeliveryModal');
  if (!modal) return;
  modal.querySelectorAll('[data-pos-deliver-award], #deliverAllTournamentAwardsBtn').forEach((button) => {
    button.disabled = Boolean(isBusy);
  });
}

function setTournamentAwardsDeliveryStatus(message = '', isError = false) {
  ensureTournamentDeliveryState();
  state.tournamentAwardsDelivery = state.tournamentAwardsDelivery || {};
  state.tournamentAwardsDelivery.statusMessage = String(message || '').trim();
  state.tournamentAwardsDelivery.statusIsError = Boolean(isError);
  const modal = $('#tournamentAwardsDeliveryModal');
  const meta = $('#tournamentAwardsDeliveryMeta');
  if (!modal || !meta) return;
  if (state.tournamentAwardsDelivery.statusMessage) {
    meta.textContent = state.tournamentAwardsDelivery.statusMessage;
    meta.classList.remove('hidden');
    meta.classList.toggle('error', Boolean(isError));
  } else {
    meta.classList.remove('error');
    const tournament = state.tournamentAwardsDelivery?.tournament || {};
    const metaText = `${tournament.game || ''}${tournament.platform ? ` · ${tournament.platform}` : ''}`.replace(/^ · /, '');
    meta.textContent = metaText;
    meta.classList.toggle('hidden', !metaText);
  }
}

async function finishTournamentAwardDelivery(message) {
  ensureTournamentDeliveryState();
  const tournamentId = state.tournamentAwardsDelivery?.tournamentId;
  if (tournamentId) await refreshTournamentAwardsDelivery(tournamentId).catch(() => {});
  setTournamentAwardsDeliveryStatus('', false);
  if (message) showToast(message);
  await loadDrawer().catch(() => {});
  await loadPosTournaments().catch(() => {});
  await loadStations().catch(() => {});
}

async function deliverTournamentAwardFromPos(awardId) {
  const tournamentId = state.tournamentAwardsDelivery?.tournamentId;
  if (!tournamentId || !awardId || state.tournamentAwardsDelivery?.isBusy) return;
  setTournamentAwardsDeliveryBusy(true, awardId);
  renderTournamentAwardsDeliveryModal();
  try {
    const response = await api(`/tournaments/${tournamentId}/awards/${awardId}/deliver`, {
      method: 'PATCH',
      body: JSON.stringify({ deliverAll: true })
    });
    state.tournamentAwardsDelivery.awards = response.awards || state.tournamentAwardsDelivery.awards || [];
    await finishTournamentAwardDelivery('Premio entregado');
  } catch (error) {
    const award = (state.tournamentAwardsDelivery?.awards || []).find((item) => String(item.id) === String(awardId)) || {};
    if (error.requiresMemberConversion || error.code === 'MEMBER_CONVERSION_REQUIRED') {
      openTournamentMemberConversionModal(error, { tournamentId, awardId, award, source: 'pos' });
    } else {
      const message = error.message || 'No se pudo entregar el premio';
      setTournamentAwardsDeliveryStatus(message, true);
      showToast(message);
    }
  } finally {
    setTournamentAwardsDeliveryBusy(false);
    renderTournamentAwardsDeliveryModal();
  }
}

async function deliverAllTournamentAwardsFromPos() {
  ensureTournamentDeliveryState();
  const tournamentId = state.tournamentAwardsDelivery?.tournamentId;
  const pendingAwards = (state.tournamentAwardsDelivery?.awards || []).filter(isTournamentAwardPending);
  if (!tournamentId || !pendingAwards.length) return showToast('No hay premios pendientes');
  if (state.tournamentAwardsDelivery?.isBusy) return;
  setTournamentAwardsDeliveryBusy(true, 'all');
  renderTournamentAwardsDeliveryModal();
  try {
    for (const award of pendingAwards) {
      const response = await api(`/tournaments/${tournamentId}/awards/${award.id}/deliver`, {
        method: 'PATCH',
        body: JSON.stringify({ deliverAll: true })
      });
      state.tournamentAwardsDelivery.awards = response.awards || state.tournamentAwardsDelivery.awards || [];
    }
    await finishTournamentAwardDelivery(pendingAwards.length > 1 ? 'Premios entregados' : 'Premio entregado');
  } catch (error) {
    if (error.requiresMemberConversion || error.code === 'MEMBER_CONVERSION_REQUIRED') {
      const awardId = error.award?.id || state.tournamentAwardsDelivery?.activeAwardId || pendingAwards.find((award) => award.membership_status === 'PENDING' && !award.member_id)?.id;
      const award = (state.tournamentAwardsDelivery?.awards || []).find((item) => String(item.id) === String(awardId)) || pendingAwards[0] || {};
      openTournamentMemberConversionModal(error, { tournamentId, awardId: award.id || awardId, award, source: 'pos' });
    } else {
      const message = error.message || 'No se pudieron entregar todos los premios';
      setTournamentAwardsDeliveryStatus(message, true);
      showToast(message);
      await refreshTournamentAwardsDelivery(tournamentId).catch(() => {});
    }
  } finally {
    setTournamentAwardsDeliveryBusy(false);
    renderTournamentAwardsDeliveryModal();
  }
}


window.deliverTournamentAwardFromPos = deliverTournamentAwardFromPos;
window.deliverAllTournamentAwardsFromPos = deliverAllTournamentAwardsFromPos;

function bindTournamentAwardsDeliveryDelegatedClicks() {
  if (window.__clubVersusAwardsDeliveryDelegatedClicksBound) return;
  window.__clubVersusAwardsDeliveryDelegatedClicksBound = true;
  document.addEventListener('click', (event) => {
    const deliverButton = event.target?.closest?.('[data-pos-deliver-award]');
    if (deliverButton) {
      event.preventDefault();
      event.stopPropagation();
      if (!deliverButton.disabled) deliverTournamentAwardFromPos(deliverButton.dataset.posDeliverAward);
      return;
    }

    const deliverAllButton = event.target?.closest?.('#deliverAllTournamentAwardsBtn');
    if (deliverAllButton) {
      event.preventDefault();
      event.stopPropagation();
      if (!deliverAllButton.disabled) deliverAllTournamentAwardsFromPos();
      return;
    }

    const closeConversion = event.target?.closest?.('#closeTournamentMemberConversionBtn, #cancelTournamentMemberConversionBtn, #tournamentMemberConversionBackdrop');
    if (closeConversion) {
      event.preventDefault();
      event.stopPropagation();
      closeTournamentMemberConversionModal();
    }
  }, true);

  document.addEventListener('submit', (event) => {
    if (event.target?.id === 'tournamentMemberConversionForm') submitTournamentMemberConversion(event);
  }, true);
}

function isTournamentFullForSale(tournament) {
  const maxPlayers = Number(tournament?.max_players || tournament?.maxPlayers || 0);
  if (!Number.isFinite(maxPlayers) || maxPlayers <= 0) return false;
  const participants = Number(tournament?.participant_count || tournament?.participants_count || 0);
  return Number.isFinite(participants) && participants >= maxPlayers;
}

function getTournamentCapacityLabel(tournament) {
  const maxPlayers = Number(tournament?.max_players || tournament?.maxPlayers || 0);
  if (!Number.isFinite(maxPlayers) || maxPlayers <= 0) return '';
  const participants = Number(tournament?.participant_count || 0);
  return `${Math.max(0, participants)}/${maxPlayers}`;
}

function renderTournamentDayPanel() {
  const panel = $('#tournamentDayPanel');
  if (!panel) return;
  const tournament = getPrimaryPosTournament();
  if (!tournament) {
    panel.classList.add('hidden');
    panel.innerHTML = '';
    return;
  }
  const pending = getPendingTournamentParticipants(tournament.id).length;
  const paid = Number(tournament.paid_count || 0);
  const total = Number(tournament.participant_count || 0);
  const todayLabel = tournament.status === 'FINISHED' ? 'TORNEO FINALIZADO' : (isTodayTournament(tournament) ? 'TORNEO HOY' : 'PRÓXIMO TORNEO');
  const isActive = tournament.status === 'ACTIVE';
  const isFinishedVisible = tournament.status === 'FINISHED' && !tournament.versus_closed_at;
  const pendingAwards = Number(tournament.pending_award_count || 0);
  const awardsButtonLabel = pendingAwards > 0 ? `Entregar premios (${pendingAwards})` : 'Entregar premios';
  const canViewTournamentAdmin = hasPermission('tournaments');
  const canStartVersusNow = canStartTournamentNow(tournament);
  const startLockLabel = getTournamentStartLockLabel(tournament);
  panel.classList.toggle('finished', tournament.status === 'FINISHED');
  panel.classList.remove('hidden');
  panel.innerHTML = `
    <div class="tournament-day-info">
      <span>${isActive ? 'MODO VERSUS ACTIVO' : todayLabel}</span>
      <strong>${escapeHtml(tournament.name || 'Torneo')}</strong>
      <small>${escapeHtml(tournament.game || '')} · ${escapeHtml(tournament.platform || 'Multiplataforma')} · ${formatTournamentDate(tournament.scheduled_at || tournament.created_at)}</small>
    </div>
    <div class="tournament-day-stats">
      <article><span>Inscritos</span><b>${total}</b></article>
      <article><span>Pagados</span><b>${paid}</b></article>
      <article><span>Pendientes</span><b>${pending}</b></article>
    </div>
    <div class="tournament-day-actions">
      ${tournament.status === 'FINISHED' ? `<button type="button" data-pos-awards-deliver="${tournament.id}">${awardsButtonLabel}</button><button type="button" class="secondary" data-pos-versus-close="${tournament.id}">Cerrar evento</button>` : isActive ? `<button type="button" class="secondary" data-pos-versus-close="${tournament.id}">Apagar Versus</button>` : isFinishedVisible ? `<button type="button" class="secondary" data-pos-versus-close="${tournament.id}">Cerrar evento</button>` : `<button type="button" data-pos-versus-start="${tournament.id}" ${canStartVersusNow ? '' : 'disabled'}>${canStartVersusNow ? 'Iniciar Modo Versus' : 'Modo Versus bloqueado'}</button>`}
      ${canViewTournamentAdmin ? `<button type="button" class="secondary" data-open-tournaments-module="${tournament.id}">Ver torneo</button>` : ''}
    </div>
  `;
  panel.querySelector('[data-pos-versus-start]')?.addEventListener('click', (event) => {
    if (event.currentTarget.disabled) return showToast(startLockLabel);
    window.ClubVersusVersusMode?.startPosVersus?.(event.currentTarget.dataset.posVersusStart);
  });
  panel.querySelector('[data-pos-versus-close]')?.addEventListener('click', (event) => window.ClubVersusVersusMode?.closePosVersus?.(event.currentTarget.dataset.posVersusClose));
  panel.querySelector('[data-pos-awards-deliver]')?.addEventListener('click', (event) => openTournamentAwardsDelivery(event.currentTarget.dataset.posAwardsDeliver));
  panel.querySelector('[data-open-tournaments-module]')?.addEventListener('click', async (event) => {
    await openTournamentsModule();
    await selectTournament(event.currentTarget.dataset.openTournamentsModule);
  });
}

function renderTournamentPosProducts(list) {
  list.className = 'modal-products-list tournament-pos-list';
  const tournaments = typeof getVisiblePosTournaments === 'function' ? getVisiblePosTournaments() : (state.posTournaments || []);
  if (!tournaments.length) {
    list.innerHTML = '<div class="empty-row">No hay torneos disponibles para inscripción</div>';
    return;
  }
  list.innerHTML = tournaments.map((tournament) => {
    const pending = getPendingTournamentParticipants(tournament.id);
    const isFull = isTournamentFullForSale(tournament);
    const capacityLabel = getTournamentCapacityLabel(tournament);
    const pendingRows = pending.slice(0, 6).map((participant) => `
      <button type="button" class="tournament-entry-row" data-add-tournament-participant="${participant.id}" data-tournament-id="${tournament.id}">
        <span><strong>${escapeHtml(participant.player_name || 'Participante')}</strong><small>Pendiente · ${escapeHtml(participant.phone || participant.nickname || '')}</small></span>
        <b>${money(participant.entry_fee_amount ?? tournament.entry_fee ?? 0)}</b>
      </button>
    `).join('');
    return `
      <article class="tournament-pos-card">
        <div class="tournament-pos-head">
          <span>
            <small class="tournament-pos-kicker">Torneo</small>
            <strong>${escapeHtml(tournament.name || 'Torneo')}</strong>
            <small>${escapeHtml(tournament.game || '')} · ${formatTournamentDate(tournament.scheduled_at || tournament.created_at)}</small>
            ${capacityLabel ? `<small>Cupo ${capacityLabel}</small>` : ''}
          </span>
          <b>${money(tournament.entry_fee ?? 0)}</b>
        </div>
        <div class="tournament-pos-actions ${isFull ? 'is-full' : ''}">
          <button type="button" data-new-tournament-entry="${tournament.id}" ${isFull ? 'disabled' : ''}>${isFull ? 'Máximo alcanzado' : 'Nueva inscripción'}</button>
          ${isFull ? '<small>Cupo lleno</small>' : (pending.length ? `<small>${pending.length} pendiente(s)</small>` : '<small>Sin pendientes</small>')}
        </div>
        <div class="tournament-pending-list">${pendingRows || ''}</div>
      </article>
    `;
  }).join('');

  list.querySelectorAll('[data-new-tournament-entry]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.disabled) return showToast('El torneo llegó al máximo de jugadores');
      window.ClubVersusTournamentEntryModal?.promptNewTournamentEntry?.(btn.dataset.newTournamentEntry);
    });
  });
  list.querySelectorAll('[data-add-tournament-participant]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const participant = (state.posTournamentParticipants || []).find((item) => String(item.id) === String(btn.dataset.addTournamentParticipant));
      const tournament = (state.posTournaments || []).find((item) => String(item.id) === String(btn.dataset.tournamentId));
      if (!participant || !tournament) return;
      window.ClubVersusTournamentEntryModal?.addTournamentEntryToOrder?.({
        tournamentId: tournament.id,
        tournamentName: tournament.name,
        participantId: participant.id,
        playerName: participant.player_name,
        phone: participant.phone,
        nickname: participant.nickname,
        memberId: participant.member_id,
        entryFee: Number(participant.entry_fee_amount ?? tournament.entry_fee ?? participant.entry_fee ?? 0)
      });
    });
  });
}


// Administración completa de torneos movida desde app.js en v2.0.6.5.
async function loadTournaments() {
  const { tournaments } = await api('/tournaments');
  state.tournaments = tournaments || [];
  renderTournamentsModule();
  loadTournamentRanking().catch(() => {});
}

async function loadTournamentRanking() {
  try {
    const result = await api('/tournaments/ranking/monthly');
    state.tournamentRanking = result.ranking || [];
    state.tournamentRankingLabel = result.label || 'Este mes';
    renderTournamentRanking();
  } catch (error) {
    state.tournamentRanking = [];
    renderTournamentRanking();
  }
}

function renderTournamentRanking() {
  const list = $('#tournamentRankingList');
  const label = $('#tournamentRankingLabel');
  if (!list) return;
  if (label) label.textContent = state.tournamentRankingLabel || 'Este mes';

  if (!state.tournamentRanking.length) {
    list.innerHTML = '<div class="empty-row compact-empty">Sin puntos este mes</div>';
    return;
  }

  list.innerHTML = state.tournamentRanking.slice(0, 10).map((player) => {
    const tier = player.membership_active ? getMembershipTierLabel(player.membership_tier) : 'General';
    const source = player.membership_source === 'TOURNAMENT' ? ' · Torneo' : '';
    return `
      <article class="ranking-row rank-${Number(player.rank || 0)}">
        <strong>#${Number(player.rank || 0)} ${player.full_name}</strong>
        <span>${Number(player.tournament_points || 0)} pts</span>
        <small>${tier}${source} · ${Number(player.tournaments_played || 0)} torneo(s) · ${Number(player.matches_won || 0)} victoria(s)</small>
      </article>
    `;
  }).join('');
}

async function loadTournamentDetail(tournamentId) {
  if (!tournamentId) return;
  const result = await api(`/tournaments/${tournamentId}`);
  state.selectedTournament = result.tournament || null;
  state.tournamentParticipants = result.participants || [];
  state.tournamentMatches = result.matches || [];
  state.tournamentPrizeConfigs = result.prizeConfigs || [];
  state.tournamentAwards = result.awards || [];
  state.tournamentFinalStandings = result.finalStandings || [];
  state.tournamentManualPairings = result.manualPairings || [];
  state.selectedTournamentId = state.selectedTournament?.id || tournamentId;
  fillTournamentForm(state.selectedTournament);
  renderTournamentsModule();
  loadTournamentRanking().catch(() => {});
}

async function openTournamentsModule() {
  if (!requirePermission('tournaments')) return;
  closeModuleHub();
  resetTournamentForm();
  $('#tournamentsModuleModal')?.classList.remove('hidden');
  $('#tournamentsModuleModal')?.setAttribute('aria-hidden', 'false');
  try {
    await loadStations().catch(() => {});
    await loadTournaments();
  } catch (error) {
    showToast(error.message || 'No se pudieron cargar los torneos');
  }
}

function closeTournamentsModule() {
  closeConfigModule('#tournamentsModuleModal');
}

function resetTournamentForm() {
  state.selectedTournamentId = null;
  state.selectedTournament = null;
  state.tournamentParticipants = [];
  state.tournamentMatches = [];
  state.tournamentPrizeConfigs = [];
  state.tournamentAwards = [];
  state.tournamentFinalStandings = [];
  state.tournamentManualPairings = [];
  setText('#tournamentFormTitle', 'Nuevo torneo');
  setText('#tournamentStatusBadge', 'Programado');
  setText('#tournamentParticipantsCount', '0');
  setText('#tournamentPaidCount', '0');
  setText('#tournamentCollectedTotal', money(0));
  setText('#tournamentWinnerLabel', 'Sin ganador');
  if ($('#tournamentNameInput')) $('#tournamentNameInput').value = '';
  if ($('#tournamentGameInput')) $('#tournamentGameInput').value = '';
  if ($('#tournamentPlatformSelect')) $('#tournamentPlatformSelect').value = 'PlayStation';
  if ($('#tournamentDateInput')) $('#tournamentDateInput').value = '';
  if ($('#tournamentEntryFeeInput')) $('#tournamentEntryFeeInput').value = '100';
  if ($('#tournamentMaxPlayersInput')) $('#tournamentMaxPlayersInput').value = '16';
  if ($('#tournamentPrizeInput')) $('#tournamentPrizeInput').value = '';
  if ($('#tournamentWinnersCountInput')) $('#tournamentWinnersCountInput').value = '1';
  if ($('#tournamentThirdPlaceModeSelect')) $('#tournamentThirdPlaceModeSelect').value = 'AUTO';
  renderTournamentPrizeConfigInputs();
  clearTournamentParticipantMember(false);
  if ($('#participantNameInput')) $('#participantNameInput').value = '';
  if ($('#participantPhoneInput')) $('#participantPhoneInput').value = '';
  if ($('#participantNicknameInput')) $('#participantNicknameInput').value = '';
  renderTournamentsModule();
}

function fillTournamentForm(tournament) {
  if (!tournament) return resetTournamentForm();
  setText('#tournamentFormTitle', tournament.name || 'Torneo');
  setText('#tournamentStatusBadge', getTournamentStatusLabel(tournament.status));
  if ($('#tournamentNameInput')) $('#tournamentNameInput').value = tournament.name || '';
  if ($('#tournamentGameInput')) $('#tournamentGameInput').value = tournament.game || '';
  if ($('#tournamentPlatformSelect')) $('#tournamentPlatformSelect').value = tournament.platform || 'PlayStation';
  if ($('#tournamentDateInput')) $('#tournamentDateInput').value = formatDateTimeLocal(tournament.scheduled_at);
  if ($('#tournamentEntryFeeInput')) $('#tournamentEntryFeeInput').value = Number(tournament.entry_fee || 0);
  if ($('#tournamentMaxPlayersInput')) $('#tournamentMaxPlayersInput').value = tournament.max_players || '';
  if ($('#tournamentPrizeInput')) $('#tournamentPrizeInput').value = tournament.prize_text || '';
  if ($('#tournamentWinnersCountInput')) $('#tournamentWinnersCountInput').value = tournament.winners_count || 1;
  if ($('#tournamentThirdPlaceModeSelect')) $('#tournamentThirdPlaceModeSelect').value = tournament.third_place_mode || 'AUTO';
  renderTournamentPrizeConfigInputs();
  setText('#tournamentParticipantsCount', tournament.participant_count || state.tournamentParticipants.length || 0);
  setText('#tournamentPaidCount', tournament.paid_count || state.tournamentParticipants.filter((p) => p.is_paid).length || 0);
  setText('#tournamentCollectedTotal', money(tournament.total_collected));
  setText('#tournamentWinnerLabel', tournament.winner_name ? `Ganador: ${tournament.winner_name}` : 'Sin ganador');
}

function getTournamentPayload() {
  return {
    name: $('#tournamentNameInput')?.value.trim(),
    game: $('#tournamentGameInput')?.value.trim(),
    platform: $('#tournamentPlatformSelect')?.value || 'PlayStation',
    scheduledAt: $('#tournamentDateInput')?.value || null,
    entryFee: Number($('#tournamentEntryFeeInput')?.value || 0),
    maxPlayers: $('#tournamentMaxPlayersInput')?.value ? Number($('#tournamentMaxPlayersInput').value) : null,
    prizeText: $('#tournamentPrizeInput')?.value.trim(),
    winnersCount: Number($('#tournamentWinnersCountInput')?.value || 1),
    thirdPlaceMode: $('#tournamentThirdPlaceModeSelect')?.value || 'AUTO',
    prizeConfigs: getTournamentPrizeConfigPayload()
  };
}


function getPositionLabel(position) {
  const labels = { 1: '1er lugar', 2: '2do lugar', 3: '3er lugar', 4: '4to lugar', 5: '5to lugar', 6: '6to lugar', 7: '7mo lugar', 8: '8vo lugar' };
  return labels[Number(position)] || `${position} lugar`;
}

function getMembershipTierLabel(tier) {
  const normalized = String(tier || '').toUpperCase();
  if (!normalized) return 'Sin membresía';
  return getMembershipLabel(normalized);
}

function renderMembershipPlanPrizeOptions(selectedTier = '') {
  const selected = String(selectedTier || '').toUpperCase();
  const plans = getMembershipTierOptions();
  const currentMissing = selected && !plans.some((plan) => plan.id === selected);
  return `
    <option value="">Ninguna</option>
    ${currentMissing ? `<option value="${selected}" selected>${getMembershipTierLabel(selected)} · Oculta</option>` : ''}
    ${plans.map((plan) => `<option value="${plan.id}" ${selected === plan.id ? 'selected' : ''}>${plan.label}</option>`).join('')}
  `;
}

function getPrizeConfigByPosition(position) {
  return (state.tournamentPrizeConfigs || []).find((prize) => Number(prize.position) === Number(position)) || {};
}

function renderTournamentPrizeConfigInputs() {
  const container = $('#tournamentPrizeConfigList');
  if (!container) return;
  const countInput = $('#tournamentWinnersCountInput');
  const count = Math.max(1, Math.min(8, Number(countInput?.value || state.selectedTournament?.winners_count || 1) || 1));
  if (countInput && String(countInput.value || '') !== String(count)) countInput.value = String(count);

  const rows = [];
  for (let position = 1; position <= count; position += 1) {
    const prize = getPrizeConfigByPosition(position);
    rows.push(`
      <article class="tournament-prize-row" data-prize-position="${position}">
        <strong>${getPositionLabel(position)}</strong>
        <label><span>Efectivo RD$</span><input data-prize-cash="${position}" type="number" min="0" step="1" value="${Number(prize.cash_amount || 0)}" /></label>
        <label><span>Membresía</span><select data-prize-membership="${position}">
          ${renderMembershipPlanPrizeOptions(prize.membership_tier)}
        </select></label>
        <label><span>Min gratis</span><input data-prize-minutes="${position}" type="number" min="0" step="1" value="${Number(prize.free_minutes || 0)}" placeholder="15, 30, 60" /></label>
        <label><span>Snacks</span><input data-prize-snacks="${position}" type="number" min="0" step="1" value="${Number(prize.snack_qty || 0)}" /></label>
        <label><span>Bebidas</span><input data-prize-drinks="${position}" type="number" min="0" step="1" value="${Number(prize.drink_qty || 0)}" /></label>
        <label><span>Días para canjear</span><input data-prize-days="${position}" type="number" min="0" step="1" value="${Number(prize.redemption_days ?? 30)}" /></label>
      </article>
    `);
  }
  container.innerHTML = rows.join('');
}

function getTournamentPrizeConfigPayload() {
  const count = Math.max(1, Math.min(8, Number($('#tournamentWinnersCountInput')?.value || 1) || 1));
  const prizes = [];
  for (let position = 1; position <= count; position += 1) {
    prizes.push({
      position,
      cashAmount: Number(document.querySelector(`[data-prize-cash="${position}"]`)?.value || 0),
      membershipTier: document.querySelector(`[data-prize-membership="${position}"]`)?.value || null,
      freeMinutes: Math.max(0, Math.round(Number(document.querySelector(`[data-prize-minutes="${position}"]`)?.value || 0))),
      snackQty: Number(document.querySelector(`[data-prize-snacks="${position}"]`)?.value || 0),
      drinkQty: Number(document.querySelector(`[data-prize-drinks="${position}"]`)?.value || 0),
      redemptionDays: Number(document.querySelector(`[data-prize-days="${position}"]`)?.value || 30)
    });
  }
  return prizes;
}

function getParticipantOptions(selectedParticipantId = '') {
  const selected = String(selectedParticipantId || '');
  return ['<option value="">Seleccionar jugador</option>'].concat((state.tournamentParticipants || []).map((participant) => {
    const label = `${participant.player_name}${participant.nickname ? ` (${participant.nickname})` : ''}`;
    return `<option value="${participant.id}" ${String(participant.id) === selected ? 'selected' : ''}>${label}</option>`;
  })).join('');
}

function getAwardByPosition(position) {
  return (state.tournamentAwards || []).find((award) => Number(award.position) === Number(position)) || null;
}

function buildTournamentAwardsPayload() {
  const count = Math.max(1, Math.min(8, Number(state.selectedTournament?.winners_count || $('#tournamentWinnersCountInput')?.value || 1) || 1));
  const awards = [];
  for (let position = 1; position <= count; position += 1) {
    const participantId = document.querySelector(`[data-award-position-select="${position}"]`)?.value || '';
    if (participantId) awards.push({ position, participantId });
  }
  return awards;
}

async function assignTournamentAwards() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  const awards = buildTournamentAwardsPayload();
  const count = Math.max(1, Math.min(8, Number(state.selectedTournament?.winners_count || 1) || 1));
  if (awards.length < count) return showToast('Selecciona todos los ganadores premiados');
  try {
    await api(`/tournaments/${state.selectedTournamentId}/awards/assign`, {
      method: 'POST',
      body: JSON.stringify({ awards })
    });
    showToast('Ganadores guardados');
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudieron guardar los ganadores');
  }
}

async function deliverTournamentAward(awardId) {
  if (!state.selectedTournamentId || !awardId) return;
  if (!window.confirm('¿Entregar este premio ahora? Si incluye efectivo, se hará el Drawer Out.')) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/awards/${awardId}/deliver`, {
      method: 'PATCH',
      body: JSON.stringify({ deliverAll: true })
    });
    showToast('Premio entregado');
    await loadDrawer().catch(() => {});
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    const award = (state.tournamentAwards || []).find((item) => String(item.id) === String(awardId)) || {};
    if (error.requiresMemberConversion || error.code === 'MEMBER_CONVERSION_REQUIRED') {
      openTournamentMemberConversionModal(error, { tournamentId: state.selectedTournamentId, awardId, award, source: 'admin' });
    } else {
      showToast(error.message || 'No se pudo entregar el premio');
    }
  }
}

function getAwardPendingLabel(award) {
  const pending = [];
  if (award.cash_status === 'PENDING') pending.push('efectivo');
  if (award.membership_status === 'PENDING') pending.push('membresía');
  if (award.bonus_status === 'PENDING') pending.push('bonos');
  if (award.goods_status === 'PENDING') pending.push('snacks/bebidas');
  return pending.length ? `Pendiente: ${pending.join(', ')}` : 'Entregado';
}

function renderTournamentFinalStandingsHtml() {
  const standings = Array.isArray(state.tournamentFinalStandings) ? state.tournamentFinalStandings : [];
  if (!standings.length) return '';
  return `
    <section class="tournament-final-standings">
      <h4>Posiciones finales oficiales</h4>
      ${standings.map((standing) => `
        <article class="tournament-standing-row position-${Number(standing.position || 0)}">
          <strong>${escapeHtml(getPositionLabel(standing.position))}</strong>
          <span>${escapeHtml(standing.player_name || standing.member_name || 'Jugador')}</span>
        </article>
      `).join('')}
    </section>
  `;
}

function renderTournamentAwardsPanel() {
  const setup = $('#tournamentAwardsSetup');
  const list = $('#tournamentAwardsList');
  const assignBtn = $('#assignTournamentAwardsBtn');
  if (!setup || !list) return;

  const tournament = state.selectedTournament;
  const isFinished = tournament?.status === 'FINISHED';
  if (assignBtn) assignBtn.disabled = !state.selectedTournamentId || !isFinished;

  if (!state.selectedTournamentId) {
    setup.innerHTML = '<div class="empty-row">Selecciona un torneo para asignar premios</div>';
    list.innerHTML = '';
    return;
  }

  if (!isFinished) {
    setup.innerHTML = '<div class="empty-row">Finaliza el bracket para seleccionar las posiciones premiadas.</div>';
    list.innerHTML = '';
    return;
  }

  const count = Math.max(1, Math.min(8, Number(tournament?.winners_count || 1) || 1));
  setup.innerHTML = Array.from({ length: count }, (_, index) => {
    const position = index + 1;
    const award = getAwardByPosition(position);
    const selected = award?.participant_id || (position === 1 ? tournament?.winner_participant_id : '');
    return `
      <label class="award-position-row">
        <span>${getPositionLabel(position)}</span>
        <select data-award-position-select="${position}">
          ${getParticipantOptions(selected)}
        </select>
      </label>
    `;
  }).join('');

  const standingsHtml = renderTournamentFinalStandingsHtml();
  if (!state.tournamentAwards.length) {
    list.innerHTML = `${standingsHtml}<div class="empty-row">Guarda los ganadores para crear los premios pendientes.</div>`;
    return;
  }

  list.innerHTML = standingsHtml + state.tournamentAwards.map((award) => {
    const prizeParts = [];
    if (Number(award.cash_amount || 0) > 0) prizeParts.push(`Efectivo ${money(award.cash_amount)}`);
    if (award.membership_tier) prizeParts.push(`Membresía ${getMembershipTierLabel(award.membership_tier)}`);
    if (Number(award.free_minutes || 0) > 0) prizeParts.push(`${award.free_minutes} min gratis`);
    if (Number(award.snack_qty || 0) > 0) prizeParts.push(`${award.snack_qty} snack(s)`);
    if (Number(award.drink_qty || 0) > 0) prizeParts.push(`${award.drink_qty} bebida(s)`);
    const pending = ['cash_status', 'membership_status', 'bonus_status', 'goods_status'].some((key) => award[key] === 'PENDING');
    return `
      <article class="tournament-award-row ${pending ? 'pending' : 'delivered'}">
        <div>
          <strong>${getPositionLabel(award.position)} · ${award.player_name}</strong>
          <small>${prizeParts.join(' · ') || 'Sin premio configurado'}</small>
          <small>${getAwardPendingLabel(award)}${award.expires_at ? ` · vence ${formatTournamentDate(award.expires_at)}` : ''}</small>
        </div>
        ${pending ? `<button type="button" data-deliver-award="${award.id}">Entregar</button>` : '<span class="payment-pill paid">Entregado</span>'}
      </article>
    `;
  }).join('');

  list.querySelectorAll('[data-deliver-award]').forEach((btn) => {
    btn.addEventListener('click', () => deliverTournamentAward(btn.dataset.deliverAward));
  });
}

async function saveTournament() {
  if (!requirePermission('tournaments')) return;
  const payload = getTournamentPayload();
  try {
    let result;
    if (state.selectedTournamentId) {
      result = await api(`/tournaments/${state.selectedTournamentId}`, { method: 'PUT', body: JSON.stringify(payload) });
      showToast('Torneo actualizado');
    } else {
      result = await api('/tournaments', { method: 'POST', body: JSON.stringify(payload) });
      showToast('Torneo creado');
    }
    await loadTournaments();
    await loadTournamentDetail(result.tournament.id);
  } catch (error) {
    showToast(error.message || 'No se pudo guardar el torneo');
  }
}

async function selectTournament(tournamentId) {
  try {
    await loadTournamentDetail(tournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo abrir el torneo');
  }
}

async function setTournamentStatus(status, winnerParticipantId = null) {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  try {
    await api(`/tournaments/${state.selectedTournamentId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, winnerParticipantId })
    });
    showToast(status === 'ACTIVE' ? 'Torneo iniciado' : status === 'CANCELLED' ? 'Torneo cancelado' : 'Torneo finalizado');
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo actualizar el torneo');
  }
}

async function cancelTournament() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  if (!window.confirm('¿Cancelar este torneo?')) return;
  await setTournamentStatus('CANCELLED');
}

async function deleteTournament() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  const name = state.selectedTournament?.name || 'este torneo';
  if (!window.confirm(`¿Eliminar ${name}? Esto es para limpiar pruebas y no se podrá deshacer.`)) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}`, { method: 'DELETE' });
    showToast('Torneo eliminado');
    state.selectedTournamentId = null;
    state.selectedTournament = null;
    state.tournamentParticipants = [];
    state.tournamentMatches = [];
    state.tournamentPrizeConfigs = [];
    state.tournamentAwards = [];
    state.tournamentManualPairings = [];
    resetTournamentForm();
    await loadTournaments();
    renderTournamentsModule();
  } catch (error) {
    showToast(error.message || 'No se pudo eliminar el torneo');
  }
}

function renderTournamentMemberPicker() {
  const selectedBox = $('#participantSelectedMember');
  const resultsBox = $('#participantMemberResults');
  const selected = state.selectedTournamentMember;

  if (selectedBox) {
    if (selected) {
      selectedBox.classList.remove('hidden');
      selectedBox.innerHTML = `
        <span>Miembro seleccionado</span>
        <strong>${selected.full_name || selected.name || 'Miembro'}</strong>
        <small>${getMembershipTierLabel(selected.membership_tier)} · ${Number(selected.reward_points || 0)} pts</small>
      `;
    } else {
      selectedBox.classList.add('hidden');
      selectedBox.innerHTML = '';
    }
  }

  if (!resultsBox) return;
  if (!state.tournamentMemberResults.length) {
    resultsBox.classList.add('hidden');
    resultsBox.innerHTML = '';
    return;
  }

  resultsBox.classList.remove('hidden');
  resultsBox.innerHTML = state.tournamentMemberResults.map((member) => `
    <button type="button" data-tournament-member-pick="${member.id}">
      <span>
        <strong>${member.full_name}</strong>
        <small>${getMembershipTierLabel(member.membership_tier)} · ${Number(member.reward_points || 0)} pts${member.phone ? ` · ${member.phone}` : ''}</small>
      </span>
    </button>
  `).join('');

  resultsBox.querySelectorAll('[data-tournament-member-pick]').forEach((btn) => {
    btn.addEventListener('click', () => selectTournamentParticipantMember(btn.dataset.tournamentMemberPick));
  });
}

async function searchTournamentParticipantMember() {
  const input = $('#participantMemberSearchInput');
  const term = input?.value.trim() || '';
  if (!term) return showToast('Escribe nombre, teléfono o QR del miembro');
  try {
    const result = await api(`/members/search?q=${encodeURIComponent(term)}`);
    state.tournamentMemberResults = result.members || [];
    renderTournamentMemberPicker();
    if (!state.tournamentMemberResults.length) showToast('No encontré ese miembro');
  } catch (error) {
    showToast(error.message || 'No se pudo buscar miembro');
  }
}

function selectTournamentParticipantMember(memberId) {
  const member = (state.tournamentMemberResults || []).find((item) => String(item.id) === String(memberId)) || (state.members || []).find((item) => String(item.id) === String(memberId));
  if (!member) return;
  state.selectedTournamentMember = member;
  state.tournamentMemberResults = [];
  if ($('#participantNameInput')) $('#participantNameInput').value = member.full_name || '';
  if ($('#participantPhoneInput')) $('#participantPhoneInput').value = member.phone || '';
  renderTournamentMemberPicker();
}

function clearTournamentParticipantMember(showMessage = true) {
  state.selectedTournamentMember = null;
  state.tournamentMemberResults = [];
  if ($('#participantMemberSearchInput')) $('#participantMemberSearchInput').value = '';
  renderTournamentMemberPicker();
  if (showMessage) showToast('Participante manual');
}

async function addTournamentParticipant() {
  if (!state.selectedTournamentId) return showToast('Guarda o selecciona un torneo primero');
  const payload = {
    playerName: $('#participantNameInput')?.value.trim(),
    phone: $('#participantPhoneInput')?.value.trim(),
    nickname: $('#participantNicknameInput')?.value.trim(),
    memberId: state.selectedTournamentMember?.id || null
  };
  try {
    await api(`/tournaments/${state.selectedTournamentId}/participants`, { method: 'POST', body: JSON.stringify(payload) });
    showToast('Participante agregado');
    clearTournamentParticipantMember(false);
    if ($('#participantNameInput')) $('#participantNameInput').value = '';
    if ($('#participantPhoneInput')) $('#participantPhoneInput').value = '';
    if ($('#participantNicknameInput')) $('#participantNicknameInput').value = '';
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo agregar participante');
  }
}

async function markParticipantPaid(participantId) {
  if (!state.selectedTournamentId) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/participants/${participantId}`, {
      method: 'PATCH',
      body: JSON.stringify({ isPaid: true })
    });
    showToast('Inscripción cobrada');
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
    await loadDrawer().catch(() => {});
  } catch (error) {
    showToast(error.message || 'No se pudo cobrar inscripción');
  }
}

async function deleteTournamentParticipant(participantId) {
  if (!state.selectedTournamentId) return;
  if (!window.confirm('¿Quitar este participante?')) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/participants/${participantId}`, { method: 'DELETE' });
    showToast('Participante quitado');
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo quitar participante');
  }
}



function getPaidTournamentParticipantOptions(selectedParticipantId = '', excludeParticipantId = '') {
  const selected = String(selectedParticipantId || '');
  const excluded = String(excludeParticipantId || '');
  const usedManualIds = new Set();
  (state.tournamentManualPairings || []).forEach((pairing) => {
    if (pairing.player1_participant_id) usedManualIds.add(String(pairing.player1_participant_id));
    if (pairing.player2_participant_id) usedManualIds.add(String(pairing.player2_participant_id));
  });

  const options = ['<option value="">Seleccionar jugador pagado</option>'];
  (state.tournamentParticipants || [])
    .filter((participant) => participant.is_paid)
    .forEach((participant) => {
      const id = String(participant.id);
      const alreadyUsed = usedManualIds.has(id) && id !== selected;
      if (id === excluded || alreadyUsed) return;
      const label = `${participant.player_name}${participant.member_name ? ' · miembro' : ''}`;
      options.push(`<option value="${participant.id}" ${id === selected ? 'selected' : ''}>${label}</option>`);
    });
  return options.join('');
}

function renderManualPairingsPanel() {
  const panel = $('#manualPairingsPanel');
  if (!panel) return;
  const hasBracket = (state.tournamentMatches || []).length > 0;
  const tournament = state.selectedTournament;
  const closed = tournament && ['FINISHED', 'CANCELLED'].includes(tournament.status);
  const canEdit = Boolean(state.selectedTournamentId) && !closed && !hasBracket;
  const pairings = state.tournamentManualPairings || [];

  if (!state.selectedTournamentId) {
    panel.innerHTML = '<div class="empty-row">Selecciona un torneo para preparar cruces manuales</div>';
    return;
  }

  const helper = hasBracket
    ? 'Bracket ya generado. Los cruces manuales quedan bloqueados.'
    : 'Opcional: arma algunas partidas de primera ronda y el sistema completa el resto automático.';

  panel.innerHTML = `
    <div class="manual-pairings-head">
      <div>
        <strong>Cruces manuales de primera ronda</strong>
        <small>${helper}</small>
      </div>
    </div>
    <div class="manual-pairing-form ${canEdit ? '' : 'disabled'}">
      <select id="manualPairPlayer1Select" ${canEdit ? '' : 'disabled'}>${getPaidTournamentParticipantOptions()}</select>
      <span>VS</span>
      <select id="manualPairPlayer2Select" ${canEdit ? '' : 'disabled'}>${getPaidTournamentParticipantOptions()}</select>
      <button id="addManualPairingBtn" type="button" class="secondary" ${canEdit ? '' : 'disabled'}>Agregar cruce</button>
    </div>
    <div class="manual-pairings-list">
      ${pairings.length ? pairings.map((pairing, index) => `
        <article class="manual-pairing-row">
          <div>
            <strong>${index + 1}. ${pairing.player1_name || 'Jugador 1'} VS ${pairing.player2_name || 'Jugador 2'}</strong>
            <small>Primera ronda manual</small>
          </div>
          ${canEdit ? `<button type="button" class="danger secondary" data-delete-manual-pairing="${pairing.id}">Quitar</button>` : ''}
        </article>
      `).join('') : '<div class="empty-row">Sin cruces manuales. Se generará automático.</div>'}
    </div>
  `;

  const player1 = $('#manualPairPlayer1Select');
  const player2 = $('#manualPairPlayer2Select');
  if (player1 && player2) {
    player1.addEventListener('change', () => { player2.innerHTML = getPaidTournamentParticipantOptions('', player1.value); });
    player2.addEventListener('change', () => { player1.innerHTML = getPaidTournamentParticipantOptions(player1.value, player2.value); });
  }
  bindClick('#addManualPairingBtn', addManualPairing);
  panel.querySelectorAll('[data-delete-manual-pairing]').forEach((btn) => {
    btn.addEventListener('click', () => deleteManualPairing(btn.dataset.deleteManualPairing));
  });
}

async function addManualPairing() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  const player1ParticipantId = $('#manualPairPlayer1Select')?.value || '';
  const player2ParticipantId = $('#manualPairPlayer2Select')?.value || '';
  if (!player1ParticipantId || !player2ParticipantId) return showToast('Selecciona los dos jugadores');
  if (player1ParticipantId === player2ParticipantId) return showToast('Elige dos jugadores diferentes');
  try {
    const result = await api(`/tournaments/${state.selectedTournamentId}/manual-pairings`, {
      method: 'POST',
      body: JSON.stringify({ player1ParticipantId, player2ParticipantId })
    });
    state.tournamentManualPairings = result.manualPairings || [];
    showToast('Cruce manual agregado');
    renderTournamentsModule();
  } catch (error) {
    showToast(error.message || 'No se pudo agregar el cruce');
  }
}

async function deleteManualPairing(pairingId) {
  if (!state.selectedTournamentId || !pairingId) return;
  try {
    const result = await api(`/tournaments/${state.selectedTournamentId}/manual-pairings/${pairingId}`, { method: 'DELETE' });
    state.tournamentManualPairings = result.manualPairings || [];
    showToast('Cruce quitado');
    renderTournamentsModule();
  } catch (error) {
    showToast(error.message || 'No se pudo quitar el cruce');
  }
}

async function generateTournamentBracket() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  const paidCount = state.tournamentParticipants.filter((participant) => participant.is_paid).length;
  if (paidCount < 2) return showToast('Necesitas al menos 2 participantes pagados');
  if (state.tournamentMatches.length && !window.confirm('Este torneo ya tiene bracket.')) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/bracket/generate`, { method: 'POST' });
    showToast('Bracket generado');
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo generar el bracket');
  }
}

async function setTournamentMatchWinner(matchId, winnerParticipantId) {
  if (!state.selectedTournamentId || !matchId || !winnerParticipantId) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/matches/${matchId}/winner`, {
      method: 'PATCH',
      body: JSON.stringify({ winnerParticipantId })
    });
    showToast('Ganador registrado');
    await loadStations().catch(() => {});
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo registrar el ganador');
  }
}

async function assignTournamentMatchStation(matchId, stationId) {
  if (!state.selectedTournamentId || !matchId) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/matches/${matchId}/station`, {
      method: 'PATCH',
      body: JSON.stringify({ stationId: stationId || null })
    });
    showToast(stationId ? 'Estación asignada' : 'Estación removida');
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo asignar estación');
  }
}

async function startTournamentMatchStation(matchId) {
  if (!state.selectedTournamentId || !matchId) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/matches/${matchId}/station/start`, { method: 'PATCH' });
    showToast('Partida iniciada');
    await loadStations().catch(() => {});
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo iniciar partida');
  }
}

async function releaseTournamentMatchStation(matchId) {
  if (!state.selectedTournamentId || !matchId) return;
  try {
    await api(`/tournaments/${state.selectedTournamentId}/matches/${matchId}/station/release`, { method: 'PATCH' });
    showToast('Estación liberada');
    await loadStations().catch(() => {});
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo liberar estación');
  }
}

function getTournamentStationOptions(selectedStationId = '') {
  const selected = String(selectedStationId || '');
  const options = ['<option value="">Sin estación</option>'];
  (state.stations || []).forEach((station) => {
    const value = String(station.id);
    const status = getStatusLabel(station.status);
    const selectedAttr = value === selected ? ' selected' : '';
    options.push(`<option value="${value}"${selectedAttr}>${station.name} · ${station.console_type} · ${status}</option>`);
  });
  return options.join('');
}

function renderTournamentBracket() {
  const bracket = $('#tournamentBracketList');
  if (!bracket) return;
  const generateBtn = $('#generateBracketBtn');
  const tournament = state.selectedTournament;
  const closed = tournament && ['FINISHED', 'CANCELLED'].includes(tournament.status);

  if (generateBtn) {
    generateBtn.disabled = !state.selectedTournamentId || closed || state.tournamentMatches.length > 0;
  }

  renderManualPairingsPanel();

  if (!state.selectedTournamentId) {
    bracket.innerHTML = '<div class="empty-row">Selecciona un torneo para generar cruces</div>';
    return;
  }

  if (!state.tournamentMatches.length) {
    bracket.innerHTML = '<div class="empty-row">Sin bracket generado. Cobra las inscripciones y presiona Generar bracket.</div>';
    return;
  }

  const paidCount = state.tournamentParticipants.filter((participant) => participant.is_paid).length;
  const estimatedRounds = Math.max(1, Math.ceil(Math.log2(getNextPowerOfTwo(paidCount || state.tournamentMatches.length || 2))));
  const rounds = state.tournamentMatches.reduce((groups, match) => {
    const key = String(match.round_number || 1);
    if (!groups[key]) groups[key] = [];
    groups[key].push(match);
    return groups;
  }, {});

  bracket.innerHTML = Object.entries(rounds).map(([roundNumber, matches]) => `
    <section class="bracket-round">
      <h4>${getTournamentRoundLabel(Number(roundNumber), estimatedRounds)}</h4>
      <div class="bracket-matches">
        ${matches.map((match) => renderTournamentMatch(match, closed)).join('')}
      </div>
    </section>
  `).join('');

  bracket.querySelectorAll('[data-match-winner]').forEach((btn) => {
    btn.addEventListener('click', () => setTournamentMatchWinner(btn.dataset.matchId, btn.dataset.matchWinner));
  });
  bracket.querySelectorAll('[data-match-station-select]').forEach((select) => {
    select.addEventListener('change', () => assignTournamentMatchStation(select.dataset.matchStationSelect, select.value));
  });
  bracket.querySelectorAll('[data-start-match-station]').forEach((btn) => {
    btn.addEventListener('click', () => startTournamentMatchStation(btn.dataset.startMatchStation));
  });
  bracket.querySelectorAll('[data-release-match-station]').forEach((btn) => {
    btn.addEventListener('click', () => releaseTournamentMatchStation(btn.dataset.releaseMatchStation));
  });
}


function getNextPowerOfTwo(value) {
  let power = 1;
  while (power < value) power *= 2;
  return power;
}

function getTournamentRoundLabel(roundNumber, totalRounds) {
  if (totalRounds && roundNumber === totalRounds) return 'Finales';
  if (totalRounds && roundNumber === totalRounds - 1) return 'Semifinal';
  return `Ronda ${roundNumber}`;
}

function getTournamentMatchLabel(match) {
  if (String(match?.match_type || 'BRACKET') === 'THIRD_PLACE') return 'Partido por 3er lugar';
  return `Partida ${match.match_number}`;
}

function renderTournamentMatch(match, closed) {
  const isFinished = match.status === 'FINISHED';
  const player1 = match.player1_name || 'Libre';
  const player2 = match.player2_name || 'Libre';
  const winner = match.winner_name || '';
  const hasStation = Boolean(match.station_id);
  const stationActive = hasStation && match.station_started_at && !match.station_finished_at && !isFinished;
  const canUseStation = !closed && !isFinished && match.player1_participant_id && match.player2_participant_id;
  const stationLabel = hasStation
    ? `${match.station_name || 'Estación'}${stationActive ? ' · en juego' : match.station_started_at ? ' · liberada' : ' · asignada'}`
    : 'Sin estación';

  return `
    <article class="bracket-match ${isFinished ? 'finished' : ''} ${stationActive ? 'match-station-active' : ''}">
      <div class="bracket-match-head">
        <strong>${escapeHtml(getTournamentMatchLabel(match))}</strong>
        <span>${isFinished ? 'Finalizada' : stationActive ? 'En estación' : 'Pendiente'}</span>
      </div>

      <div class="bracket-station-box">
        <div>
          <span>Estación</span>
          <strong>${stationLabel}</strong>
        </div>
        ${canUseStation ? `
          <select data-match-station-select="${match.id}" ${stationActive ? 'disabled' : ''}>
            ${getTournamentStationOptions(match.station_id)}
          </select>
          <div class="bracket-station-actions">
            ${hasStation && !stationActive ? `<button type="button" class="secondary" data-start-match-station="${match.id}">Iniciar</button>` : ''}
            ${stationActive ? `<button type="button" class="danger secondary" data-release-match-station="${match.id}">Liberar</button>` : ''}
          </div>
        ` : ''}
      </div>

      <div class="bracket-player ${String(match.winner_participant_id || '') === String(match.player1_participant_id || '') ? 'winner' : ''}">
        <span>${player1}</span>
        ${!closed && !isFinished && match.player1_participant_id ? `<button type="button" class="secondary" data-match-id="${match.id}" data-match-winner="${match.player1_participant_id}">Ganó</button>` : ''}
      </div>
      <div class="bracket-player ${String(match.winner_participant_id || '') === String(match.player2_participant_id || '') ? 'winner' : ''}">
        <span>${player2}</span>
        ${!closed && !isFinished && match.player2_participant_id ? `<button type="button" class="secondary" data-match-id="${match.id}" data-match-winner="${match.player2_participant_id}">Ganó</button>` : ''}
      </div>
      ${winner ? `<div class="bracket-winner">Ganador: ${winner}</div>` : ''}
    </article>
  `;
}

function renderTournamentsModule() {
  renderTournamentRanking();
  const list = $('#tournamentsList');
  if (list) {
    if (!state.tournaments.length) {
      list.innerHTML = '<div class="empty-row">No hay torneos creados</div>';
    } else {
      list.innerHTML = state.tournaments.map((tournament) => `
        <button type="button" class="tournament-row ${tournament.id === state.selectedTournamentId ? 'active-selection' : ''}" data-tournament-id="${tournament.id}">
          <span>
            <strong>${tournament.name}</strong>
            <small>${tournament.game} · ${tournament.platform}</small>
            <small>${formatTournamentDate(tournament.scheduled_at)}</small>
          </span>
          <em class="tournament-state ${String(tournament.status || '').toLowerCase()}">${getTournamentStatusLabel(tournament.status)}</em>
        </button>
      `).join('');
      list.querySelectorAll('[data-tournament-id]').forEach((btn) => {
        btn.addEventListener('click', () => selectTournament(btn.dataset.tournamentId));
      });
    }
  }

  const tournament = state.selectedTournament;
  if (tournament) fillTournamentForm(tournament);
  const startBtn = $('#startTournamentBtn');
  const cancelBtn = $('#cancelTournamentBtn');
  const deleteBtn = $('#deleteTournamentBtn');
  const addBtn = $('#addParticipantBtn');
  const closed = tournament && ['FINISHED', 'CANCELLED'].includes(tournament.status);
  if (startBtn) {
    const startAllowed = tournament ? canStartTournamentNow(tournament) : false;
    startBtn.disabled = !state.selectedTournamentId || closed || tournament?.status === 'ACTIVE' || !startAllowed;
    startBtn.title = startAllowed ? '' : getTournamentStartLockLabel(tournament || {});
  }
  if (cancelBtn) cancelBtn.disabled = !state.selectedTournamentId || closed;
  if (deleteBtn) deleteBtn.disabled = !state.selectedTournamentId;
  if (addBtn) addBtn.disabled = !state.selectedTournamentId || closed;
  renderTournamentBracket();
  renderTournamentAwardsPanel();
  renderTournamentMemberPicker();

  const participantsList = $('#tournamentParticipantsList');
  if (!participantsList) return;
  if (!state.selectedTournamentId) {
    participantsList.innerHTML = '<div class="empty-row">Guarda o selecciona un torneo para agregar participantes</div>';
    return;
  }
  if (!state.tournamentParticipants.length) {
    participantsList.innerHTML = '<div class="empty-row">Sin participantes todavía</div>';
    return;
  }

  participantsList.innerHTML = state.tournamentParticipants.map((participant, index) => `
    <div class="participant-row ${participant.is_paid ? 'paid' : ''}">
      <div>
        <strong>${index + 1}. ${participant.player_name}</strong>
        <small>${participant.member_name ? `Miembro · ${getMembershipTierLabel(participant.member_tier)} · ${Number(participant.member_reward_points || 0)} pts` : (participant.nickname || participant.phone || 'Manual')}${Number(participant.tournament_points_earned || 0) > 0 ? ` · +${Number(participant.tournament_points_earned || 0)} pts torneo` : ''}</small>
      </div>
      <span class="payment-pill ${participant.is_paid ? 'paid' : 'pending'}">${participant.is_paid ? 'Pagado' : 'Pendiente'}</span>
      <div class="participant-actions">
        ${participant.is_paid ? '' : `<button type="button" class="secondary" data-pay-participant="${participant.id}">Cobrar</button>`}
        ${closed ? '' : `<button type="button" class="secondary" data-winner-participant="${participant.id}">Campeón</button>`}
        ${participant.is_paid ? '' : `<button type="button" class="danger secondary" data-delete-participant="${participant.id}">Quitar</button>`}
      </div>
    </div>
  `).join('');

  participantsList.querySelectorAll('[data-pay-participant]').forEach((btn) => {
    btn.addEventListener('click', () => markParticipantPaid(btn.dataset.payParticipant));
  });
  participantsList.querySelectorAll('[data-winner-participant]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (window.confirm('¿Marcar este participante como campeón y finalizar el torneo?')) {
        setTournamentStatus('FINISHED', btn.dataset.winnerParticipant);
      }
    });
  });
  participantsList.querySelectorAll('[data-delete-participant]').forEach((btn) => {
    btn.addEventListener('click', () => deleteTournamentParticipant(btn.dataset.deleteParticipant));
  });
}


  window.openTournamentAwardsDelivery = openTournamentAwardsDelivery;
  window.deliverTournamentAwardFromPos = deliverTournamentAwardFromPos;
  window.deliverAllTournamentAwardsFromPos = deliverAllTournamentAwardsFromPos;

  window.ClubVersusTournaments = {
    loadPosTournaments,
    isTodayTournament,
    isClosedFinishedTournament,
    getVisiblePosTournaments,
    getPrimaryPosTournament,
    getTournamentEntryFee,
    getPendingTournamentParticipants,
    isTournamentAwardPending,
    getTournamentAwardPrizeParts,
    closeTournamentAwardsDeliveryModal,
    renderTournamentAwardsDeliveryModal,
    refreshTournamentAwardsDelivery,
    openTournamentAwardsDelivery,
    setTournamentAwardsDeliveryBusy,
    setTournamentAwardsDeliveryStatus,
    finishTournamentAwardDelivery,
    deliverTournamentAwardFromPos,
    deliverAllTournamentAwardsFromPos,
    closeTournamentMemberConversionModal,
    openTournamentMemberConversionModal,
    submitTournamentMemberConversion,
    bindTournamentAwardsDeliveryDelegatedClicks,
    loadTournaments,
    loadTournamentRanking,
    renderTournamentRanking,
    loadTournamentDetail,
    openTournamentsModule,
    closeTournamentsModule,
    resetTournamentForm,
    fillTournamentForm,
    getTournamentPayload,
    getPositionLabel,
    getMembershipTierLabel,
    renderMembershipPlanPrizeOptions,
    getPrizeConfigByPosition,
    renderTournamentPrizeConfigInputs,
    getTournamentPrizeConfigPayload,
    getParticipantOptions,
    getAwardByPosition,
    buildTournamentAwardsPayload,
    assignTournamentAwards,
    deliverTournamentAward,
    getAwardPendingLabel,
    renderTournamentAwardsPanel,
    saveTournament,
    selectTournament,
    setTournamentStatus,
    cancelTournament,
    deleteTournament,
    renderTournamentMemberPicker,
    searchTournamentParticipantMember,
    selectTournamentParticipantMember,
    clearTournamentParticipantMember,
    addTournamentParticipant,
    markParticipantPaid,
    deleteTournamentParticipant,
    getPaidTournamentParticipantOptions,
    renderManualPairingsPanel,
    addManualPairing,
    deleteManualPairing,
    generateTournamentBracket,
    setTournamentMatchWinner,
    assignTournamentMatchStation,
    startTournamentMatchStation,
    releaseTournamentMatchStation,
    getTournamentStationOptions,
    renderTournamentBracket,
    getNextPowerOfTwo,
    getTournamentRoundLabel,
    renderTournamentMatch,
    renderTournamentsModule,
    isTournamentFullForSale,
    getTournamentCapacityLabel,
    renderTournamentDayPanel,
    renderTournamentPosProducts
  };

  window.ClubVersusModules['tournaments'] = window.ClubVersusTournaments;
})();
