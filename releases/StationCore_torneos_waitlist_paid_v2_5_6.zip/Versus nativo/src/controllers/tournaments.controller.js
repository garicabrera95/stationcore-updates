import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { query, withTransaction } from '../db/pool.js';
import { logAuditEvent } from '../services/audit.service.js';
import {
  awardTournamentFinalStandingPoints,
  awardTournamentMatchWinPoints,
  awardTournamentParticipationPoints,
  awardTournamentRankingPoints,
  syncTournamentParticipantRankingPoints,
  getTournamentPositionPoints,
  getTournamentRankingSettings,
  saveTournamentRankingSettings
} from '../services/tournament-ranking.service.js';
import { syncMemberAchievements } from '../services/member-achievements.service.js';


async function syncTournamentAchievementMembers(client, tournamentId, userId = null) {
  const { rows } = await client.query(
    `SELECT DISTINCT member_id
     FROM tournament_participants
     WHERE tournament_id = $1
       AND member_id IS NOT NULL`,
    [tournamentId]
  );
  for (const row of rows) {
    await syncMemberAchievements(client, { memberId: row.member_id, userId });
  }
}

function sendControllerError(res, error) {
  const status = error.status || 500;
  if (status >= 500) console.error(error);
  else console.warn(error.message);
  const body = { error: status === 500 ? 'Error interno del servidor' : error.message };
  if (status < 500 && error.payload && typeof error.payload === 'object') Object.assign(body, error.payload);
  return res.status(status).json(body);
}

function canManageTournaments(req) {
  return req.user?.role === 'OWNER' || req.user?.role === 'MANAGER' || req.user?.permissions?.includes('tournaments');
}

function canOperateVersus(req) {
  return canManageTournaments(req) || req.user?.permissions?.includes('versus');
}


function getTournamentStartDate(value) {
  if (!value) return null;
  const raw = String(value).trim();
  const local = raw.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (local) {
    const date = new Date(Number(local[1]), Number(local[2]) - 1, Number(local[3]), Number(local[4]), Number(local[5]), Number(local[6] || 0));
    return Number.isNaN(date.getTime()) ? null : date;
  }
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function assertTournamentCanStart(tournament = {}) {
  const start = getTournamentStartDate(tournament.scheduled_at || tournament.created_at);
  if (!start) return;
  if (Date.now() < start.getTime()) {
    const label = start.toLocaleString('es-DO', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true });
    const error = new Error(`Modo Versus estará disponible el ${label}`);
    error.status = 409;
    throw error;
  }
}

function getDefaultPaymentDeadline(scheduledAt) {
  if (!scheduledAt) return null;
  const date = new Date(scheduledAt);
  if (Number.isNaN(date.getTime())) return null;
  date.setDate(date.getDate() - 2);
  date.setHours(23, 59, 0, 0);
  return date.toISOString();
}

function normalizeTournamentPayload(body = {}) {
  const name = String(body.name || '').trim();
  const game = String(body.game || '').trim();
  const platform = String(body.platform || 'PlayStation').trim() || 'PlayStation';
  const prizeText = String(body.prizeText || body.prize_text || '').trim();
  const scheduledAt = String(body.scheduledAt || body.scheduled_at || '').trim() || null;
  const paymentDeadlineAt = String(body.paymentDeadlineAt || body.payment_deadline_at || '').trim() || getDefaultPaymentDeadline(scheduledAt);
  const entryFee = Number(body.entryFee ?? body.entry_fee ?? 0);
  const maxPlayersRaw = body.maxPlayers ?? body.max_players ?? null;
  const maxPlayers = maxPlayersRaw === null || maxPlayersRaw === '' ? null : Number.parseInt(String(maxPlayersRaw), 10);
  const winnersCount = Math.max(1, Math.min(8, Number.parseInt(String(body.winnersCount ?? body.winners_count ?? 1), 10) || 1));
  const thirdPlaceModeRaw = String(body.thirdPlaceMode || body.third_place_mode || 'AUTO').trim().toUpperCase();
  const thirdPlaceMode = ['AUTO', 'ALWAYS', 'DISABLED'].includes(thirdPlaceModeRaw) ? thirdPlaceModeRaw : 'AUTO';
  const prizeConfigs = normalizePrizeConfigs(body.prizeConfigs || body.prize_configs || [], winnersCount);

  if (!name) {
    const error = new Error('Nombre del torneo requerido');
    error.status = 400;
    throw error;
  }
  if (!game) {
    const error = new Error('Juego requerido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(entryFee) || entryFee < 0) {
    const error = new Error('Inscripción inválida');
    error.status = 400;
    throw error;
  }
  if (maxPlayers !== null && (!Number.isFinite(maxPlayers) || maxPlayers <= 0)) {
    const error = new Error('Máximo de jugadores inválido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    game,
    platform,
    prizeText: prizeText || null,
    scheduledAt,
    entryFee: Number(entryFee.toFixed(2)),
    paymentDeadlineAt,
    maxPlayers,
    winnersCount,
    thirdPlaceMode,
    prizeConfigs
  };
}

function normalizePrizeConfigs(prizeConfigs = [], winnersCount = 1) {
  const byPosition = new Map();
  if (Array.isArray(prizeConfigs)) {
    for (const prize of prizeConfigs) {
      const position = Number.parseInt(String(prize.position || 0), 10);
      if (position >= 1 && position <= winnersCount) byPosition.set(position, prize);
    }
  }

  const normalized = [];
  for (let position = 1; position <= winnersCount; position += 1) {
    const prize = byPosition.get(position) || {};
    const cashAmount = Number(prize.cashAmount ?? prize.cash_amount ?? 0);
    const membershipTierRaw = String(prize.membershipTier ?? prize.membership_tier ?? '')
      .trim()
      .toUpperCase()
      .replace(/[^A-Z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '');
    const membershipTier = membershipTierRaw || null;
    const freeMinutes = Number.parseInt(String(prize.freeMinutes ?? prize.free_minutes ?? 0), 10) || 0;
    const snackQty = Number.parseInt(String(prize.snackQty ?? prize.snack_qty ?? 0), 10) || 0;
    const drinkQty = Number.parseInt(String(prize.drinkQty ?? prize.drink_qty ?? 0), 10) || 0;
    const redemptionDays = Number.parseInt(String(prize.redemptionDays ?? prize.redemption_days ?? 30), 10);

    if (!Number.isFinite(cashAmount) || cashAmount < 0) {
      const error = new Error(`Efectivo inválido para posición ${position}`);
      error.status = 400;
      throw error;
    }

    normalized.push({
      position,
      cashAmount: Number(cashAmount.toFixed(2)),
      membershipTier,
      freeMinutes: Math.max(0, freeMinutes),
      snackQty: Math.max(0, snackQty),
      drinkQty: Math.max(0, drinkQty),
      redemptionDays: Number.isFinite(redemptionDays) && redemptionDays >= 0 ? redemptionDays : 30,
      notes: String(prize.notes || '').trim() || null
    });
  }
  return normalized;
}

async function upsertPrizeConfigs(client, tournamentId, prizeConfigs) {
  const positions = prizeConfigs.map((prize) => prize.position);
  if (positions.length) {
    await client.query(
      `DELETE FROM tournament_prize_configs WHERE tournament_id = $1 AND position <> ALL($2::int[])`,
      [tournamentId, positions]
    );
  }

  for (const prize of prizeConfigs) {
    await client.query(
      `INSERT INTO tournament_prize_configs
         (tournament_id, position, cash_amount, membership_tier, free_minutes, snack_qty, drink_qty, redemption_days, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (tournament_id, position) DO UPDATE SET
         cash_amount = EXCLUDED.cash_amount,
         membership_tier = EXCLUDED.membership_tier,
         free_minutes = EXCLUDED.free_minutes,
         snack_qty = EXCLUDED.snack_qty,
         drink_qty = EXCLUDED.drink_qty,
         redemption_days = EXCLUDED.redemption_days,
         notes = EXCLUDED.notes,
         updated_at = NOW()`,
      [tournamentId, prize.position, prize.cashAmount, prize.membershipTier, prize.freeMinutes, prize.snackQty, prize.drinkQty, prize.redemptionDays, prize.notes]
    );
  }
}

function getAwardStatus(value) {
  return Number(value || 0) > 0 || value ? 'PENDING' : 'NONE';
}


function normalizePortalUsername(value) {
  return String(value || '').trim().replace(/\s+/g, '');
}

function validatePortalUsername(username) {
  if (!username) return 'Ingresa el usuario/nickname del portal';
  if (username.length < 3 || username.length > 24) return 'El usuario debe tener entre 3 y 24 caracteres';
  if (!/^[a-zA-Z0-9._-]+$/.test(username)) return 'El usuario solo puede tener letras, números, punto, guion o guion bajo';
  return null;
}

function validatePortalPin(pin, confirmPin = pin) {
  if (!/^\d{4,6}$/.test(String(pin || ''))) return 'El PIN debe tener de 4 a 6 números';
  if (String(pin || '') !== String(confirmPin || '')) return 'El PIN y la confirmación no coinciden';
  return null;
}

async function assertPortalUsernameAvailableForTournament(client, username) {
  const { rows } = await client.query(
    `SELECT id FROM members WHERE deleted_at IS NULL AND portal_username IS NOT NULL AND LOWER(portal_username) = LOWER($1) LIMIT 1`,
    [username]
  );
  if (rows[0]) {
    const suffix = Math.floor(10 + Math.random() * 89);
    const base = username.replace(/[^a-zA-Z0-9]/g, '').slice(0, 14) || 'Jugador';
    const error = new Error(`Ese usuario ya está en uso. Prueba ${base}${suffix} o una variante.`);
    error.status = 409;
    throw error;
  }
}

function throwMemberConversionRequired(participant, award) {
  const error = new Error('Completa el miembro para entregar este premio');
  error.status = 409;
  error.payload = {
    code: 'MEMBER_CONVERSION_REQUIRED',
    requiresMemberConversion: true,
    participant: {
      id: participant.participant_id || participant.id || null,
      fullName: participant.player_name || '',
      phone: participant.phone || '',
      nickname: participant.nickname || ''
    },
    award: {
      id: award.id,
      membershipTier: award.membership_tier || null,
      position: award.position || null
    }
  };
  throw error;
}

async function ensureParticipantMember(client, participant, tournamentName, conversion = null) {
  if (participant.member_id) return participant.member_id;

  const participantId = participant.participant_id || participant.id;
  if (!participantId || !participant.tournament_id) {
    const error = new Error('No se pudo vincular el participante al miembro.');
    error.status = 400;
    throw error;
  }

  const conversionData = conversion && typeof conversion === 'object' ? conversion : null;
  if (!conversionData) throwMemberConversionRequired(participant, participant);

  const fullName = String(conversionData.fullName || conversionData.full_name || participant.player_name || '').trim();
  const phone = String(conversionData.phone ?? participant.phone ?? '').trim() || null;
  const portalUsername = normalizePortalUsername(conversionData.portalUsername || conversionData.portal_username || conversionData.nickname || participant.nickname || '');
  const portalPin = String(conversionData.portalPin || conversionData.portal_pin || conversionData.pin || '').trim();
  const portalPinConfirm = String(conversionData.portalPinConfirm || conversionData.portal_pin_confirm || conversionData.confirmPin || conversionData.confirm_pin || '').trim();

  if (!fullName) {
    const error = new Error('Ingresa el nombre del ganador');
    error.status = 400;
    throw error;
  }
  const usernameError = validatePortalUsername(portalUsername);
  if (usernameError) {
    const error = new Error(usernameError);
    error.status = 400;
    throw error;
  }
  const pinError = validatePortalPin(portalPin, portalPinConfirm);
  if (pinError) {
    const error = new Error(pinError);
    error.status = 400;
    throw error;
  }
  await assertPortalUsernameAvailableForTournament(client, portalUsername);
  const portalPinHash = await bcrypt.hash(portalPin, 10);
  const qrCode = `CV-${uuidv4()}`;
  const { rows } = await client.query(
    `INSERT INTO members
       (full_name, phone, qr_code, is_active, membership_source, portal_username, portal_pin_hash, portal_pin_set_at, portal_enabled)
     VALUES ($1, $2, $3, true, 'TOURNAMENT', $4, $5, NOW(), true)
     RETURNING id`,
    [fullName, phone, qrCode, portalUsername, portalPinHash]
  );
  await client.query(
    `UPDATE tournament_participants
     SET member_id = $3, player_name = $4, phone = $5, nickname = COALESCE($6, nickname), updated_at = NOW()
     WHERE id = $1 AND tournament_id = $2`,
    [participantId, participant.tournament_id, rows[0].id, fullName, phone, portalUsername]
  );
  return rows[0].id;
}

function getRankingRange(queryParams = {}) {
  const startDate = String(queryParams.startDate || queryParams.start_date || '').trim();
  const endDate = String(queryParams.endDate || queryParams.end_date || '').trim();
  const period = String(queryParams.period || 'month').trim().toLowerCase();

  if (startDate && endDate) {
    return { startDate, endDate };
  }

  if (period === 'all') {
    return { startDate: null, endDate: null };
  }

  return { startDate: null, endDate: null, currentMonth: true };
}


function getMonthKey(value = '') {
  const raw = String(value || '').trim();
  if (/^\d{4}-\d{2}$/.test(raw)) return raw;
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

function getMonthDateRange(monthKey) {
  const safeMonth = getMonthKey(monthKey);
  return {
    monthKey: safeMonth,
    startDate: `${safeMonth}-01`,
    endDate: `${safeMonth}-31`
  };
}

function normalizeMonthlyPrizePayload(body = {}) {
  const monthKey = getMonthKey(body.monthKey || body.month_key || body.month);
  const prizes = Array.isArray(body.prizes) ? body.prizes : [];
  const normalized = [];
  for (const prize of prizes) {
    const position = Number.parseInt(String(prize.position || 0), 10);
    const prizeName = String(prize.prizeName || prize.prize_name || '').trim();
    const prizeCost = Number.parseFloat(String(prize.prizeCost ?? prize.prize_cost ?? 0).replace(',', '.'));
    const notes = String(prize.notes || '').trim();
    const isActive = prize.isActive ?? prize.is_active;
    if (position < 1 || position > 10 || !prizeName) continue;
    normalized.push({
      position,
      prizeName,
      prizeCost: Number.isFinite(prizeCost) && prizeCost > 0 ? Number(prizeCost.toFixed(2)) : 0,
      notes: notes || null,
      isActive: isActive !== false
    });
  }
  return { monthKey, prizes: normalized };
}

async function getRankingRowsForMonth(client, monthKey, limit = 10) {
  const { startDate, endDate } = getMonthDateRange(monthKey);
  const { rows } = await client.query(
    `WITH point_totals AS (
       SELECT mtp.member_id,
              COALESCE(SUM(mtp.points), 0)::int AS tournament_points,
              COUNT(DISTINCT mtp.tournament_id)::int AS tournaments_played,
              COUNT(*) FILTER (WHERE mtp.match_id IS NOT NULL)::int AS matches_won,
              MAX(mtp.created_at) AS last_points_at
       FROM member_tournament_points mtp
       JOIN tournaments t ON t.id = mtp.tournament_id
       WHERE mtp.created_at >= $1::date AND mtp.created_at < ($2::date + INTERVAL '1 day')
       GROUP BY mtp.member_id
     ), standing_totals AS (
       SELECT tp.member_id AS member_id,
              COUNT(*) FILTER (WHERE tfs.position = 1)::int AS first_places,
              COUNT(*) FILTER (WHERE tfs.position = 2)::int AS second_places,
              COUNT(*) FILTER (WHERE tfs.position = 3)::int AS third_places
       FROM tournament_final_standings tfs
       JOIN tournament_participants tp ON tp.id = tfs.participant_id
       WHERE tfs.created_at >= $1::date AND tfs.created_at < ($2::date + INTERVAL '1 day')
         AND tp.member_id IS NOT NULL
       GROUP BY tp.member_id
     )
     SELECT m.id,
            m.full_name,
            m.phone,
            m.membership_tier,
            m.membership_active,
            COALESCE(pt.tournament_points, 0)::int AS tournament_points,
            COALESCE(pt.tournaments_played, 0)::int AS tournaments_played,
            COALESCE(pt.matches_won, 0)::int AS matches_won,
            COALESCE(st.first_places, 0)::int AS first_places,
            COALESCE(st.second_places, 0)::int AS second_places,
            COALESCE(st.third_places, 0)::int AS third_places,
            ROW_NUMBER() OVER (
              ORDER BY COALESCE(pt.tournament_points, 0) DESC,
                       COALESCE(st.first_places, 0) DESC,
                       COALESCE(st.second_places, 0) DESC,
                       COALESCE(st.third_places, 0) DESC,
                       m.full_name ASC
            )::int AS rank
     FROM members m
     LEFT JOIN point_totals pt ON pt.member_id = m.id
     LEFT JOIN standing_totals st ON st.member_id = m.id
     WHERE m.deleted_at IS NULL
       AND COALESCE(pt.tournament_points, 0) > 0
     ORDER BY tournament_points DESC, first_places DESC, second_places DESC, third_places DESC, m.full_name ASC
     LIMIT $3`,
    [startDate, endDate, Math.min(Math.max(Number.parseInt(String(limit || '10'), 10) || 10, 1), 50)]
  );
  return rows;
}


async function getMemberForTournamentEntryDiscount(client, memberId) {
  if (!memberId) return null;
  const { rows } = await client.query('SELECT id, full_name, membership_tier, membership_active FROM members WHERE id = $1 LIMIT 1', [memberId]);
  return rows[0] || null;
}

async function calculateTournamentEntryPendingPrice(client, tournament, memberId) {
  const baseAmount = Number(tournament.entry_fee || 0);
  const member = await getMemberForTournamentEntryDiscount(client, memberId);
  if (!member?.membership_active || !member.membership_tier) return { total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  const tier = String(member.membership_tier || '').toUpperCase();
  const { rows } = await client.query('SELECT * FROM tournament_entry_discounts WHERE membership_tier = $1 AND is_active = true LIMIT 1', [tier]);
  const rule = rows[0];
  if (!rule || rule.discount_type === 'NONE') return { total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  let total = baseAmount;
  if (rule.discount_type === 'PERCENT') total = baseAmount - (baseAmount * Number(rule.discount_value || 0) / 100);
  if (rule.discount_type === 'FIXED_AMOUNT') total = baseAmount - Number(rule.discount_value || 0);
  if (rule.discount_type === 'FREE') total = 0;
  total = Math.max(0, Number(total.toFixed(2)));
  const discountAmount = Math.max(0, Number((baseAmount - total).toFixed(2)));
  const label = rule.discount_type === 'FREE' ? `${tier} gratis` : rule.discount_type === 'PERCENT' ? `${tier} ${Number(rule.discount_value || 0)}%` : `${tier} -RD$${Number(rule.discount_value || 0).toFixed(2)}`;
  return { total, discountAmount, discountType: rule.discount_type, label };
}

async function normalizeParticipantPayload(client, body = {}) {
  const memberId = body.memberId || body.member_id || null;
  let playerName = String(body.playerName || body.player_name || '').trim();
  let phone = String(body.phone || '').trim();
  const nickname = String(body.nickname || '').trim();

  if (memberId && (!playerName || !phone)) {
    const memberResult = await client.query(
      `SELECT full_name, phone FROM members WHERE id = $1 AND deleted_at IS NULL LIMIT 1`,
      [memberId]
    );
    const member = memberResult.rows[0];
    if (member) {
      if (!playerName) playerName = String(member.full_name || '').trim();
      if (!phone) phone = String(member.phone || '').trim();
    }
  }

  if (!playerName) {
    const error = new Error('Nombre del participante requerido');
    error.status = 400;
    throw error;
  }

  return { playerName, phone: phone || null, nickname: nickname || null, memberId: memberId || null };
}

async function getTournamentById(client, tournamentId) {
  const { rows } = await client.query(
    `SELECT t.*,
            u.full_name AS created_by_name,
            wp.player_name AS winner_name,
            COUNT(tp.id)::int AS participant_count,
            COUNT(tp.id) FILTER (WHERE tp.is_paid = true)::int AS paid_count,
            COUNT(tp.id) FILTER (WHERE COALESCE(tp.payment_status, CASE WHEN tp.is_paid THEN 'PAID' ELSE 'PENDING' END) = 'PENDING')::int AS pending_count,
              (SELECT COUNT(*)::int FROM tournament_awards ta WHERE ta.tournament_id = t.id) AS award_count,
              (SELECT COUNT(*)::int
                 FROM tournament_awards ta
                WHERE ta.tournament_id = t.id
                  AND (ta.cash_status = 'PENDING' OR ta.membership_status = 'PENDING' OR ta.bonus_status = 'PENDING' OR ta.goods_status = 'PENDING')) AS pending_award_count,
            COALESCE(SUM(CASE WHEN tp.is_paid THEN t.entry_fee ELSE 0 END), 0)::numeric(12,2) AS total_collected
     FROM tournaments t
     LEFT JOIN users u ON u.id = t.created_by_user_id
     LEFT JOIN tournament_participants wp ON wp.id = t.winner_participant_id
     LEFT JOIN tournament_participants tp ON tp.tournament_id = t.id
     WHERE t.id = $1
     GROUP BY t.id, u.full_name, wp.player_name`,
    [tournamentId]
  );
  return rows[0] || null;
}


async function getTournamentMatches(client, tournamentId) {
  const { rows } = await client.query(
    `SELECT tm.*,
            p1.player_name AS player1_name,
            p2.player_name AS player2_name,
            wp.player_name AS winner_name,
            s.name AS station_name,
            s.console_type AS station_console_type,
            s.status AS station_status
     FROM tournament_matches tm
     LEFT JOIN tournament_participants p1 ON p1.id = tm.player1_participant_id
     LEFT JOIN tournament_participants p2 ON p2.id = tm.player2_participant_id
     LEFT JOIN tournament_participants wp ON wp.id = tm.winner_participant_id
     LEFT JOIN stations s ON s.id = tm.station_id
     WHERE tm.tournament_id = $1
     ORDER BY tm.round_number ASC, tm.match_number ASC`,
    [tournamentId]
  );
  return rows;
}



async function getTournamentManualPairings(client, tournamentId) {
  const { rows } = await client.query(
    `SELECT tmp.*,
            p1.player_name AS player1_name,
            p2.player_name AS player2_name,
            p1.is_paid AS player1_paid,
            p2.is_paid AS player2_paid
     FROM tournament_manual_pairings tmp
     JOIN tournament_participants p1 ON p1.id = tmp.player1_participant_id
     JOIN tournament_participants p2 ON p2.id = tmp.player2_participant_id
     WHERE tmp.tournament_id = $1
     ORDER BY tmp.created_at ASC`,
    [tournamentId]
  );
  return rows;
}

async function buildSeededParticipantsForBracket(client, tournamentId, participants) {
  const paidIds = participants.map((participant) => String(participant.id));
  const paidSet = new Set(paidIds);
  const used = new Set();
  const seeded = [];

  const pairings = await client.query(
    `SELECT * FROM tournament_manual_pairings
     WHERE tournament_id = $1
     ORDER BY created_at ASC
     FOR UPDATE`,
    [tournamentId]
  );

  for (const pairing of pairings.rows) {
    const p1 = String(pairing.player1_participant_id || '');
    const p2 = String(pairing.player2_participant_id || '');
    if (!paidSet.has(p1) || !paidSet.has(p2)) {
      const error = new Error('Hay un cruce manual con participante sin pago. Cobra o elimina ese cruce antes de generar bracket.');
      error.status = 409;
      throw error;
    }
    if (used.has(p1) || used.has(p2)) {
      const error = new Error('Un jugador está repetido en cruces manuales. Revisa los cruces antes de generar bracket.');
      error.status = 409;
      throw error;
    }
    seeded.push(pairing.player1_participant_id, pairing.player2_participant_id);
    used.add(p1);
    used.add(p2);
  }

  for (const participant of participants) {
    const id = String(participant.id);
    if (!used.has(id)) seeded.push(participant.id);
  }

  return seeded;
}

function isStationCompatibleWithTournament(stationConsoleType = '', tournamentPlatform = '') {
  const station = String(stationConsoleType || '').toLowerCase();
  const platform = String(tournamentPlatform || '').toLowerCase();
  if (!platform || platform.includes('multi')) return true;
  if (platform.includes('playstation') || platform === 'ps' || platform === 'ps4' || platform === 'ps5') return station.includes('playstation') || station.includes('ps4') || station.includes('ps5');
  if (platform.includes('nintendo') || platform.includes('switch')) return station.includes('nintendo') || station.includes('switch');
  if (platform.includes('xbox')) return station.includes('xbox');
  if (platform.includes('pc')) return station.includes('pc');
  return true;
}

async function releaseIdleVersusStations(client) {
  await client.query(
    `UPDATE stations s
     SET status = 'AVAILABLE',
         updated_at = NOW()
     WHERE s.status = 'BUSY'
       AND NOT EXISTS (
         SELECT 1 FROM game_sessions gs
         WHERE gs.station_id = s.id AND gs.status = 'ACTIVE'
       )
       AND NOT EXISTS (
         SELECT 1 FROM tournament_matches tm
         WHERE tm.station_id = s.id
           AND tm.status = 'SCHEDULED'
           AND tm.station_started_at IS NOT NULL
           AND tm.station_finished_at IS NULL
       )`
  );
}

async function getAvailableCompatibleStations(client, tournamentPlatform) {
  await releaseIdleVersusStations(client);
  const stations = await client.query(
    `SELECT s.*
     FROM stations s
     LEFT JOIN game_sessions gs ON gs.station_id = s.id AND gs.status = 'ACTIVE'
     WHERE s.deleted_at IS NULL
       AND s.status = 'AVAILABLE'
       AND gs.id IS NULL
     ORDER BY s.sort_order ASC, s.name ASC
     FOR UPDATE OF s`
  );
  return stations.rows.filter((station) => isStationCompatibleWithTournament(station.console_type, tournamentPlatform));
}

async function autoAssignVersusMatches(client, tournamentId) {
  const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [tournamentId]);
  if (tournamentResult.rowCount === 0) return { assigned: 0 };
  const tournament = tournamentResult.rows[0];
  if (tournament.status !== 'ACTIVE') return { assigned: 0 };

  const stations = await getAvailableCompatibleStations(client, tournament.platform);
  if (!stations.length) return { assigned: 0 };

  const matches = await client.query(
    `SELECT *
     FROM tournament_matches
     WHERE tournament_id = $1
       AND status = 'SCHEDULED'
       AND winner_participant_id IS NULL
       AND player1_participant_id IS NOT NULL
       AND player2_participant_id IS NOT NULL
       AND (station_id IS NULL OR station_started_at IS NULL OR station_finished_at IS NOT NULL)
     ORDER BY round_number ASC, match_number ASC
     FOR UPDATE`,
    [tournamentId]
  );

  let assigned = 0;
  const usedStationIds = new Set();
  for (const match of matches.rows) {
    const station = stations.find((item) => !usedStationIds.has(String(item.id)));
    if (!station) break;
    usedStationIds.add(String(station.id));
    await client.query(`UPDATE stations SET status = 'BUSY', updated_at = NOW() WHERE id = $1`, [station.id]);
    await client.query(
      `UPDATE tournament_matches
       SET station_id = $3,
           station_started_at = NOW(),
           station_finished_at = NULL,
           updated_at = NOW()
       WHERE id = $1 AND tournament_id = $2`,
      [match.id, tournamentId, station.id]
    );
    assigned += 1;
  }
  return { assigned };
}

async function ensureTournamentBracket(client, tournamentId) {
  const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [tournamentId]);
  if (tournamentResult.rowCount === 0) return null;
  const tournament = tournamentResult.rows[0];
  if (!['SCHEDULED', 'ACTIVE'].includes(tournament.status)) {
    const error = new Error('Este torneo ya está cerrado');
    error.status = 409;
    throw error;
  }

  const existing = await client.query('SELECT COUNT(*)::int AS total FROM tournament_matches WHERE tournament_id = $1', [tournamentId]);
  if (Number(existing.rows[0].total || 0) > 0) return tournament;

  const participants = await client.query(
    `SELECT id FROM tournament_participants
     WHERE tournament_id = $1 AND is_paid = true
     ORDER BY created_at ASC`,
    [tournamentId]
  );
  if (participants.rowCount < 2) {
    const error = new Error('Necesitas al menos 2 participantes pagados para iniciar Modo Versus');
    error.status = 400;
    throw error;
  }

  const bracketSize = nextPowerOfTwo(participants.rowCount);
  const seeded = await buildSeededParticipantsForBracket(client, tournamentId, participants.rows);
  while (seeded.length < bracketSize) seeded.push(null);
  await createRoundMatches(client, tournamentId, 1, seeded);
  await advanceTournamentRound(client, tournamentId, 1, null);
  return tournament;
}
async function releaseTournamentStations(client, tournamentId) {
  const matches = await client.query(
    `SELECT id, station_id
     FROM tournament_matches
     WHERE tournament_id = $1
       AND station_id IS NOT NULL
       AND station_started_at IS NOT NULL
       AND station_finished_at IS NULL`,
    [tournamentId]
  );

  for (const match of matches.rows) {
    const activeSession = await client.query(
      `SELECT id FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
      [match.station_id]
    );
    if (activeSession.rowCount === 0) {
      await client.query(`UPDATE stations SET status = 'AVAILABLE' WHERE id = $1 AND status = 'BUSY'`, [match.station_id]);
    }
    await client.query(
      `UPDATE tournament_matches
       SET station_finished_at = COALESCE(station_finished_at, NOW()),
           updated_at = NOW()
       WHERE id = $1`,
      [match.id]
    );
  }
}

function nextPowerOfTwo(value) {
  let power = 1;
  while (power < value) power *= 2;
  return power;
}

function getMatchLoserId(match) {
  if (!match?.winner_participant_id) return null;
  const winner = String(match.winner_participant_id);
  const p1 = match.player1_participant_id ? String(match.player1_participant_id) : '';
  const p2 = match.player2_participant_id ? String(match.player2_participant_id) : '';
  if (p1 && p1 !== winner) return match.player1_participant_id;
  if (p2 && p2 !== winner) return match.player2_participant_id;
  return null;
}

async function getPaidParticipantCount(client, tournamentId) {
  const { rows } = await client.query(
    `SELECT COUNT(*)::int AS total FROM tournament_participants WHERE tournament_id = $1 AND is_paid = true`,
    [tournamentId]
  );
  return Number(rows[0]?.total || 0);
}

function shouldDisputeThirdPlace(tournament, paidParticipantCount) {
  const mode = String(tournament?.third_place_mode || 'AUTO').toUpperCase();
  if (mode === 'DISABLED') return false;
  return Number(paidParticipantCount || 0) >= 4;
}

async function upsertFinalStanding(client, { tournamentId, participantId, position, sourceMatchId = null, userId = null }) {
  if (!tournamentId || !participantId || !position) return false;
  await client.query(
    `INSERT INTO tournament_final_standings
       (tournament_id, participant_id, position, source_match_id, assigned_by_user_id)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (tournament_id, position) DO UPDATE SET
       participant_id = EXCLUDED.participant_id,
       source_match_id = EXCLUDED.source_match_id,
       assigned_by_user_id = COALESCE(EXCLUDED.assigned_by_user_id, tournament_final_standings.assigned_by_user_id),
       updated_at = NOW()`,
    [tournamentId, participantId, position, sourceMatchId, userId]
  );
  return true;
}

async function ensureTournamentFinalStandings(client, tournamentId, tournament, userId = null) {
  const matchesResult = await client.query(
    `SELECT * FROM tournament_matches
     WHERE tournament_id = $1
       AND status = 'FINISHED'
       AND winner_participant_id IS NOT NULL
     ORDER BY round_number ASC, match_number ASC`,
    [tournamentId]
  );
  const matches = matchesResult.rows;
  if (!matches.length) return { saved: 0 };

  const bracketMatches = matches.filter((match) => String(match.match_type || 'BRACKET') === 'BRACKET');
  const maxBracketRound = Math.max(1, ...bracketMatches.map((match) => Number(match.round_number || 1)));
  const finalMatch = bracketMatches.find((match) => Number(match.round_number || 1) === maxBracketRound && match.winner_participant_id)
    || bracketMatches.find((match) => String(match.winner_participant_id || '') === String(tournament?.winner_participant_id || ''));
  const thirdPlaceMatch = matches.find((match) => String(match.match_type || '') === 'THIRD_PLACE' && match.winner_participant_id);

  let saved = 0;
  if (finalMatch?.winner_participant_id) {
    if (await upsertFinalStanding(client, { tournamentId, participantId: finalMatch.winner_participant_id, position: 1, sourceMatchId: finalMatch.id, userId })) saved += 1;
  }
  const secondPlaceId = getMatchLoserId(finalMatch);
  if (secondPlaceId) {
    if (await upsertFinalStanding(client, { tournamentId, participantId: secondPlaceId, position: 2, sourceMatchId: finalMatch.id, userId })) saved += 1;
  }
  if (thirdPlaceMatch?.winner_participant_id) {
    if (await upsertFinalStanding(client, { tournamentId, participantId: thirdPlaceMatch.winner_participant_id, position: 3, sourceMatchId: thirdPlaceMatch.id, userId })) saved += 1;
    const fourthPlaceId = getMatchLoserId(thirdPlaceMatch);
    if (fourthPlaceId) {
      if (await upsertFinalStanding(client, { tournamentId, participantId: fourthPlaceId, position: 4, sourceMatchId: thirdPlaceMatch.id, userId })) saved += 1;
    }
  }

  return { saved };
}

async function createRoundMatches(client, tournamentId, roundNumber, participants, options = {}) {
  const matches = [];
  for (let index = 0; index < participants.length; index += 2) {
    const player1 = participants[index] || null;
    const player2 = participants[index + 1] || null;
    const winner = player1 && !player2 ? player1 : null;
    const { rows } = await client.query(
      `INSERT INTO tournament_matches
         (tournament_id, round_number, match_number, player1_participant_id, player2_participant_id, winner_participant_id, status, match_type, placement_position)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        tournamentId,
        roundNumber,
        options.matchNumberStart ? options.matchNumberStart + (index / 2) : (index / 2) + 1,
        player1,
        player2,
        winner,
        winner ? 'FINISHED' : 'SCHEDULED',
        options.matchType || 'BRACKET',
        options.placementPosition || null
      ]
    );
    matches.push(rows[0]);
  }
  return matches;
}

async function advanceTournamentRound(client, tournamentId, roundNumber, userId = null) {
  const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [tournamentId]);
  if (tournamentResult.rowCount === 0) return;
  const tournament = tournamentResult.rows[0];

  const currentRound = await client.query(
    `SELECT * FROM tournament_matches
     WHERE tournament_id = $1 AND round_number = $2
     ORDER BY match_number ASC`,
    [tournamentId, roundNumber]
  );
  if (currentRound.rowCount === 0) return;

  const bracketMatches = currentRound.rows.filter((match) => String(match.match_type || 'BRACKET') === 'BRACKET');
  if (!bracketMatches.length) return;
  if (bracketMatches.some((match) => match.status !== 'FINISHED' || !match.winner_participant_id)) return;

  const thirdPlaceMatches = currentRound.rows.filter((match) => String(match.match_type || '') === 'THIRD_PLACE');
  const hasPendingThirdPlace = thirdPlaceMatches.some((match) => match.status !== 'FINISHED' || !match.winner_participant_id);
  const winners = bracketMatches.map((match) => match.winner_participant_id);

  if (winners.length === 1) {
    if (hasPendingThirdPlace) return;

    await releaseTournamentStations(client, tournamentId);
    await client.query(
      `UPDATE tournaments
       SET status = 'FINISHED',
           winner_participant_id = $2,
           finished_at = NOW(),
           versus_visible_until = COALESCE(versus_visible_until, date_trunc('day', NOW()) + INTERVAL '1 day'),
           updated_at = NOW()
       WHERE id = $1`,
      [tournamentId, winners[0]]
    );
    await ensureTournamentFinalStandings(client, tournamentId, { ...tournament, winner_participant_id: winners[0] }, userId);
    await awardTournamentFinalStandingPoints(client, { tournamentId, userId });
    await syncTournamentAchievementMembers(client, tournamentId, userId);
    return;
  }

  const nextRoundNumber = roundNumber + 1;
  const nextRound = await client.query(
    `SELECT id FROM tournament_matches WHERE tournament_id = $1 AND round_number = $2 LIMIT 1`,
    [tournamentId, nextRoundNumber]
  );
  if (nextRound.rowCount > 0) return;

  await createRoundMatches(client, tournamentId, nextRoundNumber, winners, { matchType: 'BRACKET' });

  const paidParticipantCount = await getPaidParticipantCount(client, tournamentId);
  if (winners.length === 2 && bracketMatches.length === 2 && shouldDisputeThirdPlace(tournament, paidParticipantCount)) {
    const semifinalLosers = bracketMatches.map(getMatchLoserId).filter(Boolean);
    if (semifinalLosers.length === 2) {
      await createRoundMatches(client, tournamentId, nextRoundNumber, semifinalLosers, {
        matchType: 'THIRD_PLACE',
        placementPosition: 3,
        matchNumberStart: 2
      });
    }
  }

  await advanceTournamentRound(client, tournamentId, nextRoundNumber, userId);
}



export async function getTournamentRankingSettingsController(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const settings = await getTournamentRankingSettings({ query });
    res.json({ settings });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateTournamentRankingSettings(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const settings = await saveTournamentRankingSettings({ query }, req.body || {}, req.user?.id || null);
    res.json({ settings });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function getTournamentRanking(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const range = getRankingRange(req.query);
    const params = [];
    let pointsWhere = '1=1';
    let standingsWhere = '1=1';
    let label = 'Este mes';

    if (range.currentMonth) {
      pointsWhere = `mtp.created_at >= date_trunc('month', NOW()) AND mtp.created_at < date_trunc('month', NOW()) + INTERVAL '1 month'`;
      standingsWhere = `tfs.created_at >= date_trunc('month', NOW()) AND tfs.created_at < date_trunc('month', NOW()) + INTERVAL '1 month'`;
    } else if (range.startDate && range.endDate) {
      params.push(range.startDate, range.endDate);
      pointsWhere = `mtp.created_at >= $1::date AND mtp.created_at < ($2::date + INTERVAL '1 day')`;
      standingsWhere = `tfs.created_at >= $1::date AND tfs.created_at < ($2::date + INTERVAL '1 day')`;
      label = `${range.startDate} - ${range.endDate}`;
    } else {
      label = 'Todo el historial';
    }

    const game = String(req.query.game || '').trim();
    if (game) {
      params.push(game);
      const idx = params.length;
      pointsWhere += ` AND LOWER(COALESCE(t.game, '')) = LOWER($${idx})`;
      standingsWhere += ` AND LOWER(COALESCE(ts.game, '')) = LOWER($${idx})`;
    }

    const platform = String(req.query.platform || '').trim();
    if (platform) {
      params.push(platform);
      const idx = params.length;
      pointsWhere += ` AND LOWER(COALESCE(t.platform, '')) = LOWER($${idx})`;
      standingsWhere += ` AND LOWER(COALESCE(ts.platform, '')) = LOWER($${idx})`;
    }

    const limit = Math.min(Math.max(Number.parseInt(String(req.query.limit || '50'), 10) || 50, 5), 100);
    params.push(limit);
    const limitParam = params.length;

    const { rows } = await query(
      `WITH point_totals AS (
         SELECT mtp.member_id,
                COALESCE(SUM(mtp.points), 0)::int AS tournament_points,
                COUNT(DISTINCT mtp.tournament_id)::int AS tournaments_played,
                COUNT(*) FILTER (WHERE mtp.match_id IS NOT NULL)::int AS matches_won,
                MAX(mtp.created_at) AS last_points_at
         FROM member_tournament_points mtp
         JOIN tournaments t ON t.id = mtp.tournament_id
         WHERE ${pointsWhere}
         GROUP BY mtp.member_id
       ), standing_totals AS (
         SELECT tp.member_id AS member_id,
                COUNT(*) FILTER (WHERE tfs.position = 1)::int AS first_places,
                COUNT(*) FILTER (WHERE tfs.position = 2)::int AS second_places,
                COUNT(*) FILTER (WHERE tfs.position = 3)::int AS third_places,
                COUNT(*) FILTER (WHERE tfs.position = 4)::int AS fourth_places,
                COUNT(*) FILTER (WHERE tfs.position <= 3)::int AS podiums
         FROM tournament_final_standings tfs
         JOIN tournament_participants tp ON tp.id = tfs.participant_id
         JOIN tournaments ts ON ts.id = tfs.tournament_id
         WHERE ${standingsWhere}
           AND tp.member_id IS NOT NULL
         GROUP BY tp.member_id
       )
       SELECT m.id,
              m.full_name,
              m.phone,
              m.membership_tier,
              m.membership_active,
              m.membership_source,
              m.reward_points,
              COALESCE(pt.tournament_points, 0)::int AS tournament_points,
              COALESCE(pt.tournaments_played, 0)::int AS tournaments_played,
              COALESCE(pt.matches_won, 0)::int AS matches_won,
              COALESCE(st.first_places, 0)::int AS first_places,
              COALESCE(st.second_places, 0)::int AS second_places,
              COALESCE(st.third_places, 0)::int AS third_places,
              COALESCE(st.fourth_places, 0)::int AS fourth_places,
              COALESCE(st.podiums, 0)::int AS podiums,
              pt.last_points_at,
              (
                SELECT tlast.name
                FROM member_tournament_points mtplast
                JOIN tournaments tlast ON tlast.id = mtplast.tournament_id
                WHERE mtplast.member_id = m.id
                ORDER BY mtplast.created_at DESC
                LIMIT 1
              ) AS last_tournament_name,
              ROW_NUMBER() OVER (
                ORDER BY COALESCE(pt.tournament_points, 0) DESC,
                         COALESCE(st.first_places, 0) DESC,
                         COALESCE(st.second_places, 0) DESC,
                         COALESCE(st.third_places, 0) DESC,
                         m.full_name ASC
              )::int AS rank
       FROM members m
       LEFT JOIN point_totals pt ON pt.member_id = m.id
       LEFT JOIN standing_totals st ON st.member_id = m.id
       WHERE m.deleted_at IS NULL
         AND COALESCE(pt.tournament_points, 0) > 0
       ORDER BY tournament_points DESC, first_places DESC, second_places DESC, third_places DESC, m.full_name ASC
       LIMIT $${limitParam}`,
      params
    );

    const filterParams = [];
    let filterWhere = '1=1';
    if (range.currentMonth) {
      filterWhere = `created_at >= date_trunc('month', NOW()) AND created_at < date_trunc('month', NOW()) + INTERVAL '1 month'`;
    } else if (range.startDate && range.endDate) {
      filterParams.push(range.startDate, range.endDate);
      filterWhere = `created_at >= $1::date AND created_at < ($2::date + INTERVAL '1 day')`;
    }

    const filtersResult = await query(
      `SELECT ARRAY_REMOVE(ARRAY_AGG(DISTINCT NULLIF(TRIM(game), '')), NULL) AS games,
              ARRAY_REMOVE(ARRAY_AGG(DISTINCT NULLIF(TRIM(platform), '')), NULL) AS platforms
       FROM tournaments
       WHERE ${filterWhere}`,
      filterParams
    );

    res.json({
      ranking: rows,
      label,
      filters: {
        games: (filtersResult.rows[0]?.games || []).sort(),
        platforms: (filtersResult.rows[0]?.platforms || []).sort()
      }
    });
  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function getMonthlyRankingPrizes(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const monthKey = getMonthKey(req.query.month || req.query.monthKey || req.query.month_key);
    const { rows: prizes } = await query(
      `SELECT *
       FROM tournament_monthly_ranking_prizes
       WHERE month_key = $1 AND is_active = true
       ORDER BY position ASC`,
      [monthKey]
    );
    const { rows: awards } = await query(
      `SELECT a.*, m.full_name AS member_name, m.membership_tier, m.membership_active
       FROM tournament_monthly_ranking_awards a
       JOIN members m ON m.id = a.member_id
       WHERE a.month_key = $1
       ORDER BY a.position ASC`,
      [monthKey]
    );
    const preview = await getRankingRowsForMonth({ query }, monthKey, 10);
    res.json({ monthKey, prizes, awards, preview });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function saveMonthlyRankingPrizes(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const { monthKey, prizes } = normalizeMonthlyPrizePayload(req.body || {});
    if (!prizes.length) {
      const error = new Error('Agrega al menos un premio mensual');
      error.status = 400;
      throw error;
    }

    const result = await withTransaction(async (client) => {
      await client.query(
        `UPDATE tournament_monthly_ranking_prizes
         SET is_active = false, updated_at = NOW()
         WHERE month_key = $1`,
        [monthKey]
      );

      for (const prize of prizes) {
        await client.query(
          `INSERT INTO tournament_monthly_ranking_prizes
             (month_key, position, prize_name, prize_cost, notes, is_active, created_by_user_id)
           VALUES ($1, $2, $3, $4, $5, true, $6)
           ON CONFLICT (month_key, position)
           DO UPDATE SET prize_name = EXCLUDED.prize_name,
                         prize_cost = EXCLUDED.prize_cost,
                         notes = EXCLUDED.notes,
                         is_active = true,
                         updated_at = NOW()`,
          [monthKey, prize.position, prize.prizeName, prize.prizeCost, prize.notes, req.user?.id || null]
        );
      }

      await logAuditEvent(client, {
        eventType: 'MONTHLY_RANKING_PRIZES_SAVED',
        userId: req.user?.id,
        entityType: 'RANKING_MONTH',
        entityId: null,
        metadata: { monthKey, prizes: prizes.map((p) => ({ position: p.position, prizeName: p.prizeName, prizeCost: p.prizeCost })) }
      });

      const { rows } = await client.query(
        `SELECT * FROM tournament_monthly_ranking_prizes WHERE month_key = $1 AND is_active = true ORDER BY position ASC`,
        [monthKey]
      );
      return rows;
    });

    res.json({ monthKey, prizes: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function closeMonthlyRanking(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const monthKey = getMonthKey(req.body?.monthKey || req.body?.month_key || req.body?.month || req.query.month);
    const result = await withTransaction(async (client) => {
      const { rows: prizes } = await client.query(
        `SELECT * FROM tournament_monthly_ranking_prizes WHERE month_key = $1 AND is_active = true ORDER BY position ASC`,
        [monthKey]
      );
      if (!prizes.length) {
        const error = new Error('Configura premios para este mes antes de cerrar el ranking');
        error.status = 400;
        throw error;
      }

      const topRows = await getRankingRowsForMonth(client, monthKey, Math.max(10, prizes.length));
      const byPosition = new Map(topRows.map((row) => [Number(row.rank), row]));
      const createdAwards = [];

      for (const prize of prizes) {
        const player = byPosition.get(Number(prize.position));
        if (!player?.id) continue;
        const inserted = await client.query(
          `INSERT INTO tournament_monthly_ranking_awards
             (month_key, position, member_id, prize_id, points, prize_name, prize_cost, created_by_user_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           ON CONFLICT (month_key, position)
           DO UPDATE SET member_id = EXCLUDED.member_id,
                         prize_id = EXCLUDED.prize_id,
                         points = EXCLUDED.points,
                         prize_name = EXCLUDED.prize_name,
                         prize_cost = EXCLUDED.prize_cost,
                         updated_at = NOW()
           RETURNING *`,
          [monthKey, prize.position, player.id, prize.id, player.tournament_points || 0, prize.prize_name, prize.prize_cost || 0, req.user?.id || null]
        );
        createdAwards.push({ ...inserted.rows[0], member_name: player.full_name });
      }

      await logAuditEvent(client, {
        eventType: 'MONTHLY_RANKING_CLOSED',
        userId: req.user?.id,
        entityType: 'RANKING_MONTH',
        entityId: null,
        metadata: { monthKey, awards: createdAwards.map((a) => ({ position: a.position, memberId: a.member_id, memberName: a.member_name, prize: a.prize_name })) }
      });

      return createdAwards;
    });

    res.json({ monthKey, awards: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deliverMonthlyRankingAward(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const { awardId } = req.params;
    const result = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `SELECT a.*, m.full_name AS member_name
         FROM tournament_monthly_ranking_awards a
         JOIN members m ON m.id = a.member_id
         WHERE a.id = $1
         LIMIT 1`,
        [awardId]
      );
      const award = rows[0];
      if (!award) {
        const error = new Error('Premio mensual no encontrado');
        error.status = 404;
        throw error;
      }
      if (award.status === 'DELIVERED') return award;

      let expenseId = award.expense_id;
      const cost = Number(award.prize_cost || 0);
      if (!expenseId && cost > 0) {
        const expense = await client.query(
          `INSERT INTO finance_expenses
             (name, category, expense_type, amount, expense_date, payment_method, notes, created_by_user_id)
           VALUES ($1, 'PROMOCION_RANKING', 'VARIABLE', $2, CURRENT_DATE, 'OTHER', $3, $4)
           RETURNING id`,
          [`Premio ranking mensual: ${award.prize_name}`, cost, `Ranking ${award.month_key} · #${award.position} · ${award.member_name}`, req.user?.id || null]
        );
        expenseId = expense.rows[0].id;
      }

      const updated = await client.query(
        `UPDATE tournament_monthly_ranking_awards
         SET status = 'DELIVERED', delivered_by_user_id = $2, delivered_at = NOW(), expense_id = COALESCE($3, expense_id), updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [awardId, req.user?.id || null, expenseId]
      );

      await logAuditEvent(client, {
        eventType: 'MONTHLY_RANKING_PRIZE_DELIVERED',
        userId: req.user?.id,
        entityType: 'RANKING_AWARD',
        entityId: awardId,
        metadata: { monthKey: award.month_key, position: award.position, memberId: award.member_id, memberName: award.member_name, prize: award.prize_name, cost, expenseId }
      });

      return { ...updated.rows[0], member_name: award.member_name };
    });

    res.json({ award: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function listTournaments(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const { rows } = await query(
      `SELECT t.*,
              wp.player_name AS winner_name,
              COUNT(tp.id)::int AS participant_count,
              COUNT(tp.id) FILTER (WHERE tp.is_paid = true)::int AS paid_count,
            COUNT(tp.id) FILTER (WHERE COALESCE(tp.payment_status, CASE WHEN tp.is_paid THEN 'PAID' ELSE 'PENDING' END) = 'PENDING')::int AS pending_count,
              (SELECT COUNT(*)::int FROM tournament_awards ta WHERE ta.tournament_id = t.id) AS award_count,
              (SELECT COUNT(*)::int
                 FROM tournament_awards ta
                WHERE ta.tournament_id = t.id
                  AND (ta.cash_status = 'PENDING' OR ta.membership_status = 'PENDING' OR ta.bonus_status = 'PENDING' OR ta.goods_status = 'PENDING')) AS pending_award_count,
              COALESCE(SUM(CASE WHEN tp.is_paid THEN t.entry_fee ELSE 0 END), 0)::numeric(12,2) AS total_collected
       FROM tournaments t
       LEFT JOIN tournament_participants wp ON wp.id = t.winner_participant_id
       LEFT JOIN tournament_participants tp ON tp.tournament_id = t.id
       GROUP BY t.id, wp.player_name
       ORDER BY
         CASE t.status WHEN 'ACTIVE' THEN 1 WHEN 'SCHEDULED' THEN 2 WHEN 'FINISHED' THEN 3 ELSE 4 END,
         COALESCE(t.scheduled_at, t.created_at) DESC
       LIMIT 100`
    );

    res.json({ tournaments: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function getTournament(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournament = await getTournamentById(client, req.params.tournamentId);
      if (!tournament) return null;

      const participants = await client.query(
        `SELECT tp.*, m.full_name AS member_name, m.membership_tier AS member_tier, m.reward_points AS member_reward_points,
                COALESCE(SUM(mtp.points), 0)::int AS tournament_points_earned
         FROM tournament_participants tp
         LEFT JOIN members m ON m.id = tp.member_id
         LEFT JOIN member_tournament_points mtp ON mtp.participant_id = tp.id
         WHERE tp.tournament_id = $1
         GROUP BY tp.id, m.full_name, m.membership_tier, m.reward_points
         ORDER BY tp.created_at ASC`,
        [req.params.tournamentId]
      );
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      const prizeConfigs = await client.query(
        `SELECT * FROM tournament_prize_configs WHERE tournament_id = $1 ORDER BY position ASC`,
        [req.params.tournamentId]
      );
      const awards = await client.query(
        `SELECT ta.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name, u.full_name AS assigned_by_name
         FROM tournament_awards ta
         JOIN tournament_participants tp ON tp.id = ta.participant_id
         LEFT JOIN members m ON m.id = ta.member_id
         LEFT JOIN users u ON u.id = ta.assigned_by_user_id
         WHERE ta.tournament_id = $1
         ORDER BY ta.position ASC`,
        [req.params.tournamentId]
      );
      const standings = await client.query(
        `SELECT tfs.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name, m.membership_tier AS member_tier
         FROM tournament_final_standings tfs
         JOIN tournament_participants tp ON tp.id = tfs.participant_id
         LEFT JOIN members m ON m.id = tp.member_id
         WHERE tfs.tournament_id = $1
         ORDER BY tfs.position ASC`,
        [req.params.tournamentId]
      );
      const manualPairings = await getTournamentManualPairings(client, req.params.tournamentId);

      return { tournament, participants: participants.rows, matches, prizeConfigs: prizeConfigs.rows, awards: awards.rows, finalStandings: standings.rows, manualPairings };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function createTournament(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const payload = normalizeTournamentPayload(req.body);
    const result = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `INSERT INTO tournaments (name, game, platform, scheduled_at, payment_deadline_at, entry_fee, prize_text, max_players, winners_count, third_place_mode, created_by_user_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         RETURNING *`,
        [payload.name, payload.game, payload.platform, payload.scheduledAt, payload.paymentDeadlineAt, payload.entryFee, payload.prizeText, payload.maxPlayers, payload.winnersCount, payload.thirdPlaceMode, req.user.id]
      );
      await upsertPrizeConfigs(client, rows[0].id, payload.prizeConfigs);
      return rows[0];
    });
    res.status(201).json({ tournament: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateTournament(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const payload = normalizeTournamentPayload(req.body);
    const result = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `UPDATE tournaments
         SET name = $2,
             game = $3,
             platform = $4,
             scheduled_at = $5,
             payment_deadline_at = $6,
             entry_fee = $7,
             prize_text = $8,
             max_players = $9,
             winners_count = $10,
             third_place_mode = $11,
             updated_at = NOW()
         WHERE id = $1
           AND status IN ('SCHEDULED', 'ACTIVE')
         RETURNING *`,
        [req.params.tournamentId, payload.name, payload.game, payload.platform, payload.scheduledAt, payload.paymentDeadlineAt, payload.entryFee, payload.prizeText, payload.maxPlayers, payload.winnersCount, payload.thirdPlaceMode]
      );
      if (!rows[0]) return null;
      await upsertPrizeConfigs(client, req.params.tournamentId, payload.prizeConfigs);
      return rows[0];
    });
    if (!result) return res.status(404).json({ error: 'Torneo no encontrado o cerrado' });
    res.json({ tournament: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateTournamentStatus(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const status = String(req.body.status || '').toUpperCase();
  const winnerParticipantId = req.body.winnerParticipantId || req.body.winner_participant_id || null;
  if (!['SCHEDULED', 'ACTIVE', 'FINISHED', 'CANCELLED'].includes(status)) return res.status(400).json({ error: 'Estado inválido' });

  try {
    const result = await withTransaction(async (client) => {
      const current = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (current.rowCount === 0) return null;

      if (winnerParticipantId) {
        const winner = await client.query(
          'SELECT id FROM tournament_participants WHERE id = $1 AND tournament_id = $2',
          [winnerParticipantId, req.params.tournamentId]
        );
        if (winner.rowCount === 0) {
          const error = new Error('Ganador inválido');
          error.status = 400;
          throw error;
        }
      }

      if (['FINISHED', 'CANCELLED'].includes(status)) {
        await releaseTournamentStations(client, req.params.tournamentId);
      }

      const { rows } = await client.query(
        `UPDATE tournaments
         SET status = $2,
             winner_participant_id = CASE WHEN $2 = 'FINISHED' THEN $3 ELSE winner_participant_id END,
             started_at = CASE WHEN $2 = 'ACTIVE' AND started_at IS NULL THEN NOW() ELSE started_at END,
             finished_at = CASE WHEN $2 = 'FINISHED' THEN NOW() ELSE finished_at END,
             versus_visible_until = CASE WHEN $2 = 'FINISHED' THEN COALESCE(versus_visible_until, date_trunc('day', NOW()) + INTERVAL '1 day') ELSE versus_visible_until END,
             cancelled_at = CASE WHEN $2 = 'CANCELLED' THEN NOW() ELSE cancelled_at END,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [req.params.tournamentId, status, winnerParticipantId]
      );
      if (rows[0]?.status === 'FINISHED') {
        await ensureTournamentFinalStandings(client, req.params.tournamentId, rows[0], req.user.id).catch(() => {});
      }
      return rows[0];
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json({ tournament: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function addParticipant(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const payload = await normalizeParticipantPayload(client, req.body);
      const tournament = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournament.rowCount === 0) return null;
      if (!['SCHEDULED', 'ACTIVE'].includes(tournament.rows[0].status)) {
        const error = new Error('Este torneo ya está cerrado');
        error.status = 409;
        throw error;
      }

      const count = await client.query('SELECT COUNT(*)::int AS total FROM tournament_participants WHERE tournament_id = $1', [req.params.tournamentId]);
      const maxPlayers = tournament.rows[0].max_players;
      if (maxPlayers && count.rows[0].total >= Number(maxPlayers)) {
        const error = new Error('El torneo llegó al máximo de jugadores');
        error.status = 409;
        throw error;
      }

      let member = null;
      if (payload.memberId) {
        const memberResult = await client.query(
          `SELECT id, full_name, phone FROM members WHERE id = $1 AND is_active = true AND deleted_at IS NULL`,
          [payload.memberId]
        );
        if (memberResult.rowCount === 0) {
          const error = new Error('Miembro inválido');
          error.status = 400;
          throw error;
        }
        member = memberResult.rows[0];
      }

      const { rows } = await client.query(
        `INSERT INTO tournament_participants (tournament_id, member_id, player_name, phone, nickname, payment_deadline_at, payment_status)
         VALUES ($1, $2, $3, $4, $5, $6, 'PENDING')
         RETURNING *`,
        [req.params.tournamentId, payload.memberId, member?.full_name || payload.playerName, payload.phone || member?.phone || null, payload.nickname, tournament.rows[0].payment_deadline_at || getDefaultPaymentDeadline(tournament.rows[0].scheduled_at)]
      );
      return rows[0];
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.status(201).json({ participant: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateParticipant(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const markPaid = req.body.isPaid ?? req.body.is_paid;
    const result = await withTransaction(async (client) => {
      const participantResult = await client.query(
        `SELECT tp.*, t.name AS tournament_name, t.entry_fee
         FROM tournament_participants tp
         JOIN tournaments t ON t.id = tp.tournament_id
         WHERE tp.id = $1 AND tp.tournament_id = $2
         FOR UPDATE OF tp`,
        [req.params.participantId, req.params.tournamentId]
      );
      if (participantResult.rowCount === 0) return null;
      const participant = participantResult.rows[0];

      if (markPaid === true && !participant.is_paid) {
        let saleId = null;
        const entryFee = Number(participant.entry_fee || 0);
        if (entryFee > 0) {
          const drawer = await client.query(`SELECT id FROM cash_drawers WHERE status = 'OPEN' LIMIT 1`);
          if (drawer.rowCount === 0) {
            const error = new Error('Debes abrir la caja antes de cobrar inscripción.');
            error.status = 409;
            throw error;
          }

          const sale = await client.query(
            `INSERT INTO sales (user_id, subtotal, total, payment_method, status, notes)
             VALUES ($1, $2, $2, 'CASH', 'PAID', $3)
             RETURNING id`,
            [req.user.id, entryFee, `Inscripción torneo: ${participant.tournament_name} · ${participant.player_name}`]
          );
          saleId = sale.rows[0].id;
          await client.query(
            `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
             VALUES ($1, 'TOURNAMENT_ENTRY', $2, 1, $3, $3)`,
            [saleId, `Inscripción ${participant.tournament_name} - ${participant.player_name}`, entryFee]
          );
        }

        const { rows } = await client.query(
          `UPDATE tournament_participants
           SET is_paid = true,
               payment_status = 'PAID',
               paid_at = NOW(),
               paid_by_user_id = $3,
               sale_id = COALESCE($4, sale_id),
               updated_at = NOW()
           WHERE id = $1 AND tournament_id = $2
           RETURNING *`,
          [req.params.participantId, req.params.tournamentId, req.user.id, saleId]
        );
        if (rows[0]?.member_id) {
          await awardTournamentParticipationPoints(client, {
            memberId: rows[0].member_id,
            tournamentId: req.params.tournamentId,
            participantId: rows[0].id,
            tournamentName: participant.tournament_name,
            userId: req.user.id
          });
        }
        return rows[0];
      }

      const { rows } = await client.query(
        `UPDATE tournament_participants
         SET player_name = COALESCE(NULLIF($3, ''), player_name),
             phone = NULLIF($4, ''),
             nickname = NULLIF($5, ''),
             updated_at = NOW()
         WHERE id = $1 AND tournament_id = $2
         RETURNING *`,
        [req.params.participantId, req.params.tournamentId, String(req.body.playerName || req.body.player_name || '').trim(), String(req.body.phone || '').trim(), String(req.body.nickname || '').trim()]
      );
      return rows[0];
    });

    if (!result) return res.status(404).json({ error: 'Participante no encontrado' });
    res.json({ participant: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}



export async function addManualPairing(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const player1ParticipantId = req.body.player1ParticipantId || req.body.player1_participant_id;
  const player2ParticipantId = req.body.player2ParticipantId || req.body.player2_participant_id;
  if (!player1ParticipantId || !player2ParticipantId) return res.status(400).json({ error: 'Selecciona los dos jugadores' });
  if (String(player1ParticipantId) === String(player2ParticipantId)) return res.status(400).json({ error: 'El cruce necesita dos jugadores diferentes' });

  try {
    const result = await withTransaction(async (client) => {
      const tournament = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournament.rowCount === 0) return null;
      if (!['SCHEDULED', 'ACTIVE'].includes(tournament.rows[0].status)) {
        const error = new Error('Este torneo ya está cerrado');
        error.status = 409;
        throw error;
      }
      const existingMatches = await client.query('SELECT id FROM tournament_matches WHERE tournament_id = $1 LIMIT 1', [req.params.tournamentId]);
      if (existingMatches.rowCount > 0) {
        const error = new Error('El bracket ya fue generado. Los cruces manuales solo se configuran antes de generar bracket.');
        error.status = 409;
        throw error;
      }

      const players = await client.query(
        `SELECT id, player_name, is_paid
         FROM tournament_participants
         WHERE tournament_id = $1 AND id = ANY($2::uuid[])`,
        [req.params.tournamentId, [player1ParticipantId, player2ParticipantId]]
      );
      if (players.rowCount !== 2) {
        const error = new Error('Selecciona participantes válidos del torneo');
        error.status = 400;
        throw error;
      }
      if (players.rows.some((player) => !player.is_paid)) {
        const error = new Error('Solo puedes crear cruces con jugadores pagados');
        error.status = 409;
        throw error;
      }

      const used = await client.query(
        `SELECT id FROM tournament_manual_pairings
         WHERE tournament_id = $1
           AND ($2::uuid IN (player1_participant_id, player2_participant_id)
             OR $3::uuid IN (player1_participant_id, player2_participant_id))
         LIMIT 1`,
        [req.params.tournamentId, player1ParticipantId, player2ParticipantId]
      );
      if (used.rowCount > 0) {
        const error = new Error('Uno de esos jugadores ya está en otro cruce manual');
        error.status = 409;
        throw error;
      }

      const { rows } = await client.query(
        `INSERT INTO tournament_manual_pairings
           (tournament_id, player1_participant_id, player2_participant_id, created_by_user_id)
         VALUES ($1, $2, $3, $4)
         RETURNING *`,
        [req.params.tournamentId, player1ParticipantId, player2ParticipantId, req.user.id]
      );
      const manualPairings = await getTournamentManualPairings(client, req.params.tournamentId);
      return { manualPairing: rows[0], manualPairings };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.status(201).json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteManualPairing(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournament = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournament.rowCount === 0) return null;
      const existingMatches = await client.query('SELECT id FROM tournament_matches WHERE tournament_id = $1 LIMIT 1', [req.params.tournamentId]);
      if (existingMatches.rowCount > 0) {
        const error = new Error('No puedes cambiar cruces manuales después de generar bracket');
        error.status = 409;
        throw error;
      }
      const deleted = await client.query(
        `DELETE FROM tournament_manual_pairings WHERE id = $1 AND tournament_id = $2`,
        [req.params.pairingId, req.params.tournamentId]
      );
      if (deleted.rowCount === 0) return null;
      const manualPairings = await getTournamentManualPairings(client, req.params.tournamentId);
      return { ok: true, manualPairings };
    });

    if (!result) return res.status(404).json({ error: 'Cruce no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function generateBracket(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournamentResult.rowCount === 0) return null;
      const tournament = tournamentResult.rows[0];
      if (!['SCHEDULED', 'ACTIVE'].includes(tournament.status)) {
        const error = new Error('Este torneo ya está cerrado');
        error.status = 409;
        throw error;
      }

      const existing = await client.query('SELECT COUNT(*)::int AS total FROM tournament_matches WHERE tournament_id = $1', [req.params.tournamentId]);
      if (existing.rows[0].total > 0) {
        const error = new Error('Este torneo ya tiene bracket generado');
        error.status = 409;
        throw error;
      }

      const participants = await client.query(
        `SELECT id FROM tournament_participants
         WHERE tournament_id = $1 AND is_paid = true
         ORDER BY created_at ASC`,
        [req.params.tournamentId]
      );
      if (participants.rowCount < 2) {
        const error = new Error('Necesitas al menos 2 participantes pagados para generar el bracket');
        error.status = 400;
        throw error;
      }

      const bracketSize = nextPowerOfTwo(participants.rowCount);
      const seeded = await buildSeededParticipantsForBracket(client, req.params.tournamentId, participants.rows);
      while (seeded.length < bracketSize) seeded.push(null);

      await createRoundMatches(client, req.params.tournamentId, 1, seeded);
      await client.query(
        `UPDATE tournaments
         SET status = CASE WHEN status = 'SCHEDULED' THEN 'ACTIVE' ELSE status END,
             started_at = COALESCE(started_at, NOW()),
             updated_at = NOW()
         WHERE id = $1`,
        [req.params.tournamentId]
      );
      await advanceTournamentRound(client, req.params.tournamentId, 1, req.user.id);
      await autoAssignVersusMatches(client, req.params.tournamentId);

      const tournamentUpdated = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament: tournamentUpdated, matches };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.status(201).json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function setMatchWinner(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso para elegir ganador' });

  const winnerParticipantId = req.body.winnerParticipantId || req.body.winner_participant_id;
  if (!winnerParticipantId) return res.status(400).json({ error: 'Ganador requerido' });

  try {
    const result = await withTransaction(async (client) => {
      const matchResult = await client.query(
        `SELECT tm.*, t.status AS tournament_status
         FROM tournament_matches tm
         JOIN tournaments t ON t.id = tm.tournament_id
         WHERE tm.id = $1 AND tm.tournament_id = $2
         FOR UPDATE OF tm`,
        [req.params.matchId, req.params.tournamentId]
      );
      if (matchResult.rowCount === 0) return null;
      const match = matchResult.rows[0];
      if (match.tournament_status === 'FINISHED' || match.tournament_status === 'CANCELLED') {
        const error = new Error('Este torneo ya está cerrado');
        error.status = 409;
        throw error;
      }

      const validWinner = [match.player1_participant_id, match.player2_participant_id]
        .filter(Boolean)
        .map(String)
        .includes(String(winnerParticipantId));
      if (!validWinner) {
        const error = new Error('El ganador debe pertenecer a esta partida');
        error.status = 400;
        throw error;
      }

      await client.query(
        `UPDATE tournament_matches
         SET winner_participant_id = $3,
             status = 'FINISHED',
             station_finished_at = CASE WHEN station_id IS NOT NULL AND station_started_at IS NOT NULL AND station_finished_at IS NULL THEN NOW() ELSE station_finished_at END,
             updated_at = NOW()
         WHERE id = $1 AND tournament_id = $2`,
        [req.params.matchId, req.params.tournamentId, winnerParticipantId]
      );

      const winnerParticipant = await client.query(
        `SELECT member_id, player_name FROM tournament_participants WHERE id = $1 AND tournament_id = $2`,
        [winnerParticipantId, req.params.tournamentId]
      );
      if (winnerParticipant.rows[0]?.member_id) {
        await awardTournamentMatchWinPoints(client, {
          memberId: winnerParticipant.rows[0].member_id,
          tournamentId: req.params.tournamentId,
          participantId: winnerParticipantId,
          matchId: match.id,
          userId: req.user.id
        });
        await syncMemberAchievements(client, { memberId: winnerParticipant.rows[0].member_id, userId: req.user?.id || null });
      }

      if (match.station_id) {
        const activeSession = await client.query(
          `SELECT id FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
          [match.station_id]
        );
        if (activeSession.rowCount === 0) {
          await client.query(`UPDATE stations SET status = 'AVAILABLE' WHERE id = $1 AND status = 'BUSY'`, [match.station_id]);
        }
      }

      await releaseIdleVersusStations(client);
      await advanceTournamentRound(client, req.params.tournamentId, match.round_number, req.user.id);
      const currentTournament = await client.query('SELECT status FROM tournaments WHERE id = $1', [req.params.tournamentId]);
      if (currentTournament.rows[0]?.status === 'ACTIVE') {
        await autoAssignVersusMatches(client, req.params.tournamentId);
      }
      const tournament = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament, matches };
    });

    if (!result) return res.status(404).json({ error: 'Partida no encontrada' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function assignMatchStation(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const stationId = req.body.stationId || req.body.station_id || null;

  try {
    const result = await withTransaction(async (client) => {
      const matchResult = await client.query(
        `SELECT tm.*, t.status AS tournament_status
         FROM tournament_matches tm
         JOIN tournaments t ON t.id = tm.tournament_id
         WHERE tm.id = $1 AND tm.tournament_id = $2
         FOR UPDATE OF tm`,
        [req.params.matchId, req.params.tournamentId]
      );
      if (matchResult.rowCount === 0) return null;
      const match = matchResult.rows[0];

      if (['FINISHED', 'CANCELLED'].includes(match.tournament_status) || match.status === 'FINISHED') {
        const error = new Error('Esta partida ya está cerrada');
        error.status = 409;
        throw error;
      }
      if (match.station_started_at && !match.station_finished_at) {
        const error = new Error('Libera la estación antes de cambiarla');
        error.status = 409;
        throw error;
      }

      if (stationId) {
        const station = await client.query(
          `SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`,
          [stationId]
        );
        if (station.rowCount === 0) {
          const error = new Error('Estación no encontrada');
          error.status = 404;
          throw error;
        }
        if (!['AVAILABLE', 'BUSY'].includes(station.rows[0].status)) {
          const error = new Error('La estación no está disponible');
          error.status = 409;
          throw error;
        }
      }

      await client.query(
        `UPDATE tournament_matches
         SET station_id = $3,
             station_started_at = NULL,
             station_finished_at = NULL,
             updated_at = NOW()
         WHERE id = $1 AND tournament_id = $2`,
        [req.params.matchId, req.params.tournamentId, stationId]
      );

      const tournament = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament, matches };
    });

    if (!result) return res.status(404).json({ error: 'Partida no encontrada' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function startMatchStation(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const matchResult = await client.query(
        `SELECT tm.*, t.status AS tournament_status
         FROM tournament_matches tm
         JOIN tournaments t ON t.id = tm.tournament_id
         WHERE tm.id = $1 AND tm.tournament_id = $2
         FOR UPDATE OF tm`,
        [req.params.matchId, req.params.tournamentId]
      );
      if (matchResult.rowCount === 0) return null;
      const match = matchResult.rows[0];
      if (!match.station_id) {
        const error = new Error('Asigna una estación primero');
        error.status = 400;
        throw error;
      }
      if (match.status === 'FINISHED' || ['FINISHED', 'CANCELLED'].includes(match.tournament_status)) {
        const error = new Error('Esta partida ya está cerrada');
        error.status = 409;
        throw error;
      }
      if (!match.player1_participant_id || !match.player2_participant_id) {
        const error = new Error('La partida necesita dos jugadores para iniciar');
        error.status = 400;
        throw error;
      }

      const station = await client.query(`SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`, [match.station_id]);
      if (station.rowCount === 0) {
        const error = new Error('Estación no encontrada');
        error.status = 404;
        throw error;
      }

      const activeSession = await client.query(
        `SELECT id FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [match.station_id]
      );
      if (activeSession.rowCount > 0 || station.rows[0].status !== 'AVAILABLE') {
        const error = new Error('La estación está ocupada');
        error.status = 409;
        throw error;
      }

      await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [match.station_id]);
      await client.query(
        `UPDATE tournament_matches
         SET station_started_at = COALESCE(station_started_at, NOW()),
             station_finished_at = NULL,
             updated_at = NOW()
         WHERE id = $1 AND tournament_id = $2`,
        [req.params.matchId, req.params.tournamentId]
      );

      const tournament = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament, matches };
    });

    if (!result) return res.status(404).json({ error: 'Partida no encontrada' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function releaseMatchStation(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const matchResult = await client.query(
        `SELECT * FROM tournament_matches
         WHERE id = $1 AND tournament_id = $2
         FOR UPDATE`,
        [req.params.matchId, req.params.tournamentId]
      );
      if (matchResult.rowCount === 0) return null;
      const match = matchResult.rows[0];
      if (!match.station_id) {
        const error = new Error('Esta partida no tiene estación asignada');
        error.status = 400;
        throw error;
      }

      const activeSession = await client.query(
        `SELECT id FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [match.station_id]
      );
      if (activeSession.rowCount === 0) {
        await client.query(`UPDATE stations SET status = 'AVAILABLE' WHERE id = $1 AND status = 'BUSY'`, [match.station_id]);
      }
      await client.query(
        `UPDATE tournament_matches
         SET station_finished_at = COALESCE(station_finished_at, NOW()),
             updated_at = NOW()
         WHERE id = $1 AND tournament_id = $2`,
        [req.params.matchId, req.params.tournamentId]
      );

      const tournament = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament, matches };
    });

    if (!result) return res.status(404).json({ error: 'Partida no encontrada' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}




export async function startVersusMode(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournament = await ensureTournamentBracket(client, req.params.tournamentId);
      if (!tournament) return null;
      assertTournamentCanStart(tournament);

      await client.query(
        `UPDATE tournaments
         SET status = 'ACTIVE',
             started_at = COALESCE(started_at, NOW()),
             updated_at = NOW()
         WHERE id = $1`,
        [req.params.tournamentId]
      );

      const assignment = await autoAssignVersusMatches(client, req.params.tournamentId);
      const updatedTournament = await getTournamentById(client, req.params.tournamentId);
      const matches = await getTournamentMatches(client, req.params.tournamentId);
      return { tournament: updatedTournament, matches, assigned: assignment.assigned };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

async function buildAutomaticAwardPositions(client, tournamentId, tournament) {
  const winnersCount = Math.max(1, Math.min(8, Number(tournament.winners_count || 1) || 1));
  await ensureTournamentFinalStandings(client, tournamentId, tournament, null).catch(() => {});
  const standingsResult = await client.query(
    `SELECT position, participant_id AS "participantId"
     FROM tournament_final_standings
     WHERE tournament_id = $1 AND position <= $2
     ORDER BY position ASC`,
    [tournamentId, winnersCount]
  );
  if (standingsResult.rowCount > 0) {
    return standingsResult.rows.map((row) => ({ position: Number(row.position), participantId: row.participantId }));
  }

  const matchesResult = await client.query(
    `SELECT * FROM tournament_matches
     WHERE tournament_id = $1
     ORDER BY round_number ASC, match_number ASC`,
    [tournamentId]
  );
  const matches = matchesResult.rows;
  const maxRound = Math.max(1, ...matches.map((match) => Number(match.round_number || 1)));
  const finalMatch = matches.find((match) => Number(match.round_number || 1) === maxRound && match.winner_participant_id)
    || matches.find((match) => String(match.winner_participant_id || '') === String(tournament.winner_participant_id || ''));

  const positions = [];
  const used = new Set();
  const addPosition = (position, participantId) => {
    if (!participantId) return;
    const key = String(participantId);
    if (used.has(key)) return;
    if (position < 1 || position > winnersCount) return;
    positions.push({ position, participantId });
    used.add(key);
  };
  const getLoser = (match) => {
    if (!match?.winner_participant_id) return null;
    const winner = String(match.winner_participant_id);
    const p1 = match.player1_participant_id ? String(match.player1_participant_id) : '';
    const p2 = match.player2_participant_id ? String(match.player2_participant_id) : '';
    if (p1 && p1 !== winner) return match.player1_participant_id;
    if (p2 && p2 !== winner) return match.player2_participant_id;
    return null;
  };

  addPosition(1, tournament.winner_participant_id || finalMatch?.winner_participant_id);
  addPosition(2, getLoser(finalMatch));

  if (winnersCount >= 3) {
    const previousRoundMatches = matches
      .filter((match) => Number(match.round_number || 1) === maxRound - 1 && match.status === 'FINISHED' && match.winner_participant_id)
      .sort((a, b) => Number(a.match_number || 0) - Number(b.match_number || 0));
    const championPathLoser = previousRoundMatches.find((match) => String(match.winner_participant_id || '') === String(tournament.winner_participant_id || ''));
    addPosition(3, getLoser(championPathLoser));
    for (const match of previousRoundMatches) {
      if (positions.length >= winnersCount) break;
      addPosition(positions.length + 1, getLoser(match));
    }
  }

  if (positions.length < winnersCount) {
    const eliminated = matches
      .filter((match) => match.status === 'FINISHED' && match.winner_participant_id)
      .sort((a, b) => Number(b.round_number || 0) - Number(a.round_number || 0) || Number(a.match_number || 0) - Number(b.match_number || 0));
    for (const match of eliminated) {
      if (positions.length >= winnersCount) break;
      addPosition(positions.length + 1, getLoser(match));
    }
  }

  return positions;
}

async function createTournamentAwards(client, { tournamentId, tournament, requestedAwards, userId, replace = true }) {
  const configsResult = await client.query(
    `SELECT * FROM tournament_prize_configs WHERE tournament_id = $1 ORDER BY position ASC`,
    [tournamentId]
  );
  const configs = new Map(configsResult.rows.map((config) => [Number(config.position), config]));
  const usedParticipants = new Set();

  if (replace) await client.query(`DELETE FROM tournament_awards WHERE tournament_id = $1`, [tournamentId]);

  for (const requested of requestedAwards) {
    const position = Number.parseInt(String(requested.position || 0), 10);
    const participantId = requested.participantId || requested.participant_id;
    if (!position || position < 1 || position > Number(tournament.winners_count || 1)) continue;
    if (!participantId || usedParticipants.has(String(participantId))) {
      const error = new Error('Cada posición necesita un ganador diferente');
      error.status = 400;
      throw error;
    }

    const participantResult = await client.query(
      `SELECT * FROM tournament_participants WHERE id = $1 AND tournament_id = $2`,
      [participantId, tournamentId]
    );
    if (participantResult.rowCount === 0) {
      const error = new Error(`Ganador inválido para posición ${position}`);
      error.status = 400;
      throw error;
    }

    const config = configs.get(position) || {};
    const cashAmount = Number(config.cash_amount || 0);
    const membershipTier = config.membership_tier || null;
    const freeMinutes = Number(config.free_minutes || 0);
    const snackQty = Number(config.snack_qty || 0);
    const drinkQty = Number(config.drink_qty || 0);
    const redemptionDays = Number(config.redemption_days ?? 30);
    const expiresExpression = Number.isFinite(redemptionDays) && redemptionDays > 0 ? `${redemptionDays} days` : '0 days';

    const awardInsert = await client.query(
      `INSERT INTO tournament_awards
         (tournament_id, participant_id, position, member_id, cash_amount, membership_tier, free_minutes, snack_qty, drink_qty, expires_at,
          cash_status, membership_status, bonus_status, goods_status, assigned_by_user_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9,
               CASE WHEN $10::int > 0 THEN NOW() + ($11::text)::interval ELSE NULL END,
               $12, $13, $14, $15, $16)
       ON CONFLICT (tournament_id, position) DO UPDATE SET
         participant_id = EXCLUDED.participant_id,
         member_id = EXCLUDED.member_id,
         cash_amount = EXCLUDED.cash_amount,
         membership_tier = EXCLUDED.membership_tier,
         free_minutes = EXCLUDED.free_minutes,
         snack_qty = EXCLUDED.snack_qty,
         drink_qty = EXCLUDED.drink_qty,
         expires_at = EXCLUDED.expires_at,
         cash_status = EXCLUDED.cash_status,
         membership_status = EXCLUDED.membership_status,
         bonus_status = EXCLUDED.bonus_status,
         goods_status = EXCLUDED.goods_status,
         assigned_by_user_id = EXCLUDED.assigned_by_user_id,
         updated_at = NOW()
       RETURNING id`,
      [
        tournamentId,
        participantId,
        position,
        participantResult.rows[0].member_id || null,
        cashAmount,
        membershipTier,
        freeMinutes,
        snackQty,
        drinkQty,
        redemptionDays,
        expiresExpression,
        cashAmount > 0 ? 'PENDING' : 'NONE',
        membershipTier ? 'PENDING' : 'NONE',
        (freeMinutes > 0 || snackQty > 0 || drinkQty > 0) ? 'PENDING' : 'NONE',
        (snackQty > 0 || drinkQty > 0) ? 'PENDING' : 'NONE',
        userId
      ]
    );
    const memberId = participantResult.rows[0].member_id;
    if (memberId) {
      const rankingSettings = await getTournamentRankingSettings(client);
      const positionPoints = getTournamentPositionPoints(rankingSettings, position);
      await awardTournamentRankingPoints(client, {
        memberId,
        tournamentId,
        participantId,
        awardId: awardInsert.rows[0].id,
        points: positionPoints,
        reason: `${positionPoints} pts por posición ${position} en torneo`,
        sourceKey: `tournament:${tournamentId}:position:${position}:participant:${participantId}`,
        userId
      });
    }
    usedParticipants.add(String(participantId));
  }

  const awards = await client.query(
    `SELECT ta.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name
     FROM tournament_awards ta
     JOIN tournament_participants tp ON tp.id = ta.participant_id
     LEFT JOIN members m ON m.id = ta.member_id
     WHERE ta.tournament_id = $1
     ORDER BY ta.position ASC`,
    [tournamentId]
  );
  return awards.rows;
}

export async function assignTournamentAwards(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const requestedAwards = Array.isArray(req.body.awards) ? req.body.awards : [];
  if (!requestedAwards.length) return res.status(400).json({ error: 'Selecciona los ganadores' });

  try {
    const result = await withTransaction(async (client) => {
      const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournamentResult.rowCount === 0) return null;
      const tournament = tournamentResult.rows[0];
      if (tournament.status !== 'FINISHED') {
        const error = new Error('Finaliza el torneo antes de asignar premios');
        error.status = 409;
        throw error;
      }

      const awards = await createTournamentAwards(client, {
        tournamentId: req.params.tournamentId,
        tournament,
        requestedAwards,
        userId: req.user.id,
        replace: true
      });
      return { awards };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function autoAssignTournamentAwards(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournamentResult.rowCount === 0) return null;
      const tournament = tournamentResult.rows[0];
      if (tournament.status !== 'FINISHED' || !tournament.winner_participant_id) {
        const error = new Error('El torneo debe tener campeón antes de entregar premios');
        error.status = 409;
        throw error;
      }

      const existingAwards = await client.query(
        `SELECT ta.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name
         FROM tournament_awards ta
         JOIN tournament_participants tp ON tp.id = ta.participant_id
         LEFT JOIN members m ON m.id = ta.member_id
         WHERE ta.tournament_id = $1
         ORDER BY ta.position ASC`,
        [req.params.tournamentId]
      );
      if (existingAwards.rowCount > 0) return { awards: existingAwards.rows, autoAssigned: false };

      const requestedAwards = await buildAutomaticAwardPositions(client, req.params.tournamentId, tournament);
      if (!requestedAwards.length) {
        const error = new Error('No se pudieron determinar los lugares automáticamente');
        error.status = 409;
        throw error;
      }

      const awards = await createTournamentAwards(client, {
        tournamentId: req.params.tournamentId,
        tournament,
        requestedAwards,
        userId: req.user.id,
        replace: true
      });
      return { awards, autoAssigned: true };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deliverTournamentAward(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const deliverAll = req.body.deliverAll !== false;
  const deliverCash = deliverAll || req.body.cash === true;
  const deliverMembership = deliverAll || req.body.membership === true;
  const deliverBonus = deliverAll || req.body.bonus === true;
  const deliverGoods = deliverAll || req.body.goods === true;

  try {
    const result = await withTransaction(async (client) => {
      const awardResult = await client.query(
        `SELECT ta.*, tp.id AS participant_id, tp.tournament_id, tp.player_name, tp.phone, tp.nickname, tp.member_id, t.name AS tournament_name
         FROM tournament_awards ta
         JOIN tournament_participants tp ON tp.id = ta.participant_id
         JOIN tournaments t ON t.id = ta.tournament_id
         WHERE ta.id = $1 AND ta.tournament_id = $2
         FOR UPDATE OF ta`,
        [req.params.awardId, req.params.tournamentId]
      );
      if (awardResult.rowCount === 0) return null;
      const award = awardResult.rows[0];
      let memberId = award.member_id || null;

      const needsMember = (deliverMembership && award.membership_status === 'PENDING') || (deliverBonus && award.bonus_status === 'PENDING');
      if (needsMember) {
        const conversionPayload = req.body.memberConversion || req.body.member_conversion || null;
        memberId = await ensureParticipantMember(client, award, award.tournament_name, conversionPayload);
        await client.query(`UPDATE tournament_awards SET member_id = $2, updated_at = NOW() WHERE id = $1`, [award.id, memberId]);
        await syncTournamentParticipantRankingPoints(client, {
          memberId,
          tournamentId: award.tournament_id,
          participantId: award.participant_id,
          userId: req.user.id
        });
      }

      if (deliverCash && award.cash_status === 'PENDING' && Number(award.cash_amount || 0) > 0) {
        const drawer = await client.query(`SELECT id FROM cash_drawers WHERE status = 'OPEN' ORDER BY opened_at DESC LIMIT 1`);
        let drawerId = drawer.rows[0]?.id || null;

        if (!drawerId) {
          const autoDrawer = await client.query(
            `INSERT INTO cash_drawers
               (opened_by_user_id, closed_by_user_id, opening_amount, closing_amount, opening_breakdown, closing_breakdown, opened_at, closed_at, status, closing_note)
             VALUES ($1, $1, 0, 0, '{}'::jsonb, '{}'::jsonb, NOW(), NOW(), 'CLOSED', $2)
             RETURNING id`,
            [req.user.id, `Premio torneo: ${award.tournament_name}`]
          );
          drawerId = autoDrawer.rows[0].id;
        }

        const movement = await client.query(
          `INSERT INTO drawer_movements (drawer_id, user_id, type, amount, reason)
           VALUES ($1, $2, 'OUT', $3, $4)
           RETURNING id`,
          [drawerId, req.user.id, Number(award.cash_amount), `Premio torneo: ${award.tournament_name} · ${award.player_name} · Lugar ${award.position}`]
        );
        await client.query(
          `UPDATE tournament_awards
           SET cash_status = 'DELIVERED', drawer_movement_id = $2, cash_delivered_by_user_id = $3, cash_delivered_at = NOW(), updated_at = NOW()
           WHERE id = $1`,
          [award.id, movement.rows[0].id, req.user.id]
        );
        await logAuditEvent(client, {
          eventType: 'TOURNAMENT_PRIZE_CASH_DELIVERED',
          userId: req.user.id,
          entityType: 'tournament_award',
          entityId: award.id,
          tournamentId: award.tournament_id,
          drawerId,
          metadata: { playerName: award.player_name, position: award.position, amount: Number(award.cash_amount || 0), movementId: movement.rows[0].id }
        });
      }

      if (deliverMembership && award.membership_status === 'PENDING' && award.membership_tier) {
        const conversionPayload = req.body.memberConversion || req.body.member_conversion || {};
        const renewalDate = /^\d{4}-\d{2}-\d{2}$/.test(String(conversionPayload.renewalDate || conversionPayload.renewal_date || ''))
          ? String(conversionPayload.renewalDate || conversionPayload.renewal_date)
          : null;
        await client.query(
          `UPDATE members
           SET membership_tier = $2,
               membership_active = true,
               membership_source = 'TOURNAMENT',
               membership_source_tournament_award_id = $3,
               membership_started_at = COALESCE(membership_started_at, NOW()),
               membership_updated_at = CASE
                 WHEN $4::date IS NOT NULL THEN ($4::date - (COALESCE((SELECT duration_days FROM membership_plans WHERE code = $2 LIMIT 1), 30)::text || ' days')::interval)
                 ELSE NOW()
               END,
               membership_cancelled_at = NULL,
               membership_cancelled_by_user_id = NULL,
               membership_cancel_reason = NULL,
               updated_at = NOW()
           WHERE id = $1`,
          [memberId, award.membership_tier, award.id, renewalDate]
        );
        await client.query(
          `INSERT INTO member_membership_history (member_id, tier, amount, is_renewal)
           VALUES ($1, $2, 0, true)`,
          [memberId, award.membership_tier]
        );
        await client.query(
          `UPDATE tournament_awards
           SET membership_status = 'DELIVERED', membership_delivered_by_user_id = $2, membership_delivered_at = NOW(), updated_at = NOW()
           WHERE id = $1`,
          [award.id, req.user.id]
        );
        await logAuditEvent(client, {
          eventType: 'TOURNAMENT_PRIZE_MEMBERSHIP_DELIVERED',
          userId: req.user.id,
          entityType: 'tournament_award',
          entityId: award.id,
          tournamentId: award.tournament_id,
          metadata: { playerName: award.player_name, position: award.position, memberId, membershipTier: award.membership_tier }
        });
      }

      if (deliverBonus && award.bonus_status === 'PENDING' && (Number(award.free_minutes || 0) > 0 || Number(award.snack_qty || 0) > 0 || Number(award.drink_qty || 0) > 0)) {
        let rewardId = null;
        if (Number(award.free_minutes || 0) > 0 || Number(award.snack_qty || 0) > 0 || Number(award.drink_qty || 0) > 0) {
          const reward = await client.query(
            `INSERT INTO member_rewards
               (member_id, tournament_award_id, reward_type, reward_minutes, prize_snack_qty, prize_drink_qty, status, expires_at, notes, created_by_user_id)
             VALUES ($1, $2, 'TOURNAMENT_PRIZE', $3, $4, $5, 'AVAILABLE', COALESCE($6::timestamptz, NOW() + INTERVAL '30 days'), $7, $8)
             RETURNING id`,
            [memberId, award.id, Number(award.free_minutes || 0), Number(award.snack_qty || 0), Number(award.drink_qty || 0), award.expires_at, `Premio torneo lugar ${award.position}`, req.user.id]
          );
          rewardId = reward.rows[0].id;
        }
        await client.query(
          `UPDATE tournament_awards
           SET bonus_status = 'DELIVERED', member_reward_id = COALESCE($2, member_reward_id), bonus_delivered_by_user_id = $3, bonus_delivered_at = NOW(), updated_at = NOW()
           WHERE id = $1`,
          [award.id, rewardId, req.user.id]
        );
        await logAuditEvent(client, {
          eventType: 'TOURNAMENT_PRIZE_BONUS_DELIVERED',
          userId: req.user.id,
          entityType: 'tournament_award',
          entityId: award.id,
          tournamentId: award.tournament_id,
          metadata: { playerName: award.player_name, position: award.position, memberId, rewardId, freeMinutes: Number(award.free_minutes || 0), snackQty: Number(award.snack_qty || 0), drinkQty: Number(award.drink_qty || 0) }
        });
      }

      if (deliverGoods && award.goods_status === 'PENDING' && (Number(award.snack_qty || 0) > 0 || Number(award.drink_qty || 0) > 0)) {
        await client.query(
          `UPDATE tournament_awards
           SET goods_status = 'DELIVERED', goods_delivered_by_user_id = $2, goods_delivered_at = NOW(), updated_at = NOW()
           WHERE id = $1`,
          [award.id, req.user.id]
        );
        await logAuditEvent(client, {
          eventType: 'TOURNAMENT_PRIZE_GOODS_DELIVERED',
          userId: req.user.id,
          entityType: 'tournament_award',
          entityId: award.id,
          tournamentId: award.tournament_id,
          metadata: { playerName: award.player_name, position: award.position, snackQty: Number(award.snack_qty || 0), drinkQty: Number(award.drink_qty || 0) }
        });
      }

      if (memberId) {
        await syncMemberAchievements(client, { memberId, userId: req.user?.id || null });
      }

      const awards = await client.query(
        `SELECT ta.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name
         FROM tournament_awards ta
         JOIN tournament_participants tp ON tp.id = ta.participant_id
         LEFT JOIN members m ON m.id = ta.member_id
         WHERE ta.tournament_id = $1
         ORDER BY ta.position ASC`,
        [req.params.tournamentId]
      );
      return { awards: awards.rows };
    });

    if (!result) return res.status(404).json({ error: 'Premio no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}



export async function listPosTournaments(req, res) {
  try {
    await query(`UPDATE tournament_participants tp
                 SET payment_status = 'EXPIRED', updated_at = NOW()
                 FROM tournaments t
                 WHERE tp.tournament_id = t.id
                   AND tp.is_paid = false
                   AND COALESCE(tp.payment_status, 'PENDING') = 'PENDING'
                   AND COALESCE(tp.payment_deadline_at, t.payment_deadline_at) IS NOT NULL
                   AND COALESCE(tp.payment_deadline_at, t.payment_deadline_at) < NOW()`).catch(() => {});

    await query(`UPDATE tournaments
                 SET versus_closed_at = COALESCE(versus_closed_at, NOW()), updated_at = NOW()
                 WHERE versus_visible_until IS NOT NULL
                   AND versus_visible_until < NOW()
                   AND versus_closed_at IS NULL`).catch(() => {});

    const { rows } = await query(
      `SELECT t.*,
              wp.player_name AS winner_name,
              COUNT(tp.id)::int AS participant_count,
              COUNT(tp.id) FILTER (WHERE tp.is_paid = true)::int AS paid_count,
              COUNT(tp.id) FILTER (WHERE COALESCE(tp.payment_status, CASE WHEN tp.is_paid THEN 'PAID' ELSE 'PENDING' END) = 'PENDING')::int AS pending_count,
              (SELECT COUNT(*)::int FROM tournament_awards ta WHERE ta.tournament_id = t.id) AS award_count,
              (SELECT COUNT(*)::int
                 FROM tournament_awards ta
                WHERE ta.tournament_id = t.id
                  AND (ta.cash_status = 'PENDING' OR ta.membership_status = 'PENDING' OR ta.bonus_status = 'PENDING' OR ta.goods_status = 'PENDING')) AS pending_award_count
       FROM tournaments t
       LEFT JOIN tournament_participants wp ON wp.id = t.winner_participant_id
       LEFT JOIN tournament_participants tp ON tp.tournament_id = t.id
       WHERE t.status IN ('SCHEDULED', 'ACTIVE', 'FINISHED')
         AND t.status <> 'CANCELLED'
         AND (t.status <> 'FINISHED' OR t.versus_closed_at IS NULL)
         AND (
           COALESCE(t.scheduled_at, t.created_at)::date BETWEEN (CURRENT_DATE - INTERVAL '1 day') AND (CURRENT_DATE + INTERVAL '30 days')
           OR (t.status = 'ACTIVE' AND t.versus_closed_at IS NULL)
           OR (t.status = 'FINISHED' AND t.versus_visible_until IS NOT NULL AND t.versus_visible_until >= NOW() AND t.versus_closed_at IS NULL)
         )
       GROUP BY t.id, wp.player_name
       ORDER BY CASE WHEN t.status = 'ACTIVE' THEN 1 WHEN COALESCE(t.scheduled_at, t.created_at)::date = CURRENT_DATE THEN 2 ELSE 3 END,
                COALESCE(t.scheduled_at, t.created_at) ASC
       LIMIT 20`
    );

    const ids = rows.map((item) => item.id);
    let participants = [];
    if (ids.length) {
      const result = await query(
        `SELECT tp.*, t.name AS tournament_name, t.entry_fee,
                COALESCE(tp.payment_deadline_at, t.payment_deadline_at) AS effective_payment_deadline_at,
                COALESCE(tp.payment_status, CASE WHEN tp.is_paid THEN 'PAID' ELSE 'PENDING' END) AS payment_status
         FROM tournament_participants tp
         JOIN tournaments t ON t.id = tp.tournament_id
         WHERE tp.tournament_id = ANY($1::uuid[])
           AND tp.is_paid = false
           AND COALESCE(tp.payment_status, 'PENDING') IN ('PENDING', 'EXPIRED')
         ORDER BY COALESCE(tp.payment_deadline_at, t.payment_deadline_at) ASC NULLS LAST, tp.created_at ASC`,
        [ids]
      );
      participants = result.rows;
    }

    res.json({ tournaments: rows, participants });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function quickRegisterTournamentParticipant(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso' });
  try {
    const result = await withTransaction(async (client) => {
      const payload = await normalizeParticipantPayload(client, req.body);
      const tournament = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournament.rowCount === 0) return null;
      if (!['SCHEDULED', 'ACTIVE'].includes(tournament.rows[0].status)) {
        const error = new Error('Este torneo no acepta inscripción');
        error.status = 409;
        throw error;
      }
      const count = await client.query('SELECT COUNT(*)::int AS total FROM tournament_participants WHERE tournament_id = $1 AND COALESCE(payment_status, CASE WHEN is_paid THEN \'PAID\' ELSE \'PENDING\' END) <> \'CANCELLED\'', [req.params.tournamentId]);
      if (tournament.rows[0].max_players && Number(count.rows[0].total || 0) >= Number(tournament.rows[0].max_players)) {
        const error = new Error('El torneo llegó al máximo de jugadores');
        error.status = 409;
        throw error;
      }
      const pricing = await calculateTournamentEntryPendingPrice(client, tournament.rows[0], payload.memberId);
      const { rows } = await client.query(
        `INSERT INTO tournament_participants (tournament_id, member_id, player_name, phone, nickname, payment_deadline_at, payment_status, entry_fee_amount, entry_discount_amount, entry_discount_type, entry_discount_label)
         VALUES ($1, $2, $3, $4, $5, $6, 'PENDING', $7, $8, $9, $10)
         RETURNING *`,
        [req.params.tournamentId, payload.memberId, payload.playerName, payload.phone, payload.nickname, tournament.rows[0].payment_deadline_at || getDefaultPaymentDeadline(tournament.rows[0].scheduled_at), pricing.total, pricing.discountAmount, pricing.discountType, pricing.label]
      );
      return rows[0];
    });
    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.status(201).json({ participant: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function closeVersusDisplay(req, res) {
  if (!canOperateVersus(req)) return res.status(403).json({ error: 'No tienes permiso para cerrar Modo Versus' });
  try {
    const result = await withTransaction(async (client) => {
      await releaseTournamentStations(client, req.params.tournamentId);
      const { rows } = await client.query(
        `UPDATE tournaments
         SET versus_closed_at = NOW(),
             versus_visible_until = COALESCE(versus_visible_until, NOW()),
             versus_closed_by_user_id = $2,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [req.params.tournamentId, req.user.id]
      );
      return rows[0] || null;
    });
    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json({ tournament: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteTournament(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const result = await withTransaction(async (client) => {
      const tournament = await client.query('SELECT id, name FROM tournaments WHERE id = $1 FOR UPDATE', [req.params.tournamentId]);
      if (tournament.rowCount === 0) return null;

      await releaseTournamentStations(client, req.params.tournamentId);
      await client.query('DELETE FROM tournament_awards WHERE tournament_id = $1', [req.params.tournamentId]);
      await client.query('UPDATE tournaments SET winner_participant_id = NULL WHERE id = $1', [req.params.tournamentId]);
      await client.query('DELETE FROM tournaments WHERE id = $1', [req.params.tournamentId]);
      return { ok: true };
    });

    if (!result) return res.status(404).json({ error: 'Torneo no encontrado' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteParticipant(req, res) {
  if (!canManageTournaments(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const { rowCount } = await query(
      `DELETE FROM tournament_participants
       WHERE id = $1
         AND tournament_id = $2
         AND is_paid = false`,
      [req.params.participantId, req.params.tournamentId]
    );
    if (rowCount === 0) return res.status(404).json({ error: 'Solo puedes quitar participantes sin pago registrado' });
    res.json({ ok: true });
  } catch (error) {
    return sendControllerError(res, error);
  }
}
