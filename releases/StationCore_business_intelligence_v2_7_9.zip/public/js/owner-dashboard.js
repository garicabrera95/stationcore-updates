const ownerState = {
  token: localStorage.getItem('stationcore_owner_token') || '',
  user: JSON.parse(localStorage.getItem('stationcore_owner_user') || 'null'),
  refreshTimer: null,
  filters: {
    period: localStorage.getItem('stationcore_owner_period') || 'today',
    startDate: localStorage.getItem('stationcore_owner_start_date') || '',
    endDate: localStorage.getItem('stationcore_owner_end_date') || '',
    shiftId: localStorage.getItem('stationcore_owner_shift_id') || ''
  },
  currentSection: localStorage.getItem('stationcore_owner_panel_section') || 'overview',
  financeRange: null,
  financeLoaded: false,
  reportsLoaded: false,
  reportTab: 'sales',
  reportRange: null,
  inventoryAlerts: null,
  payroll: { employees: [], shifts: [], payments: [] }
};

const $ = (selector) => document.querySelector(selector);

function money(value) {
  return `RD$${Number(value || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
}

function timeLabel(value) {
  if (!value) return '';
  try {
    return new Date(value).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  } catch (_error) {
    return '';
  }
}

function dateTimeLabel(value) {
  if (!value) return '';
  try {
    return new Date(value).toLocaleString('es-DO', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch (_error) {
    return '';
  }
}

function dateOnlyInput(value) {
  if (!value) return '';
  try {
    const date = new Date(value);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  } catch (_error) {
    return '';
  }
}

function rangeLabel(data) {
  return data?.range?.label || 'Hoy';
}

function elapsedMinutes(startedAt) {
  if (!startedAt) return 0;
  return Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 60000));
}

function remainingLabel(station) {
  if (!station?.active_session_id) return 'Disponible';
  if (station.rate_type === 'PREPAID' && Number(station.prepaid_minutes || 0) > 0) {
    const remaining = Math.max(0, Number(station.prepaid_minutes || 0) - elapsedMinutes(station.started_at));
    return `${remaining} min restantes`;
  }
  return `${elapsedMinutes(station.started_at)} min en modo libre`;
}

function statusText(station) {
  const status = String(station.status || '').toUpperCase();
  if (station.active_session_id || status === 'BUSY') return 'Ocupada';
  if (status === 'MAINTENANCE') return 'Mantenimiento';
  if (status === 'OFFLINE') return 'Fuera';
  return 'Disponible';
}

function statusClass(station) {
  const status = String(station.status || '').toUpperCase();
  if (station.active_session_id || status === 'BUSY') return 'busy';
  if (status === 'MAINTENANCE') return 'maintenance';
  if (status === 'OFFLINE') return 'offline';
  return 'available';
}

function setVisible() {
  const loggedIn = Boolean(ownerState.token);
  $('#ownerLogin')?.classList.toggle('hidden', loggedIn);
  $('#ownerDashboard')?.classList.toggle('hidden', !loggedIn);
}

function setOwnerSection(section = 'overview') {
  const allowed = ['overview', 'codes', 'payments', 'requests', 'stations', 'sales', 'reports', 'finance', 'security', 'printing'];
  ownerState.currentSection = allowed.includes(section) ? section : 'overview';
  localStorage.setItem('stationcore_owner_panel_section', ownerState.currentSection);
  document.querySelectorAll('[data-owner-section-tab]').forEach((button) => {
    button.classList.toggle('active', button.dataset.ownerSectionTab === ownerState.currentSection);
  });
  document.querySelectorAll('[data-owner-section]').forEach((sectionEl) => {
    const sections = String(sectionEl.dataset.ownerSection || '').split(/\s+/).filter(Boolean);
    sectionEl.classList.toggle('hidden', !sections.includes(ownerState.currentSection));
  });
  // Reportes y Finanzas administran su propio período; Códigos no depende de
  // fechas. El filtro operativo se conserva para las vistas que comparten datos.
  const showOperationalFilter = !['reports', 'finance', 'codes', 'security', 'printing'].includes(ownerState.currentSection);
  document.querySelector('.owner-filter-bar')?.classList.toggle('hidden', !showOperationalFilter);
  if (ownerState.currentSection === 'finance') {
    loadOwnerFinance().catch((error) => alert(error.message || 'No se pudo cargar Finanzas'));
  }
  if (ownerState.currentSection === 'reports') loadOwnerReports();
  if (ownerState.currentSection === 'security') loadOwnerPosSecurity();
  if (ownerState.currentSection === 'printing') loadOwnerPrinting();
}

const printSupplyLabels = { PAPER: 'Papel carta', BLACK_INK: 'Tinta negra T544', COLOR_INK: 'Juego de tintas color T544' };
function printUnitMoney(value) { return `RD$${Number(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}`; }
function printCatalogOptions(rows = [], selected = '') { return rows.map((row) => `<option value="${escapeHtml(row.code)}" ${String(row.code) === String(selected) ? 'selected' : ''}>${escapeHtml(row.label)}</option>`).join(''); }
function printCatalogRow(group = '', code = '') { return (ownerState.printingData?.catalog?.[group] || []).find((row) => row.code === code); }
function printProfileRow(code = '') { return printCatalogRow('paperProfiles', code); }
function printSupplyProfileLabel(supply = {}) { const profile = printProfileRow(supply.media_profile); const size = profile?.sizes?.find((row) => row.code === supply.paper_size); return [profile?.label, size?.label, supply.paper_brand].filter(Boolean).join(' · '); }
function toggleManualInkFields(container, auto) { container?.querySelectorAll('[data-recipe-field="blackInkUnits"],[data-recipe-field="colorInkUnits"]').forEach((input) => { input.disabled = auto; }); }

function populateNewPaperSizes() {
  const profile = printProfileRow($('#ownerNewPrintMediaProfile')?.value) || ownerState.printingData?.catalog?.paperProfiles?.[0];
  const select = $('#ownerNewPrintPaperSize');
  if (select) select.innerHTML = printCatalogOptions(profile?.sizes || []);
  if ($('#ownerNewPrintPaperHelp')) $('#ownerNewPrintPaperHelp').textContent = profile?.official
    ? 'Perfil y tamaños compatibles indicados por Epson para la L3250/L3251.'
    : 'Usa el perfil del controlador Epson que más se parezca al papel compatible que compraste.';
}

function populateSupplyCardPaperSizes(card) {
  const profile = printProfileRow(card?.querySelector('[data-print-field="mediaProfile"]')?.value);
  const select = card?.querySelector('[data-print-field="paperSize"]');
  if (select) select.innerHTML = printCatalogOptions(profile?.sizes || [], profile?.sizes?.[0]?.code);
}

function updateNewPrintBorderlessAvailability() {
  const supply = (ownerState.printingData?.supplies || []).find((row) => row.supply_type === $('#ownerNewPrintPaperSupply')?.value);
  const profile = printProfileRow(supply?.media_profile);
  const allowed = Boolean(profile?.borderlessSizeCodes?.includes(supply?.paper_size));
  const checkbox = $('#ownerNewPrintBorderless');
  if (checkbox) { checkbox.disabled = !allowed; if (!allowed) checkbox.checked = false; }
}

function applyNewPrintTypeDefaults() {
  const type = $('#ownerNewPrintOutputType')?.value || 'DOCUMENT';
  const defaults = {
    DOCUMENT: { quality: 'STANDARD', coverage: 'MEDIUM', waste: 15 },
    PHOTO: { quality: 'HIGH', coverage: 'FULL_PHOTO', waste: 20 },
    ID_COPY: { quality: 'STANDARD', coverage: 'LIGHT', waste: 15 },
    GRAPHIC: { quality: 'HIGH', coverage: 'HIGH', waste: 18 }
  }[type];
  if (!defaults) return;
  if ($('#ownerNewPrintQuality')) $('#ownerNewPrintQuality').value = defaults.quality;
  if ($('#ownerNewPrintCoverage')) $('#ownerNewPrintCoverage').value = defaults.coverage;
  if ($('#ownerNewPrintWaste')) $('#ownerNewPrintWaste').value = String(defaults.waste);
}

function maintenanceDate(value) { return value ? new Date(value).toLocaleString('es-DO') : 'Sin registrar'; }
function maintenanceEventLabel(value = '') { return ({ NOZZLE_CHECK: 'Prueba de inyectores', HEAD_CLEANING: 'Limpieza normal', POWER_CLEANING: 'Limpieza a fondo', HEAD_ALIGNMENT: 'Alineación', EXTERIOR_CLEANING: 'Limpieza exterior', INK_VISUAL_CHECK: 'Revisión de tintas' })[value] || value; }
function maintenanceResultLabel(value = '') { return ({ CLEAN: 'Patrón correcto', GAPS: 'Con espacios', MOSTLY_MISSING: 'Patrón casi ausente' })[value] || ''; }

function renderPrinterMaintenance(maintenance = {}) {
  const alerts = maintenance.alerts || [];
  const badge = $('#ownerPrintingAlertBadge');
  if (badge) { badge.textContent = String(alerts.length); badge.classList.toggle('hidden', alerts.length === 0); }
  if ($('#ownerPrinterMaintenanceStatus')) $('#ownerPrinterMaintenanceStatus').textContent = alerts.length ? `${alerts.length} pendiente${alerts.length === 1 ? '' : 's'}` : 'Al día';
  const cards = $('#ownerPrinterMaintenanceCards');
  if (cards) cards.innerHTML = [
    ['Hojas registradas', Number(maintenance.totalSheets || 0).toFixed(0)],
    ['Desde revisión', Number(maintenance.sheetsSinceCheck || 0).toFixed(0)],
    ['Días desde revisión', maintenance.daysSinceCheck == null ? 'Nunca' : maintenance.daysSinceCheck],
    ['Limpiezas seguidas', Number(maintenance.consecutiveCleanings || 0)]
  ].map(([label, value]) => `<article><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value))}</strong></article>`).join('');
  const alertBox = $('#ownerPrinterMaintenanceAlerts');
  if (alertBox) alertBox.innerHTML = alerts.length ? alerts.map((alert) => `<article class="${escapeHtml(String(alert.level || '').toLowerCase())}"><strong>${escapeHtml(alert.title)}</strong><span>${escapeHtml(alert.detail)}</span></article>`).join('') : '<div class="owner-alert-empty">No hay mantenimiento pendiente.</div>';
  const settings = maintenance.settings || {};
  if ($('#ownerNozzleCheckDays')) $('#ownerNozzleCheckDays').value = Number(settings.nozzleCheckDays || 30);
  if ($('#ownerNozzleCheckSheets')) $('#ownerNozzleCheckSheets').value = Number(settings.nozzleCheckSheets || 500);
  if ($('#ownerPrinterInactivityDays')) $('#ownerPrinterInactivityDays').value = Number(settings.inactivityDays || 14);
  if ($('#ownerExteriorCleaningDays')) $('#ownerExteriorCleaningDays').value = Number(settings.exteriorCleaningDays || 120);
  const history = $('#ownerPrinterMaintenanceHistory');
  if (history) history.innerHTML = (maintenance.recentEvents || []).length ? maintenance.recentEvents.map((event) => `<div><span><strong>${escapeHtml(maintenanceEventLabel(event.event_type))}</strong><small>${escapeHtml(maintenanceResultLabel(event.result) || event.notes || 'Registrado')}</small></span><b>${escapeHtml(maintenanceDate(event.performed_at))}</b></div>`).join('') : '<div class="owner-alert-empty">Todavía no hay mantenimiento registrado.</div>';
}

function renderOwnerPrinting(data = {}) {
  ownerState.printingData = data;
  const supplies = $('#ownerPrintSupplies');
  const recipes = $('#ownerPrintRecipes');
  const paperSupplies = (data.supplies || []).filter((supply) => String(supply.supply_group || '').toUpperCase() === 'PAPER' && supply.is_active !== false);
  const paperOptions = (selected = 'PAPER') => paperSupplies.map((supply) => `
    <option value="${escapeHtml(supply.supply_type)}" ${String(supply.supply_type) === String(selected) ? 'selected' : ''}>${escapeHtml(supply.display_name || printSupplyLabels[supply.supply_type] || supply.supply_type)}</option>
  `).join('');

  const newServicePaperSelect = $('#ownerNewPrintPaperSupply');
  if (newServicePaperSelect) newServicePaperSelect.innerHTML = paperOptions('PAPER');
  const profileSelect = $('#ownerNewPrintMediaProfile');
  if (profileSelect) profileSelect.innerHTML = printCatalogOptions(data.catalog?.paperProfiles || [], 'PHOTO_GLOSSY');
  populateNewPaperSizes();
  for (const [id, group, selected] of [
    ['ownerNewPrintOutputType', 'outputTypes', 'DOCUMENT'],
    ['ownerNewPrintColorMode', 'colorModes', 'COLOR'],
    ['ownerNewPrintQuality', 'qualities', 'STANDARD'],
    ['ownerNewPrintCoverage', 'coverages', 'MEDIUM']
  ]) { const select = $(`#${id}`); if (select) select.innerHTML = printCatalogOptions(data.catalog?.[group] || [], selected); }
  updateNewPrintBorderlessAvailability();

  if (supplies) {
    supplies.innerHTML = (data.supplies || []).map((supply) => {
      const isPaper = String(supply.supply_group || '').toUpperCase() === 'PAPER';
      const profile = printProfileRow(supply.media_profile) || data.catalog?.paperProfiles?.at(-1);
      const paperFields = isPaper ? `<label>Perfil Epson<select data-print-field="mediaProfile">${printCatalogOptions(data.catalog?.paperProfiles || [], profile?.code)}</select></label><label>Tamaño<select data-print-field="paperSize">${printCatalogOptions(profile?.sizes || [], supply.paper_size || profile?.sizes?.[0]?.code)}</select></label><label>Marca o referencia<input data-print-field="paperBrand" type="text" maxlength="80" value="${escapeHtml(supply.paper_brand || '')}" placeholder="Opcional"></label>` : '';
      return `
      <div class="owner-print-setting" data-print-supply="${supply.supply_type}">
        <h3>${escapeHtml(supply.display_name || printSupplyLabels[supply.supply_type] || supply.supply_type)}</h3>
        <input data-print-field="supplyGroup" type="hidden" value="${escapeHtml(supply.supply_group || '')}">
        <label>Nombre del insumo<input data-print-field="displayName" type="text" maxlength="80" value="${escapeHtml(supply.display_name || printSupplyLabels[supply.supply_type] || supply.supply_type)}" ${supply.is_system ? 'disabled' : ''}></label>
        ${paperFields}
        <label>Costo de compra<input data-print-field="purchaseCost" type="number" min="0" step=".01" value="${Number(supply.purchase_cost || 0)}"></label>
        <label>Rendimiento total<input data-print-field="yieldUnits" type="number" min="1" step="1" value="${Number(supply.yield_units || 1)}"></label>
        <label>Disponible estimado<input data-print-field="remainingUnits" type="number" min="0" step="1" value="${Number(supply.remaining_units || 0)}"></label>
        <label>Alertar cuando queden<input data-print-field="lowLevelUnits" type="number" min="0" step="1" value="${Number(supply.low_level_units || 0)}"></label>
        ${supply.supply_group === 'PAPER' && supply.media_profile ? `<small>${escapeHtml(printSupplyProfileLabel(supply))}</small>` : ''}
        <small>Unidades = ${escapeHtml(supply.unit_label || (supply.supply_group === 'INK' ? 'páginas estimadas' : 'hojas'))} · Costo unitario ${printUnitMoney(Number(supply.purchase_cost || 0) / Math.max(1, Number(supply.yield_units || 1)))}</small>
        <button type="button" class="secondary" data-register-print-purchase>Sumar una compra</button>
      </div>
    `; }).join('');
  }

  if (recipes) {
    recipes.innerHTML = (data.recipes || []).map((recipe) => {
      const isActive = recipe.is_active !== false;
      const bulkFrom = Number(recipe.bulk_from || 0);
      const bulkPrice = Number(recipe.bulk_price ?? recipe.regular_price ?? recipe.price ?? 0);
      const selectedPaper = String(recipe.paper_supply_type || 'PAPER');
      const autoInk = recipe.auto_ink_estimate === true;
      const calculation = recipe.calculation || {};
      return `
        <div class="owner-print-setting ${isActive ? '' : 'is-inactive'}" data-print-recipe="${recipe.product_id}">
          <h3>${escapeHtml(recipe.name)}</h3>
          <label>Nombre del servicio<input data-recipe-field="name" type="text" maxlength="80" value="${escapeHtml(recipe.name)}"></label>
          <label>Precio de 1 unidad<input data-recipe-field="price" type="number" min="0" step=".01" value="${Number(recipe.regular_price ?? recipe.price ?? 0)}"></label>
          <label>Aplicar precio bajo desde<input data-recipe-field="bulkFrom" type="number" min="0" step="1" value="${bulkFrom}"></label>
          <label>Precio por unidad desde esa cantidad<input data-recipe-field="bulkPrice" type="number" min="0" step=".01" value="${bulkPrice}"></label>
          <label>Papel utilizado<select data-recipe-field="paperSupplyType">${paperOptions(selectedPaper)}</select></label>
          <label>Tipo de trabajo<select data-recipe-field="outputType">${printCatalogOptions(data.catalog?.outputTypes || [], recipe.output_type || 'DOCUMENT')}</select></label>
          <label>Color<select data-recipe-field="colorMode">${printCatalogOptions(data.catalog?.colorModes || [], recipe.color_mode || 'COLOR')}</select></label>
          <label>Calidad<select data-recipe-field="printQuality">${printCatalogOptions(data.catalog?.qualities || [], recipe.print_quality || 'STANDARD')}</select></label>
          <label>Cobertura<select data-recipe-field="coverageProfile">${printCatalogOptions(data.catalog?.coverages || [], recipe.coverage_profile || 'MEDIUM')}</select></label>
          <label>Hojas por unidad<input data-recipe-field="paperSheets" type="number" min="0" step=".1" value="${Number(recipe.paper_sheets || 1)}"></label>
          <label>Reserva/merma %<input data-recipe-field="wastePercent" type="number" min="0" max="100" value="${Number(recipe.waste_percent || 15)}"></label>
          <label class="owner-print-active"><input data-recipe-field="borderless" type="checkbox" ${recipe.borderless ? 'checked' : ''}><span>Sin bordes</span></label>
          <label class="owner-print-active"><input data-recipe-field="isActive" type="checkbox" ${isActive ? 'checked' : ''}><span>Disponible en Venta rápida</span></label>
          <details class="owner-print-advanced"><summary>Ajuste avanzado de tinta</summary><label class="owner-print-active"><input data-recipe-field="autoInkEstimate" type="checkbox" ${autoInk ? 'checked' : ''}><span>Calcular automáticamente</span></label><label>Consumo tinta negra<input data-recipe-field="blackInkUnits" type="number" min="0" step=".001" value="${Number(recipe.black_ink_units || 0)}" ${autoInk ? 'disabled' : ''}></label><label>Consumo tinta color<input data-recipe-field="colorInkUnits" type="number" min="0" step=".001" value="${Number(recipe.color_ink_units || 0)}" ${autoInk ? 'disabled' : ''}></label></details>
          <small class="owner-print-cost-note">Costo estimado ${printUnitMoney(calculation.estimatedUnitCost)} · Capacidad ${Number(calculation.estimatedCapacity || 0)}${calculation.limitingSupply ? ` · limita ${escapeHtml(calculation.limitingSupply)}` : ''}</small>
          <small class="owner-print-price-note">${bulkFrom >= 2 ? `Desde ${bulkFrom}: ${printUnitMoney(bulkPrice)} cada una` : 'Sin precio especial por cantidad'}</small>
        </div>
      `;
    }).join('');
  }

  renderPrinterMaintenance(data.maintenance || {});
}

async function loadOwnerPrinting() {
  try {
    renderOwnerPrinting(await ownerApi('/printing'));
  } catch (error) {
    alert(error.message);
  }
}

async function saveOwnerPrinting() {
  const supplies = [...document.querySelectorAll('[data-print-supply]')].map((element) => ({
    supplyType: element.dataset.printSupply,
    supplyGroup: element.querySelector('[data-print-field="supplyGroup"]')?.value || '',
    displayName: element.querySelector('[data-print-field="displayName"]').value.trim(),
    mediaProfile: element.querySelector('[data-print-field="mediaProfile"]')?.value || null,
    paperSize: element.querySelector('[data-print-field="paperSize"]')?.value || null,
    paperBrand: element.querySelector('[data-print-field="paperBrand"]')?.value?.trim() || '',
    purchaseQuantity: 1,
    purchaseCost: Number(element.querySelector('[data-print-field="purchaseCost"]').value || 0),
    yieldUnits: Number(element.querySelector('[data-print-field="yieldUnits"]').value || 1),
    remainingUnits: Number(element.querySelector('[data-print-field="remainingUnits"]').value || 0),
    lowLevelUnits: Number(element.querySelector('[data-print-field="lowLevelUnits"]').value || 0)
  }));
  const recipes = [...document.querySelectorAll('[data-print-recipe]')].map((element) => ({
    productId: element.dataset.printRecipe,
    name: element.querySelector('[data-recipe-field="name"]').value.trim(),
    price: Number(element.querySelector('[data-recipe-field="price"]').value || 0),
    bulkFrom: Number(element.querySelector('[data-recipe-field="bulkFrom"]').value || 0),
    bulkPrice: Number(element.querySelector('[data-recipe-field="bulkPrice"]').value || 0),
    paperSupplyType: element.querySelector('[data-recipe-field="paperSupplyType"]').value,
    paperSheets: Number(element.querySelector('[data-recipe-field="paperSheets"]').value || 0),
    outputType: element.querySelector('[data-recipe-field="outputType"]').value,
    colorMode: element.querySelector('[data-recipe-field="colorMode"]').value,
    printQuality: element.querySelector('[data-recipe-field="printQuality"]').value,
    coverageProfile: element.querySelector('[data-recipe-field="coverageProfile"]').value,
    borderless: element.querySelector('[data-recipe-field="borderless"]').checked,
    autoInkEstimate: element.querySelector('[data-recipe-field="autoInkEstimate"]').checked,
    blackInkUnits: Number(element.querySelector('[data-recipe-field="blackInkUnits"]').value || 0),
    colorInkUnits: Number(element.querySelector('[data-recipe-field="colorInkUnits"]').value || 0),
    wastePercent: Number(element.querySelector('[data-recipe-field="wastePercent"]').value || 0),
    isActive: element.querySelector('[data-recipe-field="isActive"]').checked
  }));

  await ownerApi('/printing', { method: 'PUT', body: JSON.stringify({ supplies, recipes }) });
  await loadOwnerPrinting();
  alert('Impresiones actualizadas');
}

async function createOwnerPrintingService(event) {
  event?.preventDefault();
  const payload = {
    name: $('#ownerNewPrintName')?.value?.trim() || '',
    price: Number($('#ownerNewPrintPrice')?.value || 0),
    bulkFrom: Number($('#ownerNewPrintBulkFrom')?.value || 0),
    bulkPrice: Number($('#ownerNewPrintBulkPrice')?.value || 0),
    paperSupplyType: $('#ownerNewPrintPaperSupply')?.value || 'PAPER',
    paperSheets: Number($('#ownerNewPrintPaperSheets')?.value || 1),
    outputType: $('#ownerNewPrintOutputType')?.value || 'DOCUMENT',
    colorMode: $('#ownerNewPrintColorMode')?.value || 'COLOR',
    printQuality: $('#ownerNewPrintQuality')?.value || 'STANDARD',
    coverageProfile: $('#ownerNewPrintCoverage')?.value || 'MEDIUM',
    borderless: Boolean($('#ownerNewPrintBorderless')?.checked),
    autoInkEstimate: Boolean($('#ownerNewPrintAutoInk')?.checked),
    blackInkUnits: Number($('#ownerNewPrintBlackInk')?.value || 0),
    colorInkUnits: Number($('#ownerNewPrintColorInk')?.value || 0),
    wastePercent: Number($('#ownerNewPrintWaste')?.value || 15),
    isActive: true
  };
  if (!payload.name) return alert('Escribe el nombre del servicio.');

  const button = $('#createOwnerPrintingServiceBtn');
  if (button) button.disabled = true;
  try {
    await ownerApi('/printing/services', { method: 'POST', body: JSON.stringify(payload) });
    $('#ownerNewPrintServiceForm')?.reset();
    if ($('#ownerNewPrintBulkFrom')) $('#ownerNewPrintBulkFrom').value = '2';
    if ($('#ownerNewPrintPaperSheets')) $('#ownerNewPrintPaperSheets').value = '1';
    if ($('#ownerNewPrintAutoInk')) $('#ownerNewPrintAutoInk').checked = true;
    toggleManualInkFields($('#ownerNewPrintServiceForm'), true);
    if ($('#ownerNewPrintWaste')) $('#ownerNewPrintWaste').value = '15';
    await loadOwnerPrinting();
    alert('Servicio de impresión creado');
  } finally {
    if (button) button.disabled = false;
  }
}

async function createOwnerPrintingSupply(event) {
  event?.preventDefault();
  const quantity = Math.max(1, Number($('#ownerNewPrintSupplyQuantity')?.value || 1));
  const payload = {
    mediaProfile: $('#ownerNewPrintMediaProfile')?.value || 'CUSTOM_COMPATIBLE',
    paperSize: $('#ownerNewPrintPaperSize')?.value || 'LETTER',
    paperBrand: $('#ownerNewPrintSupplyBrand')?.value?.trim() || '',
    purchaseCost: Number($('#ownerNewPrintSupplyCost')?.value || 0),
    yieldUnits: quantity,
    remainingUnits: quantity,
    lowLevelUnits: Number($('#ownerNewPrintSupplyLowLevel')?.value || 0),
    isActive: true
  };
  const button = $('#createOwnerPrintingSupplyBtn');
  if (button) button.disabled = true;
  try {
    await ownerApi('/printing/supplies', { method: 'POST', body: JSON.stringify(payload) });
    $('#ownerNewPrintSupplyForm')?.reset();
    if ($('#ownerNewPrintSupplyQuantity')) $('#ownerNewPrintSupplyQuantity').value = '20';
    if ($('#ownerNewPrintSupplyLowLevel')) $('#ownerNewPrintSupplyLowLevel').value = '5';
    await loadOwnerPrinting();
    alert('Papel y compra registrados');
  } finally {
    if (button) button.disabled = false;
  }
}

function updatePrinterMaintenanceForm() {
  const type = $('#ownerPrinterMaintenanceType')?.value || 'NOZZLE_CHECK';
  $('#ownerPrinterMaintenanceResultLabel')?.classList.toggle('hidden', type !== 'NOZZLE_CHECK');
  $('#ownerPowerCleaningSafety')?.classList.toggle('hidden', type !== 'POWER_CLEANING');
  if (type !== 'POWER_CLEANING' && $('#ownerPowerCleaningConfirmed')) $('#ownerPowerCleaningConfirmed').checked = false;
}

async function createPrinterMaintenanceEvent(event) {
  event?.preventDefault();
  const type = $('#ownerPrinterMaintenanceType')?.value || 'NOZZLE_CHECK';
  const payload = {
    eventType: type,
    result: type === 'NOZZLE_CHECK' ? $('#ownerPrinterMaintenanceResult')?.value : null,
    printerSheetCounter: $('#ownerPrinterSheetCounter')?.value || null,
    notes: $('#ownerPrinterMaintenanceNotes')?.value?.trim() || '',
    safetyConfirmed: type === 'POWER_CLEANING' ? Boolean($('#ownerPowerCleaningConfirmed')?.checked) : false
  };
  if (type === 'POWER_CLEANING' && !payload.safetyConfirmed) return alert('Confirma primero las condiciones de seguridad indicadas por Epson.');
  const result = await ownerApi('/printing/maintenance', { method: 'POST', body: JSON.stringify(payload) });
  if ($('#ownerPrinterSheetCounter')) $('#ownerPrinterSheetCounter').value = '';
  if ($('#ownerPrinterMaintenanceNotes')) $('#ownerPrinterMaintenanceNotes').value = '';
  if ($('#ownerPowerCleaningConfirmed')) $('#ownerPowerCleaningConfirmed').checked = false;
  renderPrinterMaintenance(result.maintenance || {});
  await loadOwnerInventoryAlerts();
  alert('Mantenimiento Epson registrado');
}

async function savePrinterMaintenanceSettings(event) {
  event?.preventDefault();
  const result = await ownerApi('/printing/maintenance/settings', {
    method: 'PUT',
    body: JSON.stringify({
      nozzleCheckDays: Number($('#ownerNozzleCheckDays')?.value || 30),
      nozzleCheckSheets: Number($('#ownerNozzleCheckSheets')?.value || 500),
      inactivityDays: Number($('#ownerPrinterInactivityDays')?.value || 14),
      exteriorCleaningDays: Number($('#ownerExteriorCleaningDays')?.value || 120)
    })
  });
  renderPrinterMaintenance(result.maintenance || {});
  await loadOwnerInventoryAlerts();
  alert('Recordatorios de mantenimiento actualizados');
}

function renderOwnerPosDevices(devices=[]) {
  const list=$('#ownerPosDevicesList'); if(!list)return;
  list.innerHTML=devices.length?devices.map(device=>`<div class="owner-device-row ${device.is_active?'active':'revoked'}"><span><strong>${escapeHtml(device.device_name||'Dispositivo POS')}</strong><small>${escapeHtml(device.last_ip||'IP no disponible')} · Última conexión ${dateTimeLabel(device.last_seen_at)||'Sin datos'} · Vence ${dateTimeLabel(device.expires_at)||'Sin fecha'}</small></span><b>${device.is_active?'Activo':'Revocado'}</b>${device.is_active?`<button type="button" data-revoke-pos-device="${device.id}" class="danger-lite">Revocar</button>`:''}</div>`).join(''):'<div class="empty-state compact">No hay dispositivos registrados.</div>';
}
async function loadOwnerPosSecurity(){try{const data=await ownerApi('/pos-security');if($('#ownerRemoteModeSelect'))$('#ownerRemoteModeSelect').value=data.settings?.remoteMode||'READ_ONLY';if($('#ownerRemoteRememberDaysSelect'))$('#ownerRemoteRememberDaysSelect').value=String(data.settings?.rememberDays||7);renderOwnerPosDevices(data.devices||[]);}catch(error){renderOwnerPosDevices([]);alert(error.message);}}
async function saveOwnerPosSecurity(){await ownerApi('/pos-security',{method:'PUT',body:JSON.stringify({remoteMode:$('#ownerRemoteModeSelect')?.value,rememberDays:Number($('#ownerRemoteRememberDaysSelect')?.value||7)})});await loadOwnerPosSecurity();}
async function revokeOwnerPosDevice(id){if(!confirm('¿Revocar este dispositivo? Tendrá que autorizarse nuevamente.'))return;await ownerApi(`/pos-security/devices/${id}`,{method:'DELETE'});await loadOwnerPosSecurity();}
async function revokeAllOwnerPosDevices(){if(!confirm('¿Cerrar el acceso de todos los dispositivos autorizados?'))return;await ownerApi('/pos-security/devices',{method:'DELETE'});await loadOwnerPosSecurity();}

function ownerAlertEmpty(message) {
  return `<div class="owner-alert-empty">${escapeHtml(message)}</div>`;
}

function renderOwnerInventoryAlerts(data = {}) {
  ownerState.inventoryAlerts = data;
  const summary = data.summary || {};
  const total = Number(summary.totalAlerts || 0);
  const badge = $('#ownerInventoryAlertBadge');
  if (badge) {
    badge.textContent = String(total);
    badge.classList.toggle('hidden', total <= 0);
  }
  const totalLabel = $('#ownerInventoryAlertTotal');
  if (totalLabel) totalLabel.textContent = total === 1 ? '1 alerta' : `${total} alertas`;
  const summaryLabel = $('#ownerInventoryAlertSummary');
  if (summaryLabel) summaryLabel.textContent = total > 0
    ? `${Number(summary.outOfStock || 0)} agotados · ${Number(summary.urgent || 0)} urgentes · ${Number(summary.orderSoon || 0)} por ordenar`
    : 'Todo está bajo control por ahora';

  const cards = $('#ownerInventoryAlertCards');
  if (cards) cards.innerHTML = [
    ['Agotados', summary.outOfStock || 0, 'danger'],
    ['Ordenar ahora', summary.urgent || 0, 'danger'],
    ['Ordenar pronto', summary.orderSoon || 0, 'warning'],
    ['Sin movimiento', summary.stagnant || 0, 'warning'],
    ['Impresión baja', summary.printSupplies || 0, 'info'],
    ['Mantenimiento Epson', summary.maintenanceAlerts || 0, 'info'],
    ['Inversión sugerida', money(summary.suggestedInvestment), 'info']
  ].map(([label, value, tone]) => `<article class="${tone}"><span>${escapeHtml(label)}</span><strong>${value}</strong></article>`).join('');

  const reorder = $('#ownerInventoryReorderAlerts');
  const reorderRows = data.reorder || [];
  if (reorder) reorder.innerHTML = reorderRows.length ? reorderRows.map((row) =>
    `<div><span><strong>${escapeHtml(row.product_name)}</strong><small>${ownerReorderStatus(row.reorder_status)} · Stock ${Number(row.stock_qty || 0)}${row.days_remaining == null ? '' : ` · ${Number(row.days_remaining).toFixed(1)} días`}</small></span><b>Pedir ${Number(row.suggested_order_qty || 0)}</b></div>`
  ).join('') : ownerAlertEmpty('No hay productos por ordenar.');

  const stagnant = $('#ownerInventoryStagnantAlerts');
  const stagnantRows = data.stagnant || [];
  if (stagnant) stagnant.innerHTML = stagnantRows.length ? stagnantRows.map((row) =>
    `<div><span><strong>${escapeHtml(row.product_name)}</strong><small>${ownerMovementStatus(row.movement_status)} · Stock ${Number(row.stock_qty || 0)}</small></span><b>Revisar</b></div>`
  ).join('') : ownerAlertEmpty('No hay productos detenidos.');

  const supplyLabels = { PAPER: 'Papel carta', BLACK_INK: 'Tinta negra T544', COLOR_INK: 'Tintas color T544' };
  const supplies = $('#ownerPrintSupplyAlerts');
  const supplyRows = data.printSupplies || [];
  if (supplies) {
    const maintenanceRows = data.printerMaintenance?.alerts || [];
    supplies.classList.toggle('hidden', supplyRows.length === 0 && maintenanceRows.length === 0);
    supplies.innerHTML = supplyRows.map((row) => `<div><strong>${escapeHtml(row.display_name || supplyLabels[row.supply_type] || row.supply_type)}</strong><span>Quedan ${Number(row.remaining_units || 0).toFixed(2)} ${escapeHtml(row.unit_label || '')} · alerta en ${Number(row.low_level_units || 0).toFixed(2)}</span></div>`).join('')
      + maintenanceRows.map((row) => `<div><strong>${escapeHtml(row.title)}</strong><span>${escapeHtml(row.detail)}</span></div>`).join('');
  }
  renderPrinterMaintenance(data.printerMaintenance || ownerState.printingData?.maintenance || {});
}

async function loadOwnerInventoryAlerts() {
  try {
    renderOwnerInventoryAlerts(await ownerApi('/inventory-alerts'));
  } catch (_error) {
    const label = $('#ownerInventoryAlertSummary');
    if (label) label.textContent = 'No se pudieron actualizar las alertas';
  }
}

function ownerReportPreset(preset = 'today') {
  const now = new Date(); const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()); const end = new Date(start);
  if (preset === 'yesterday') { start.setDate(start.getDate() - 1); end.setDate(end.getDate() - 1); }
  if (preset === 'week') { const day = start.getDay() || 7; start.setDate(start.getDate() - day + 1); }
  if (preset === 'month') start.setDate(1);
  return { preset, startDate: localDateOnly(start), endDate: localDateOnly(end), startTime: '00:00', endTime: '23:59' };
}

function ownerReportList(title, rows = [], renderer) {
  return `<article class="owner-report-panel"><h3>${escapeHtml(title)}</h3><div class="owner-report-list">${rows.length ? rows.map(renderer).join('') : '<div class="owner-report-empty">Sin datos</div>'}</div></article>`;
}
function ownerReportCards(cards = []) {
  return `<div class="owner-report-cards">${cards.map(([label, value]) => `<article><span>${escapeHtml(label)}</span><strong>${value}</strong></article>`).join('')}</div>`;
}
function ownerReportRow(label, detail, value = '') {
  return `<div class="owner-report-row"><span><strong>${escapeHtml(label || 'Sin nombre')}</strong>${detail ? `<small>${escapeHtml(detail)}</small>` : ''}</span>${value ? `<b>${value}</b>` : ''}</div>`;
}
function ownerAuditLabel(type = '') {
  const labels = { SALE_CREATED: 'Venta registrada', STATION_STARTED: 'Estación iniciada', STATION_ENDED: 'Estación cerrada', STATION_CHARGED: 'Estación cobrada', DRAWER_OPENED: 'Caja abierta', DRAWER_CLOSED: 'Caja cerrada', DRAWER_MOVEMENT: 'Movimiento de caja', TOURNAMENT_PRIZE_DELIVERED: 'Premio entregado', QUICK_SALE: 'Venta rápida' };
  return labels[String(type).toUpperCase()] || 'Acción operativa';
}
function ownerStatusLabel(value = '') {
  const labels={OPEN:'Abierto',CLOSED:'Cerrado',PAID:'Pagado',PENDING:'Pendiente',FINISHED:'Finalizado',ACTIVE:'Activo',CANCELED:'Cancelado',DELIVERED:'Entregado'};
  return labels[String(value).toUpperCase()]||'Registrado';
}
function ownerMembershipLabel(value='') {
  const labels={GAMER:'Gamer',GAMER_PRO:'Gamer Pro',CHAMPION:'Champion'};
  return labels[String(value).toUpperCase()]||'Membresía';
}
function ownerReorderStatus(value='') {
  const labels={OUT_OF_STOCK:'Agotado',URGENT:'Urgente',ORDER_SOON:'Ordenar pronto',HEALTHY:'Saludable',NO_HISTORY:'Sin historial'};
  return labels[String(value).toUpperCase()]||'Revisar';
}
function ownerMovementStatus(value='') {
  const labels={NEVER_SOLD:'Nunca vendido',NO_MOVEMENT_30:'Sin movimiento por 30+ días',NO_MOVEMENT_15:'Sin movimiento por 15+ días',NO_MOVEMENT_7:'Sin movimiento por 7+ días',EXCESS_STOCK:'Exceso de inventario',MOVING:'Se está moviendo'};
  return labels[String(value).toUpperCase()]||'Revisar';
}
function ownerOpportunityLabel(value='') {
  const labels={PROMOTE_OR_COMBO:'Promocionar o incluir en combo',STOP_REORDER_AND_PROMOTE:'No volver a ordenar y promocionar',REDUCE_NEXT_ORDER:'Reducir la próxima compra',REDUCE_EXCESS:'Reducir el exceso antes de comprar',MONITOR:'Continuar observando'};
  return labels[String(value).toUpperCase()]||'Revisar producto';
}

function renderOwnerReportSection() {
  const content = $('#ownerReportContent'); if (!content) return;
  const d = ownerState.reportData || {}; const tab = ownerState.reportTab || 'sales';
  const s = d.sales || {}, sessions = d.sessions || {}, drawer = d.drawer || {}, expenses = d.expenseSummary || {};
  const headings = {
    sales: ['Reportes de ventas', 'Resumen del período, productos, categorías, estaciones y cajeros.'], cash: ['Reportes de caja / pagos', 'Caja, transferencias, pendientes y sesiones cerradas.'],
    inventory: ['Rendimiento del inventario', 'Ingresos netos, costos, ganancia bruta y margen por producto.'],
    expenses: ['Reportes de gastos', 'Gastos del período por categoría, tipo y método de pago.'], tournaments: ['Reportes de torneos', 'Inscripciones, premios y resultados.'],
    games: ['Reportes por juego', 'Juegos jugados, solicitudes, demanda y copias.'], extras: ['Reportes de extras', 'Racing Wheel, VR, Streaming y otros extras.'],
    points: ['Puntos / Bonos', 'Puntos ganados, canjes, bonos y recompensas.'], employees: ['Reportes de empleados', 'Ventas y acciones por cajero.'],
    members: ['Reportes de miembros', 'Membresías, cuentas y actividad.'], audit: ['Auditoría', 'Historial completo de acciones operativas.']
    ,printing: ['Reporte de impresiones', 'Páginas, hojas, costos estimados, ingresos y ganancias.']
  };
  let body = '';
  if (tab === 'sales') body = ownerReportCards([['Total vendido', money(s.total_sales)], ['Efectivo', money(s.cash_sales)], ['Transferencias', money(s.transfer_sales)], ['Sesiones', sessions.session_count || 0], ['Minutos', sessions.total_minutes || 0], ['Bonos usados', d.bonuses?.used_count || 0], ['Desc. familiares', money(d.familyDiscountSummary?.discount_amount)]]) +
    `<div class="owner-report-grid">${ownerReportList('Ventas por categoría', d.categorySales || [], r => ownerReportRow(r.category, `${Number(r.qty || 0)} unidades`, money(r.total)))}${ownerReportList('Ventas por fecha', d.dailySales || [], r => ownerReportRow(String(r.sale_date || '').slice(0,10), `${r.sale_count || 0} ventas`, money(r.total)))}${ownerReportList('Ventas por estación', d.stationSales || [], r => ownerReportRow(r.station_name, `${r.session_count || 0} sesiones · ${r.total_minutes || 0} min`, money(r.total)))}${ownerReportList('Top vendidos', d.topProducts || [], r => ownerReportRow(r.description, `${Number(r.qty || 0)} vendidos`, money(r.total)))}${ownerReportList('Ventas por cajero', d.cashierSales || [], r => ownerReportRow(r.cashier_name || r.employee_name, `${r.sale_count || 0} ventas`, money(r.total)))}${ownerReportList('Descuentos familiares', d.familyDiscountRows || [], r => ownerReportRow(r.code, `${r.discount_percent || 0}% · ${r.usage_count || 0} usos`, `-${money(r.discount_amount)}`))}</div>`;
  if (tab === 'inventory') { const inv=d.inventoryPerformanceSummary||{}, products=d.inventoryPerformanceProducts||[], reorder=d.reorderSummary||{}, recommendations=d.reorderRecommendations||[]; body=ownerReportCards([
    ['Ingresos de productos',money(inv.net_revenue)],['Costo vendido',money(inv.cost_of_goods)],['Ganancia bruta',money(inv.gross_profit)],
    ['Margen bruto',`${Number(inv.margin_percent||0).toFixed(1)}%`],['Inventario al costo',money(inv.inventory_cost_value)],['Valor potencial',money(inv.inventory_retail_value)],
    ['Unidades vendidas',Number(inv.units_sold||0).toLocaleString('en-US')],['Productos sin costo',Number(inv.products_without_cost||0)]
  ])+`${Number(inv.estimated_products||0)>0?`<div class="owner-report-estimate-note">Histórico estimado: ${Number(inv.estimated_products)} producto(s) se calcularon con el costo actual porque fueron vendidos antes de guardar costos por venta.</div>`:''}<section class="owner-reorder-summary"><header><div><h3>Reposición inteligente</h3><p>Calculada con el consumo real de 7, 30 y 90 días, incluyendo artículos usados dentro de combos.</p></div></header>${ownerReportCards([['Agotados',reorder.out_of_stock||0],['Urgentes',reorder.urgent||0],['Ordenar pronto',reorder.order_soon||0],['Stock saludable',reorder.healthy||0],['Unidades sugeridas',reorder.suggested_units||0],['Inversión sugerida',money(reorder.suggested_investment)]])}</section><div class="owner-report-grid">${ownerReportList('Qué debo ordenar',recommendations.filter(r=>['OUT_OF_STOCK','URGENT','ORDER_SOON'].includes(r.reorder_status)),r=>ownerReportRow(r.product_name,`${ownerReorderStatus(r.reorder_status)} · Stock ${r.stock_qty} · ${r.days_remaining==null?'sin consumo calculado':`${Number(r.days_remaining).toFixed(1)} días restantes`} · Suplidor ${r.supplier_lead_days} días`,`Pedir ${r.suggested_order_qty}`))}${ownerReportList('Uso y cobertura',recommendations,r=>ownerReportRow(r.product_name,`${ownerReorderStatus(r.reorder_status)} · 7d: ${Number(r.used_7_days||0)} · 30d: ${Number(r.used_30_days||0)} · 90d: ${Number(r.used_90_days||0)}`,r.days_remaining==null?'Sin historial':`${Number(r.days_remaining).toFixed(1)} días`))}${ownerReportList('Ganancia por producto',products,r=>ownerReportRow(r.product_name,`${Number(r.units_sold||0)} vendidos · Ingresos ${money(r.net_revenue)} · Costo ${money(r.cost_of_goods)}${r.has_estimated_cost?' · Estimado':''}`,`${money(r.gross_profit)} · ${Number(r.margin_percent||0).toFixed(1)}%`))}${ownerReportList('Rendimiento por categoría',d.inventoryCategoryPerformance||[],r=>ownerReportRow(r.category_name,`${Number(r.units_sold||0)} vendidos · Ingresos ${money(r.net_revenue)} · Costo ${money(r.cost_of_goods)}`,money(r.gross_profit)))}</div>${(()=>{const slow=d.stagnantSummary||{},rows=d.stagnantProducts||[],attention=rows.filter(r=>r.movement_status!=='MOVING');return `<section class="owner-opportunity-summary"><header><div><h3>Productos estancados y oportunidades</h3><p>Capital detenido, exceso de stock y acciones recomendadas.</p></div></header>${ownerReportCards([['Requieren atención',slow.attention_count||0],['Nunca vendidos',slow.never_sold||0],['Sin movimiento 30+ días',slow.no_movement_30||0],['Sin movimiento 15+ días',slow.no_movement_15||0],['Exceso de stock',slow.excess_stock||0],['Capital detenido',money(slow.stagnant_capital)]])}<div class="owner-report-grid">${ownerReportList('Qué no se está moviendo',attention,r=>ownerReportRow(r.product_name,`${ownerMovementStatus(r.movement_status)} · Stock ${r.stock_qty} · Último movimiento ${r.last_movement_at?dateTimeLabel(r.last_movement_at):'Nunca'}`,money(r.capital_in_stock)))}${ownerReportList('Acciones recomendadas',attention,r=>ownerReportRow(r.product_name,`${ownerOpportunityLabel(r.recommendation_code)} · ${Number(r.units_30_days||0)} unidades en 30 días`,r.coverage_days==null?'Sin cobertura':`${Number(r.coverage_days).toFixed(0)} días de stock`))}</div></section>`;})()}`; }
  if (tab === 'cash') body = ownerReportCards([['Estado', drawer.status === 'OPEN' ? 'Abierta' : 'Cerrada'], ['Monto inicial', money(drawer.opening_amount)], ['Efectivo esperado', money(drawer.expected_cash)], ['Diferencia', money(drawer.cash_difference)], ['Pendiente', money(d.pendingAccounts?.pending_total)], ['Cuentas abiertas', d.pendingAccounts?.account_count || 0]]) + `<div class="owner-report-grid">${ownerReportList('Movimientos de caja', drawer.movements || [], r => ownerReportRow(r.reason || (r.type === 'OUT' ? 'Salida' : 'Entrada'), `${dateTimeLabel(r.created_at)} · ${r.user_name || 'Empleado'}`, `${r.type === 'OUT' ? '-' : '+'}${money(r.amount)}`))}${ownerReportList('Transferencias', d.transfers || [], r => ownerReportRow(r.member_name || 'Venta general', `${dateTimeLabel(r.created_at)} · ${r.cashier_name || 'Cajero'}`, money(r.total)))}${ownerReportList('Cuentas abiertas', d.openAccounts || [], r => ownerReportRow(r.station_name, r.member_name || 'General', money(r.pending_total)))}${ownerReportList('Sesiones cerradas', d.closedSessions || [], r => ownerReportRow(r.station_name, `${dateTimeLabel(r.ended_at)} · ${r.total_minutes || 0} min`, money(r.total_amount)))}</div>`;
  if (tab === 'expenses') body = ownerReportCards([['Total gastos', money(expenses.total_expenses)], ['Cantidad', expenses.expense_count || 0], ['Fijos', money(expenses.fixed_expenses)], ['Variables', money(expenses.variable_expenses)], ['Efectivo', money(expenses.cash_expenses)], ['Transferencia', money(expenses.transfer_expenses)]]) + `<div class="owner-report-grid">${ownerReportList('Gastos por categoría', d.financeExpenses || [], r => ownerReportRow(r.category || 'General', `${r.expense_count || r.count || 0} gastos`, money(r.total || r.amount)))}${ownerReportList('Gastos recientes', d.recentExpenses || [], r => ownerReportRow(r.name || r.description || 'Gasto', `${String(r.expense_date || '').slice(0,10)} · ${paymentLabel(r.payment_method)}`, money(r.amount)))}</div>`;
  if (tab === 'tournaments') { const t=d.tournamentReportSummary||{}; body=ownerReportCards([['Torneos',t.tournament_count||0],['Finalizados',t.finished_count||0],['Participantes',t.participant_count||0],['Inscripciones pagas',t.paid_entry_count||0],['Ingresos',money(t.entry_revenue)],['Premios',t.award_count||0]])+`<div class="owner-report-grid">${ownerReportList('Inscripciones por torneo',d.tournamentEntrySalesReport||[],r=>ownerReportRow(r.tournament_name||r.name,`${r.entry_count||r.sale_count||0} inscripciones`,money(r.total||r.revenue)))}${ownerReportList('Torneos del período',d.tournamentsReport||[],r=>ownerReportRow(r.name,ownerStatusLabel(r.status),`${r.participant_count||0} participantes`))}${ownerReportList('Premios registrados',d.tournamentAwardsReport||[],r=>ownerReportRow(r.member_name||r.participant_name||'Ganador',`${r.tournament_name||'Torneo'} · Premio`,r.cash_amount?money(r.cash_amount):''))}</div>`; }
  if (tab === 'games') { const g=d.gameReportSummary||{}; body=ownerReportCards([['Partidas con juego',g.played_sessions||0],['Minutos jugados',g.played_minutes||0],['Juegos usados',g.games_played||0],['Solicitudes',g.request_count||0],['No disponibles',g.unavailable_requests||0],['Se fueron',g.left_count||0]])+`<div class="owner-report-grid">${ownerReportList('Juegos más jugados',d.topGamesReport||[],r=>ownerReportRow(r.game_name,`${r.session_count||0} partidas · ${r.total_minutes||0} min`,''))}${ownerReportList('Juegos por plataforma',d.gamePlatformReport||[],r=>ownerReportRow(r.platform,`${r.session_count||0} partidas · ${r.total_minutes||0} min`,''))}${ownerReportList('Juegos por miembro',d.memberGameReport||[],r=>ownerReportRow(r.member_name,r.game_name||'Juego',`${r.session_count||0} partidas`))}${ownerReportList('Juegos más solicitados',d.requestedGamesReport||[],r=>ownerReportRow(r.game_name||r.requested_game_name,r.platform||'Sin plataforma',`${r.request_count||0} solicitudes`))}${ownerReportList('Recomendación de copias',d.copyRecommendationReport||[],r=>ownerReportRow(r.game_name,`${r.unavailable_count||0} veces no disponible`,r.recommendation||'Revisar'))}</div>`; }
  if (tab === 'extras') body=ownerReportCards([['Extras vendidos',(d.extraSales||[]).reduce((a,r)=>a+Number(r.qty||0),0)],['Ingresos',(money((d.extraSales||[]).reduce((a,r)=>a+Number(r.total||0),0)))]])+`<div class="owner-report-grid">${ownerReportList('Extras vendidos',d.extraSales||[],r=>ownerReportRow(r.extra_name,`${r.qty||0} usos · ${r.sale_count||0} ventas`,money(r.total)))}${ownerReportList('Extras por estación',d.extraStationSales||[],r=>ownerReportRow(r.station_name,`${r.extra_name||'Extra'} · ${r.qty||0} usos`,money(r.total)))}</div>`;
  if (tab === 'points') { const p=d.pointsSummary||{}, rewards=d.rewardSummary||{}; body=ownerReportCards([['Puntos ganados',p.earned_points||0],['Puntos usados',p.spent_points||0],['Puntos ranking',p.ranking_points||0],['Movimientos',p.movement_count||0],['Recompensas usadas',rewards.used_count||0],['Bonos usados',d.bonuses?.used_count||0]])+`<div class="owner-report-grid">${ownerReportList('Puntos por categoría',d.pointsByCategory||[],r=>ownerReportRow(r.category,`${r.movement_count||0} movimientos`,`${r.earned_points||0} ganados · ${r.spent_points||0} usados`))}${ownerReportList('Movimientos recientes',d.recentPointMovements||[],r=>ownerReportRow(r.member_name,`${r.reason||'Movimiento'} · ${dateTimeLabel(r.created_at)}`,`${Number(r.points||0)>0?'+':''}${r.points||0}`))}${ownerReportList('Canjes de puntos',d.pointRedemptions||[],r=>ownerReportRow(r.member_name,r.reward_name||r.description||'Canje',`${r.points_spent||r.points||0} puntos`))}${ownerReportList('Recompensas utilizadas',d.rewardUsageByType||[],r=>ownerReportRow(r.reward_type||r.type,`${r.usage_count||r.count||0} usos`,''))}</div>`; }
  if (tab === 'employees') { const e=d.employeeReport?.totals||{}; body=ownerReportCards([['Empleados',e.employee_count||0],['Ventas',money(e.total_sales)],['Efectivo',money(e.cash_sales)],['Transferencias',money(e.transfer_sales)],['Minutos',e.minutes_handled||0],['Estaciones cobradas',e.stations_charged||0]])+ownerReportList('Rendimiento por empleado',d.employeeReport?.employees||[],r=>ownerReportRow(r.employee_name,`${r.sale_count||0} ventas · ${r.stations_charged||0} estaciones · ${r.minutes_handled||0} min`,money(r.total_sales))); }
  if (tab === 'members') body=ownerReportCards([['Membresías vendidas',(d.memberships||[]).reduce((a,r)=>a+Number(r.count||0),0)],['Cuentas abiertas',d.pendingAccounts?.account_count||0],['Pendiente',money(d.pendingAccounts?.pending_total)]])+`<div class="owner-report-grid">${ownerReportList('Membresías',d.memberships||[],r=>ownerReportRow(ownerMembershipLabel(r.tier),`${r.count||0} vendidas`,money(r.total)))}${ownerReportList('Cuentas de miembros',d.openAccounts||[],r=>ownerReportRow(r.member_name||'General',r.station_name||'Estación',money(r.pending_total)))}</div>`;
  if (tab === 'audit') body=ownerReportList('Historial de acciones',d.auditEvents||[],r=>ownerReportRow(ownerAuditLabel(r.event_type),`${dateTimeLabel(r.created_at)} · ${r.user_name||'Sistema'}${r.station_name?` · ${r.station_name}`:''}`,r.amount?money(r.amount):''));
  if(tab==='printing'){const p=d.printingReport||{};body=ownerReportCards([['Trabajos',p.job_count||0],['Páginas',p.printed_pages||0],['Hojas',p.paper_sheets||0],['Ingresos',money(p.revenue)],['Costo estimado',money(p.estimated_cost)],['Ganancia bruta',money(p.gross_profit)]])+ownerReportList('Rendimiento por servicio',d.printingByService||[],r=>ownerReportRow(({ 'PRINT-BW':'Blanco y negro','PRINT-COLOR-LIGHT':'Color liviano','PRINT-COLOR-FULL':'Color página completa','PRINT-ID':'Copia de cédula'})[r.service_code]||'Impresión',`${r.printed_pages||0} páginas · Costo ${money(r.estimated_cost)}`,`${money(r.gross_profit)} ganancia`));}
  content.innerHTML=`<header class="owner-report-section-title"><div><h2>${headings[tab][0]}</h2><p>${headings[tab][1]}</p></div></header>${body}`;
  document.querySelectorAll('[data-owner-report-tab]').forEach(b=>b.classList.toggle('active',b.dataset.ownerReportTab===tab));
}

async function loadOwnerReports() {
  const status=$('#ownerReportsStatus'); status?.classList.add('hidden');
  const range=ownerState.reportRange||ownerReportPreset('today'); ownerState.reportRange=range;
  ['StartDate','EndDate','StartTime','EndTime'].forEach(k=>{const el=$(`#ownerReport${k}`); if(el) el.value=range[k[0].toLowerCase()+k.slice(1)]||'';});
  document.querySelectorAll('[data-owner-report-preset]').forEach(b=>b.classList.toggle('active',b.dataset.ownerReportPreset===range.preset));
  const qs=new URLSearchParams({startDate:range.startDate,endDate:range.endDate,startTime:range.startTime,endTime:range.endTime});
  try { const [summary,employee,audit]=await Promise.all([ownerApi(`/reports/daily-summary?${qs}`),ownerApi(`/reports/employee-summary?${qs}`),ownerApi(`/reports/audit-events?${qs}&limit=250`)]); ownerState.reportData={...summary,employeeReport:employee,auditEvents:audit.events||[]}; renderOwnerReportSection(); ownerState.reportsLoaded=true; }
  catch(error){if(status){status.textContent=error.message||'No se pudieron cargar los reportes.';status.classList.remove('hidden');}}
}

async function ownerApi(path, options = {}) {
  const response = await fetch(`/api/owner-dashboard${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(ownerState.token ? { Authorization: `Bearer ${ownerState.token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || data.message || 'No se pudo completar la solicitud.');
  return data;
}

async function loginOwner(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  const errorBox = $('#ownerLoginError');
  const pin = $('#ownerPin')?.value || '';
  errorBox?.classList.add('hidden');
  button.disabled = true;
  try {
    const result = await ownerApi('/login', {
      method: 'POST',
      body: JSON.stringify({ pin })
    });
    ownerState.token = result.token;
    ownerState.user = result.user;
    localStorage.setItem('stationcore_owner_token', result.token);
    localStorage.setItem('stationcore_owner_user', JSON.stringify(result.user));
    $('#ownerPin').value = '';
    setVisible();
    await loadDashboard();
    startAutoRefresh();
  } catch (error) {
    if (errorBox) {
      errorBox.textContent = error.message;
      errorBox.classList.remove('hidden');
    }
  } finally {
    button.disabled = false;
  }
}

function logoutOwner() {
  ownerState.token = '';
  ownerState.user = null;
  localStorage.removeItem('stationcore_owner_token');
  localStorage.removeItem('stationcore_owner_user');
  clearInterval(ownerState.refreshTimer);
  setVisible();
}

function renderMetrics(data) {
  const label = rangeLabel(data);
  $('#metricTotalLabel').textContent = `Ventas · ${label}`;
  $('#metricTotal').textContent = money(data.sales?.total_sales);
  $('#metricSalesCount').textContent = `${data.sales?.sale_count || 0} ventas`;
  $('#metricCash').textContent = money(data.sales?.cash_sales);
  $('#metricCashCount').textContent = `${data.sales?.cash_count || 0} pagos`;
  $('#metricTransfer').textContent = money(data.sales?.transfer_sales);
  $('#metricTransferCount').textContent = `${data.sales?.transfer_count || 0} pagos`;
  $('#metricExpensesLabel').textContent = `Pagos · ${label}`;
  $('#metricExpenses').textContent = money(data.expenses?.total_expenses);
  $('#metricExpensesCount').textContent = `${data.expenses?.expense_count || 0} pagos`;
  $('#metricExpectedCash').textContent = money(data.drawer?.expected_cash || 0);
  const opening = money(data.drawer?.opening_amount || 0);
  const withdraw = money(data.drawer?.cash_to_withdraw || 0);
  $('#metricDrawerStatus').textContent = data.drawer?.status === 'OPEN'
    ? `Abierta · Fondo fijo ${opening} · Retirar ${withdraw}`
    : `Historial · Fondo fijo ${opening} · Retirar ${withdraw}`;
  $('#metricActiveStations').textContent = `${data.stationSummary?.active || 0}/${data.stationSummary?.total || 0}`;
  $('#metricStationStatus').textContent = `${data.stationSummary?.available || 0} disponibles`;
  $('#ownerPaymentsRangeLabel').textContent = label;
  $('#ownerRecentSalesRangeLabel').textContent = label;
  $('#ownerDrawerRangeLabel').textContent = label;
}

function ownerHourLabel(hour, includeEnd = false) {
  const start = new Date(2026, 0, 1, Number(hour || 0));
  const startLabel = start.toLocaleTimeString('es-DO', { hour: 'numeric' });
  if (!includeEnd) return startLabel;
  const end = new Date(start);
  end.setHours(end.getHours() + 1);
  return `${startLabel} – ${end.toLocaleTimeString('es-DO', { hour: 'numeric' })}`;
}

function ownerTrend(currentValue, previousValue, comparisonLabel) {
  const current = Number(currentValue || 0);
  const previous = Number(previousValue || 0);
  if (previous <= 0) {
    if (current > 0) return { className: 'up', text: `↑ Movimiento nuevo vs ${comparisonLabel}` };
    return { className: 'neutral', text: `Sin movimiento en ambos períodos` };
  }
  const percent = ((current - previous) / previous) * 100;
  const absolute = Math.abs(percent).toLocaleString('es-DO', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  if (Math.abs(percent) < .05) return { className: 'neutral', text: `→ Igual que ${comparisonLabel}` };
  return {
    className: percent > 0 ? 'up' : 'down',
    text: `${percent > 0 ? '↑' : '↓'} ${absolute}% vs ${comparisonLabel}`
  };
}

function setOwnerTrend(selector, currentValue, previousValue, comparisonLabel) {
  const element = $(selector);
  if (!element) return;
  const trend = ownerTrend(currentValue, previousValue, comparisonLabel);
  element.className = trend.className;
  element.textContent = trend.text;
}

function renderOwnerComparisonChart(comparison = {}) {
  const container = $('#ownerComparisonChart');
  if (!container) return;
  let points = Array.isArray(comparison.points) ? comparison.points : [];
  if (comparison.chartUnit === 'hour' && points.length) {
    const used = points.map((point, index) => ({ point, index })).filter(({ point }) => Number(point.current?.totalSales || 0) > 0 || Number(point.previous?.totalSales || 0) > 0);
    if (used.length) {
      const first = Math.max(0, used[0].index - 1);
      const last = Math.min(points.length - 1, used[used.length - 1].index + 1);
      points = points.slice(first, last + 1);
    }
  }
  const maxValue = Math.max(0, ...points.flatMap((point) => [Number(point.current?.totalSales || 0), Number(point.previous?.totalSales || 0)]));
  if (!points.length || maxValue <= 0) {
    container.innerHTML = '<div class="owner-comparison-empty">Todavía no hay ventas para graficar en estos períodos.</div>';
    return;
  }
  const minWidth = Math.max(520, points.length * 48);
  container.innerHTML = `<div class="owner-comparison-plot" style="min-width:${minWidth}px">${points.map((point) => {
    const current = Number(point.current?.totalSales || 0);
    const previous = Number(point.previous?.totalSales || 0);
    const currentHeight = current > 0 ? Math.max(2, (current / maxValue) * 100) : 0;
    const previousHeight = previous > 0 ? Math.max(2, (previous / maxValue) * 100) : 0;
    const title = `${point.label}: actual ${money(current)} · anterior ${money(previous)}`;
    return `<div class="owner-comparison-column" title="${escapeHtml(title)}">
      <div class="owner-comparison-bars">
        <i class="owner-comparison-bar current" style="height:${currentHeight}%"></i>
        <i class="owner-comparison-bar previous" style="height:${previousHeight}%"></i>
      </div>
      <small>${escapeHtml(point.label)}</small>
    </div>`;
  }).join('')}</div>`;
}

function ownerPeakScore(row, maxRevenue) {
  const utilization = Number(row.utilizationPercent || 0);
  const revenueWeight = maxRevenue > 0 ? (Number(row.averageRevenue || 0) / maxRevenue) * 100 : 0;
  return utilization * .7 + revenueWeight * .3;
}

function renderOwnerPeakHours(peakHours = {}) {
  const cards = $('#ownerPeakInsightCards');
  const grid = $('#ownerPeakHourGrid');
  const recommendation = $('#ownerPeakRecommendation');
  const status = $('#ownerPeakHoursStatus');
  const summary = $('#ownerPeakHoursSummary');
  const historyLabel = $('#ownerPeakHistoryLabel');
  const rows = Array.isArray(peakHours.hours) ? peakHours.hours : [];
  if (historyLabel) historyLabel.textContent = peakHours.historyLabel || 'Últimas ocho semanas';
  if (!peakHours.available || !rows.length) {
    if (cards) cards.innerHTML = '<div class="empty-state compact">Aún no hay suficientes turnos cerrados para calcular horas pico.</div>';
    if (grid) grid.innerHTML = '';
    if (recommendation) { recommendation.textContent = 'StationCore mostrará recomendaciones cuando exista historial suficiente.'; recommendation.classList.remove('hidden'); }
    if (status) status.textContent = 'Faltan datos';
    if (summary) summary.textContent = 'Se necesitan varios días abiertos para comparar horarios.';
    return;
  }

  const reliable = rows.filter((row) => Number(row.openDays || 0) >= 3);
  const candidates = reliable.length ? reliable : rows;
  const maxRevenue = Math.max(0, ...candidates.map((row) => Number(row.averageRevenue || 0)));
  const scored = candidates.map((row) => ({ ...row, score: ownerPeakScore(row, maxRevenue) })).sort((a, b) => b.score - a.score);
  const peak = scored[0];
  const slow = [...scored].sort((a, b) => a.score - b.score)[0];
  const sortedByHour = [...candidates].sort((a, b) => Number(a.hour) - Number(b.hour));
  const windows = [];
  sortedByHour.forEach((row, index) => {
    const next = sortedByHour[index + 1];
    if (!next || Number(next.hour) !== Number(row.hour) + 1) return;
    windows.push({ start: row, end: next, score: (ownerPeakScore(row, maxRevenue) + ownerPeakScore(next, maxRevenue)) / 2 });
  });
  const promoWindow = windows.sort((a, b) => a.score - b.score)[0] || { start: slow, end: slow, score: slow.score };
  const openingHour = sortedByHour[0];
  const openingLooksSlow = Number(openingHour.openDays || 0) >= 4
    && Number(openingHour.utilizationPercent || 0) < 10
    && Number(openingHour.averageRevenue || 0) < maxRevenue * .2;

  const promoLabel = promoWindow.start === promoWindow.end
    ? ownerHourLabel(promoWindow.start.hour, true)
    : `${ownerHourLabel(promoWindow.start.hour)} – ${ownerHourLabel(Number(promoWindow.end.hour) + 1)}`;
  const openingDecision = openingLooksSlow ? `Revisar abrir después de ${ownerHourLabel(openingHour.hour)}` : 'El inicio del horario sí muestra movimiento';
  if (cards) cards.innerHTML = `
    <article class="owner-peak-insight peak"><span>Hora pico</span><strong>${escapeHtml(ownerHourLabel(peak.hour, true))}</strong><small>${Number(peak.utilizationPercent || 0).toFixed(0)}% ocupación · ${money(peak.averageRevenue)} promedio</small></article>
    <article class="owner-peak-insight"><span>Hora más lenta</span><strong>${escapeHtml(ownerHourLabel(slow.hour, true))}</strong><small>${Number(slow.utilizationPercent || 0).toFixed(0)}% ocupación · ${money(slow.averageRevenue)} promedio</small></article>
    <article class="owner-peak-insight opportunity"><span>Ventana para promoción</span><strong>${escapeHtml(promoLabel)}</strong><small>Es la franja de menor movimiento con historial suficiente.</small></article>
    <article class="owner-peak-insight"><span>Horario de apertura</span><strong>${escapeHtml(openingDecision)}</strong><small>Basado en ${Number(openingHour.openDays || 0)} día(s) registrados a esa hora.</small></article>`;

  const maxHeatScore = Math.max(1, ...rows.map((row) => ownerPeakScore(row, maxRevenue)));
  if (grid) grid.innerHTML = rows.map((row) => {
    const heat = Math.max(.04, ownerPeakScore(row, maxRevenue) / maxHeatScore * .3);
    const isPeak = Number(row.hour) === Number(peak.hour);
    const isSlow = Number(row.hour) === Number(slow.hour);
    return `<article class="owner-peak-hour ${isPeak ? 'peak' : ''} ${isSlow ? 'slow' : ''}" style="--heat-alpha:${heat.toFixed(3)}" title="${Number(row.openDays || 0)} días abiertos">
      <strong>${escapeHtml(ownerHourLabel(row.hour))}</strong>
      <span>${Number(row.utilizationPercent || 0).toFixed(0)}% ocupación</span>
      <div class="owner-peak-utilization"><i style="width:${Math.min(100, Number(row.utilizationPercent || 0))}%"></i></div>
      <small>${money(row.averageRevenue)} prom. · ${Number(row.averageSales || 0).toFixed(1)} ventas</small>
    </article>`;
  }).join('');
  if (recommendation) {
    recommendation.textContent = `Oportunidad: prueba promociones entre ${promoLabel}. Evita descuentos generales durante ${ownerHourLabel(peak.hour, true)}, porque ya es la franja con mayor demanda combinada.`;
    recommendation.classList.remove('hidden');
  }
  if (status) status.textContent = `Pico ${ownerHourLabel(peak.hour)} · Promo ${ownerHourLabel(promoWindow.start.hour)}`;
  if (summary) summary.textContent = `${peakHours.historyLabel || 'Histórico reciente'} · combina ocupación y ventas.`;
}

function ownerProjectionTime(secondsValue) {
  const seconds = Number(secondsValue || 0);
  if (!Number.isFinite(seconds) || seconds <= 0) return 'Sin calcular';
  const totalMinutes = Math.round(seconds / 60);
  const hour = Math.floor(totalMinutes / 60) % 24;
  const minute = totalMinutes % 60;
  return new Date(2026, 0, 1, hour, minute).toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' });
}

function renderOwnerDayProjection(projection = {}) {
  const close = $('#ownerProjectedClose');
  const pace = $('#ownerProjectionPace');
  const typicalClose = $('#ownerTypicalClose');
  const explanation = $('#ownerProjectionExplanation');
  if (!projection.available) {
    if (close) close.textContent = 'Faltan datos';
    if (pace) { pace.textContent = 'Sin historial suficiente'; pace.className = ''; }
    if (typicalClose) typicalClose.textContent = ownerProjectionTime(projection.averageCloseSeconds);
    if (explanation) explanation.textContent = `StationCore necesita al menos tres ${new Date().toLocaleDateString('es-DO', { weekday: 'long' })} abiertos para proyectar el cierre.`;
    return;
  }
  const pacePercent = Number(projection.pacePercent || 0);
  const confidenceLabel = { HIGH: 'confianza alta', MEDIUM: 'confianza media', LIMITED: 'referencia inicial' }[projection.confidence] || 'referencia inicial';
  if (close) close.textContent = money(projection.projectedClose);
  if (pace) {
    pace.textContent = `${pacePercent >= 0 ? '↑' : '↓'} ${Math.abs(pacePercent).toLocaleString('es-DO', { maximumFractionDigits: 1 })}%`;
    pace.className = pacePercent >= 0 ? 'up' : 'down';
  }
  if (typicalClose) typicalClose.textContent = ownerProjectionTime(projection.averageCloseSeconds);
  if (explanation) explanation.textContent = `Proyección basada en ${Number(projection.comparableDays || 0)} días equivalentes (${confidenceLabel}). A esta hora el promedio histórico era ${money(projection.averageThrough)}.`;
}

const ownerWeekdayLabels = { 0: 'Domingo', 1: 'Lunes', 2: 'Martes', 3: 'Miércoles', 4: 'Jueves', 5: 'Viernes', 6: 'Sábado' };

function ownerHeatmapValue(cell, metric, maxRevenue) {
  const utilization = Number(cell.utilizationPercent || 0);
  const normalizedRevenue = maxRevenue > 0 ? Number(cell.averageRevenue || 0) / maxRevenue * 100 : 0;
  if (metric === 'utilization') return utilization;
  if (metric === 'revenue') return normalizedRevenue;
  return (utilization * .65) + (normalizedRevenue * .35);
}

function renderOwnerWeeklyHeatmap(heatmap = {}) {
  const container = $('#ownerWeeklyHeatmap');
  const status = $('#ownerWeeklyHeatmapStatus');
  const summary = $('#ownerWeeklyHeatmapSummary');
  const history = $('#ownerWeeklyHeatmapHistory');
  const insight = $('#ownerWeeklyHeatmapInsight');
  const metric = $('#ownerWeeklyHeatmapMetric')?.value || 'combined';
  const cells = Array.isArray(heatmap.cells) ? heatmap.cells : [];
  if (history) history.textContent = heatmap.historyLabel || 'Últimas ocho semanas completas';
  if (!heatmap.available || !cells.length) {
    if (container) container.innerHTML = '<div class="empty-state compact">Aún no hay suficientes semanas abiertas para construir el mapa.</div>';
    if (status) status.textContent = 'Faltan datos';
    if (summary) summary.textContent = 'Se necesitan por lo menos tres semanas comparables.';
    if (insight) { insight.textContent = 'El mapa aparecerá automáticamente cuando exista historial suficiente.'; insight.classList.remove('hidden'); }
    return;
  }

  const hours = [...new Set(cells.map((cell) => Number(cell.hour)))].sort((a, b) => a - b);
  const dayOrder = [1, 2, 3, 4, 5, 6, 0];
  const byKey = new Map(cells.map((cell) => [`${cell.dayOfWeek}-${cell.hour}`, cell]));
  const reliable = cells.filter((cell) => Number(cell.openDays || 0) >= 3);
  const maxRevenue = Math.max(0, ...reliable.map((cell) => Number(cell.averageRevenue || 0)));
  const scored = reliable.map((cell) => ({ ...cell, score: ownerHeatmapValue(cell, metric, maxRevenue) })).sort((a, b) => b.score - a.score);
  const strongest = scored[0];
  const slowest = scored[scored.length - 1];
  const tableParts = [
    '<div class="owner-heatmap-corner">Día</div>',
    ...hours.map((hour) => `<div class="owner-heatmap-hour">${escapeHtml(ownerHourLabel(hour))}</div>`)
  ];
  dayOrder.forEach((day) => {
    tableParts.push(`<div class="owner-heatmap-day">${ownerWeekdayLabels[day]}</div>`);
    hours.forEach((hour) => {
      const cell = byKey.get(`${day}-${hour}`);
      if (!cell) {
        tableParts.push('<div class="owner-heatmap-cell empty"><small>Cerrado</small></div>');
        return;
      }
      const score = ownerHeatmapValue(cell, metric, maxRevenue);
      const alpha = Math.max(.04, Math.min(.48, .04 + (score / 100) * .44));
      const value = metric === 'revenue'
        ? money(cell.averageRevenue)
        : `${Number(cell.utilizationPercent || 0).toFixed(0)}%`;
      const detail = metric === 'utilization'
        ? `${money(cell.averageRevenue)} prom.`
        : `${Number(cell.utilizationPercent || 0).toFixed(0)}% ocup.`;
      tableParts.push(`<div class="owner-heatmap-cell ${score >= 75 ? 'hot' : ''}" style="--cell-alpha:${alpha.toFixed(3)}" title="${Number(cell.openDays || 0)} días abiertos · ${money(cell.averageRevenue)} promedio · ${Number(cell.utilizationPercent || 0).toFixed(1)}% ocupación"><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></div>`);
    });
  });
  if (container) container.innerHTML = `<div class="owner-heatmap-table" style="grid-template-columns:82px repeat(${hours.length},74px)">${tableParts.join('')}</div>`;
  if (strongest && slowest && insight) {
    insight.textContent = `Mayor movimiento: ${ownerWeekdayLabels[strongest.dayOfWeek]} de ${ownerHourLabel(strongest.hour, true)}. Franja más lenta con historial: ${ownerWeekdayLabels[slowest.dayOfWeek]} de ${ownerHourLabel(slowest.hour, true)}.`;
    insight.classList.remove('hidden');
  }
  if (status && strongest) status.textContent = `${ownerWeekdayLabels[strongest.dayOfWeek]} ${ownerHourLabel(strongest.hour)}`;
  if (summary) summary.textContent = `${heatmap.historyLabel || 'Histórico reciente'} · ventas y ocupación por franja.`;
}

function renderOwnerStationPerformance(performance = {}) {
  const container = $('#ownerStationPerformanceList');
  const status = $('#ownerStationPerformanceStatus');
  const summary = $('#ownerStationPerformanceSummary');
  const history = $('#ownerStationPerformanceHistory');
  const insight = $('#ownerStationPerformanceInsight');
  const stations = Array.isArray(performance.stations) ? performance.stations : [];
  if (history) history.textContent = performance.historyLabel || 'Últimos 30 días';
  if (!performance.available || !stations.length) {
    if (container) container.innerHTML = '<div class="empty-state compact">Aún no hay horas abiertas suficientes para comparar estaciones.</div>';
    if (status) status.textContent = 'Faltan datos';
    if (summary) summary.textContent = 'Se calculará usando las horas abiertas del club.';
    if (insight) { insight.textContent = 'La comparación aparecerá cuando existan sesiones dentro del período.'; insight.classList.remove('hidden'); }
    return;
  }
  const ranked = [...stations].sort((a, b) => Number(b.gameRevenue || 0) - Number(a.gameRevenue || 0) || Number(b.occupiedMinutes || 0) - Number(a.occupiedMinutes || 0));
  if (container) container.innerHTML = ranked.map((station, index) => `
    <article class="owner-station-performance-row">
      <b>${index + 1}</b>
      <div><span>Estación</span><strong>${escapeHtml(station.name || 'Estación')}</strong><small>${escapeHtml(station.consoleType || '')} · ${Number(station.sessionCount || 0)} sesiones</small></div>
      <div><span>Ingresos de juego</span><strong>${money(station.gameRevenue)}</strong><small>${money(station.revenuePerOccupiedHour)} por hora usada</small></div>
      <div><span>Ocupación</span><strong>${Number(station.utilizationPercent || 0).toFixed(1)}%</strong><div class="owner-station-usage-bar"><i style="width:${Math.min(100, Number(station.utilizationPercent || 0))}%"></i></div></div>
      <div><span>Tiempo utilizado</span><strong>${Math.round(Number(station.occupiedMinutes || 0) / 60).toLocaleString('es-DO')} horas</strong><small>${station.lastUsedAt ? `Último uso ${dateTimeLabel(station.lastUsedAt)}` : 'Sin uso en el período'}</small></div>
    </article>`).join('');
  const activeRanked = ranked.filter((station) => Number(station.sessionCount || 0) > 0);
  const top = activeRanked[0];
  const low = activeRanked[activeRanked.length - 1];
  if (insight) {
    insight.textContent = top && low && top.id !== low.id
      ? `${top.name} lidera en ingresos de juego. ${low.name} es la estación activa con menor rendimiento; conviene revisar su ubicación, catálogo de juegos o estado técnico antes de invertir en otra estación.`
      : 'El rendimiento se vuelve más útil al acumular varias semanas de uso por estación.';
    insight.classList.remove('hidden');
  }
  if (status && top) status.textContent = `Líder: ${top.name}`;
  if (summary) summary.textContent = `${performance.historyLabel || 'Últimos 30 días'} · uso sobre las horas abiertas del club.`;
}

function renderOwnerIntelligence(data = {}) {
  const intelligence = data.intelligence || {};
  ownerState.intelligence = intelligence;
  renderOwnerDayProjection(intelligence.dayProjection || {});
  renderOwnerWeeklyHeatmap(intelligence.weeklyHeatmap || {});
  renderOwnerStationPerformance(intelligence.stationPerformance || {});
  const comparison = intelligence.comparison || {};
  if (!comparison.available) {
    $('#ownerComparisonTitle').textContent = 'Comparación no disponible para este turno';
    $('#ownerComparisonSubtitle').textContent = comparison.reason || 'Selecciona Hoy, Semana, Mes o Rango.';
    $('#ownerComparisonThrough').textContent = 'Selecciona un período';
    $('#ownerComparisonChart').innerHTML = '<div class="owner-comparison-empty">Elige un período para compararlo automáticamente.</div>';
    renderOwnerPeakHours(intelligence.peakHours || {});
    return;
  }
  const current = comparison.current || {};
  const previous = comparison.previous || {};
  $('#ownerComparisonTitle').textContent = `Ventas · ${comparison.currentLabel || rangeLabel(data)}`;
  $('#ownerComparisonSubtitle').textContent = `Comparado con ${comparison.comparisonLabel || 'el período anterior'}.`;
  $('#ownerComparisonThrough').textContent = comparison.throughLabel || 'Período comparable';
  $('#ownerComparisonLegendCurrent').textContent = comparison.currentLabel || 'Actual';
  $('#ownerComparisonLegendPrevious').textContent = comparison.comparisonLabel || 'Anterior';
  $('#ownerComparisonSales').textContent = money(current.totalSales);
  $('#ownerComparisonOrders').textContent = Number(current.saleCount || 0).toLocaleString('es-DO');
  $('#ownerComparisonTicket').textContent = money(current.averageTicket);
  setOwnerTrend('#ownerComparisonSalesTrend', current.totalSales, previous.totalSales, comparison.comparisonLabel);
  setOwnerTrend('#ownerComparisonOrdersTrend', current.saleCount, previous.saleCount, comparison.comparisonLabel);
  setOwnerTrend('#ownerComparisonTicketTrend', current.averageTicket, previous.averageTicket, comparison.comparisonLabel);
  renderOwnerComparisonChart(comparison);
  renderOwnerPeakHours(intelligence.peakHours || {});
}

function renderStations(stations = []) {
  const container = $('#ownerStations');
  if (!container) return;
  if (!stations.length) {
    container.innerHTML = '<div class="empty-state">No hay estaciones registradas.</div>';
    return;
  }
  container.innerHTML = stations.map((station) => {
    const cls = statusClass(station);
    const active = Boolean(station.active_session_id);
    const game = station.game_name || (active ? 'Juego no indicado' : 'Lista para usar');
    const client = active ? (station.member_name || 'General') : 'Sin cliente';
    const cashier = active ? (station.cashier_name || 'Cajera') : '';
    return `
      <article class="station-live-card ${cls}">
        <div class="station-head">
          <div>
            <div class="station-name">${escapeHtml(station.name || 'Estación')}</div>
            <div class="station-console">${escapeHtml(station.console_type || '')}</div>
          </div>
          <span class="status-pill ${cls}">${statusText(station)}</span>
        </div>
        <div class="station-main">
          <strong>${escapeHtml(remainingLabel(station))}</strong>
          <p>${escapeHtml(game)}</p>
          <p>${escapeHtml(client)}${cashier ? ` · ${escapeHtml(cashier)}` : ''}</p>
        </div>
        <div class="station-foot">
          <span>Pendiente: ${money(station.pending_total)}</span>
          <span>${active ? `Inicio ${timeLabel(station.started_at)}` : 'Disponible'}</span>
        </div>
      </article>
    `;
  }).join('');
}

function renderRecentSales(sales = []) {
  const container = $('#ownerRecentSales');
  if (!container) return;
  if (!sales.length) {
    container.innerHTML = '<div class="empty-state">Todavía no hay ventas hoy.</div>';
    return;
  }
  container.innerHTML = sales.map((sale) => {
    const itemSummary = Array.isArray(sale.items)
      ? sale.items.slice(0, 3).map((item) => `${Number(item.quantity || 1)}x ${item.description}`).join(' · ')
      : '';
    const more = Array.isArray(sale.items) && sale.items.length > 3 ? ` · +${sale.items.length - 3}` : '';
    return `
      <article class="sale-row">
        <div class="sale-row-top">
          <div>
            <strong>${money(sale.total)} cobrado</strong><br>
            <span>${timeLabel(sale.created_at)} · ${paymentLabel(sale.payment_method)}${Number(sale.discount_total || 0) > 0 ? ` · ${money(sale.discount_total)} descontado` : ''}</span>
          </div>
          <span>${escapeHtml(sale.cashier_name || 'Cajera')}</span>
        </div>
        <p>${escapeHtml(sale.member_name || 'General')} · ${escapeHtml(itemSummary || 'Venta')}${escapeHtml(more)}</p>
      </article>
    `;
  }).join('');
}


function codeTypeLabel(type = '') {
  return String(type).toUpperCase() === 'PAYMENT' ? 'Pago' : 'Transferencia';
}

function codeStatusLabel(code) {
  if (code.is_used) return `Usado${code.used_by_name ? ` por ${code.used_by_name}` : ''}`;
  if (new Date(code.expires_at).getTime() <= Date.now()) return 'Vencido';
  return `Activo hasta ${timeLabel(code.expires_at)}`;
}

function renderCodes(codes = []) {
  const container = $('#ownerCodesList');
  if (!container) return;
  if (!codes.length) {
    container.innerHTML = '<div class="empty-state compact">Sin códigos recientes.</div>';
    return;
  }
  container.innerHTML = codes.slice(0, 6).map((code) => `
    <div class="mini-row ${code.is_used ? 'used' : ''}">
      <span><strong>${escapeHtml(code.code)}</strong> · ${codeTypeLabel(code.code_type)}<small>${escapeHtml(codeStatusLabel(code))}${code.purpose_note ? ` · ${escapeHtml(code.purpose_note)}` : ''}</small></span>
    </div>
  `).join('');
}


function familyCodeStatusLabel(code) {
  if (code.is_active === false) return 'Inactivo';
  if (new Date(code.expires_at).getTime() <= Date.now()) return 'Vencido';
  if (Number(code.used_count || 0) >= Number(code.max_uses || 1)) return 'Usado completo';
  return `Activo · ${Number(code.used_count || 0)}/${Number(code.max_uses || 1)} uso(s)`;
}

function renderFamilyDiscountCodes(codes = []) {
  const container = $('#ownerFamilyDiscountList');
  if (!container) return;
  if (!codes.length) {
    container.innerHTML = '<div class="empty-state compact">Sin códigos familiares recientes.</div>';
    return;
  }
  container.innerHTML = codes.slice(0, 8).map((code) => `
    <div class="mini-row ${Number(code.used_count || 0) >= Number(code.max_uses || 1) ? 'used' : ''}">
      <span><strong>${escapeHtml(code.code)}</strong> · ${Number(code.discount_percent || 0)}%<small>${escapeHtml(familyCodeStatusLabel(code))} · vence ${dateTimeLabel(code.expires_at)}${code.note ? ` · ${escapeHtml(code.note)}` : ''}</small></span>
      <b>${money(code.discount_amount || 0)} descontado</b>
    </div>
  `).join('');
}

function renderFamilyDiscountUsage(summary = {}) {
  const rows = summary.rows || [];
  $('#ownerDiscountsRangeLabel').textContent = rangeLabel(window.__ownerLastData || {});
  $('#ownerFamilyDiscountTotal').textContent = money(summary.discount_amount || 0);
  const paidWithDiscount = Number(summary.paid_after_discount || 0);
  const paidBox = $('#ownerFamilyDiscountPaidTotal');
  if (paidBox) paidBox.textContent = money(paidWithDiscount);
  $('#ownerFamilyDiscountCount').textContent = `${Number(summary.usage_count || 0)} uso(s) · ${Number(summary.code_count || 0)} código(s) · no afecta caja`;
  const container = $('#ownerFamilyDiscountUsageList');
  if (!container) return;
  if (!rows.length) {
    container.innerHTML = '<div class="empty-state compact">Sin descuentos familiares en este rango.</div>';
    return;
  }
  container.innerHTML = rows.map((row) => `
    <div class="mini-row payment">
      <span><strong>${money(row.discount_amount)}</strong> descontado · ${escapeHtml(row.code)} · ${Number(row.discount_percent || 0)}%<small>${timeLabel(row.used_at)} · cliente pagó ${money(row.total_after_discount || 0)} · ${escapeHtml(row.cashier_name || 'Cajera')} · ${escapeHtml(row.member_name || 'General')} · no es gasto</small></span>
    </div>
  `).join('');
}

async function loadFamilyDiscountCodes() {
  try {
    const data = await ownerApi('/family-discount-codes');
    renderFamilyDiscountCodes(data.discountCodes || []);
  } catch (_error) {
    renderFamilyDiscountCodes([]);
  }
}

async function generateOwnerFamilyDiscountCode() {
  const button = $('#generateOwnerFamilyDiscountBtn');
  const box = $('#ownerGeneratedFamilyDiscount');
  if (button) button.disabled = true;
  if (box) {
    box.classList.add('hidden');
    box.textContent = '';
  }
  try {
    const data = await ownerApi('/family-discount-codes', {
      method: 'POST',
      body: JSON.stringify({
        discountPercent: Number($('#ownerFamilyDiscountPercentSelect')?.value || 50),
        expiresDays: Number($('#ownerFamilyDiscountDaysSelect')?.value || 7),
        maxUses: Number($('#ownerFamilyDiscountUsesSelect')?.value || 1),
        code: $('#ownerFamilyDiscountCustomCodeInput')?.value?.trim() || '',
        note: $('#ownerFamilyDiscountNoteInput')?.value?.trim() || ''
      })
    });
    const code = data.discountCode;
    if (box && code) {
      box.innerHTML = `<span>Descuento familiar ${Number(code.discount_percent || 0)}%</span><strong>${escapeHtml(code.code)}</strong><small>Vence ${dateTimeLabel(code.expires_at)} · ${Number(code.max_uses || 1)} uso(s)</small>`;
      box.classList.remove('hidden');
    }
    if ($('#ownerFamilyDiscountCustomCodeInput')) $('#ownerFamilyDiscountCustomCodeInput').value = '';
    if ($('#ownerFamilyDiscountNoteInput')) $('#ownerFamilyDiscountNoteInput').value = '';
    await loadFamilyDiscountCodes();
  } catch (error) {
    if (box) {
      box.textContent = error.message;
      box.classList.remove('hidden');
    }
  } finally {
    if (button) button.disabled = false;
  }
}

function renderPayments(payments = []) {
  const container = $('#ownerPaymentsList');
  if (!container) return;
  if (!payments.length) {
    container.innerHTML = `<div class="empty-state compact">Sin pagos registrados en ${escapeHtml(rangeLabel(window.__ownerLastData || {})).toLowerCase()}.</div>`;
    return;
  }
  container.innerHTML = payments.map((payment) => `
    <div class="mini-row payment">
      <span><strong>${money(payment.amount)}</strong> · ${escapeHtml(payment.reason || 'Pago')}</span>
      <small>${timeLabel(payment.created_at)} · ${escapeHtml(payment.user_name || 'Cajera')}</small>
    </div>
  `).join('');
}

async function loadAuthorizationCodes() {
  try {
    const data = await ownerApi('/authorization-codes');
    renderCodes(data.codes || []);
  } catch (_error) {
    renderCodes([]);
  }
}

async function generateOwnerAuthorizationCode() {
  const button = $('#generateOwnerCodeBtn');
  const box = $('#ownerGeneratedCode');
  if (button) button.disabled = true;
  if (box) {
    box.classList.add('hidden');
    box.textContent = '';
  }
  try {
    const data = await ownerApi('/authorization-codes', {
      method: 'POST',
      body: JSON.stringify({
        codeType: $('#ownerCodeTypeSelect')?.value || 'TRANSFER',
        expiresMinutes: Number($('#ownerCodeMinutesSelect')?.value || 15),
        purposeNote: $('#ownerCodeNoteInput')?.value?.trim() || ''
      })
    });
    const code = data.authorizationCode;
    if (box && code) {
      box.innerHTML = `<span>${codeTypeLabel(code.code_type)}</span><strong>${escapeHtml(code.code)}</strong><small>Vence ${timeLabel(code.expires_at)}</small>`;
      box.classList.remove('hidden');
    }
    $('#ownerCodeNoteInput').value = '';
    await loadAuthorizationCodes();
    await loadFamilyDiscountCodes();
  } catch (error) {
    if (box) {
      box.textContent = error.message;
      box.classList.remove('hidden');
    }
  } finally {
    if (button) button.disabled = false;
  }
}


function requestStatusLabel(status = '') {
  const map = {
    PENDIENTE: 'Pendiente',
    ESPERANDO: 'Esperando',
    REVISADO: 'Revisado',
    COMPRADO: 'Comprado',
    DESCARTADO: 'Rechazado',
    CONVERTIDO: 'Disponible'
  };
  return map[String(status || '').toUpperCase()] || status || 'Pendiente';
}

function requestDecisionLabel(decision = '') {
  const map = {
    ESPERA: 'Espera',
    ACEPTO_OTRO: 'Aceptó otro',
    SE_FUE: 'Se fue',
    SOLO_REGISTRAR: 'Solo registrar'
  };
  return map[String(decision || '').toUpperCase()] || decision || 'Sin decisión';
}

function renderGameRequests(requests = []) {
  const container = $('#ownerGameRequestsList');
  const countLabel = $('#ownerGameRequestsCount');
  if (!container) return;
  if (countLabel) countLabel.textContent = requests.length ? `${requests.length} solicitud(es)` : 'Sin pendientes';
  if (!requests.length) {
    container.innerHTML = '<div class="empty-state compact">No hay solicitudes recientes.</div>';
    return;
  }
  container.innerHTML = requests.map((request) => {
    const status = String(request.status || 'PENDIENTE').toUpperCase();
    const title = request.requested_game_name || request.game_name || 'Juego solicitado';
    const platform = request.platform || 'Plataforma no indicada';
    const station = request.station_name ? ` · ${request.station_name}` : '';
    const customer = request.customer_name || 'Cliente';
    const note = request.admin_note || request.member_note || request.unavailable_reason || '';
    const canAct = ['PENDIENTE', 'ESPERANDO'].includes(status);
    const actionsHtml = canAct ? `
        <div class="game-request-actions">
          <button type="button" data-owner-request-action="REVISADO">Aprobar</button>
          <button type="button" data-owner-request-action="COMPRADO">Comprado</button>
          <button type="button" data-owner-request-action="DESCARTADO" class="danger-lite">Rechazar</button>
        </div>` : '<div class="game-request-actions processed">Solicitud procesada</div>';
    return `
      <article class="game-request-row status-${escapeHtml(status.toLowerCase())}" data-game-request-id="${escapeHtml(request.id)}">
        <div class="game-request-main">
          <div>
            <strong>${escapeHtml(title)}</strong>
            <span>${escapeHtml(platform)}${escapeHtml(station)} · ${escapeHtml(customer)} · ${requestDecisionLabel(request.customer_decision)}</span>
            ${note ? `<small>${escapeHtml(note)}</small>` : ''}
          </div>
          <b>${requestStatusLabel(status)}</b>
        </div>
        ${actionsHtml}
      </article>
    `;
  }).join('');
}

async function updateOwnerGameRequest(requestId, status) {
  const labels = { REVISADO: 'aprobada/revisada', COMPRADO: 'marcada como comprada', DESCARTADO: 'rechazada' };
  const adminNote = window.prompt(`Nota opcional para la solicitud ${labels[status] || ''}:`, '') || '';
  await ownerApi(`/game-requests/${encodeURIComponent(requestId)}`, {
    method: 'PATCH',
    body: JSON.stringify({ status, adminNote })
  });
  await loadDashboard();
}

function paymentLabel(method = '') {
  const map = { CASH: 'Efectivo', TRANSFER: 'Transferencia', MIXED: 'Mixto', CARD: 'Tarjeta' };
  return map[String(method).toUpperCase()] || method || 'Pago';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function syncOwnerFiltersUi() {
  const periodSelect = $('#ownerPeriodSelect');
  const startInput = $('#ownerStartDate');
  const endInput = $('#ownerEndDate');
  if (periodSelect) periodSelect.value = ownerState.filters.period || 'today';
  if (startInput) startInput.value = ownerState.filters.startDate || '';
  if (endInput) endInput.value = ownerState.filters.endDate || '';
  const custom = ownerState.filters.period === 'custom';
  document.querySelectorAll('.owner-custom-date').forEach((el) => el.classList.toggle('hidden', !custom));
}

function buildSummaryQuery() {
  const params = new URLSearchParams();
  params.set('period', ownerState.filters.period || 'today');
  if (ownerState.filters.period === 'custom') {
    if (ownerState.filters.startDate) params.set('startDate', ownerState.filters.startDate);
    if (ownerState.filters.endDate) params.set('endDate', ownerState.filters.endDate || ownerState.filters.startDate);
  }
  if (ownerState.filters.shiftId) params.set('shiftId', ownerState.filters.shiftId);
  return `?${params.toString()}`;
}

function persistOwnerFilters() {
  localStorage.setItem('stationcore_owner_period', ownerState.filters.period || 'today');
  localStorage.setItem('stationcore_owner_start_date', ownerState.filters.startDate || '');
  localStorage.setItem('stationcore_owner_end_date', ownerState.filters.endDate || '');
  localStorage.setItem('stationcore_owner_shift_id', ownerState.filters.shiftId || '');
}

function renderShiftFilter(shifts = []) {
  const select = $('#ownerShiftSelect');
  if (!select) return;
  const current = ownerState.filters.shiftId || '';
  select.innerHTML = '<option value="">Todos los turnos</option>' + shifts.map((shift) => {
    const label = `${shift.status === 'OPEN' ? 'Abierto' : 'Cerrado'} · ${dateTimeLabel(shift.opened_at)} · ${money(shift.cash_sales)} ventas`;
    return `<option value="${escapeHtml(shift.id)}">${escapeHtml(label)}</option>`;
  }).join('');
  select.value = shifts.some((shift) => shift.id === current) ? current : '';
  if (current && !select.value) {
    ownerState.filters.shiftId = '';
    persistOwnerFilters();
  }
}

function renderDrawerBreakdown(data) {
  const container = $('#ownerDrawerBreakdown');
  if (!container) return;
  const drawer = data.drawer || {};
  const opening = Number(drawer.opening_amount || 0);
  const cashSales = Number(drawer.cash_sales || data.sales?.cash_sales || 0);
  const drawerIn = Number(drawer.drawer_in || 0);
  const drawerOut = Number(drawer.drawer_out || 0);
  const expected = Number(drawer.expected_cash || 0);
  const withdraw = Number(drawer.cash_to_withdraw ?? (expected - opening));
  const status = drawer.status === 'OPEN' ? 'Caja abierta' : 'Caja cerrada / historial';
  container.innerHTML = `
    <div class="drawer-breakdown-grid">
      <div><span>Fondo inicial</span><strong>${money(opening)}</strong></div>
      <div><span>Ventas efectivo</span><strong>${money(cashSales)}</strong></div>
      <div><span>Entradas caja</span><strong>${money(drawerIn)}</strong></div>
      <div><span>Pagos / salidas</span><strong>${money(drawerOut)}</strong></div>
      <div><span>Total físico esperado</span><strong>${money(expected)}</strong></div>
      <div><span>Retirar dejando fondo</span><strong>${money(withdraw)}</strong></div>
    </div>
    <p class="drawer-breakdown-note">${escapeHtml(status)} · ${escapeHtml(drawer.opened_by_name || 'Sin cajera')} ${drawer.opened_at ? `· abrió ${dateTimeLabel(drawer.opened_at)}` : ''}${drawer.closed_at ? ` · cerró ${dateTimeLabel(drawer.closed_at)}` : ''}</p>
  `;
}

function renderShiftList(shifts = []) {
  const container = $('#ownerShiftList');
  if (!container) return;
  if (!shifts.length) {
    container.innerHTML = '<div class="empty-state compact">No hay turnos en este rango.</div>';
    return;
  }
  container.innerHTML = shifts.slice(0, 8).map((shift) => `
    <article class="owner-shift-row ${shift.status === 'OPEN' ? 'open' : ''}">
      <div>
        <strong>${shift.status === 'OPEN' ? 'Turno abierto' : 'Turno cerrado'}</strong>
        <span>${dateTimeLabel(shift.opened_at)}${shift.closed_at ? ` → ${dateTimeLabel(shift.closed_at)}` : ' → ahora'} · ${escapeHtml(shift.opened_by_name || 'Empleado')}</span>
      </div>
      <div>
        <b>${money(shift.cash_sales)}</b>
        <small>Retirar ${money(shift.cash_to_withdraw)}</small>
      </div>
    </article>
  `).join('');
}


function localDateOnly(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function ownerFinancePresetRange(preset = 'month') {
  const now = new Date();
  const today = localDateOnly(now);
  if (preset === 'today') return { preset, startDate: today, endDate: today, label: 'Hoy' };
  if (preset === 'week') {
    const start = new Date(now);
    start.setDate(now.getDate() - now.getDay());
    return { preset, startDate: localDateOnly(start), endDate: today, label: 'Esta semana' };
  }
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  return { preset: 'month', startDate: localDateOnly(start), endDate: today, label: 'Este mes' };
}

function ensureOwnerFinanceRange() {
  if (!ownerState.financeRange?.startDate) ownerState.financeRange = ownerFinancePresetRange('month');
  if ($('#ownerFinanceStartDate')) $('#ownerFinanceStartDate').value = ownerState.financeRange.startDate;
  if ($('#ownerFinanceEndDate')) $('#ownerFinanceEndDate').value = ownerState.financeRange.endDate;
  document.querySelectorAll('[data-owner-finance-preset]').forEach((button) => {
    button.classList.toggle('active', button.dataset.ownerFinancePreset === ownerState.financeRange.preset);
  });
  return ownerState.financeRange;
}

function ownerFinanceDate(value) {
  return value ? String(value).slice(0, 10) : '';
}

function ownerFinanceList(selector, rows, renderer) {
  const box = $(selector);
  if (!box) return;
  box.innerHTML = rows?.length ? rows.map(renderer).join('') : '<div class="empty-state compact-empty">Sin registros</div>';
}

function setOwnerFinanceText(selector, value) {
  const el = $(selector);
  if (el) el.textContent = value;
}

function renderOwnerFinance(data = {}) {
  const totals = data.totals || {};
  const range = ownerState.financeRange || data.range || {};
  const label = range.label || `${range.startDate || ''} - ${range.endDate || ''}`;
  setOwnerFinanceText('#ownerFinancePeriodLabel', label);
  setOwnerFinanceText('#ownerFinanceTotalInvestment', money(totals.totalInvestment));
  setOwnerFinanceText('#ownerFinanceInvestmentSplit', `Inicial ${money(totals.initialInvestment)} · Reinversión ${money(totals.reinvestment)}`);
  setOwnerFinanceText('#ownerFinancePeriodSales', money(totals.periodSales));
  setOwnerFinanceText('#ownerFinancePeriodExpenses', money(totals.periodExpenses));
  setOwnerFinanceText('#ownerFinancePeriodNet', money(totals.periodNet));
  setOwnerFinanceText('#ownerFinanceRecurringMonthly', money(totals.recurringMonthlyExpenses));
  setOwnerFinanceText('#ownerFinanceRoiTime', totals.monthsToRecover === null ? 'Sin datos' : (Number(totals.monthsToRecover) <= 0 ? 'Recuperado' : `${totals.monthsToRecover} meses`));
  setOwnerFinanceText('#ownerFinanceRoiProgress', `${Number(totals.recoveredPercent || 0).toFixed(1)}% recuperado`);
  setOwnerFinanceText('#ownerFinanceMonthSales', money(totals.monthSales));
  setOwnerFinanceText('#ownerFinanceEstimatedMonthlyExpenses', money(totals.estimatedMonthlyExpenses));
  setOwnerFinanceText('#ownerFinanceEstimatedMonthlyNet', money(totals.estimatedMonthlyNet));
  setOwnerFinanceText('#ownerFinanceRemainingInvestment', money(totals.remainingInvestment));
  ownerFinanceList('#ownerFinanceRecentList', [...(data.expenses || []), ...(data.investments || [])].slice(0, 8), (row) =>
    `<div><span>${escapeHtml(row.name)} · ${ownerFinanceDate(row.expense_date || row.invested_at)}</span><strong>${money(row.amount || row.monthly_amount)}</strong></div>`);
  ownerFinanceList('#ownerFinanceInvestmentsList', data.investments || [], (row) =>
    `<div><span>${escapeHtml(row.name)} · ${escapeHtml(row.category || 'GENERAL')} · ${ownerFinanceDate(row.invested_at)}</span><strong>${money(row.amount)}</strong><button type="button" class="secondary small-action" data-owner-delete-investment="${row.id}">Eliminar</button></div>`);
  ownerFinanceList('#ownerFinanceExpensesList', data.expenses || [], (row) =>
    `<div><span>${escapeHtml(row.name)} · ${escapeHtml(row.category || 'GENERAL')} · ${ownerFinanceDate(row.expense_date)}</span><strong>${money(row.amount)}</strong><button type="button" class="secondary small-action" data-owner-delete-expense="${row.id}">Eliminar</button></div>`);
  ownerFinanceList('#ownerFinanceRecurringList', data.recurringExpenses || [], (row) =>
    `<div><span>${escapeHtml(row.name)} · día ${row.due_day || '-'}</span><strong>${money(row.monthly_amount)}</strong><button type="button" class="secondary small-action" data-owner-delete-recurring="${row.id}">Eliminar</button></div>`);
  document.querySelectorAll('[data-owner-delete-investment]').forEach((button) => button.addEventListener('click', () => deleteOwnerFinanceItem(`/finances/investments/${button.dataset.ownerDeleteInvestment}`)));
  document.querySelectorAll('[data-owner-delete-expense]').forEach((button) => button.addEventListener('click', () => deleteOwnerFinanceItem(`/finances/expenses/${button.dataset.ownerDeleteExpense}`)));
  document.querySelectorAll('[data-owner-delete-recurring]').forEach((button) => button.addEventListener('click', () => deleteOwnerFinanceItem(`/finances/recurring-expenses/${button.dataset.ownerDeleteRecurring}`)));
}

async function loadOwnerFinance() {
  const range = ensureOwnerFinanceRange();
  const data = await ownerApi(`/finances/summary?startDate=${encodeURIComponent(range.startDate)}&endDate=${encodeURIComponent(range.endDate)}`);
  renderOwnerFinance(data);
  ownerState.financeLoaded = true;
}

function setOwnerFinanceTab(tab = 'summary') {
  document.querySelectorAll('[data-owner-finance-tab]').forEach((button) => button.classList.toggle('active', button.dataset.ownerFinanceTab === tab));
  document.querySelectorAll('[data-owner-finance-panel]').forEach((panel) => panel.classList.toggle('hidden', panel.dataset.ownerFinancePanel !== tab));
  if (tab === 'payroll') loadOwnerPayroll().catch((error) => alert(error.message || 'No se pudo cargar sueldos'));
}

async function deleteOwnerFinanceItem(path) {
  if (!confirm('¿Eliminar este registro?')) return;
  await ownerApi(path, { method: 'DELETE' });
  await loadOwnerFinance();
}

async function saveOwnerFinanceInvestment(event) {
  event.preventDefault();
  await ownerApi('/finances/investments', { method: 'POST', body: JSON.stringify({
    name: $('#ownerFinanceInvestmentName')?.value,
    category: $('#ownerFinanceInvestmentCategory')?.value,
    amount: $('#ownerFinanceInvestmentAmount')?.value,
    investedAt: $('#ownerFinanceInvestmentDate')?.value,
    investmentType: $('#ownerFinanceInvestmentType')?.value,
    notes: $('#ownerFinanceInvestmentNotes')?.value
  }) });
  event.currentTarget.reset();
  await loadOwnerFinance();
}

async function saveOwnerFinanceExpense(event) {
  event.preventDefault();
  await ownerApi('/finances/expenses', { method: 'POST', body: JSON.stringify({
    name: $('#ownerFinanceExpenseName')?.value,
    category: $('#ownerFinanceExpenseCategory')?.value,
    amount: $('#ownerFinanceExpenseAmount')?.value,
    expenseDate: $('#ownerFinanceExpenseDate')?.value,
    expenseType: $('#ownerFinanceExpenseType')?.value,
    paymentMethod: $('#ownerFinanceExpensePaymentMethod')?.value,
    notes: $('#ownerFinanceExpenseNotes')?.value
  }) });
  event.currentTarget.reset();
  await loadOwnerFinance();
}

async function saveOwnerFinanceRecurring(event) {
  event.preventDefault();
  await ownerApi('/finances/recurring-expenses', { method: 'POST', body: JSON.stringify({
    name: $('#ownerFinanceRecurringName')?.value,
    category: $('#ownerFinanceRecurringCategory')?.value,
    monthlyAmount: $('#ownerFinanceRecurringAmount')?.value,
    dueDay: $('#ownerFinanceRecurringDueDay')?.value,
    notes: $('#ownerFinanceRecurringNotes')?.value
  }) });
  event.currentTarget.reset();
  await loadOwnerFinance();
}

function renderOwnerPayroll(data = {}) {
  ownerState.payroll = { employees: data.employees || [], shifts: data.shifts || [], payments: data.payments || [] };
  const totals = data.totals || {};
  setOwnerFinanceText('#ownerPayrollEmployeesCount', totals.employeesOnPayroll || 0);
  setOwnerFinanceText('#ownerPayrollShiftsCount', totals.scheduledShifts || 0);
  setOwnerFinanceText('#ownerPayrollEstimatedTotal', money(totals.estimatedPayroll));
  setOwnerFinanceText('#ownerPayrollPaidTotal', money(totals.paidPayroll));
  setOwnerFinanceText('#ownerPayrollPendingTotal', money(totals.pendingPayroll));
  const options = (data.employees || []).filter((employee) => employee.is_active !== false).map((employee) => `<option value="${escapeHtml(employee.id)}">${escapeHtml(employee.full_name || 'Empleado')}</option>`).join('');
  ['#ownerPayrollEmployeeSelect', '#ownerPayrollShiftEmployeeSelect', '#ownerPayrollPaymentEmployeeSelect'].forEach((selector) => {
    const select = $(selector);
    if (select) select.innerHTML = options;
  });
  fillOwnerPayrollEmployeeForm($('#ownerPayrollEmployeeSelect')?.value);
  ownerFinanceList('#ownerPayrollShiftsList', data.shifts || [], (shift) =>
    `<div><span>${escapeHtml(shift.full_name || 'Empleado')} · ${ownerFinanceDate(shift.work_date)} · ${(shift.start_time || '').slice(0,5)}-${(shift.end_time || '').slice(0,5)}</span><strong>${money(shift.estimated_cost)}</strong><button type="button" class="secondary small-action" data-owner-delete-shift="${shift.id}">Eliminar</button></div>`);
  ownerFinanceList('#ownerPayrollPaymentsList', data.payments || [], (payment) =>
    `<div><span>${escapeHtml(payment.full_name || 'Empleado')} · ${ownerFinanceDate(payment.paid_at)}</span><strong>${money(payment.amount)}</strong></div>`);
  document.querySelectorAll('[data-owner-delete-shift]').forEach((button) => button.addEventListener('click', async () => {
    if (!confirm('¿Eliminar este turno?')) return;
    await ownerApi(`/payroll/shifts/${button.dataset.ownerDeleteShift}`, { method: 'DELETE' });
    await loadOwnerPayroll();
  }));
}

async function loadOwnerPayroll() {
  const range = ensureOwnerFinanceRange();
  const data = await ownerApi(`/payroll/summary?startDate=${encodeURIComponent(range.startDate)}&endDate=${encodeURIComponent(range.endDate)}`);
  renderOwnerPayroll(data);
}

function fillOwnerPayrollEmployeeForm(employeeId) {
  const employee = (ownerState.payroll.employees || []).find((item) => String(item.id) === String(employeeId)) || ownerState.payroll.employees?.[0];
  if (!employee) return;
  if ($('#ownerPayrollEmployeeSelect')) $('#ownerPayrollEmployeeSelect').value = employee.id;
  if ($('#ownerPayrollPayTypeSelect')) $('#ownerPayrollPayTypeSelect').value = employee.pay_type || 'MONTHLY';
  if ($('#ownerPayrollPayRateInput')) $('#ownerPayrollPayRateInput').value = Number(employee.pay_rate || 0).toFixed(2);
  if ($('#ownerPayrollPayFrequencySelect')) $('#ownerPayrollPayFrequencySelect').value = employee.pay_frequency || 'MONTHLY';
  if ($('#ownerPayrollDefaultStartInput')) $('#ownerPayrollDefaultStartInput').value = (employee.default_start_time || '10:00').slice(0, 5);
  if ($('#ownerPayrollDefaultEndInput')) $('#ownerPayrollDefaultEndInput').value = (employee.default_end_time || '22:00').slice(0, 5);
  if ($('#ownerPayrollEnabledInput')) $('#ownerPayrollEnabledInput').checked = employee.payroll_enabled !== false;
  if ($('#ownerPayrollEmployeeNotesInput')) $('#ownerPayrollEmployeeNotesInput').value = employee.notes || '';
}

async function saveOwnerPayrollEmployee() {
  const userId = $('#ownerPayrollEmployeeSelect')?.value;
  if (!userId) return;
  await ownerApi(`/payroll/employees/${userId}`, { method: 'PUT', body: JSON.stringify({
    payrollEnabled: $('#ownerPayrollEnabledInput')?.checked,
    payType: $('#ownerPayrollPayTypeSelect')?.value,
    payRate: $('#ownerPayrollPayRateInput')?.value,
    payFrequency: $('#ownerPayrollPayFrequencySelect')?.value,
    defaultStartTime: $('#ownerPayrollDefaultStartInput')?.value,
    defaultEndTime: $('#ownerPayrollDefaultEndInput')?.value,
    notes: $('#ownerPayrollEmployeeNotesInput')?.value
  }) });
  await loadOwnerPayroll();
  await loadOwnerFinance();
}

async function saveOwnerPayrollShift() {
  await ownerApi('/payroll/shifts', { method: 'POST', body: JSON.stringify({
    userId: $('#ownerPayrollShiftEmployeeSelect')?.value,
    workDate: $('#ownerPayrollShiftDateInput')?.value,
    shiftName: $('#ownerPayrollShiftNameInput')?.value || 'Turno',
    startTime: $('#ownerPayrollShiftStartInput')?.value,
    endTime: $('#ownerPayrollShiftEndInput')?.value
  }) });
  await loadOwnerPayroll();
}

async function saveOwnerPayrollPayment() {
  await ownerApi('/payroll/payments', { method: 'POST', body: JSON.stringify({
    userId: $('#ownerPayrollPaymentEmployeeSelect')?.value,
    periodStart: $('#ownerPayrollPaymentStartInput')?.value,
    periodEnd: $('#ownerPayrollPaymentEndInput')?.value,
    amount: $('#ownerPayrollPaymentAmountInput')?.value,
    paidAt: $('#ownerPayrollPaymentDateInput')?.value,
    paymentMethod: $('#ownerPayrollPaymentMethodSelect')?.value,
    notes: $('#ownerPayrollPaymentNotesInput')?.value
  }) });
  await loadOwnerPayroll();
  await loadOwnerFinance();
}


async function loadDashboard() {
  try {
    const data = await ownerApi(`/summary${buildSummaryQuery()}`);
    window.__ownerLastData = data;
    renderMetrics(data);
    renderOwnerIntelligence(data);
    renderStations(data.stations || []);
    renderRecentSales(data.recentSales || []);
    renderPayments(data.payments || []);
    renderFamilyDiscountUsage(data.familyDiscounts || {});
    renderDrawerBreakdown(data);
    renderShiftFilter(data.shifts || []);
    renderShiftList(data.shifts || []);
    renderGameRequests(data.gameRequests || []);
    await loadOwnerInventoryAlerts();
    if (ownerState.currentSection === 'reports') await loadOwnerReports();
    await loadAuthorizationCodes();
    await loadFamilyDiscountCodes();
    const date = new Date(data.generatedAt || Date.now());
    $('#ownerMeta').textContent = `${ownerState.user?.name || 'Owner'} · actualizado ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    $('#stationUpdatedLabel').textContent = `Actualizado ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
  } catch (error) {
    if (String(error.message || '').toLowerCase().includes('sesión') || String(error.message || '').toLowerCase().includes('token')) {
      logoutOwner();
      const errorBox = $('#ownerLoginError');
      if (errorBox) {
        errorBox.textContent = error.message;
        errorBox.classList.remove('hidden');
      }
      return;
    }
    $('#ownerMeta').textContent = error.message;
  }
}

function startAutoRefresh() {
  clearInterval(ownerState.refreshTimer);
  ownerState.refreshTimer = setInterval(loadDashboard, 30000);
}

$('#ownerLoginForm')?.addEventListener('submit', loginOwner);
$('#logoutOwnerDashboard')?.addEventListener('click', logoutOwner);
$('#refreshOwnerDashboard')?.addEventListener('click', loadDashboard);
$('#generateOwnerCodeBtn')?.addEventListener('click', generateOwnerAuthorizationCode);
$('#generateOwnerFamilyDiscountBtn')?.addEventListener('click', generateOwnerFamilyDiscountCode);
$('#saveOwnerPosSecurityBtn')?.addEventListener('click',()=>saveOwnerPosSecurity().catch(e=>alert(e.message)));
$('#saveOwnerPrintingBtn')?.addEventListener('click',()=>saveOwnerPrinting().catch(e=>alert(e.message)));
$('#saveOwnerPrintingSuppliesBtn')?.addEventListener('click',()=>saveOwnerPrinting().catch(e=>alert(e.message)));
$('#ownerNewPrintServiceForm')?.addEventListener('submit',(event)=>createOwnerPrintingService(event).catch(error=>alert(error.message)));
$('#ownerNewPrintSupplyForm')?.addEventListener('submit',(event)=>createOwnerPrintingSupply(event).catch(error=>alert(error.message)));
$('#ownerNewPrintMediaProfile')?.addEventListener('change',populateNewPaperSizes);
$('#ownerNewPrintPaperSupply')?.addEventListener('change',updateNewPrintBorderlessAvailability);
$('#ownerNewPrintOutputType')?.addEventListener('change',applyNewPrintTypeDefaults);
$('#ownerWeeklyHeatmapMetric')?.addEventListener('change',()=>renderOwnerWeeklyHeatmap(ownerState.intelligence?.weeklyHeatmap || {}));
$('#ownerNewPrintAutoInk')?.addEventListener('change',(event)=>toggleManualInkFields($('#ownerNewPrintServiceForm'),event.target.checked));
$('#ownerPrinterMaintenanceType')?.addEventListener('change',updatePrinterMaintenanceForm);
$('#ownerPrinterMaintenanceForm')?.addEventListener('submit',(event)=>createPrinterMaintenanceEvent(event).catch(error=>alert(error.message)));
$('#ownerPrinterMaintenanceSettingsForm')?.addEventListener('submit',(event)=>savePrinterMaintenanceSettings(event).catch(error=>alert(error.message)));
$('#ownerPrintSupplies')?.addEventListener('click',(event)=>{const button=event.target.closest('[data-register-print-purchase]');if(!button)return;const card=button.closest('[data-print-supply]');const cost=Number(card?.querySelector('[data-print-field="purchaseCost"]')?.value||0);const yieldUnits=Number(card?.querySelector('[data-print-field="yieldUnits"]')?.value||0);const remainingInput=card?.querySelector('[data-print-field="remainingUnits"]');const currentRemaining=Number(remainingInput?.value||0);if(cost<=0||yieldUnits<=0)return alert('Primero indica el costo y el rendimiento de la compra.');if(remainingInput)remainingInput.value=String(currentRemaining+yieldUnits);saveOwnerPrinting().catch(e=>alert(e.message));});
$('#ownerPrintSupplies')?.addEventListener('change',(event)=>{if(event.target.matches('[data-print-field="mediaProfile"]'))populateSupplyCardPaperSizes(event.target.closest('[data-print-supply]'));});
$('#ownerPrintRecipes')?.addEventListener('change',(event)=>{const card=event.target.closest('[data-print-recipe]');if(event.target.matches('[data-recipe-field="isActive"]'))card?.classList.toggle('is-inactive',!event.target.checked);if(event.target.matches('[data-recipe-field="autoInkEstimate"]'))toggleManualInkFields(card,event.target.checked);});
$('#ownerInventoryAlertsOpenReportBtn')?.addEventListener('click',()=>{ownerState.reportTab='inventory';setOwnerSection('reports');document.querySelectorAll('[data-owner-report-tab]').forEach(button=>button.classList.toggle('active',button.dataset.ownerReportTab==='inventory'));});
$('#revokeAllOwnerPosDevicesBtn')?.addEventListener('click',()=>revokeAllOwnerPosDevices().catch(e=>alert(e.message)));
$('#ownerPosDevicesList')?.addEventListener('click',(event)=>{const button=event.target.closest('[data-revoke-pos-device]');if(button)revokeOwnerPosDevice(button.dataset.revokePosDevice).catch(e=>alert(e.message));});
document.querySelectorAll('[data-owner-section-tab]').forEach((button) => {
  button.addEventListener('click', () => setOwnerSection(button.dataset.ownerSectionTab));
});
document.querySelectorAll('[data-owner-report-tab]').forEach((button) => button.addEventListener('click', () => {
  ownerState.reportTab = button.dataset.ownerReportTab || 'sales';
  renderOwnerReportSection();
}));
document.querySelectorAll('[data-owner-report-preset]').forEach((button) => button.addEventListener('click', async () => {
  ownerState.reportRange = ownerReportPreset(button.dataset.ownerReportPreset || 'today');
  await loadOwnerReports();
}));
$('#applyOwnerReportRangeBtn')?.addEventListener('click', async () => {
  const startDate=$('#ownerReportStartDate')?.value||localDateOnly(), endDate=$('#ownerReportEndDate')?.value||startDate;
  ownerState.reportRange={preset:'custom',startDate,endDate,startTime:$('#ownerReportStartTime')?.value||'00:00',endTime:$('#ownerReportEndTime')?.value||'23:59'};
  await loadOwnerReports();
});

document.querySelectorAll('[data-owner-finance-preset]').forEach((button) => {
  button.addEventListener('click', async () => {
    ownerState.financeRange = ownerFinancePresetRange(button.dataset.ownerFinancePreset);
    await loadOwnerFinance();
    if (!document.querySelector('[data-owner-finance-panel="payroll"]')?.classList.contains('hidden')) await loadOwnerPayroll();
  });
});
document.querySelectorAll('[data-owner-finance-tab]').forEach((button) => {
  button.addEventListener('click', () => setOwnerFinanceTab(button.dataset.ownerFinanceTab));
});
$('#applyOwnerFinanceRangeBtn')?.addEventListener('click', async () => {
  ownerState.financeRange = {
    preset: 'custom',
    startDate: $('#ownerFinanceStartDate')?.value || localDateOnly(),
    endDate: $('#ownerFinanceEndDate')?.value || localDateOnly(),
    label: 'Rango'
  };
  await loadOwnerFinance();
});
$('#ownerFinanceInvestmentForm')?.addEventListener('submit', saveOwnerFinanceInvestment);
$('#ownerFinanceExpenseForm')?.addEventListener('submit', saveOwnerFinanceExpense);
$('#ownerFinanceRecurringForm')?.addEventListener('submit', saveOwnerFinanceRecurring);
$('#ownerPayrollEmployeeSelect')?.addEventListener('change', () => fillOwnerPayrollEmployeeForm($('#ownerPayrollEmployeeSelect')?.value));
$('#ownerSavePayrollEmployeeBtn')?.addEventListener('click', saveOwnerPayrollEmployee);
$('#ownerSavePayrollShiftBtn')?.addEventListener('click', saveOwnerPayrollShift);
$('#ownerSavePayrollPaymentBtn')?.addEventListener('click', saveOwnerPayrollPayment);

$('#ownerPeriodSelect')?.addEventListener('change', async (event) => {
  ownerState.filters.period = event.target.value || 'today';
  ownerState.filters.shiftId = '';
  syncOwnerFiltersUi();
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerStartDate')?.addEventListener('change', async (event) => {
  ownerState.filters.startDate = event.target.value || '';
  ownerState.filters.shiftId = '';
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerEndDate')?.addEventListener('change', async (event) => {
  ownerState.filters.endDate = event.target.value || '';
  ownerState.filters.shiftId = '';
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerShiftSelect')?.addEventListener('change', async (event) => {
  ownerState.filters.shiftId = event.target.value || '';
  persistOwnerFilters();
  await loadDashboard();
});

$('#ownerGameRequestsList')?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-owner-request-action]');
  if (!button) return;
  const row = button.closest('[data-game-request-id]');
  const requestId = row?.dataset?.gameRequestId;
  const status = button.dataset.ownerRequestAction;
  if (!requestId || !status) return;
  button.disabled = true;
  try {
    await updateOwnerGameRequest(requestId, status);
  } catch (error) {
    alert(error.message || 'No se pudo actualizar la solicitud.');
  } finally {
    button.disabled = false;
  }
});

setVisible();
syncOwnerFiltersUi();
setOwnerSection(ownerState.currentSection);
updatePrinterMaintenanceForm();
if (ownerState.token) {
  loadDashboard();
  startAutoRefresh();
}
