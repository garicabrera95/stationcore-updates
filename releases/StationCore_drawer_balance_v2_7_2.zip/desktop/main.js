import { app as electronApp, BrowserWindow, dialog, ipcMain, Menu, shell } from 'electron';
import fs from 'fs';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { getHardwareConfig, saveHardwareConfig } from './services/hardware-store.js';
import { listWindowsPrinters, sendRawToPrinter, textToEscPosHex } from './services/windows-raw-printer.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const appRoot = path.resolve(__dirname, '..');
const execFileAsync = promisify(execFile);
const AUTO_BACKUP_KEEP_COUNT = 30;
const DEFAULT_UPDATE_CHECK_INTERVAL_HOURS = 6;
const APP_PROCESS_STARTED_AT = new Date().toISOString();
let updateCheckTimer = null;
let lastUpdateCheck = null;

function readPackageVersion() {
  try {
    const packageJson = JSON.parse(fs.readFileSync(path.join(appRoot, 'package.json'), 'utf8'));
    return String(packageJson.version || '0.0.0');
  } catch {
    return '0.0.0';
  }
}

function getInstalledAppVersion() {
  const packageVersion = readPackageVersion();
  if (packageVersion && packageVersion !== '0.0.0') return packageVersion;
  return process.env.APP_VERSION || '0.0.0';
}

let mainWindow = null;
let localServer = null;
let startServer = null;
let env = null;
let localHost = process.env.DESKTOP_SERVER_HOST || '127.0.0.1';
let localPort = Number(process.env.DESKTOP_SERVER_PORT || process.env.PORT || 3000);
let localUrl = `http://${localHost}:${localPort}`;

function isTruthy(value) {
  return ['true', '1', 'yes', 'si', 'sí'].includes(String(value || '').trim().toLowerCase());
}

function isDesktopKioskEnabled() {
  return isTruthy(process.env.DESKTOP_KIOSK);
}

function getDefaultEnvText() {
  return [
    'NODE_ENV=production',
    'PORT=3000',
    'DATABASE_URL=postgresql://postgres:Versus102126@localhost:5432/club_versus_pos',
    'JWT_SECRET=club-versus-local-secret-cambiar-luego',
    'APP_NAME=StationCore',
    `APP_VERSION=${readPackageVersion()}`,
    'BUSINESS_NAME=Club Versus',
    'CURRENCY=RD$',
    'DESKTOP_SERVER_HOST=127.0.0.1',
    'DESKTOP_SERVER_PORT=3000',
    'DESKTOP_KIOSK=true',
    'STATIONCORE_UPDATE_FEED_URL=https://raw.githubusercontent.com/garicabrera95/stationcore-updates/main/latest.json',
    'STATIONCORE_UPDATE_CHECK_INTERVAL_HOURS=6',
    ''
  ].join('\n');
}



const LEGACY_ARENAOS_HOME = 'C:\\ArenaOS';

function copyDirectoryWithoutOverwrite(source, destination) {
  if (!source || !destination || !fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const sourcePath = path.join(source, entry.name);
    const destinationPath = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      copyDirectoryWithoutOverwrite(sourcePath, destinationPath);
    } else if (!fs.existsSync(destinationPath)) {
      fs.copyFileSync(sourcePath, destinationPath);
    }
  }
}

function migrateLegacyArenaOsData(stationCoreHomeDir) {
  try {
    if (process.env.STATIONCORE_SKIP_LEGACY_MIGRATION === 'true') return;
    const legacyHomeDir = process.env.ARENAOS_HOME || LEGACY_ARENAOS_HOME;
    if (!legacyHomeDir || !fs.existsSync(legacyHomeDir)) return;
    if (path.resolve(legacyHomeDir).toLowerCase() === path.resolve(stationCoreHomeDir).toLowerCase()) return;

    for (const folderName of ['config', 'backups', 'logs', 'updates']) {
      const legacyFolder = path.join(legacyHomeDir, folderName);
      const stationCoreFolder = path.join(stationCoreHomeDir, folderName);
      copyDirectoryWithoutOverwrite(legacyFolder, stationCoreFolder);
    }

    console.log(`StationCore migró datos existentes desde ${legacyHomeDir} hacia ${stationCoreHomeDir}. La carpeta vieja no fue borrada.`);
  } catch (error) {
    console.warn(`No se pudo migrar datos antiguos de ArenaOS a StationCore: ${error.message}`);
  }
}

function syncLegacyPathEnvAliases(homeDir) {
  process.env.STATIONCORE_HOME = homeDir;
  process.env.STATIONCORE_CONFIG_DIR = path.join(homeDir, 'config');
  process.env.STATIONCORE_BACKUP_DIR = path.join(homeDir, 'backups');
  process.env.STATIONCORE_LOG_DIR = path.join(homeDir, 'logs');
  process.env.STATIONCORE_UPDATES_DIR = path.join(homeDir, 'updates');

  // Compatibilidad temporal para scripts/módulos que todavía puedan leer variables antiguas.
  process.env.ARENAOS_HOME = process.env.ARENAOS_HOME || homeDir;
  process.env.ARENAOS_CONFIG_DIR = process.env.ARENAOS_CONFIG_DIR || process.env.STATIONCORE_CONFIG_DIR;
  process.env.ARENAOS_BACKUP_DIR = process.env.ARENAOS_BACKUP_DIR || process.env.STATIONCORE_BACKUP_DIR;
  process.env.ARENAOS_LOG_DIR = process.env.ARENAOS_LOG_DIR || process.env.STATIONCORE_LOG_DIR;
  process.env.ARENAOS_UPDATES_DIR = process.env.ARENAOS_UPDATES_DIR || process.env.STATIONCORE_UPDATES_DIR;
}


function ensureEnvFileDefaults(envFile) {
  if (!envFile || !fs.existsSync(envFile)) return;
  let text = fs.readFileSync(envFile, 'utf8');
  const defaults = [
    ['APP_NAME', 'StationCore'],
    ['APP_VERSION', readPackageVersion()],
    ['STATIONCORE_UPDATE_FEED_URL', 'https://raw.githubusercontent.com/garicabrera95/stationcore-updates/main/latest.json'],
    ['STATIONCORE_UPDATE_CHECK_INTERVAL_HOURS', '6']
  ];
  const additions = [];

  for (const [key, value] of defaults) {
    const keyPattern = new RegExp(`^${key}=.*$`, 'm');
    const blankPattern = new RegExp(`^${key}=\s*$`, 'm');

    if (!keyPattern.test(text)) {
      additions.push(`${key}=${value}`);
    } else if (key === 'APP_NAME') {
      text = text.replace(keyPattern, `${key}=${value}`);
    } else if (key === 'APP_VERSION') {
      text = text.replace(keyPattern, `${key}=${value}`);
    } else if (key === 'STATIONCORE_UPDATE_FEED_URL' && blankPattern.test(text)) {
      text = text.replace(blankPattern, `${key}=${value}`);
    }
  }

  if (!additions.length) {
    fs.writeFileSync(envFile, text, 'utf8');
    return;
  }

  const prefix = text.endsWith('\n') ? '' : '\n';
  fs.writeFileSync(envFile, `${text}${prefix}${additions.join('\n')}\n`, 'utf8');
}

function getArenaOsHomeDir() {
  return process.env.STATIONCORE_HOME || 'C:\\StationCore';
}

function ensureArenaOsLocalFolders() {
  const homeDir = getArenaOsHomeDir();
  const folders = [
    homeDir,
    path.join(homeDir, 'config'),
    path.join(homeDir, 'backups'),
    path.join(homeDir, 'logs'),
    path.join(homeDir, 'updates')
  ];

  try {
    migrateLegacyArenaOsData(homeDir);
    for (const folder of folders) {
      fs.mkdirSync(folder, { recursive: true });
    }
    syncLegacyPathEnvAliases(homeDir);
    return { ok: true, homeDir };
  } catch (error) {
    const fallbackDir = path.join(electronApp.getPath('userData'), 'local');
    const fallbackFolders = [
      fallbackDir,
      path.join(fallbackDir, 'config'),
      path.join(fallbackDir, 'backups'),
      path.join(fallbackDir, 'logs'),
      path.join(fallbackDir, 'updates')
    ];
    for (const folder of fallbackFolders) {
      fs.mkdirSync(folder, { recursive: true });
    }
    syncLegacyPathEnvAliases(fallbackDir);
    console.warn(`No se pudo crear C:\\StationCore. Usando fallback: ${fallbackDir}. ${error.message}`);
    return { ok: false, homeDir: fallbackDir, error };
  }
}

function ensureDesktopEnvFile() {
  if (process.env.STATIONCORE_ENV_FILE) return process.env.STATIONCORE_ENV_FILE;
  if (process.env.ARENAOS_ENV_FILE) {
    process.env.STATIONCORE_ENV_FILE = process.env.ARENAOS_ENV_FILE;
    return process.env.STATIONCORE_ENV_FILE;
  }

  if (!electronApp.isPackaged) {
    const projectEnv = path.join(appRoot, '.env');
    if (fs.existsSync(projectEnv)) {
      process.env.STATIONCORE_ENV_FILE = projectEnv;
      console.log(`StationCore usando configuración de desarrollo: ${projectEnv}`);
      return projectEnv;
    }
  }

  const localFolders = ensureArenaOsLocalFolders();
  const envFile = path.join(localFolders.homeDir, 'config', '.env');

  if (!fs.existsSync(envFile)) {
    fs.writeFileSync(envFile, getDefaultEnvText(), 'utf8');
    console.log(`StationCore creó configuración de producción: ${envFile}`);
  } else {
    ensureEnvFileDefaults(envFile);
    console.log(`StationCore usando configuración de producción: ${envFile}`);
  }

  process.env.STATIONCORE_ENV_FILE = envFile;
  return envFile;
}


function getLocalDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function safeFileTimestamp(date = new Date()) {
  return date.toISOString().replace(/[:.]/g, '-');
}

function getAutoBackupMarkerFile() {
  const backupDir = process.env.STATIONCORE_BACKUP_DIR || path.join(getArenaOsHomeDir(), 'backups');
  return path.join(backupDir, '.stationcore-auto-backup.json');
}

function readAutoBackupMarker() {
  try {
    const markerFile = getAutoBackupMarkerFile();
    if (!fs.existsSync(markerFile)) return null;
    return JSON.parse(fs.readFileSync(markerFile, 'utf8'));
  } catch {
    return null;
  }
}

function writeAutoBackupMarker(marker) {
  try {
    const markerFile = getAutoBackupMarkerFile();
    fs.mkdirSync(path.dirname(markerFile), { recursive: true });
    fs.writeFileSync(markerFile, JSON.stringify(marker, null, 2), 'utf8');
  } catch (error) {
    console.warn('No se pudo guardar marcador de backup automático:', error.message);
  }
}

function pruneOldAutoBackups() {
  const backupDir = process.env.STATIONCORE_BACKUP_DIR || path.join(getArenaOsHomeDir(), 'backups');
  if (!fs.existsSync(backupDir)) return;
  const autoBackups = fs.readdirSync(backupDir)
    .filter((name) => /^stationcore-auto-.*\.dump$/i.test(name))
    .map((name) => {
      const file = path.join(backupDir, name);
      const stat = fs.statSync(file);
      return { file, name, mtimeMs: stat.mtimeMs };
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);

  for (const oldBackup of autoBackups.slice(AUTO_BACKUP_KEEP_COUNT)) {
    try {
      fs.unlinkSync(oldBackup.file);
      console.log(`StationCore eliminó backup automático viejo: ${oldBackup.name}`);
    } catch (error) {
      console.warn(`No se pudo eliminar backup viejo ${oldBackup.name}:`, error.message);
    }
  }
}

async function runStartupBackupIfNeeded() {
  const databaseUrl = env?.databaseUrl || process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.warn('Backup automático omitido: DATABASE_URL no está configurado.');
    return;
  }

  const backupDir = process.env.STATIONCORE_BACKUP_DIR || path.join(getArenaOsHomeDir(), 'backups');
  fs.mkdirSync(backupDir, { recursive: true });

  const today = getLocalDateKey();
  const marker = readAutoBackupMarker();
  if (marker?.lastBackupDate === today && marker?.lastBackupFile && fs.existsSync(marker.lastBackupFile)) {
    console.log(`Backup automático omitido: ya existe backup de hoy (${path.basename(marker.lastBackupFile)}).`);
    return;
  }

  const existingToday = fs.readdirSync(backupDir).some((name) => name.startsWith(`stationcore-auto-${today}`) && name.endsWith('.dump'));
  if (existingToday) {
    writeAutoBackupMarker({ lastBackupDate: today, lastBackupFile: '', updatedAt: new Date().toISOString(), skipped: 'existing-file' });
    console.log('Backup automático omitido: ya hay un backup automático de hoy.');
    return;
  }

  const file = path.join(backupDir, `stationcore-auto-${safeFileTimestamp()}.dump`);
  console.log('StationCore creando backup automático de inicio...');
  await execFileAsync('pg_dump', ['--format=custom', '--file', file, databaseUrl], {
    windowsHide: true,
    maxBuffer: 1024 * 1024 * 20
  });

  writeAutoBackupMarker({ lastBackupDate: today, lastBackupFile: file, updatedAt: new Date().toISOString() });
  pruneOldAutoBackups();
  console.log(`Backup automático creado: ${file}`);
}


function normalizeVersionPart(value) {
  const parsed = Number.parseInt(String(value || '').replace(/\D.*/, ''), 10);
  return Number.isFinite(parsed) ? parsed : 0;
}

function compareVersions(a, b) {
  const left = String(a || '0.0.0').split(/[.-]/).map(normalizeVersionPart);
  const right = String(b || '0.0.0').split(/[.-]/).map(normalizeVersionPart);
  const length = Math.max(left.length, right.length, 3);
  for (let index = 0; index < length; index += 1) {
    const diff = (left[index] || 0) - (right[index] || 0);
    if (diff > 0) return 1;
    if (diff < 0) return -1;
  }
  return 0;
}

function getUpdateConfig() {
  const intervalHours = Number(process.env.STATIONCORE_UPDATE_CHECK_INTERVAL_HOURS || process.env.ARENAOS_UPDATE_CHECK_INTERVAL_HOURS || DEFAULT_UPDATE_CHECK_INTERVAL_HOURS);
  return {
    feedUrl: String(process.env.STATIONCORE_UPDATE_FEED_URL || process.env.ARENAOS_UPDATE_FEED_URL || '').trim(),
    intervalHours: Number.isFinite(intervalHours) && intervalHours > 0 ? intervalHours : DEFAULT_UPDATE_CHECK_INTERVAL_HOURS,
    installedVersion: getInstalledAppVersion(),
    updatesDir: process.env.STATIONCORE_UPDATES_DIR || path.join(getArenaOsHomeDir(), 'updates')
  };
}

function normalizeUpdateFeed(payload = {}) {
  const version = String(payload.version || payload.latestVersion || '').trim();
  if (!version) {
    const error = new Error('El feed de actualización no tiene versión.');
    error.code = 'BAD_UPDATE_FEED';
    throw error;
  }
  const notes = Array.isArray(payload.notes)
    ? payload.notes.map((item) => String(item)).filter(Boolean)
    : String(payload.notes || payload.changelog || '').split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
  return {
    version,
    minVersion: payload.minVersion || payload.min_version || '',
    title: payload.title || `StationCore ${version}`,
    notes,
    downloadUrl: payload.downloadUrl || payload.download_url || payload.url || '',
    sha256: payload.sha256 || payload.hash || '',
    publishedAt: payload.publishedAt || payload.published_at || '',
    raw: payload
  };
}

async function fetchJsonWithTimeout(url, timeoutMs = 12000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        'User-Agent': `StationCore/${getInstalledAppVersion()}`
      }
    });
    if (!response.ok) throw new Error(`Servidor respondió ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}


function getUpdatesDir() {
  const config = getUpdateConfig();
  const updatesDir = config.updatesDir || path.join(getArenaOsHomeDir(), 'updates');
  fs.mkdirSync(updatesDir, { recursive: true });
  return updatesDir;
}



function normalizeReceiptText(value = '') {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ñ/g, 'n')
    .replace(/Ñ/g, 'N')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[–—]/g, '-')
    .replace(/[^\x00-\x7F]/g, '')
    .replace(/[\r\n]+/g, ' ')
    .trim();
}

function centerReceiptLine(text = '', width = 42) {
  const value = normalizeReceiptText(text).slice(0, width);
  const left = Math.max(0, Math.floor((width - value.length) / 2));
  return `${' '.repeat(left)}${value}`.slice(0, width);
}

function receiptLine(left = '', right = '', width = 42) {
  const l = normalizeReceiptText(left);
  const r = normalizeReceiptText(right);
  if (!right) return l.slice(0, width);
  const space = Math.max(1, width - l.length - r.length);
  if (l.length + r.length + space <= width) return `${l}${' '.repeat(space)}${r}`;
  return `${l.slice(0, Math.max(1, width - r.length - 1))} ${r}`.slice(0, width);
}

function formatReceiptMoney(value) {
  const amount = Number(value || 0);
  return `RD$${amount.toFixed(2)}`;
}

function formatReceiptDate(value = null) {
  const date = value ? new Date(value) : new Date();
  if (Number.isNaN(date.getTime())) return normalizeReceiptText(String(value || ''));
  const pad = (number) => String(number).padStart(2, '0');
  let hours = date.getHours();
  const minutes = pad(date.getMinutes());
  const seconds = pad(date.getSeconds());
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  if (hours === 0) hours = 12;
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(hours)}:${minutes}:${seconds} ${ampm}`;
}

function escPosTextBlock(lines = []) {
  return lines.join('\n');
}

function buildSaleReceiptText(receipt = {}) {
  const width = 42;
  const lines = [];
  const businessName = normalizeReceiptText(receipt.businessName || process.env.BUSINESS_NAME || 'Club Versus') || 'Club Versus';
  const date = formatReceiptDate(receipt.date || null);
  const cashier = normalizeReceiptText(receipt.cashier || '');
  const station = normalizeReceiptText(receipt.station || '');
  const member = normalizeReceiptText(receipt.member || '');
  const saleLabel = normalizeReceiptText(receipt.saleLabel || '');
  const paymentMethod = String(receipt.paymentMethod || 'CASH').toUpperCase() === 'TRANSFER' ? 'Transferencia' : 'Efectivo';
  const safeLines = Array.isArray(receipt.lines) ? receipt.lines : [];

  lines.push('\x1B@'); // Inicializar impresora
  lines.push('\x1Ba\x01'); // Centrar
  lines.push('\x1BE\x01'); // Bold ON
  lines.push('\x1B!\x10'); // Texto alto para encabezado, sin hacerlo gigante
  lines.push(businessName);
  lines.push('\x1B!\x00'); // Normal
  lines.push('Recibo de venta');
  lines.push(date);
  lines.push('\x1BE\x00'); // Bold OFF
  lines.push('');
  lines.push('\x1Ba\x00'); // Izquierda
  if (saleLabel) lines.push(receiptLine('Tipo', saleLabel, width));
  if (cashier) lines.push(receiptLine('Cajero', cashier, width));
  if (station) lines.push(receiptLine('Estacion', station, width));
  if (member) lines.push(receiptLine('Cliente', member, width));
  lines.push('-'.repeat(width));

  if (safeLines.length) {
    for (const item of safeLines) {
      const name = normalizeReceiptText(item.name || item.description || 'Articulo');
      const qty = Number(item.quantity || 1);
      const total = Number(item.total ?? item.amount ?? 0);
      const label = qty > 1 ? `${qty} x ${name}` : name;
      lines.push(receiptLine(label, formatReceiptMoney(total), width));
      const note = normalizeReceiptText(item.note || '');
      if (note) lines.push(`  ${note}`.slice(0, width));
    }
  } else {
    lines.push(receiptLine('Venta', formatReceiptMoney(receipt.total || 0), width));
  }

  lines.push('-'.repeat(width));
  lines.push('\x1BE\x01');
  lines.push(receiptLine('TOTAL', formatReceiptMoney(receipt.total || 0), width));
  lines.push('\x1BE\x00');
  lines.push(receiptLine('Pago', paymentMethod, width));
  if (String(receipt.paymentMethod || 'CASH').toUpperCase() === 'CASH' || paymentMethod === 'Efectivo') {
    lines.push(receiptLine('Recibido', formatReceiptMoney(receipt.received || receipt.total || 0), width));
    lines.push(receiptLine('Cambio', formatReceiptMoney(receipt.change || 0), width));
  }
  lines.push('');
  lines.push('\x1Ba\x01');
  lines.push('Gracias por su visita');
  lines.push('');
  lines.push('');
  lines.push('');
  lines.push('\x1D\x56\x00'); // Corte completo si la impresora lo soporta
  return escPosTextBlock(lines);
}


function buildDrawerReceiptText(receipt = {}) {
  const width = 42;
  const lines = [];
  const businessName = normalizeReceiptText(receipt.businessName || process.env.BUSINESS_NAME || 'Club Versus') || 'Club Versus';
  const type = String(receipt.type || receipt.kind || '').toUpperCase();
  const isClose = type === 'DRAWER_CLOSE' || type === 'CLOSE';
  const title = isClose ? 'CIERRE / CUADRE DE CAJA' : 'APERTURA DE CAJA';
  const cashier = normalizeReceiptText(receipt.cashier || receipt.user || '');
  const openedAt = receipt.openedAt || receipt.opened_at || receipt.date || null;
  const closedAt = receipt.closedAt || receipt.closed_at || null;
  const openingAmount = Number(receipt.openingAmount ?? receipt.opening_amount ?? 0);
  const cashSales = Number(receipt.cashSales ?? receipt.cash_sales ?? 0);
  const drawerIn = Number(receipt.drawerIn ?? receipt.drawer_in ?? 0);
  const drawerOut = Number(receipt.drawerOut ?? receipt.drawer_out ?? 0);
  const expectedCash = Number(receipt.expectedCash ?? receipt.expected_cash ?? (openingAmount + cashSales + drawerIn - drawerOut));
  const closingAmount = Number(receipt.closingAmount ?? receipt.closing_amount ?? expectedCash);
  const cashDifference = Number(receipt.cashDifference ?? receipt.cash_difference ?? (closingAmount - expectedCash));
  const moneyToDeliver = Number(receipt.moneyToDeliver ?? receipt.money_to_deliver ?? Math.max(0, expectedCash - openingAmount));

  lines.push('\x1B@');
  lines.push('\x1Ba\x01');
  lines.push('\x1BE\x01');
  lines.push('\x1B!\x10');
  lines.push(businessName);
  lines.push('\x1B!\x00');
  lines.push(title);
  lines.push(formatReceiptDate(isClose ? (closedAt || null) : (openedAt || null)));
  lines.push('\x1BE\x00');
  lines.push('');
  lines.push('\x1Ba\x00');
  if (cashier) lines.push(receiptLine('Usuario', cashier, width));
  if (openedAt) lines.push(receiptLine('Abierta', formatReceiptDate(openedAt), width));
  if (isClose && closedAt) lines.push(receiptLine('Cerrada', formatReceiptDate(closedAt), width));
  lines.push('-'.repeat(width));
  lines.push(receiptLine('Fondo inicial', formatReceiptMoney(openingAmount), width));
  if (isClose) {
    lines.push(receiptLine('Ventas efectivo', formatReceiptMoney(cashSales), width));
    if (drawerIn > 0) lines.push(receiptLine('Entradas caja', formatReceiptMoney(drawerIn), width));
    if (drawerOut > 0) lines.push(receiptLine('Pagos / salidas', `-${formatReceiptMoney(drawerOut)}`, width));
    lines.push('-'.repeat(width));
    lines.push(receiptLine('Total esperado', formatReceiptMoney(expectedCash), width));
    lines.push(receiptLine('Efectivo contado', formatReceiptMoney(closingAmount), width));
    lines.push('-'.repeat(width));
    lines.push('\x1BE\x01');
    if (cashDifference < -0.005) {
      lines.push(receiptLine('FALTANTE', formatReceiptMoney(Math.abs(cashDifference)), width));
    } else if (cashDifference > 0.005) {
      lines.push(receiptLine('SOBRANTE', formatReceiptMoney(cashDifference), width));
    } else {
      lines.push(receiptLine('CUADRE EXACTO', formatReceiptMoney(0), width));
    }
    lines.push('\x1BE\x00');
    lines.push('-'.repeat(width));
    lines.push('\x1BE\x01');
    lines.push(receiptLine('DINERO A ENTREGAR', formatReceiptMoney(moneyToDeliver), width));
    lines.push('\x1BE\x00');
  }
  lines.push('');
  lines.push('\x1Ba\x01');
  lines.push(isClose ? 'Entregar este recibo con el dinero' : 'Caja abierta correctamente');
  lines.push('');
  lines.push('');
  lines.push('');
  lines.push('\x1D\x56\x00');
  return escPosTextBlock(lines);
}

function sanitizeUpdateFileName(name, fallback = 'StationCore_update.zip') {
  const clean = String(name || '')
    .replace(/[\\/:*?"<>|]+/g, '-')
    .replace(/\s+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120);
  return clean || fallback;
}

function getUpdateFileName(latest = {}) {
  let name = '';
  try {
    const parsed = new URL(latest.downloadUrl || '');
    name = path.basename(decodeURIComponent(parsed.pathname || ''));
  } catch {
    name = '';
  }
  const fallback = `StationCore-update-${String(latest.version || getInstalledAppVersion()).replace(/[^0-9A-Za-z._-]/g, '-')}.zip`;
  name = sanitizeUpdateFileName(name, fallback);
  if (!/\.zip$/i.test(name)) name = `${name}.zip`;
  return name;
}

function inferUpdateVersionFromFileName(name = '') {
  const match = String(name || '').match(/(\d+\.\d+\.\d+(?:[-.]\d+)?)/);
  return match ? match[1] : '';
}

function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  const data = fs.readFileSync(filePath);
  hash.update(data);
  return hash.digest('hex');
}

function getDownloadedUpdateInfo(latest = null) {
  const updatesDir = getUpdatesDir();
  if (!fs.existsSync(updatesDir)) return null;
  const zipFiles = fs.readdirSync(updatesDir)
    .filter((name) => /\.zip$/i.test(name))
    .map((name) => {
      const file = path.join(updatesDir, name);
      const stat = fs.statSync(file);
      return {
        file,
        name,
        sizeBytes: stat.size,
        version: latest?.version || inferUpdateVersionFromFileName(name),
        downloadedAt: stat.mtime.toISOString(),
        mtimeMs: stat.mtimeMs
      };
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);

  if (latest?.version) {
    const expectedName = getUpdateFileName(latest);
    const exact = zipFiles.find((item) => item.name === expectedName);
    if (exact) return exact;
    return null;
  }
  return zipFiles[0] || null;
}

function assertSupportedUpdateUrl(downloadUrl) {
  let parsed;
  try {
    parsed = new URL(downloadUrl);
  } catch {
    const error = new Error('La URL de descarga de la actualización no es válida.');
    error.code = 'BAD_UPDATE_DOWNLOAD_URL';
    throw error;
  }
  if (!['https:', 'http:'].includes(parsed.protocol)) {
    const error = new Error('Por seguridad, la descarga de updates solo acepta URLs http/https.');
    error.code = 'UNSUPPORTED_UPDATE_PROTOCOL';
    throw error;
  }
  return parsed.toString();
}

function getUpdateLogFile() {
  const logDir = process.env.STATIONCORE_LOG_DIR || path.join(getArenaOsHomeDir(), 'logs');
  fs.mkdirSync(logDir, { recursive: true });
  return path.join(logDir, 'stationcore-updates.log');
}

function writeUpdateLog(message, meta = {}) {
  try {
    const line = JSON.stringify({
      at: new Date().toISOString(),
      message,
      ...meta
    });
    fs.appendFileSync(getUpdateLogFile(), `${line}\n`, 'utf8');
  } catch (error) {
    console.warn('No se pudo escribir log de update:', error.message);
  }
}

function getUpdateStateFile() {
  const updatesDir = getUpdatesDir();
  if (electronApp.isPackaged) return path.join(updatesDir, '.stationcore-update-state.json');

  const devHash = crypto.createHash('sha1').update(appRoot).digest('hex').slice(0, 8);
  return path.join(updatesDir, `.stationcore-update-state.dev-${devHash}.json`);
}

function cleanupCompletedUpdateFile(state = {}) {
  try {
    const updateFile = state.updateFile || '';
    if (!updateFile) return state;

    const updatesDir = path.resolve(getUpdatesDir());
    const resolvedFile = path.resolve(updateFile);
    if (!resolvedFile.startsWith(updatesDir + path.sep)) return state;

    if (fs.existsSync(resolvedFile)) fs.unlinkSync(resolvedFile);
    return {
      ...state,
      updateFileCleanedAt: state.updateFileCleanedAt || new Date().toISOString()
    };
  } catch (error) {
    writeUpdateLog('No se pudo limpiar ZIP de update completado.', {
      updateFile: state.updateFile || '',
      error: error.message || String(error)
    });
    return state;
  }
}

function normalizeUpdateState(state) {
  if (!state || typeof state !== 'object') return null;

  const targetVersion = String(state.targetVersion || '').trim();
  const isPendingRestart = state.pendingRestart || state.status === 'applied';
  const appliedProcessStartedAt = String(state.appliedProcessStartedAt || '').trim();
  const restartedAfterApply = Boolean(appliedProcessStartedAt && appliedProcessStartedAt !== APP_PROCESS_STARTED_AT);

  if (isPendingRestart && targetVersion && restartedAfterApply && compareVersions(getInstalledAppVersion(), targetVersion) >= 0) {
    let completedState = {
      ...state,
      status: 'completed',
      pendingRestart: false,
      completedAfterRestartAt: state.completedAfterRestartAt || new Date().toISOString()
    };
    completedState = cleanupCompletedUpdateFile(completedState);
    writeUpdateState(completedState);
    writeUpdateLog('Update confirmado despues de reinicio.', {
      targetVersion,
      installedVersion: getInstalledAppVersion(),
      updateFileCleanedAt: completedState.updateFileCleanedAt || ''
    });
    return completedState;
  }

  if (isPendingRestart) {
    return {
      ...state,
      status: 'applied',
      pendingRestart: true
    };
  }

  return state;
}

function readRawUpdateState() {
  try {
    const stateFile = getUpdateStateFile();
    if (!fs.existsSync(stateFile)) return null;
    return JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  } catch {
    return null;
  }
}

function readUpdateState() {
  return normalizeUpdateState(readRawUpdateState());
}

function writeUpdateState(state) {
  try {
    fs.writeFileSync(getUpdateStateFile(), JSON.stringify(state, null, 2), 'utf8');
  } catch (error) {
    console.warn('No se pudo guardar estado de update:', error.message);
  }
}

function isInsidePath(childPath, parentPath) {
  const relative = path.relative(path.resolve(parentPath), path.resolve(childPath));
  return Boolean(relative) && !relative.startsWith('..') && !path.isAbsolute(relative);
}

function shouldSkipUpdateEntry(relativePath) {
  const normalized = String(relativePath || '').replace(/\\/g, '/').replace(/^\/+/, '');
  if (!normalized) return true;
  const parts = normalized.split('/').filter(Boolean);
  if (!parts.length) return true;
  const first = parts[0].toLowerCase();
  const base = parts[parts.length - 1].toLowerCase();
  return [
    '.env',
    'node_modules',
    'dist',
    'backups',
    'logs',
    'updates',
    '.git'
  ].includes(first) || ['.env', '.env.local', '.env.production', '.env.development'].includes(base);
}

function findUpdatePayloadRoot(stagingDir) {
  const entries = fs.readdirSync(stagingDir, { withFileTypes: true }).filter((entry) => !entry.name.startsWith('__MACOSX'));
  const hasAppMarkers = entries.some((entry) => ['package.json', 'desktop', 'public', 'src', 'migrations', 'scripts'].includes(entry.name));
  if (hasAppMarkers) return stagingDir;
  if (entries.length === 1 && entries[0].isDirectory()) {
    const nested = path.join(stagingDir, entries[0].name);
    const nestedEntries = fs.readdirSync(nested, { withFileTypes: true });
    const nestedHasMarkers = nestedEntries.some((entry) => ['package.json', 'desktop', 'public', 'src', 'migrations', 'scripts'].includes(entry.name));
    if (nestedHasMarkers) return nested;
  }
  return stagingDir;
}

function copyUpdatePayload(sourceDir, targetDir) {
  const copied = [];
  const skipped = [];

  function walk(currentSource, relativeBase = '') {
    const entries = fs.readdirSync(currentSource, { withFileTypes: true });
    for (const entry of entries) {
      const relative = path.join(relativeBase, entry.name);
      if (shouldSkipUpdateEntry(relative)) {
        skipped.push(relative);
        continue;
      }
      const source = path.join(currentSource, entry.name);
      const destination = path.join(targetDir, relative);
      if (!isInsidePath(destination, targetDir)) {
        skipped.push(relative);
        continue;
      }
      if (entry.isDirectory()) {
        fs.mkdirSync(destination, { recursive: true });
        walk(source, relative);
        continue;
      }
      if (!entry.isFile()) {
        skipped.push(relative);
        continue;
      }
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      fs.copyFileSync(source, destination);
      copied.push(relative.replace(/\\/g, '/'));
    }
  }

  walk(sourceDir);
  return { copied, skipped };
}

async function runUpdateNodeScript(relativeScript, label) {
  const scriptPath = path.join(appRoot, relativeScript);
  if (!fs.existsSync(scriptPath)) throw new Error(`No se encontró ${label}: ${relativeScript}`);

  const result = await execFileAsync(process.execPath, [scriptPath], {
    cwd: appRoot,
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: '1',
      STATIONCORE_ENV_FILE: process.env.STATIONCORE_ENV_FILE || ''
    },
    windowsHide: true,
    maxBuffer: 1024 * 1024 * 20
  });

  writeUpdateLog(`${label} completado`, {
    output: String(result.stdout || '').trim().slice(-6000)
  });
  return true;
}

async function validateCopiedUpdate() {
  await runUpdateNodeScript(path.join('scripts', 'migrate.js'), 'Migraciones del update');
  await runUpdateNodeScript(path.join('scripts', 'stationcore-doctor.js'), 'StationCore Doctor');
  return { migrationsCompleted: true, doctorCompleted: true };
}

async function prepareDatabaseBeforeServerStart() {
  await runUpdateNodeScript(path.join('scripts', 'migrate.js'), 'Migraciones de inicio');

  const state = readRawUpdateState();
  const isPendingUpdate = Boolean(state && (state.pendingRestart || state.status === 'applied'));
  if (!isPendingUpdate) return;

  if (!state.doctorCompleted) {
    await runUpdateNodeScript(path.join('scripts', 'stationcore-doctor.js'), 'StationCore Doctor post-update');
  }

  writeUpdateState({
    ...state,
    migrationsCompleted: true,
    doctorCompleted: true,
    postUpdateValidatedAt: state.postUpdateValidatedAt || new Date().toISOString()
  });
}

async function createPreUpdateBackup(latest = {}) {
  const databaseUrl = env?.databaseUrl || process.env.DATABASE_URL;
  if (!databaseUrl) {
    const error = new Error('DATABASE_URL no está configurado. No se aplicará update sin backup previo.');
    error.code = 'UPDATE_BACKUP_MISSING_DATABASE_URL';
    throw error;
  }

  const backupDir = process.env.STATIONCORE_BACKUP_DIR || path.join(getArenaOsHomeDir(), 'backups');
  fs.mkdirSync(backupDir, { recursive: true });
  const fromVersion = String(getInstalledAppVersion()).replace(/[^0-9A-Za-z._-]/g, '-');
  const toVersion = String(latest.version || 'update').replace(/[^0-9A-Za-z._-]/g, '-');
  const file = path.join(backupDir, `stationcore-pre-update-${fromVersion}-to-${toVersion}-${safeFileTimestamp()}.dump`);

  await execFileAsync('pg_dump', ['--format=custom', '--file', file, databaseUrl], {
    windowsHide: true,
    maxBuffer: 1024 * 1024 * 20
  });

  return file;
}

function removeDirectorySafe(dir) {
  try {
    if (dir && fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  } catch (error) {
    console.warn('No se pudo limpiar carpeta temporal de update:', error.message);
  }
}

async function extractZipToDirectory(zipFile, destinationDir) {
  fs.rmSync(destinationDir, { recursive: true, force: true });
  fs.mkdirSync(destinationDir, { recursive: true });

  if (process.platform === 'win32') {
    await execFileAsync('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      `Expand-Archive -LiteralPath ${JSON.stringify(zipFile)} -DestinationPath ${JSON.stringify(destinationDir)} -Force`
    ], { windowsHide: true, maxBuffer: 1024 * 1024 * 10 });
    return;
  }

  await execFileAsync('unzip', ['-q', '-o', zipFile, '-d', destinationDir], {
    windowsHide: true,
    maxBuffer: 1024 * 1024 * 10
  });
}

async function applyDownloadedUpdate(options = {}) {
  const startedAt = new Date().toISOString();
  let updateResult = lastUpdateCheck?.ok ? lastUpdateCheck : null;

  if (!updateResult?.latest || compareVersions(updateResult.latest.version, getInstalledAppVersion()) <= 0) {
    updateResult = await checkForUpdates({ notify: false, manual: true }).catch(() => null);
  }

  const latest = normalizeUpdateFeed(updateResult?.latest || {});
  const downloaded = updateResult?.downloaded || getDownloadedUpdateInfo(latest);

  if (compareVersions(latest.version, getInstalledAppVersion()) <= 0) {
    const state = readUpdateState();
    return {
      ok: false,
      updateAvailable: false,
      installedVersion: getInstalledAppVersion(),
      latest,
      downloaded,
      applied: state,
      startedAt,
      message: 'La actualización descargada ya no es más nueva que la versión instalada.'
    };
  }

  if (!downloaded?.file || !fs.existsSync(downloaded.file)) {
    return {
      ok: false,
      updateAvailable: Boolean(updateResult?.updateAvailable),
      installedVersion: getInstalledAppVersion(),
      latest,
      startedAt,
      message: 'No hay update descargado para aplicar.'
    };
  }

  if (latest.sha256) {
    const actualSha256 = sha256File(downloaded.file);
    if (actualSha256.toLowerCase() !== String(latest.sha256).trim().toLowerCase()) {
      const error = new Error('El ZIP descargado ya no coincide con el SHA256 del feed. No se aplicará.');
      error.code = 'UPDATE_APPLY_SHA256_MISMATCH';
      throw error;
    }
  }

  const stagingDir = path.join(getUpdatesDir(), `_staging-${safeFileTimestamp()}`);
  const previousVersion = getInstalledAppVersion();
  const state = {
    status: 'applying',
    previousVersion,
    targetVersion: latest.version,
    updateFile: downloaded.file,
    startedAt
  };
  writeUpdateState(state);
  writeUpdateLog('Iniciando aplicación de update', state);

  let backupFile = '';
  try {
    backupFile = await createPreUpdateBackup(latest);
    writeUpdateLog('Backup pre-update creado', { backupFile, targetVersion: latest.version });

    await extractZipToDirectory(downloaded.file, stagingDir);
    const payloadRoot = findUpdatePayloadRoot(stagingDir);
    const copyResult = copyUpdatePayload(payloadRoot, appRoot);
    const validationResult = await validateCopiedUpdate();

    const completedAt = new Date().toISOString();
    const appliedState = {
      status: 'applied',
      previousVersion,
      targetVersion: latest.version,
      appRoot,
      updateFile: downloaded.file,
      backupFile,
      copiedCount: copyResult.copied.length,
      skippedCount: copyResult.skipped.length,
      copied: copyResult.copied.slice(0, 200),
      skipped: copyResult.skipped.slice(0, 200),
      ...validationResult,
      startedAt,
      completedAt,
      appliedProcessStartedAt: APP_PROCESS_STARTED_AT,
      pendingRestart: true
    };
    writeUpdateState(appliedState);
    writeUpdateLog('Update aplicado. Reinicio pendiente.', appliedState);
    removeDirectorySafe(stagingDir);

    lastUpdateCheck = {
      ...updateResult,
      applied: appliedState,
      message: `Actualización v${latest.version} aplicada. Reinicia StationCore para completar.`
    };

    return {
      ok: true,
      installedVersion: previousVersion,
      latest,
      applied: appliedState,
      message: `Actualización v${latest.version} aplicada. Reinicia StationCore para completar.`
    };
  } catch (error) {
    const failedState = {
      ...state,
      status: 'error',
      backupFile,
      error: error.message || String(error),
      failedAt: new Date().toISOString()
    };
    writeUpdateState(failedState);
    writeUpdateLog('Update falló', failedState);
    removeDirectorySafe(stagingDir);
    throw error;
  }
}

async function downloadUpdatePackage(options = {}) {
  const config = getUpdateConfig();
  const startedAt = new Date().toISOString();
  if (!config.feedUrl) {
    return {
      ok: false,
      configured: false,
      installedVersion: config.installedVersion,
      startedAt,
      message: 'No hay servidor de actualizaciones configurado.'
    };
  }

  let updateResult = lastUpdateCheck;
  if (!updateResult?.ok || !updateResult?.updateAvailable || options.forceCheck) {
    updateResult = await checkForUpdates({ notify: false, manual: true });
  }

  if (!updateResult?.ok) return updateResult;
  if (!updateResult.updateAvailable) {
    return {
      ok: false,
      configured: true,
      updateAvailable: false,
      installedVersion: config.installedVersion,
      checkedAt: updateResult.checkedAt,
      message: 'No hay actualización nueva para descargar.'
    };
  }

  const latest = normalizeUpdateFeed(updateResult.latest || {});
  if (compareVersions(latest.version, getInstalledAppVersion()) <= 0) {
    return {
      ok: false,
      configured: true,
      updateAvailable: false,
      installedVersion: getInstalledAppVersion(),
      latest,
      checkedAt: updateResult.checkedAt,
      message: 'StationCore ya tiene esta versión o una más reciente.'
    };
  }

  if (!latest.downloadUrl) {
    const error = new Error('La actualización no tiene downloadUrl en el feed.');
    error.code = 'MISSING_UPDATE_DOWNLOAD_URL';
    throw error;
  }
  if (!latest.sha256) {
    const error = new Error('La actualización no tiene sha256. Por seguridad no se descargará.');
    error.code = 'MISSING_UPDATE_SHA256';
    throw error;
  }

  const downloadUrl = assertSupportedUpdateUrl(latest.downloadUrl);
  const updatesDir = getUpdatesDir();
  const fileName = getUpdateFileName(latest);
  const finalPath = path.join(updatesDir, fileName);
  const tempPath = `${finalPath}.download`;

  const response = await fetch(downloadUrl, {
    headers: {
      Accept: 'application/zip, application/octet-stream, */*',
      'User-Agent': `StationCore/${getInstalledAppVersion()}`
    }
  });
  if (!response.ok) throw new Error(`No se pudo descargar update. Servidor respondió ${response.status}`);

  const buffer = Buffer.from(await response.arrayBuffer());
  fs.writeFileSync(tempPath, buffer);

  const actualSha256 = sha256File(tempPath);
  if (actualSha256.toLowerCase() !== String(latest.sha256).trim().toLowerCase()) {
    try { fs.unlinkSync(tempPath); } catch {}
    const error = new Error('El SHA256 del update no coincide. Descarga rechazada.');
    error.code = 'UPDATE_SHA256_MISMATCH';
    error.expectedSha256 = latest.sha256;
    error.actualSha256 = actualSha256;
    throw error;
  }

  if (fs.existsSync(finalPath)) fs.unlinkSync(finalPath);
  fs.renameSync(tempPath, finalPath);

  const downloaded = {
    file: finalPath,
    name: fileName,
    sizeBytes: buffer.length,
    sha256: actualSha256,
    version: latest.version,
    downloadedAt: new Date().toISOString()
  };

  lastUpdateCheck = {
    ...updateResult,
    downloaded,
    message: `Actualización v${latest.version} descargada y verificada.`
  };

  return {
    ok: true,
    configured: true,
    updateAvailable: true,
    installedVersion: config.installedVersion,
    latest,
    downloaded,
    startedAt,
    message: `Actualización v${latest.version} descargada y verificada.`
  };
}

async function checkForUpdates(options = {}) {
  const config = getUpdateConfig();
  const checkedAt = new Date().toISOString();
  if (!config.feedUrl) {
    const result = {
      ok: true,
      configured: false,
      updateAvailable: false,
      installedVersion: config.installedVersion,
      checkedAt,
      message: 'No hay servidor de actualizaciones configurado.'
    };
    lastUpdateCheck = result;
    return result;
  }

  try {
    const payload = await fetchJsonWithTimeout(config.feedUrl);
    const latest = normalizeUpdateFeed(payload);
    const updateAvailable = compareVersions(latest.version, config.installedVersion) > 0;
    const result = {
      ok: true,
      configured: true,
      updateAvailable,
      installedVersion: config.installedVersion,
      latest,
      checkedAt,
      message: updateAvailable ? 'Hay una actualización disponible.' : 'StationCore está actualizado.'
    };
    lastUpdateCheck = result;

    if (updateAvailable && mainWindow && !mainWindow.isDestroyed() && options.notify !== false) {
      mainWindow.webContents.send('club-versus-desktop:update-available', result);
    }
    return result;
  } catch (error) {
    const result = {
      ok: false,
      configured: true,
      updateAvailable: false,
      installedVersion: config.installedVersion,
      checkedAt,
      message: error.name === 'AbortError' ? 'La búsqueda de actualización tardó demasiado.' : (error.message || 'No se pudo buscar actualización.')
    };
    lastUpdateCheck = result;
    return result;
  }
}

function scheduleUpdateChecks() {
  if (updateCheckTimer) clearInterval(updateCheckTimer);
  const config = getUpdateConfig();
  if (!config.feedUrl) return;
  const intervalMs = Math.max(1, config.intervalHours) * 60 * 60 * 1000;
  updateCheckTimer = setInterval(() => {
    checkForUpdates({ notify: true, automatic: true }).catch((error) => {
      console.warn('Búsqueda automática de actualización falló:', error.message);
    });
  }, intervalMs);
}

async function loadBackendModules() {
  ensureDesktopEnvFile();
  const envModule = await import('../src/config/env.js');
  const serverModule = await import('../server.js');
  env = envModule.env;
  startServer = serverModule.startServer;
  localHost = process.env.DESKTOP_SERVER_HOST || '127.0.0.1';
  localPort = Number(process.env.DESKTOP_SERVER_PORT || env.port || 3000);
  localUrl = `http://${localHost}:${localPort}`;
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    title: 'StationCore',
    width: 1440,
    height: 960,
    minWidth: 1180,
    minHeight: 720,
    backgroundColor: '#050814',
    show: false,
    autoHideMenuBar: true,
    fullscreenable: true,
    kiosk: isDesktopKioskEnabled(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDesktopKioskEnabled()) {
      mainWindow.setFullScreen(true);
    } else {
      mainWindow.maximize();
    }
  });

  mainWindow.webContents.on('preload-error', (_event, preloadPath, error) => {
    console.error('Error cargando preload de Electron:', preloadPath, error);
    dialog.showErrorBox(
      'StationCore Desktop',
      `No se pudo cargar el puente nativo de hardware.\n\n${error?.message || error}`
    );
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription) => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    dialog.showErrorBox(
      'StationCore no pudo cargar',
      `No se pudo abrir ${localUrl}.\n\nCódigo: ${errorCode}\nDetalle: ${errorDescription}`
    );
  });

  mainWindow.loadURL(localUrl);
  return mainWindow;
}

async function startLocalBackend() {
  if (localServer) return localServer;
  return new Promise((resolve, reject) => {
    try {
      localServer = startServer({ port: localPort, host: localHost });
      localServer.once('listening', () => resolve(localServer));
      localServer.once('error', reject);
    } catch (error) {
      reject(error);
    }
  });
}

function getLastUpdateCheckForCurrentInstall() {
  if (!lastUpdateCheck?.latest?.version) return lastUpdateCheck;
  const installedVersion = getInstalledAppVersion();
  if (compareVersions(lastUpdateCheck.latest.version, installedVersion) > 0) return lastUpdateCheck;
  return {
    ...lastUpdateCheck,
    updateAvailable: false,
    installedVersion,
    downloaded: null,
    message: 'StationCore está actualizado.'
  };
}

function registerDesktopIpc() {
  ipcMain.handle('club-versus-desktop:get-status', () => ({
    desktop: true,
    appName: env?.appName || 'StationCore',
    businessName: env?.businessName || 'Club Versus',
    localUrl,
    platform: process.platform,
    kiosk: isDesktopKioskEnabled(),
    envFile: process.env.STATIONCORE_ENV_FILE || '',
    version: getInstalledAppVersion(),
    updateConfig: getUpdateConfig(),
    lastUpdateCheck: getLastUpdateCheckForCurrentInstall()
  }));

  ipcMain.handle('club-versus-desktop:get-update-status', () => {
    const config = getUpdateConfig();
    const state = readUpdateState();
    const currentLastUpdateCheck = getLastUpdateCheckForCurrentInstall();
    const downloaded = getDownloadedUpdateInfo(currentLastUpdateCheck?.latest || null);
    return {
      ok: true,
      installedVersion: config.installedVersion,
      config,
      lastUpdateCheck: currentLastUpdateCheck,
      downloadedUpdate: downloaded,
      updateState: state
    };
  });

  ipcMain.handle('club-versus-desktop:check-updates', async (_event, options = {}) => checkForUpdates({
    notify: options.notify !== false,
    manual: options.manual !== false
  }));

  ipcMain.handle('club-versus-desktop:download-update', async (_event, options = {}) => downloadUpdatePackage(options));

  ipcMain.handle('club-versus-desktop:apply-update', async (_event, options = {}) => applyDownloadedUpdate(options));

  ipcMain.handle('club-versus-desktop:restart-app', () => {
    electronApp.relaunch();
    electronApp.quit();
    return { ok: true };
  });

  ipcMain.handle('club-versus-desktop:reload-pos', () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.reload();
    return { ok: true };
  });

  ipcMain.handle('club-versus-desktop:quit-app', () => {
    electronApp.quit();
    return { ok: true };
  });

  ipcMain.handle('club-versus-desktop:list-printers', async () => {
    const byName = new Map();
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        const electronPrinters = await mainWindow.webContents.getPrintersAsync();
        for (const printer of electronPrinters || []) {
          if (!printer?.name) continue;
          byName.set(printer.name, {
            name: printer.name,
            displayName: printer.displayName || printer.name,
            description: printer.description || '',
            status: printer.status || 0,
            isDefault: Boolean(printer.isDefault),
            isOffline: false,
            source: 'electron'
          });
        }
      }
    } catch (error) {
      console.warn('No se pudo listar impresoras desde Electron:', error.message);
    }

    try {
      const windowsPrinters = await listWindowsPrinters();
      for (const printer of windowsPrinters || []) {
        const current = byName.get(printer.name) || {};
        byName.set(printer.name, {
          ...printer,
          ...current,
          isDefault: Boolean(current.isDefault || printer.isDefault),
          isOffline: Boolean(printer.isOffline),
          description: current.description || printer.description || printer.driverName || printer.portName || ''
        });
      }
    } catch (error) {
      console.warn('No se pudo listar impresoras desde Windows:', error.message);
    }

    const printers = Array.from(byName.values()).sort((a, b) => {
      if (a.isDefault && !b.isDefault) return -1;
      if (!a.isDefault && b.isDefault) return 1;
      return String(a.displayName || a.name).localeCompare(String(b.displayName || b.name));
    });

    return { ok: true, printers };
  });

  ipcMain.handle('club-versus-desktop:get-hardware-config', async () => ({
    ok: true,
    config: await getHardwareConfig()
  }));

  ipcMain.handle('club-versus-desktop:save-hardware-config', async (_event, config) => ({
    ok: true,
    config: await saveHardwareConfig(config || {})
  }));

  ipcMain.handle('club-versus-desktop:kick-cash-drawer', async (_event, payload = {}) => {
    const config = await getHardwareConfig();
    if (config.cashDrawerEnabled === false) return { ok: true, skipped: true, message: 'Apertura de caja desactivada.' };

    const eventMap = {
      'drawer-open-count': 'drawerOpenCount',
      'cash-payment': 'cashPayment',
      'drawer-close-count': 'drawerCloseCount'
    };
    const eventKey = eventMap[payload.reason] || payload.reason;
    if (eventKey && config.cashDrawerEvents?.[eventKey] === false) {
      return { ok: true, skipped: true, message: 'Evento de caja desactivado.' };
    }

    const printerName = payload.printerName || config.cashDrawerPrinterName || config.receiptPrinterName;
    const hexData = payload.hexData || config.cashDrawerKickHex || '1B700019FA';
    await sendRawToPrinter({ printerName, hexData, jobName: 'StationCore - Abrir caja' });
    return { ok: true };
  });

  ipcMain.handle('club-versus-desktop:test-receipt-printer', async (_event, payload = {}) => {
    const config = await getHardwareConfig();
    const printerName = payload.printerName || config.receiptPrinterName;
    const now = formatReceiptDate();
    const businessName = normalizeReceiptText(process.env.BUSINESS_NAME || 'Club Versus') || 'Club Versus';
    const body = escPosTextBlock([
      '\x1B@',
      '\x1Ba\x01',
      '\x1BE\x01',
      '\x1B!\x10',
      businessName,
      '\x1B!\x00',
      'Prueba de impresora',
      now,
      '\x1BE\x00',
      '',
      'Impresora configurada correctamente.',
      '',
      '',
      '',
      '\x1D\x56\x00'
    ]);
    const hexData = textToEscPosHex(body);
    await sendRawToPrinter({ printerName, hexData, jobName: `${businessName} - Prueba impresora` });
    return { ok: true };
  });

  ipcMain.handle('club-versus-desktop:print-receipt', async (_event, payload = {}) => {
    const config = await getHardwareConfig();
    const printerName = payload.printerName || config.receiptPrinterName;
    const receipt = payload.receipt || payload || {};
    const receiptType = String(receipt.type || receipt.kind || '').toUpperCase();
    const body = receiptType.startsWith('DRAWER_') ? buildDrawerReceiptText(receipt) : buildSaleReceiptText(receipt);
    const hexData = textToEscPosHex(body);
    await sendRawToPrinter({ printerName, hexData, jobName: receiptType.startsWith('DRAWER_') ? 'Club Versus - Cuadre caja' : 'Club Versus - Recibo' });
    return { ok: true };
  });
}

async function boot() {
  Menu.setApplicationMenu(null);

  try {
    await loadBackendModules();
    await prepareDatabaseBeforeServerStart();
    registerDesktopIpc();
    await startLocalBackend();
    runStartupBackupIfNeeded().catch((backupError) => {
      console.warn('Backup automático de inicio falló:', backupError.message);
    });
    createMainWindow();
    scheduleUpdateChecks();
    setTimeout(() => {
      checkForUpdates({ notify: true, automatic: true }).catch((updateError) => {
        console.warn('Búsqueda inicial de actualización falló:', updateError.message);
      });
    }, 5000);
  } catch (error) {
    dialog.showErrorBox(
      'No se pudo iniciar StationCore',
      `Revisa PostgreSQL, .env y el puerto ${localPort}.\n\n${error.message}`
    );
    electronApp.quit();
  }
}

electronApp.whenReady().then(boot);

electronApp.on('window-all-closed', () => {
  if (process.platform !== 'darwin') electronApp.quit();
});

electronApp.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
});

electronApp.on('before-quit', () => {
  if (updateCheckTimer) {
    clearInterval(updateCheckTimer);
    updateCheckTimer = null;
  }
  if (localServer) {
    localServer.close();
    localServer = null;
  }
});
