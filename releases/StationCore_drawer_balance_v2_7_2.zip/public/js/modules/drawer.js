(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};
  window.ClubVersusModules.drawer = window.ClubVersusModules.drawer || {};
})();

// Módulo de Caja / cuadre tipo JK POS.
// Mantiene funciones globales usadas por app.js y botones existentes.

const DRAWER_DENOMINATIONS = {
  bills: [2000, 1000, 500, 200, 100, 50],
  coins: [25, 10, 5, 1]
};

function openDrawerModule() {
  if (!requirePermission('drawer')) return;
  closeModuleHub();
  openDenominationCounter(state.drawer ? 'close' : 'open');
}

function closeDrawerModule() {
  closeConfigModule('#drawerModuleModal');
}

function renderDrawerModule() {
  const label = $('#drawerModuleStatus');
  const openBtn = $('#drawerOpenActionBtn');
  const closeBtn = $('#drawerCloseActionBtn');
  const paymentBtn = $('#drawerPaymentActionBtn');
  const quickPaymentBtn = $('#quickDrawerPaymentActionBtn');
  if (!label || !openBtn || !closeBtn) return;

  const drawer = state.drawer;
  const summary = drawer?.summary || {};
  const isOpen = Boolean(drawer);

  if (isOpen) {
    label.textContent = `Abierta · ${formatTime(drawer.opened_at)}`;
  } else {
    label.textContent = 'Cerrada';
  }

  openBtn.disabled = isOpen;
  closeBtn.disabled = !isOpen;
  if (paymentBtn) paymentBtn.disabled = !isOpen;
  if (quickPaymentBtn) {
    quickPaymentBtn.disabled = !isOpen;
    quickPaymentBtn.classList.toggle('is-disabled', !isOpen);
    quickPaymentBtn.title = isOpen ? 'Registrar salida de efectivo autorizada' : 'Abre la caja antes de registrar un pago';
  }
  setDrawerText('#drawerOpeningAmount', money(drawer?.opening_amount || 0));
  setDrawerText('#drawerCashSales', money(summary.cash_sales || 0));
  setDrawerText('#drawerTransferSales', money(summary.transfer_sales || 0));
  setDrawerText('#drawerCashIn', money(summary.drawer_in || 0));
  setDrawerText('#drawerCashOut', money(summary.drawer_out || 0));
  setDrawerText('#drawerExpectedCash', money(summary.expected_cash || 0));

  const movements = Array.isArray(summary.movements) ? summary.movements : [];
  const movementsList = $('#drawerMovementsList');
  if (movementsList) {
    movementsList.innerHTML = movements.length
      ? movements.map((movement) => `
        <div class="drawer-movement-row ${String(movement.type || '').toLowerCase()}">
          <span>
            <strong>${movement.type === 'OUT' ? 'Pago' : 'Entrada'}</strong>
            <small>${formatDateTime(movement.created_at)} · ${movement.user_name || 'Usuario'}</small>
            <em>${movement.reason || 'Sin razón'}</em>
          </span>
          <b>${movement.type === 'OUT' ? '-' : '+'}${money(movement.amount)}</b>
        </div>
      `).join('')
      : '<div class="empty-state compact">Sin movimientos de caja.</div>';
  }
  setDrawerText('#drawerMovementsCount', movements.length ? `${movements.length} movimiento(s)` : 'Sin movimientos');
}


function getDrawerUserName(drawer = state.drawer) {
  return drawer?.opened_by_name || drawer?.closed_by_name || state.user?.full_name || state.user?.name || state.user?.username || 'Usuario';
}

async function printDrawerReceipt(type, drawerPayload = null) {
  const desktopApi = window.clubVersusDesktop || window.ClubVersusDesktop || window.desktopAPI || null;
  if (!desktopApi?.printReceipt) return;
  const drawer = drawerPayload || state.drawer || {};
  const summary = drawer.summary || state.drawer?.summary || {};
  const openingAmount = Number(drawer.opening_amount || 0);
  const expectedCash = Number(summary.expected_cash ?? drawer.expected_cash ?? 0);
  const closingAmount = Number(drawer.closing_amount ?? expectedCash);
  const cashDifference = Number(summary.cash_difference ?? drawer.cash_difference ?? (closingAmount - expectedCash));
  const payload = {
    type,
    businessName: 'Club Versus',
    cashier: type === 'DRAWER_CLOSE' ? (drawer.closed_by_name || getDrawerUserName(drawer)) : (drawer.opened_by_name || getDrawerUserName(drawer)),
    openedAt: drawer.opened_at || null,
    closedAt: drawer.closed_at || null,
    openingAmount,
    cashSales: Number(summary.cash_sales || 0),
    drawerIn: Number(summary.drawer_in || 0),
    drawerOut: Number(summary.drawer_out || 0),
    expectedCash,
    closingAmount,
    cashDifference,
    moneyToDeliver: Math.max(0, expectedCash - openingAmount)
  };
  try {
    await desktopApi.printReceipt({ receipt: payload });
  } catch (error) {
    console.warn('No se pudo imprimir recibo de caja:', error?.message || error);
    showToast('Caja guardada, pero no se pudo imprimir el recibo de cuadre. Revisa impresora.');
  }
}

function setDrawerText(selector, value) {
  const el = $(selector);
  if (el) el.textContent = value;
}

function openDenominationCounter(mode) {
  state.denominationMode = mode;

  if (window.ClubVersusHardware?.kickCashDrawerForEvent) {
    window.ClubVersusHardware.kickCashDrawerForEvent(mode === 'close' ? 'drawer-close-count' : 'drawer-open-count');
  }

  const isClose = mode === 'close';
  const modal = $('#denominationModal');
  const title = $('#denominationTitle');
  const subtitle = $('#denominationSubtitle');
  const note = $('#denominationNote');
  const confirmBtn = $('#confirmDenominationBtn');
  const openingPanel = $('#openingCountPanel');
  const closingPanel = $('#closingCountPanel');

  if (title) title.textContent = isClose ? 'Cerrar caja' : 'Apertura de caja';
  if (subtitle) subtitle.textContent = isClose ? 'Cuenta el efectivo final.' : 'Cuenta el efectivo inicial.';
  modal?.classList.toggle('drawer-count-closing', isClose);
  modal?.classList.toggle('drawer-count-opening', !isClose);
  if (note) {
    note.value = '';
    note.classList.toggle('hidden', !isClose);
  }
  if (confirmBtn) confirmBtn.textContent = isClose ? 'Cerrar caja' : 'Abrir caja';

  const openingBreakdown = isClose ? normalizeDenominationBreakdown(state.drawer?.opening_breakdown) : {};
  renderDenominationRows('billsList', DRAWER_DENOMINATIONS.bills, 'opening', { values: openingBreakdown, readonly: isClose });
  renderDenominationRows('coinsList', DRAWER_DENOMINATIONS.coins, 'opening', { values: openingBreakdown, readonly: isClose });
  setDenominationOther('opening', openingBreakdown.other || 0, isClose);

  renderDenominationRows('closingBillsList', DRAWER_DENOMINATIONS.bills, 'closing', { values: {}, readonly: !isClose });
  renderDenominationRows('closingCoinsList', DRAWER_DENOMINATIONS.coins, 'closing', { values: {}, readonly: !isClose });
  setDenominationOther('closing', 0, !isClose);

  if (openingPanel) {
    openingPanel.classList.toggle('drawer-count-reference', isClose);
    openingPanel.classList.toggle('drawer-count-active', !isClose);
  }
  if (closingPanel) {
    closingPanel.classList.toggle('drawer-count-disabled', !isClose);
    closingPanel.classList.toggle('drawer-count-active', isClose);
    closingPanel.classList.toggle('hidden', !isClose);
  }

  const expectedCard = $('#denominationExpectedCard');
  const differenceCard = $('#denominationDifferenceCard');
  expectedCard?.classList.toggle('hidden', !isClose);
  differenceCard?.classList.toggle('hidden', !isClose);

  updateDenominationTotal();
  modal?.classList.remove('hidden');
  modal?.setAttribute('aria-hidden', 'false');
  document.body.classList.add('drawer-count-open');
  document.body.classList.toggle('drawer-count-closing-open', isClose);
  document.body.classList.toggle('drawer-count-opening-open', !isClose);

  const firstInput = isClose
    ? modal?.querySelector('[data-denomination-scope="closing"]:not([disabled])')
    : modal?.querySelector('[data-denomination-scope="opening"]:not([disabled])');
  setTimeout(() => firstInput?.focus(), 50);
}

function closeDenominationCounter(options = {}) {
  $('#denominationModal')?.classList.add('hidden');
  $('#denominationModal')?.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('drawer-count-open', 'drawer-count-closing-open', 'drawer-count-opening-open');
  $('#denominationModal')?.classList.remove('drawer-count-opening', 'drawer-count-closing');
  state.denominationMode = null;
  if (!options.keepPendingLogout) state.logoutAfterDrawerClose = false;
}

function normalizeDenominationBreakdown(value) {
  if (!value) return {};
  if (typeof value === 'object') return value;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (_error) {
    return {};
  }
}

function renderDenominationRows(containerId, values, scope, options = {}) {
  const container = $(`#${containerId}`);
  if (!container) return;
  const breakdown = options.values || {};
  const readonly = Boolean(options.readonly);

  container.innerHTML = values.map((value) => {
    const count = Math.max(0, Number(breakdown[String(value)] || 0));
    const rowTotal = count * Number(value);
    return `
      <label class="denomination-row ${readonly ? 'readonly' : ''}">
        <span>RD$${value}</span>
        <input type="number" min="0" step="1" value="${count}" data-denomination="${value}" data-denomination-scope="${scope}" ${readonly ? 'disabled' : ''} />
        <strong data-denomination-total="${scope}-${value}">${money(rowTotal)}</strong>
      </label>
    `;
  }).join('');

  container.querySelectorAll('input').forEach((input) => {
    input.addEventListener('input', updateDenominationTotal);
    input.addEventListener('focus', () => input.select());
  });
}

function setDenominationOther(scope, value = 0, readonly = false) {
  const input = scope === 'closing' ? $('#closingDenominationOtherInput') : $('#denominationOtherInput');
  const total = scope === 'closing' ? $('#closingDenominationOtherTotal') : $('#denominationOtherTotal');
  if (!input) return;
  input.value = String(Math.max(0, Number(value || 0)));
  input.disabled = readonly;
  input.dataset.denominationScope = scope;
  input.classList.toggle('readonly', readonly);
  if (total) total.textContent = money(Number(input.value || 0));
  input.removeEventListener?.('input', updateDenominationTotal);
  input.addEventListener('input', updateDenominationTotal);
}

function getDenominationData(scope = null) {
  const activeScope = scope || (state.denominationMode === 'close' ? 'closing' : 'opening');
  const counts = {};
  let total = 0;

  document.querySelectorAll(`[data-denomination-scope="${activeScope}"][data-denomination]`).forEach((input) => {
    const value = Number(input.dataset.denomination);
    const count = Math.max(0, Number(input.value || 0));
    const rowTotal = value * count;
    counts[String(value)] = count;
    total += rowTotal;

    const totalLabel = document.querySelector(`[data-denomination-total="${activeScope}-${value}"]`);
    if (totalLabel) totalLabel.textContent = money(rowTotal);
  });

  const otherInput = activeScope === 'closing' ? $('#closingDenominationOtherInput') : $('#denominationOtherInput');
  const otherTotal = activeScope === 'closing' ? $('#closingDenominationOtherTotal') : $('#denominationOtherTotal');
  const other = Math.max(0, Number(otherInput?.value || 0));
  total += other;
  counts.other = other;
  if (otherTotal) otherTotal.textContent = money(other);

  return { counts, total };
}

function updateDenominationTotal() {
  const opening = getDenominationData('opening');
  const closing = getDenominationData('closing');
  const isClose = state.denominationMode === 'close';
  const active = isClose ? closing : opening;

  setDrawerText('#openingCountTotalLabel', money(opening.total));
  setDrawerText('#closingCountTotalLabel', isClose ? money(closing.total) : 'Pendiente');
  setDrawerText('#denominationTotal', money(active.total));

  if (isClose) {
    const expected = Number(state.drawer?.summary?.expected_cash || 0);
    const difference = active.total - expected;
    const differenceLabel = $('#denominationDifferenceCard span');
    let resultLabel = 'Cuadre exacto';
    let resultAmount = 0;
    if (difference < -0.005) {
      resultLabel = 'Faltante';
      resultAmount = Math.abs(difference);
    } else if (difference > 0.005) {
      resultLabel = 'Sobrante';
      resultAmount = difference;
    }
    setDrawerText('#denominationExpected', money(expected));
    if (differenceLabel) differenceLabel.textContent = resultLabel;
    setDrawerText('#denominationDifference', money(resultAmount));
    $('#denominationDifference')?.classList.toggle('positive', difference >= -0.005);
    $('#denominationDifference')?.classList.toggle('negative', difference < -0.005);
    setDrawerText('#denominationSubtitle', `${resultLabel}: ${money(resultAmount)}`);
  } else {
    setDrawerText('#denominationSubtitle', money(active.total));
  }
}

function showDrawerPaymentError(message = '') {
  const box = $('#drawerPaymentError');
  if (!box) return;
  box.textContent = message || '';
  box.classList.toggle('hidden', !message);
}

function openDrawerPaymentModal() {
  if (!state.drawer) return showToast('Abre la caja antes de registrar un pago');
  $('#drawerPaymentAmountInput').value = '';
  $('#drawerPaymentReasonInput').value = '';
  $('#drawerPaymentAuthorizationCodeInput').value = '';
  showDrawerPaymentError('');
  const modal = $('#drawerPaymentModal');
  modal?.classList.remove('hidden');
  modal?.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('#drawerPaymentAmountInput')?.focus(), 50);
}

function closeDrawerPaymentModal() {
  $('#drawerPaymentModal')?.classList.add('hidden');
  $('#drawerPaymentModal')?.setAttribute('aria-hidden', 'true');
  showDrawerPaymentError('');
}

async function confirmDrawerPayment() {
  const amount = Number($('#drawerPaymentAmountInput')?.value || 0);
  const reason = $('#drawerPaymentReasonInput')?.value?.trim() || '';
  const authorizationCode = $('#drawerPaymentAuthorizationCodeInput')?.value?.trim() || '';
  const button = $('#confirmDrawerPaymentBtn');
  showDrawerPaymentError('');

  if (!state.drawer) return showDrawerPaymentError('No hay caja abierta.');
  if (!Number.isFinite(amount) || amount <= 0) return showDrawerPaymentError('Ingresa un monto válido.');
  if (reason.length < 3) return showDrawerPaymentError('Escribe la razón del pago.');
  if (!/^\d{6}$/.test(authorizationCode)) return showDrawerPaymentError('Ingresa el código de autorización de 6 dígitos.');

  if (button) button.disabled = true;
  try {
    await api('/drawer/movement', {
      method: 'POST',
      body: JSON.stringify({ type: 'OUT', amount, reason, authorizationCode })
    });

    let drawerOpened = true;
    if (window.ClubVersusHardware?.kickCashDrawerForEvent) {
      try {
        await window.ClubVersusHardware.kickCashDrawerForEvent('cash-payment', { toast: true });
      } catch (drawerError) {
        drawerOpened = false;
        console.warn('Pago registrado, pero no se pudo abrir la caja:', drawerError?.message || drawerError);
      }
    }

    showToast(drawerOpened ? 'Pago registrado. Caja abierta.' : 'Pago registrado, pero no se pudo abrir la caja. Revisa Configuración > Hardware.');
    closeDrawerPaymentModal();
    await loadDrawer();
    renderDrawerModule();
  } catch (error) {
    showDrawerPaymentError(error.message || 'No se pudo registrar el pago.');
  } finally {
    if (button) button.disabled = false;
  }
}

async function confirmDenominationCounter() {
  const mode = state.denominationMode;
  const { counts, total } = getDenominationData(mode === 'close' ? 'closing' : 'opening');

  try {
    let drawerReceiptPayload = null;
    let drawerReceiptType = '';

    if (mode === 'open') {
      const response = await api('/drawer/open', {
        method: 'POST',
        body: JSON.stringify({ openingAmount: total, openingBreakdown: counts })
      });
      drawerReceiptPayload = response.drawer || null;
      drawerReceiptType = 'DRAWER_OPEN';

      showToast('Caja abierta');
    }

    if (mode === 'close') {
      const response = await api('/drawer/close', {
        method: 'POST',
        body: JSON.stringify({
          closingAmount: total,
          closingBreakdown: counts,
          closingNote: $('#denominationNote')?.value.trim() || ''
        })
      });
      drawerReceiptPayload = response.drawer || null;
      drawerReceiptType = 'DRAWER_CLOSE';

      showToast('Caja cerrada');
    }

    const shouldLogoutAfterClose = mode === 'close' && Boolean(state.logoutAfterDrawerClose);
    closeDenominationCounter({ keepPendingLogout: shouldLogoutAfterClose });
    if (drawerReceiptPayload && drawerReceiptType) await printDrawerReceipt(drawerReceiptType, drawerReceiptPayload);
    await loadDrawer();

    if (shouldLogoutAfterClose && typeof performLogout === 'function') {
      if (typeof closeCurrentEmployeeSection === 'function') await closeCurrentEmployeeSection();
      performLogout();
    }
  } catch (error) {
    showToast(error.message);
  }
}
