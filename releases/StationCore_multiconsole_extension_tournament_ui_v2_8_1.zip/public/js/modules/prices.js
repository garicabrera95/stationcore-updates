(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

// Precios, promociones, planes de membresía y bonos movidos desde app.js en v2.0.6.5.

const groupEventPriceTypes = [
  { value: 'GROUP', label: 'Grupo' },
  { value: 'BIRTHDAY', label: 'Cumpleaños' },
  { value: 'PRIVATE_EVENT', label: 'Todo el club' }
];

function getDefaultGroupEventPriceRows() {
  return [
    { price_type: 'GROUP', name: 'Grupo 5+ · 2 estaciones', min_players: 5, station_count: 2, is_full_club: false, duration_minutes: 60, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 10, notes: 'Grupo normal desde 5 personas.' },
    { price_type: 'GROUP', name: 'Grupo 5+ · 2 estaciones', min_players: 5, station_count: 2, is_full_club: false, duration_minutes: 120, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 20, notes: 'Recomendado para grupos.' },
    { price_type: 'BIRTHDAY', name: 'Cumpleaños básico', min_players: 6, station_count: 2, is_full_club: false, duration_minutes: 120, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 30, notes: 'Cumpleaños mínimo 2 horas.' },
    { price_type: 'BIRTHDAY', name: 'Cumpleaños premium', min_players: 8, station_count: 3, is_full_club: false, duration_minutes: 180, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 40, notes: 'Más estaciones para grupo grande.' },
    { price_type: 'PRIVATE_EVENT', name: 'Evento privado · todo el club', min_players: 10, station_count: 0, is_full_club: true, duration_minutes: 120, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 50, notes: 'Bloquea todo el club.' },
    { price_type: 'PRIVATE_EVENT', name: 'Evento privado · todo el club', min_players: 10, station_count: 0, is_full_club: true, duration_minutes: 180, price: 0, deposit_percent: 50, min_deposit_amount: 0, extra_player_price: 0, extra_station_price: 0, is_active: true, sort_order: 60, notes: 'Bloquea todo el club.' }
  ];
}

function getGroupEventPriceTypeLabel(value) {
  return groupEventPriceTypes.find((item) => item.value === String(value || '').toUpperCase())?.label || 'Grupo';
}

function renderGroupEventPriceRows() {
  const box = $('#groupEventPricesRows');
  if (!box) return;
  const rows = (state.groupEventPrices && state.groupEventPrices.length ? state.groupEventPrices : getDefaultGroupEventPriceRows())
    .slice()
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0));
  box.innerHTML = rows.map((row, index) => {
    const id = row.id || '';
    const type = String(row.price_type || row.priceType || 'GROUP').toUpperCase();
    const isFullClub = Boolean(row.is_full_club ?? row.isFullClub);
    return `
      <article class="group-event-price-row" data-group-event-price-row data-group-event-price-id="${escapeAttr(id)}">
        <div class="group-event-price-topline">
          <strong>${escapeHtml(row.name || getGroupEventPriceTypeLabel(type))}</strong>
          <label class="toggle-pill small-toggle">
            <input data-group-event-active type="checkbox" ${row.is_active !== false ? 'checked' : ''} />
            <span>Activo</span>
          </label>
        </div>
        <div class="group-event-price-grid">
          <label><span>Tipo</span><select data-group-event-type>${groupEventPriceTypes.map((item) => `<option value="${item.value}" ${type === item.value ? 'selected' : ''}>${item.label}</option>`).join('')}</select></label>
          <label><span>Nombre</span><input data-group-event-name type="text" value="${escapeAttr(row.name || '')}" placeholder="Ej. Cumpleaños básico" /></label>
          <label><span>Personas base incluidas</span><input data-group-event-min-players type="number" min="1" max="200" step="1" value="${Number(row.min_players ?? row.minPlayers ?? 5)}" /></label>
          <label><span>Estaciones incluidas</span><input data-group-event-stations type="number" min="0" max="50" step="1" value="${Number(row.station_count ?? row.stationCount ?? 1)}" ${isFullClub ? 'disabled' : ''} /></label>
          <label><span>Duración min</span><input data-group-event-duration type="number" min="30" step="15" value="${Number(row.duration_minutes ?? row.durationMinutes ?? 120)}" /></label>
          <label><span>Precio base RD$</span><input data-group-event-price type="number" min="0" step="1" value="${Number(row.price || 0).toFixed(0)}" /></label>
          <label><span>Persona extra RD$</span><input data-group-event-extra-player-price type="number" min="0" step="1" value="${Number(row.extra_player_price ?? row.extraPlayerPrice ?? 0).toFixed(0)}" /></label>
          <label><span>Estación extra RD$</span><input data-group-event-extra-station-price type="number" min="0" step="1" value="${Number(row.extra_station_price ?? row.extraStationPrice ?? 0).toFixed(0)}" /></label>
          <label><span>Depósito %</span><input data-group-event-deposit-percent type="number" min="0" max="100" step="1" value="${Number(row.deposit_percent ?? row.depositPercent ?? 50).toFixed(0)}" /></label>
          <label><span>Mín. depósito RD$</span><input data-group-event-min-deposit type="number" min="0" step="1" value="${Number(row.min_deposit_amount ?? row.minDepositAmount ?? 0).toFixed(0)}" /></label>
          <label class="group-event-switch-row"><span>Todo el club</span><input data-group-event-full-club type="checkbox" ${isFullClub ? 'checked' : ''} /><i aria-hidden="true"></i></label>
          <label><span>Orden</span><input data-group-event-order type="number" step="1" value="${Number(row.sort_order ?? row.sortOrder ?? ((index + 1) * 10))}" /></label>
        </div>
        <label class="group-event-notes"><span>Nota interna</span><input data-group-event-notes type="text" value="${escapeAttr(row.notes || '')}" placeholder="Opcional" /></label>
      </article>
    `;
  }).join('');
  box.querySelectorAll('[data-group-event-full-club]').forEach((input) => {
    input.addEventListener('change', () => {
      const row = input.closest('[data-group-event-price-row]');
      const stationsInput = row?.querySelector('[data-group-event-stations]');
      if (!stationsInput) return;
      stationsInput.disabled = input.checked;
      if (input.checked) stationsInput.value = '0';
      else if (Number(stationsInput.value || 0) <= 0) stationsInput.value = '2';
    });
  });
}

function addGroupEventPriceRow() {
  state.groupEventPrices = state.groupEventPrices || [];
  state.groupEventPrices.push({
    price_type: 'GROUP',
    name: 'Nuevo precio grupal',
    min_players: 5,
    station_count: 2,
    is_full_club: false,
    duration_minutes: 120,
    price: 0,
    deposit_percent: 50,
    min_deposit_amount: 0,
    extra_player_price: 0,
    extra_station_price: 0,
    is_active: true,
    sort_order: (state.groupEventPrices.length + 1) * 10,
    notes: ''
  });
  renderGroupEventPriceRows();
}

function collectGroupEventPriceRows() {
  return Array.from(document.querySelectorAll('[data-group-event-price-row]')).map((row, index) => {
    const isFullClub = Boolean(row.querySelector('[data-group-event-full-club]')?.checked);
    return {
      id: row.dataset.groupEventPriceId || null,
      priceType: row.querySelector('[data-group-event-type]')?.value || 'GROUP',
      name: row.querySelector('[data-group-event-name]')?.value?.trim() || 'Precio grupal',
      minPlayers: Number(row.querySelector('[data-group-event-min-players]')?.value || 5),
      stationCount: isFullClub ? 0 : Number(row.querySelector('[data-group-event-stations]')?.value || 1),
      isFullClub,
      durationMinutes: Number(row.querySelector('[data-group-event-duration]')?.value || 0),
      price: Number(row.querySelector('[data-group-event-price]')?.value || 0),
      depositPercent: Number(row.querySelector('[data-group-event-deposit-percent]')?.value || 50),
      minDepositAmount: Number(row.querySelector('[data-group-event-min-deposit]')?.value || 0),
      extraPlayerPrice: Number(row.querySelector('[data-group-event-extra-player-price]')?.value || 0),
      extraStationPrice: Number(row.querySelector('[data-group-event-extra-station-price]')?.value || 0),
      isActive: Boolean(row.querySelector('[data-group-event-active]')?.checked),
      sortOrder: Number(row.querySelector('[data-group-event-order]')?.value || ((index + 1) * 10)),
      notes: row.querySelector('[data-group-event-notes]')?.value?.trim() || ''
    };
  });
}

async function saveGroupEventPrices() {
  const prices = collectGroupEventPriceRows();
  try {
    const result = await api('/stations/group-event-prices', { method: 'PUT', body: JSON.stringify({ prices }) });
    state.groupEventPrices = result.prices || [];
    renderGroupEventPriceRows();
    showToast('Precios grupales guardados');
  } catch (error) {
    showToast(error.message || 'No se pudieron guardar precios grupales');
  }
}

function openTimePricesModule() {
  if (!requirePermission('prices')) return;
  closeModuleHub();
  if (!state.selectedTimePriceScope?.id) state.selectedTimePriceScope = { type: 'console', id: 'PlayStation 4' };
  renderTimePricesModule();
  $('#timePricesModuleModal').classList.remove('hidden');
  $('#timePricesModuleModal').setAttribute('aria-hidden', 'false');
}

function closeTimePricesModule() {
  closeConfigModule('#timePricesModuleModal');
}

function getDefaultKidsCourtesySettings() {
  return { enabled: false, consoleTypes: ['Nintendo Switch'], consoleType: 'Nintendo Switch', baseMinutes: 15, extensionMinutes: 5, label: 'Extensión niños' };
}

function normalizeKidsCourtesySettingsClient(settings = {}) {
  const requestedConsoleTypes = Array.isArray(settings.consoleTypes || settings.console_types)
    ? (settings.consoleTypes || settings.console_types)
    : [settings.consoleType || settings.console_type || 'Nintendo Switch'];
  const consoleTypes = [...new Set(requestedConsoleTypes
    .map((value) => String(value || '').trim())
    .filter((value) => priceConsoleTypes.includes(value)))];
  return {
    enabled: settings.enabled === true,
    consoleTypes,
    consoleType: consoleTypes[0] || '',
    baseMinutes: Math.max(1, Number(settings.baseMinutes ?? settings.base_minutes ?? 15)),
    extensionMinutes: Math.max(1, Number(settings.extensionMinutes ?? settings.extension_minutes ?? 5)),
    label: String(settings.label || 'Extensión niños').trim() || 'Extensión niños'
  };
}

async function loadKidsCourtesySettings() {
  try {
    const result = await api('/stations/kids-courtesy-extension');
    state.kidsCourtesySettings = normalizeKidsCourtesySettingsClient(result.settings || {});
    return state.kidsCourtesySettings;
  } catch (error) {
    state.kidsCourtesySettings = state.kidsCourtesySettings || getDefaultKidsCourtesySettings();
    throw error;
  }
}

function renderKidsCourtesySettingsCard() {
  const settings = normalizeKidsCourtesySettingsClient(state.kidsCourtesySettings || getDefaultKidsCourtesySettings());
  const consoleOptions = priceConsoleTypes.map((consoleType) => `
    <label class="kids-courtesy-console-option">
      <input type="checkbox" data-kids-courtesy-console value="${escapeAttr(consoleType)}" ${settings.consoleTypes.includes(consoleType) ? 'checked' : ''} />
      <span>${escapeHtml(consoleType)}</span>
    </label>
  `).join('');
  return `
    <details class="kids-courtesy-prices-card" open>
      <summary>
        <span>
          <strong>Extensión infantil</strong>
          <small>Configura el 15 + cortesía desde precios. Se cobra el tiempo base y se regalan minutos.</small>
        </span>
      </summary>
      <div class="kids-courtesy-prices-grid">
        <div class="kids-courtesy-console-field">
          <span>Aplicar esta extensión en</span>
          <div class="kids-courtesy-console-options">${consoleOptions}</div>
        </div>
        <div class="kids-courtesy-active-field">
          <span>Estado</span>
          <label class="toggle-pill kids-courtesy-active">
            <input id="kidsCourtesyEnabledInput" type="checkbox" ${settings.enabled ? 'checked' : ''} />
            <span>Extensión activa</span>
          </label>
        </div>
        <label class="kids-courtesy-base-field">
          <span>Duración base</span>
          <select id="kidsCourtesyBaseMinutesSelect">
            <option value="15" ${Number(settings.baseMinutes) === 15 ? 'selected' : ''}>15 min</option>
            <option value="30" ${Number(settings.baseMinutes) === 30 ? 'selected' : ''}>30 min</option>
          </select>
        </label>
        <label class="kids-courtesy-minutes-field">
          <span>Minutos cortesía</span>
          <input id="kidsCourtesyExtensionMinutesInput" type="number" min="1" max="60" step="1" value="${Number(settings.extensionMinutes || 5)}" />
        </label>
        <label class="kids-courtesy-label-field">
          <span>Nombre visible</span>
          <input id="kidsCourtesyLabelInput" type="text" maxlength="60" value="${escapeAttr(settings.label || 'Extensión niños')}" />
        </label>
        <button id="saveKidsCourtesySettingsBtn" type="button" class="compact">Guardar cambios</button>
      </div>
    </details>
  `;
}

function getKidsCourtesyFormPayload() {
  return {
    enabled: Boolean($('#kidsCourtesyEnabledInput')?.checked),
    consoleTypes: [...document.querySelectorAll('[data-kids-courtesy-console]:checked')].map((input) => input.value),
    baseMinutes: Number($('#kidsCourtesyBaseMinutesSelect')?.value || 15),
    extensionMinutes: Number($('#kidsCourtesyExtensionMinutesInput')?.value || 5),
    label: $('#kidsCourtesyLabelInput')?.value || 'Extensión niños'
  };
}

async function saveKidsCourtesySettings() {
  try {
    const payload = getKidsCourtesyFormPayload();
    if (payload.enabled && !payload.consoleTypes.length) {
      showToast('Selecciona al menos una consola');
      return;
    }
    const result = await api('/stations/kids-courtesy-extension', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
    state.kidsCourtesySettings = normalizeKidsCourtesySettingsClient(result.settings || payload);
    showToast('Extensión infantil guardada');
    renderTimePricesModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message || 'No se pudo guardar la extensión infantil');
  }
}

function bindKidsCourtesySettingsCard() {
  $('#saveKidsCourtesySettingsBtn')?.addEventListener('click', saveKidsCourtesySettings);
}


function getTimePriceScopeRows(playerCount = 1) {
  const scope = state.selectedTimePriceScope || { type: 'console', id: 'PlayStation 4' };
  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  let rows = [];

  if (scope.type === 'station') {
    rows = state.timePrices.filter((price) => price.station_id === scope.id && Number(price.player_count || 1) === normalizedPlayerCount);
  } else {
    rows = state.timePrices.filter((price) => !price.station_id && price.console_type === scope.id && Number(price.player_count || 1) === normalizedPlayerCount);
  }

  const byMinutes = new Map(rows.map((row) => [Number(row.minutes), row]));
  return timePackages.map((pkg, index) => {
    const saved = byMinutes.get(pkg.minutes);
    return saved || {
      id: '',
      label: pkg.label,
      minutes: pkg.minutes,
      player_count: normalizedPlayerCount,
      price: 0,
      is_active: Number(pkg.minutes) !== 15,
      sort_order: (index + 1) * 10
    };
  });
}

function getTimePriceScopeName(scope = state.selectedTimePriceScope) {
  const selectedScope = scope || { type: 'console', id: 'PlayStation 4' };
  if (selectedScope.type === 'station') {
    const station = state.stations.find((item) => String(item.id) === String(selectedScope.id));
    return station ? `${station.name} · ${station.console_type}` : 'Estación';
  }
  return selectedScope.id || 'Modelo';
}

function renderTimePriceEditorRows(rows, playerLabel) {
  const rowByMinutes = new Map(rows.map((row) => [Number(row.minutes), row]));
  const extension = rowByMinutes.get(15) || rows[0] || {};
  const regularPackages = timePackages.filter((pkg) => Number(pkg.minutes) !== 15);

  return `
    <section class="price-player-group redesigned-price-card">
      <div class="price-player-header">
        <h4>${playerLabel}</h4>
        <span class="price-player-badge">${rows.length} reglas</span>
      </div>

      <div class="extension-price-card" data-time-price-row data-time-price-player-count="${Number(extension.player_count || 1)}">
        <div class="extension-price-title">
          <span class="price-chip warning">Extensión</span>
          <strong>15 min</strong>
        </div>
        <input data-time-price-label type="hidden" value="Extensión 15 min" />
        <input data-time-price-minutes type="hidden" value="15" />
        <input data-time-price-order type="hidden" value="10" />
        <label class="price-input-box extension-input">
          <span>Precio</span>
          <input data-time-price-price type="number" min="0" step="1" value="${Number(extension.price || 0).toFixed(0)}" />
        </label>
        <label class="toggle-pill time-price-active extension-toggle">
          <input data-time-price-active type="checkbox" ${extension.is_active ? 'checked' : ''} />
          <span>Inicial</span>
        </label>
      </div>

      <div class="price-table-card">
        <div class="price-table-head">
          <span>Tiempo</span>
          <span>Precio</span>
          <span>Activo</span>
        </div>
        ${regularPackages.map((pkg, index) => {
          const price = rowByMinutes.get(Number(pkg.minutes)) || {
            label: pkg.label,
            minutes: pkg.minutes,
            player_count: Number(extension.player_count || 1),
            price: 0,
            is_active: true,
            sort_order: (index + 2) * 10
          };
          return `
            <div class="time-price-row redesigned-row" data-time-price-row data-time-price-player-count="${Number(price.player_count || 1)}">
              <input data-time-price-label type="hidden" value="${price.label || pkg.label}" />
              <input data-time-price-minutes type="hidden" value="${Number(price.minutes || pkg.minutes)}" />
              <input data-time-price-order type="hidden" value="${Number(price.sort_order || (index + 2) * 10)}" />
              <div class="price-duration-label">
                <strong>${price.label || pkg.label}</strong>
                <small>${Number(price.minutes || pkg.minutes)} min</small>
              </div>
              <label class="price-input-box compact">
                <span>RD$</span>
                <input data-time-price-price type="number" min="0" step="1" value="${Number(price.price || 0).toFixed(0)}" />
              </label>
              <label class="toggle-pill time-price-active small-toggle">
                <input data-time-price-active type="checkbox" ${price.is_active ? 'checked' : ''} />
                <span>Activo</span>
              </label>
            </div>
          `;
        }).join('')}
      </div>
    </section>
  `;
}

function renderTimePricesModule() {
  const consoleList = $('#timePricesConsoleList');
  const stationList = $('#timePricesStationList');
  const rowsBox = $('#timePricesRows');
  const title = $('#timePricesPanelTitle');
  const label = $('#timePricesScopeLabel');
  if (!consoleList || !stationList || !rowsBox || !title || !label) return;

  const scope = state.selectedTimePriceScope || { type: 'console', id: 'PlayStation 4' };

  consoleList.innerHTML = priceConsoleTypes.map((consoleType) => `
    <button type="button" class="time-price-scope ${scope.type === 'console' && scope.id === consoleType ? 'active-selection' : ''}" data-price-scope-type="console" data-price-scope-id="${consoleType}">
      <span class="mini-brand-badge ${getConsoleClass(consoleType)}">${getConsoleLogo(consoleType)}</span>
      <strong>${consoleType}</strong>
      <small>Base por modelo</small>
    </button>
  `).join('');

  stationList.innerHTML = state.stations.map((station) => `
    <button type="button" class="time-price-scope ${scope.type === 'station' && String(scope.id) === String(station.id) ? 'active-selection' : ''}" data-price-scope-type="station" data-price-scope-id="${station.id}">
      <span class="mini-brand-badge ${getConsoleClass(station.console_type)}">${getConsoleLogo(station.console_type)}</span>
      <span><strong>${station.name}</strong><small>${station.console_type}</small></span>
    </button>
  `).join('');

  document.querySelectorAll('[data-price-scope-type]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedTimePriceScope = { type: btn.dataset.priceScopeType, id: btn.dataset.priceScopeId };
      renderTimePricesModule();
    });
  });

  const scopeName = getTimePriceScopeName(scope);
  title.textContent = scope.type === 'station' ? 'Precios por estación' : 'Precios base por modelo';
  label.textContent = scopeName;

  renderGroupEventPriceRows();

  rowsBox.innerHTML = `
    <div class="price-editor-summary compact">
      <span class="price-chip">Editando</span>
      <h3>${scopeName}</h3>
    </div>
    ${renderKidsCourtesySettingsCard()}
    <div class="price-player-grid">
      ${timePlayerOptions.map((playerOption) => renderTimePriceEditorRows(getTimePriceScopeRows(playerOption.value), playerOption.label)).join('')}
    </div>
  `;
  bindKidsCourtesySettingsCard();
  renderGroupEventPriceRows();
}

function collectTimePriceRows() {
  return Array.from(document.querySelectorAll('[data-time-price-row]')).map((row, index) => ({
    label: row.querySelector('[data-time-price-label]').value.trim(),
    playerCount: Number(row.dataset.timePricePlayerCount || 1),
    minutes: Number(row.querySelector('[data-time-price-minutes]').value || 0),
    price: Number(row.querySelector('[data-time-price-price]').value || 0),
    isActive: row.querySelector('[data-time-price-active]').checked,
    sortOrder: Number(row.querySelector('[data-time-price-order]').value || (index + 1) * 10)
  }));
}

async function saveTimePrices() {
  const scope = state.selectedTimePriceScope || { type: 'console', id: 'PlayStation 4' };
  const rows = collectTimePriceRows();

  try {
    await api('/stations/time-prices', {
      method: 'PUT',
      body: JSON.stringify({
        scopeType: scope.type,
        consoleType: scope.type === 'console' ? scope.id : null,
        stationId: scope.type === 'station' ? scope.id : null,
        prices: rows
      })
    });
    showToast('Precios guardados');
    await loadTimePrices();
    renderTimePricesModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}

async function applyTimePricesToAll() {
  const rows = collectTimePriceRows();
  const answer = await showAppDialog({
    title: 'Aplicar a todas',
    subtitle: 'Esto copiará estos precios a todos los modelos y estaciones.',
    message: 'Úsalo cuando quieras configurar todo de una vez sin ir estación por estación.',
    primaryText: 'Aplicar',
    secondaryText: 'Cancelar'
  });
  if (answer !== 'primary') return;

  try {
    await api('/stations/time-prices', {
      method: 'PUT',
      body: JSON.stringify({ scopeType: 'all', prices: rows })
    });
    showToast('Precios aplicados a todas');
    await loadTimePrices();
    renderTimePricesModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}


const promotionDayOptions = [
  { value: 0, label: 'Dom' },
  { value: 1, label: 'Lun' },
  { value: 2, label: 'Mar' },
  { value: 3, label: 'Mié' },
  { value: 4, label: 'Jue' },
  { value: 5, label: 'Vie' },
  { value: 6, label: 'Sáb' }
];

function canManagePromotions() {
  return state.user?.role === 'OWNER' || state.user?.role === 'MANAGER' || hasPermission('promotions');
}

function inputDate(value) {
  if (!value) return '';
  return String(value).slice(0, 10);
}

function todayInputDate() {
  return new Date().toISOString().slice(0, 10);
}

function getPromotionScopeLabel(promotion) {
  if (promotion.scope_type === 'STATION') return promotion.station_name || 'Estación';
  if (promotion.scope_type === 'CONSOLE') return promotion.console_type || 'Modelo';
  return 'Todas';
}

function getPromotionTypeLabel(promotion) {
  if (promotion.discount_type === 'PERCENT') return `${Number(promotion.discount_value || 0).toFixed(0)}%`;
  return money(promotion.discount_value || 0);
}

async function openPromotionsModule() {
  if (!canManagePromotions()) return showToast('No tienes permiso');
  closeModuleHub();

  document.documentElement.classList.add('cv-config-module-open');
  document.body.classList.add('cv-config-module-open');
  const modal = $('#promotionsModuleModal');
  if (modal) window.ClubVersusCore?.modalManager?.open?.(modal, { base: 7200, focus: false });

  try {
    await loadBonusRules().catch((error) => console.warn('No se pudieron refrescar bonos', error));
    resetPromotionForm();
    renderPromotionsModule();
    renderMemberPricesModule();
    renderBonusRulesModule();
  } catch (error) {
    console.error('Error cargando descuentos:', error);
    showToast('No se pudo cargar Descuentos. Revisa la consola.');
  }
}

function closePromotionsModule() {
  closeConfigModule('#promotionsModuleModal');
}

function resetPromotionForm() {
  state.selectedPromotionId = null;
  $('#promotionFormTitle').textContent = 'Nueva promoción';
  $('#promotionNameInput').value = 'Happy Hour';
  $('#promotionTypeSelect').value = 'PERCENT';
  $('#promotionValueInput').value = '20';
  $('#promotionScopeSelect').value = 'ALL';
  $('#promotionConsoleSelect').value = 'PlayStation 4';
  renderPromotionStationOptions();
  $('#promotionStartDateInput').value = todayInputDate();
  $('#promotionEndDateInput').value = '';
  $('#promotionNoEndInput').checked = true;
  $('#promotionAllDayInput').checked = true;
  $('#promotionStartTimeInput').value = '14:00';
  $('#promotionEndTimeInput').value = '17:00';
  $('#promotionActiveInput').checked = true;
  renderPromotionDays([0, 1, 2, 3, 4, 5, 6]);
  updatePromotionFormVisibility();
  renderTournamentEntryDiscountRules();
}

function renderPromotionStationOptions(selectedId = '') {
  const select = $('#promotionStationSelect');
  if (!select) return;
  select.innerHTML = state.stations.map((station) => `<option value="${station.id}">${station.name} · ${station.console_type}</option>`).join('');
  if (selectedId) select.value = selectedId;
}

function renderPromotionDays(selectedDays = [0, 1, 2, 3, 4, 5, 6]) {
  const box = $('#promotionDaysList');
  if (!box) return;
  const days = selectedDays.map(Number);
  box.innerHTML = promotionDayOptions.map((day) => `
    <label class="day-chip">
      <input type="checkbox" value="${day.value}" ${days.includes(day.value) ? 'checked' : ''} />
      <span>${day.label}</span>
    </label>
  `).join('');
}

function updatePromotionFormVisibility() {
  const scope = $('#promotionScopeSelect').value;
  const allDay = $('#promotionAllDayInput').checked;
  const noEnd = $('#promotionNoEndInput').checked;

  $('#promotionConsoleLabel').classList.toggle('hidden', scope !== 'CONSOLE');
  $('#promotionStationLabel').classList.toggle('hidden', scope !== 'STATION');
  $('#promotionTimeRange').classList.toggle('hidden', allDay);
  $('#promotionEndDateInput').disabled = noEnd;
  if (noEnd) $('#promotionEndDateInput').value = '';
}

function selectPromotion(promotionId) {
  const promotion = state.promotions.find((item) => item.id === promotionId);
  if (!promotion) return;

  state.selectedPromotionId = promotion.id;
  $('#promotionFormTitle').textContent = promotion.name;
  $('#promotionNameInput').value = promotion.name || '';
  $('#promotionTypeSelect').value = promotion.discount_type || 'PERCENT';
  $('#promotionValueInput').value = Number(promotion.discount_value || 0).toFixed(0);
  $('#promotionScopeSelect').value = promotion.scope_type || 'ALL';
  $('#promotionConsoleSelect').value = promotion.console_type || 'PlayStation 4';
  renderPromotionStationOptions(promotion.station_id || '');
  $('#promotionStartDateInput').value = inputDate(promotion.starts_on) || todayInputDate();
  $('#promotionEndDateInput').value = inputDate(promotion.ends_on);
  $('#promotionNoEndInput').checked = !promotion.ends_on;
  $('#promotionAllDayInput').checked = Boolean(promotion.all_day);
  $('#promotionStartTimeInput').value = String(promotion.start_time || '14:00').slice(0, 5);
  $('#promotionEndTimeInput').value = String(promotion.end_time || '17:00').slice(0, 5);
  $('#promotionActiveInput').checked = Boolean(promotion.is_active);
  renderPromotionDays(Array.isArray(promotion.days_of_week) ? promotion.days_of_week : [0, 1, 2, 3, 4, 5, 6]);
  updatePromotionFormVisibility();
  renderPromotionsModule();
}


function renderTournamentEntryDiscountRules() {
  const box = $('#tournamentEntryDiscountRules');
  if (!box) return;
  const tiers = ['GAMER', 'GAMER_PRO', 'CHAMPION'];
  box.innerHTML = tiers.map((tier) => {
    const rule = (state.tournamentEntryDiscounts || []).find((item) => String(item.membership_tier || '').toUpperCase() === tier) || { discount_type: 'NONE', discount_value: 0, is_active: true };
    return `
      <div class="tournament-entry-discount-rule" data-tournament-entry-discount-tier="${tier}">
        <strong>${getMembershipTierLabel(tier)}</strong>
        <select data-entry-discount-type>
          <option value="NONE" ${rule.discount_type === 'NONE' ? 'selected' : ''}>Sin descuento</option>
          <option value="PERCENT" ${rule.discount_type === 'PERCENT' ? 'selected' : ''}>Porcentaje</option>
          <option value="FIXED_AMOUNT" ${rule.discount_type === 'FIXED_AMOUNT' ? 'selected' : ''}>Monto fijo menos</option>
          <option value="FREE" ${rule.discount_type === 'FREE' ? 'selected' : ''}>Gratis</option>
        </select>
        <input data-entry-discount-value type="number" min="0" step="1" value="${Number(rule.discount_value || 0)}" />
        <label class="checkbox-line"><input data-entry-discount-active type="checkbox" ${rule.is_active !== false ? 'checked' : ''} /><span>Activo</span></label>
      </div>
    `;
  }).join('');
}

async function saveTournamentEntryDiscountRules() {
  const rows = Array.from(document.querySelectorAll('[data-tournament-entry-discount-tier]'));
  const discounts = rows.map((row) => ({
    membershipTier: row.dataset.tournamentEntryDiscountTier,
    discountType: row.querySelector('[data-entry-discount-type]')?.value || 'NONE',
    discountValue: Number(row.querySelector('[data-entry-discount-value]')?.value || 0),
    isActive: Boolean(row.querySelector('[data-entry-discount-active]')?.checked)
  }));
  try {
    const result = await api('/promotions/tournament-entry-discounts', { method: 'PUT', body: JSON.stringify({ discounts }) });
    state.tournamentEntryDiscounts = result.discounts || [];
    renderTournamentEntryDiscountRules();
    showToast('Descuentos de torneos guardados');
  } catch (error) {
    showToast(error.message || 'No se pudieron guardar descuentos');
  }
}

function renderPromotionsModule() {
  const list = $('#promotionsList');
  if (!list) return;

  const activeCount = state.promotions.filter((promotion) => promotion.is_active).length;
  $('#promotionsModuleCount').textContent = `${activeCount} activos`;

  if (!state.promotions.length) {
    list.innerHTML = '<div class="empty-state">Sin descuentos</div>';
  } else {
    list.innerHTML = state.promotions.map((promotion) => {
      const days = Array.isArray(promotion.days_of_week) ? promotion.days_of_week : [];
      const dayText = days.length === 7 ? 'Todos los días' : days.map((day) => promotionDayOptions.find((item) => item.value === Number(day))?.label).filter(Boolean).join(', ');
      const timeText = promotion.all_day ? 'Todo el día' : `${String(promotion.start_time || '').slice(0, 5)} - ${String(promotion.end_time || '').slice(0, 5)}`;
      return `
        <button type="button" class="promotion-row ${promotion.id === state.selectedPromotionId ? 'active-selection' : ''} ${promotion.is_active ? '' : 'muted-row'}" data-promotion-id="${promotion.id}">
          <span class="promotion-dot"></span>
          <span>
            <strong>${promotion.name}</strong>
            <small>${getPromotionTypeLabel(promotion)} · ${getPromotionScopeLabel(promotion)} · ${dayText} · ${timeText}</small>
          </span>
        </button>
      `;
    }).join('');
  }

  list.querySelectorAll('[data-promotion-id]').forEach((btn) => {
    btn.addEventListener('click', () => selectPromotion(btn.dataset.promotionId));
  });

  $('#deletePromotionBtn').classList.toggle('hidden', !state.selectedPromotionId);
  updatePromotionFormVisibility();
  renderTournamentEntryDiscountRules();
}

async function savePromotion() {
  const selectedDays = Array.from(document.querySelectorAll('#promotionDaysList input:checked')).map((input) => Number(input.value));
  const scopeType = $('#promotionScopeSelect').value;
  const payload = {
    name: $('#promotionNameInput').value.trim(),
    discountType: $('#promotionTypeSelect').value,
    discountValue: Number($('#promotionValueInput').value || 0),
    scopeType,
    consoleType: scopeType === 'CONSOLE' ? $('#promotionConsoleSelect').value : null,
    stationId: scopeType === 'STATION' ? $('#promotionStationSelect').value : null,
    startsOn: $('#promotionStartDateInput').value,
    endsOn: $('#promotionNoEndInput').checked ? null : $('#promotionEndDateInput').value,
    allDay: $('#promotionAllDayInput').checked,
    startTime: $('#promotionAllDayInput').checked ? null : $('#promotionStartTimeInput').value,
    endTime: $('#promotionAllDayInput').checked ? null : $('#promotionEndTimeInput').value,
    daysOfWeek: selectedDays,
    isActive: $('#promotionActiveInput').checked
  };

  try {
    if (state.selectedPromotionId) {
      await api(`/promotions/${state.selectedPromotionId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } else {
      await api('/promotions', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    }

    showToast('Descuento guardado');
    await loadPromotions();
    renderPromotionsModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}

async function deletePromotion() {
  if (!state.selectedPromotionId) return;

  if (!confirm('¿Eliminar promoción?')) return;

  try {
    await api(`/promotions/${state.selectedPromotionId}`, { method: 'DELETE' });
    showToast('Descuento eliminado');
    await loadPromotions();
    resetPromotionForm();
    renderPromotionsModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}





function renderMembershipPlansModule() {
  const list = $('#membershipPlansList');
  if (!list) return;
  const plans = getMembershipTierOptions(true);
  list.innerHTML = plans.map((plan) => `
    <button type="button" class="membership-plan-row ${plan.archived_at ? 'archived-row' : (plan.is_active === false ? 'muted-row' : '')}" data-membership-plan-code="${plan.id}" style="--plan-color:${plan.color || '#2563eb'}">
      <span class="membership-plan-dot"></span>
      <span>
        <strong>${plan.label}</strong>
        <small>${money(state.membershipPlans.find((item) => item.code === plan.id)?.monthly_price || 0)} · ${plan.archived_at ? 'Legacy' : (plan.show_in_pos === false ? 'Oculta' : 'Venta')} · ${plan.archived_at ? 'Archivada' : (plan.is_active === false ? 'Inactiva' : 'Activa')}</small>
      </span>
    </button>
  `).join('') || '<div class="empty-state">Sin planes</div>';

  list.querySelectorAll('[data-membership-plan-code]').forEach((btn) => {
    btn.addEventListener('click', () => openMembershipPlanModal(btn.dataset.membershipPlanCode));
  });
}

function getMembershipPlanFormPayload() {
  const name = $('#membershipPlanNameInput')?.value.trim() || '';
  const rawCode = $('#membershipPlanCodeInput')?.value.trim() || name;
  return {
    code: rawCode.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, ''),
    name,
    color: $('#membershipPlanColorInput')?.value || '#2563eb',
    monthlyPrice: Number($('#membershipPlanPriceInput')?.value || 0),
    durationDays: Number($('#membershipPlanDaysInput')?.value || 30),
    sortOrder: Number($('#membershipPlanOrderInput')?.value || 100),
    isActive: $('#membershipPlanActiveInput')?.checked !== false,
    showInPos: $('#membershipPlanShowInput')?.checked !== false,
    savedGameEnabled: Boolean($('#membershipPlanSavedGameEnabledInput')?.checked),
    savedGameLimit: Number($('#membershipPlanSavedGameLimitInput')?.value || 0),
    savedGameUnlimited: Boolean($('#membershipPlanSavedGameUnlimitedInput')?.checked),
    featuredGamePriority: Boolean($('#membershipPlanFeaturedPriorityInput')?.checked),
    savedGameUpgradeMessage: $('#membershipPlanSavedGameMessageInput')?.value?.trim() || 'Hazte miembro y guarda tu progreso en Club Versus.'
  };
}

function openMembershipPlanModal(code = null) {
  state.selectedMembershipPlanCode = code;
  const plan = state.membershipPlans.find((item) => item.code === code) || null;
  $('#membershipPlanModalTitle').textContent = plan ? `Editar ${plan.name}` : 'Nuevo plan';
  $('#membershipPlanNameInput').value = plan?.name || '';
  $('#membershipPlanCodeInput').value = plan?.code || '';
  $('#membershipPlanCodeInput').disabled = Boolean(plan);
  $('#membershipPlanPriceInput').value = Number(plan?.monthly_price || 0).toFixed(0);
  $('#membershipPlanDaysInput').value = Number(plan?.duration_days || 30);
  $('#membershipPlanColorInput').value = plan?.color || '#2563eb';
  $('#membershipPlanOrderInput').value = Number(plan?.sort_order || 100);
  $('#membershipPlanActiveInput').checked = Boolean(plan?.is_active ?? true);
  $('#membershipPlanShowInput').checked = Boolean(plan?.show_in_pos ?? true);
  $('#membershipPlanSavedGameEnabledInput').checked = Boolean(plan?.saved_game_enabled ?? false);
  $('#membershipPlanSavedGameLimitInput').value = String(Number(plan?.saved_game_limit || 0));
  $('#membershipPlanSavedGameUnlimitedInput').checked = Boolean(plan?.saved_game_unlimited ?? false);
  $('#membershipPlanFeaturedPriorityInput').checked = Boolean(plan?.featured_game_priority ?? false);
  $('#membershipPlanSavedGameMessageInput').value = plan?.saved_game_upgrade_message || 'Hazte miembro y guarda tu progreso en Club Versus.';
  const isArchived = Boolean(plan?.archived_at);
  $('#archiveMembershipPlanBtn')?.classList.toggle('hidden', !plan || isArchived);
  $('#restoreMembershipPlanBtn')?.classList.toggle('hidden', !plan || !isArchived);
  $('#membershipPlanActiveInput').disabled = isArchived;
  $('#membershipPlanShowInput').disabled = isArchived;
  $('#membershipPlanSavedGameEnabledInput').disabled = isArchived;
  $('#membershipPlanSavedGameLimitInput').disabled = isArchived;
  $('#membershipPlanSavedGameUnlimitedInput').disabled = isArchived;
  $('#membershipPlanFeaturedPriorityInput').disabled = isArchived;
  $('#membershipPlanSavedGameMessageInput').disabled = isArchived;
  $('#saveMembershipPlanBtn').disabled = false;
  $('#membershipPlanModal')?.classList.remove('hidden');
  $('#membershipPlanModal')?.setAttribute('aria-hidden', 'false');
}

function closeMembershipPlanModal() {
  $('#membershipPlanModal')?.classList.add('hidden');
  $('#membershipPlanModal')?.setAttribute('aria-hidden', 'true');
}

async function saveMembershipPlan() {
  const payload = getMembershipPlanFormPayload();
  if (!payload.name) return showToast('Nombre requerido');
  if (!payload.code) return showToast('Código requerido');

  try {
    await api(state.selectedMembershipPlanCode ? `/promotions/membership-plans/${state.selectedMembershipPlanCode}` : '/promotions/membership-plans', {
      method: state.selectedMembershipPlanCode ? 'PUT' : 'POST',
      body: JSON.stringify(payload)
    });
    showToast('Plan guardado');
    closeMembershipPlanModal();
    await loadMembershipPlans();
    await loadMemberTimePrices();
    await loadProducts();
    renderMembershipPlansModule();
    renderMemberPricesModule();
    renderBonusRulesModule();
    renderManualBonusMembershipOptions();
    renderTournamentPrizeConfigInputs();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}

async function archiveMembershipPlan() {
  if (!state.selectedMembershipPlanCode) return;
  if (!confirm('¿Archivar este plan? No aparecerá para venta ni bonos nuevos, pero seguirá en historial.')) return;
  try {
    await api(`/promotions/membership-plans/${state.selectedMembershipPlanCode}/archive`, { method: 'PATCH' });
    showToast('Plan archivado');
    closeMembershipPlanModal();
    await loadMembershipPlans();
    await loadProducts();
    renderMembershipPlansModule();
    renderMemberPricesModule();
    renderManualBonusMembershipOptions();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}

async function restoreMembershipPlan() {
  if (!state.selectedMembershipPlanCode) return;
  try {
    await api(`/promotions/membership-plans/${state.selectedMembershipPlanCode}/restore`, { method: 'PATCH' });
    showToast('Plan restaurado');
    closeMembershipPlanModal();
    await loadMembershipPlans();
    await loadProducts();
    renderMembershipPlansModule();
    renderMemberPricesModule();
    renderManualBonusMembershipOptions();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}

function getMemberPriceRows(tier, playerCount = 1) {
  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  const rows = state.memberTimePrices.filter((price) => price.membership_tier === tier && Number(price.player_count || 1) === normalizedPlayerCount);
  const byMinutes = new Map(rows.map((row) => [Number(row.minutes), row]));

  return timePackages.map((pkg, index) => {
    const saved = byMinutes.get(pkg.minutes);
    return saved || {
      label: pkg.label,
      minutes: pkg.minutes,
      player_count: normalizedPlayerCount,
      price: 0,
      is_active: false,
      sort_order: (index + 1) * 10,
      membership_tier: tier
    };
  });
}

function renderMemberPricesModule() {
  const grid = $('#memberPricesGrid');
  if (!grid) return;

  renderMembershipPlansModule();

  grid.innerHTML = getMembershipTierOptions(true).map((tier, tierIndex) => {
    const tierRows = timePlayerOptions.flatMap((playerOption) => getMemberPriceRows(tier.id, playerOption.value));
    const activeCount = tierRows.filter((price) => price.is_active).length;
    const groups = timePlayerOptions.map((playerOption) => `
      <section class="member-price-player-card">
        <header class="member-price-player-header">
          <h5>${playerOption.label}</h5>
          <span>${getMemberPriceRows(tier.id, playerOption.value).filter((price) => price.is_active).length} activos</span>
        </header>
        <div class="member-price-table-card">
          <div class="member-price-table-head">
            <span>Tiempo</span>
            <span>Precio</span>
            <span>Activo</span>
          </div>
          ${getMemberPriceRows(tier.id, playerOption.value).map((price, index) => `
            <div class="member-price-row redesigned-member-row" data-member-price-row="${tier.id}" data-member-price-player-count="${playerOption.value}">
              <input data-member-price-label type="hidden" value="${price.label}" />
              <input data-member-price-minutes type="hidden" value="${Number(price.minutes)}" />
              <input data-member-price-order type="hidden" value="${Number(price.sort_order || (index + 1) * 10)}" />
              <div class="price-duration-label">
                <strong>${price.label}</strong>
                <small>${Number(price.minutes)} min</small>
              </div>
              <label class="price-input-box compact">
                <span>RD$</span>
                <input data-member-price-price type="number" min="0" step="1" value="${Number(price.price || 0).toFixed(0)}" />
              </label>
              <label class="toggle-pill small-toggle">
                <input data-member-price-active type="checkbox" ${price.is_active ? 'checked' : ''} />
                <span>Activo</span>
              </label>
            </div>
          `).join('')}
        </div>
      </section>
    `).join('');

    return `
      <details class="member-price-card member-price-accordion member-tier-${getMembershipKey(tier.id)}" ${tierIndex === 0 ? 'open' : ''}>
        <summary class="member-price-summary">
          <span class="member-price-tier-name">${tier.label}</span>
          <span class="member-price-tier-count">${activeCount} activos</span>
        </summary>
        <div class="member-price-accordion-body">
          <div class="member-price-player-grid">
            ${groups}
          </div>
          <button type="button" data-save-member-prices="${tier.id}">Guardar ${tier.label}</button>
        </div>
      </details>
    `;
  }).join('');

  grid.querySelectorAll('[data-save-member-prices]').forEach((btn) => {
    btn.addEventListener('click', () => saveMemberTimePrices(btn.dataset.saveMemberPrices));
  });
}

async function saveMemberTimePrices(tier) {
  const rows = Array.from(document.querySelectorAll(`[data-member-price-row="${tier}"]`)).map((row, index) => ({
    label: row.querySelector('[data-member-price-label]').value.trim(),
    playerCount: Number(row.dataset.memberPricePlayerCount || 1),
    minutes: Number(row.querySelector('[data-member-price-minutes]').value || 0),
    price: Number(row.querySelector('[data-member-price-price]').value || 0),
    isActive: row.querySelector('[data-member-price-active]').checked,
    sortOrder: Number(row.querySelector('[data-member-price-order]').value || (index + 1) * 10)
  }));

  try {
    await api(`/promotions/member-time-prices/${tier}`, {
      method: 'PUT',
      body: JSON.stringify({ prices: rows })
    });

    showToast('Precios miembros guardados');
    await loadMemberTimePrices();
    renderMemberPricesModule();
    renderTimeOptions();
    renderOrder();
  } catch (error) {
    showToast(error.message);
  }
}



function renderManualBonusMembershipOptions() {
  const select = $('#manualBonusMembershipTierSelect');
  if (!select) return;
  const current = select.value;
  const plans = getMembershipTierOptions();
  select.innerHTML = plans.length
    ? plans.map((plan) => `<option value="${plan.id}">${plan.label}</option>`).join('')
    : '<option value="">Sin membresías</option>';
  if (current && Array.from(select.options).some((option) => option.value === current)) select.value = current;
}

function getManualBonusProductCategoryOptions() {
  const productCategories = new Set(state.products.map((product) => product.category).filter(Boolean));
  return getProductCategories().filter((category) => {
    if (category.is_active === false || category.show_in_bonuses === false || category.is_membership) return false;
    return productCategories.has(category.code) || ['SNACK', 'DRINK'].includes(category.code);
  });
}

function renderManualBonusProductOptions() {
  const categorySelect = $('#manualBonusProductCategorySelect');
  const productSelect = $('#manualBonusProductSelect');
  if (!categorySelect) return;
  const currentCategory = categorySelect.value;
  const categories = getManualBonusProductCategoryOptions();
  categorySelect.innerHTML = categories.map((category) => `<option value="${category.code}">${category.name}</option>`).join('');
  if (currentCategory && Array.from(categorySelect.options).some((option) => option.value === currentCategory)) categorySelect.value = currentCategory;
  renderManualBonusProductItemOptions();
}

function renderManualBonusProductItemOptions() {
  const categorySelect = $('#manualBonusProductCategorySelect');
  const productSelect = $('#manualBonusProductSelect');
  if (!productSelect) return;
  const category = categorySelect?.value || '';
  const currentProductId = productSelect.value;
  const products = state.products
    .filter((product) => product.is_active !== false && product.category === category && product.category !== 'MEMBERSHIP')
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  productSelect.innerHTML = products.length
    ? products.map((product) => `<option value="${product.id}">${product.name} · ${money(product.price || 0)}</option>`).join('')
    : '<option value="">Sin artículos</option>';
  if (currentProductId && Array.from(productSelect.options).some((option) => option.value === currentProductId)) productSelect.value = currentProductId;
}

function getBonusTierOptions(selected = 'ALL') {
  const options = [
    ['ALL', 'Todos'],
    ['PAID_MEMBERS', 'Miembros premium/pagos'],
    ['GENERAL', 'General sin membresía'],
    ['GAMER', 'Gamer'],
    ['GAMER_PRO', 'Gamer Pro'],
    ['CHAMPION', 'Champion']
  ];
  return options.map(([value, label]) => `<option value="${value}" ${value === selected ? 'selected' : ''}>${label}</option>`).join('');
}

function renderBonusRulesModule() {
  const welcomeRule = getBonusRule('WELCOME_MEMBERSHIP');
  const visitRule = getBonusRule('VISIT_REWARD');

  if ($('#welcomeBonusTierSelect')) $('#welcomeBonusTierSelect').innerHTML = getBonusTierOptions(welcomeRule?.applies_to_tier || 'PAID_MEMBERS');
  if ($('#welcomeBonusMinutesInput')) $('#welcomeBonusMinutesInput').value = Number(welcomeRule?.reward_minutes || 30);
  if ($('#welcomeBonusExpiresInput')) $('#welcomeBonusExpiresInput').value = Number(welcomeRule?.expires_days || 7);
  if ($('#welcomeBonusActiveInput')) $('#welcomeBonusActiveInput').checked = Boolean(welcomeRule?.is_active ?? true);
  if ($('#welcomeBonusSummary')) $('#welcomeBonusSummary').textContent = `${Number(welcomeRule?.reward_minutes || 30)} min · ${welcomeRule?.is_active === false ? 'Inactivo' : 'Activo'}`;

  if ($('#visitBonusTierSelect')) $('#visitBonusTierSelect').innerHTML = getBonusTierOptions(visitRule?.applies_to_tier || 'PAID_MEMBERS');
  if ($('#visitBonusRequiredInput')) $('#visitBonusRequiredInput').value = Number(visitRule?.required_visits || 5);
  if ($('#visitBonusMinutesInput')) $('#visitBonusMinutesInput').value = Number(visitRule?.reward_minutes || 30);
  if ($('#visitBonusMinGameInput')) $('#visitBonusMinGameInput').value = String(Number(visitRule?.min_game_minutes || 0));
  if ($('#visitBonusExpiresInput')) $('#visitBonusExpiresInput').value = Number(visitRule?.expires_days || 30);
  if ($('#visitBonusActiveInput')) $('#visitBonusActiveInput').checked = Boolean(visitRule?.is_active ?? true);
  if ($('#visitBonusSummary')) $('#visitBonusSummary').textContent = `${Number(visitRule?.required_visits || 5)} visitas · ${Number(visitRule?.reward_minutes || 30)} min`;

  renderManualBonusProductOptions();
  renderManualBonusMembershipOptions();
  updateManualBonusFields();
  renderManualBonusMember();
}

async function saveBonusRule(ruleKey) {
  const current = getBonusRule(ruleKey);
  const isWelcome = ruleKey === 'WELCOME_MEMBERSHIP';
  const payload = isWelcome
    ? {
        name: current?.name || 'Bono de bienvenida',
        rewardMinutes: Number($('#welcomeBonusMinutesInput').value || 0),
        expiresDays: Number($('#welcomeBonusExpiresInput').value || 0),
        requiredVisits: 0,
        minGameMinutes: 0,
        appliesToTier: $('#welcomeBonusTierSelect')?.value || 'PAID_MEMBERS',
        repeatable: false,
        isActive: $('#welcomeBonusActiveInput').checked
      }
    : {
        name: current?.name || 'Bono por visitas',
        rewardMinutes: Number($('#visitBonusMinutesInput').value || 0),
        expiresDays: Number($('#visitBonusExpiresInput').value || 0),
        requiredVisits: Number($('#visitBonusRequiredInput').value || 0),
        minGameMinutes: Number($('#visitBonusMinGameInput').value || 0),
        appliesToTier: $('#visitBonusTierSelect')?.value || 'PAID_MEMBERS',
        repeatable: true,
        isActive: $('#visitBonusActiveInput').checked
      };

  try {
    await api(`/promotions/bonus-rules/${ruleKey}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
    showToast('Bono guardado');
    await loadBonusRules();
    renderBonusRulesModule();
  } catch (error) {
    showToast(error.message);
  }
}

function renderManualBonusMember() {
  const box = $('#manualBonusMemberResult');
  if (!box) return;

  const member = state.manualBonusMember;
  if (!member) {
    box.className = 'member-result empty';
    box.textContent = 'Selecciona miembro';
    return;
  }

  const membership = member.membership_active ? getMembershipLabel(member.membership_tier) : 'General';
  box.className = 'member-result';
  box.innerHTML = `
    <div class="member-result-card">
      <span>
        <strong>${member.full_name}</strong>
        <small>${membership}${member.phone ? ` · ${member.phone}` : ''}</small>
      </span>
    </div>
  `;
}

function updateManualBonusFields() {
  const type = $('#manualBonusTypeSelect')?.value || 'TIME';
  document.querySelectorAll('.manual-bonus-time-field').forEach((el) => el.classList.toggle('hidden', type !== 'TIME'));
  document.querySelectorAll('.manual-bonus-product-field').forEach((el) => el.classList.toggle('hidden', type !== 'PRODUCT'));
  document.querySelectorAll('.manual-bonus-membership-field').forEach((el) => el.classList.toggle('hidden', type !== 'MEMBERSHIP'));
  if (type === 'PRODUCT') renderManualBonusProductItemOptions();
  if ($('#manualBonusExpiresInput')) $('#manualBonusExpiresInput').disabled = type === 'MEMBERSHIP';
  if ($('#manualBonusSummary')) {
    const labels = { TIME: 'Tiempo', PRODUCT: 'Producto / servicio', MEMBERSHIP: 'Membresía' };
    $('#manualBonusSummary').textContent = labels[type] || 'Bono manual';
  }
}

async function searchManualBonusMember() {
  const q = $('#manualBonusMemberSearchInput').value.trim();
  if (!q) return showToast('Ingresa miembro');

  try {
    const { members } = await api(`/members/search?q=${encodeURIComponent(q)}`);
    state.manualBonusMember = members?.[0] || null;
    renderManualBonusMember();
    if (!state.manualBonusMember) showToast('Miembro no encontrado');
  } catch (error) {
    showToast(error.message);
  }
}

async function grantManualBonus() {
  if (!state.manualBonusMember) return showToast('Selecciona miembro');

  const bonusType = $('#manualBonusTypeSelect')?.value || 'TIME';

  try {
    const result = await api('/promotions/manual-bonus', {
      method: 'POST',
      body: JSON.stringify({
        memberId: state.manualBonusMember.id,
        bonusType,
        minutes: Number($('#manualBonusMinutesInput')?.value || 0),
        productCategory: $('#manualBonusProductCategorySelect')?.value || null,
        productId: $('#manualBonusProductSelect')?.value || null,
        productQty: Number($('#manualBonusProductQtyInput')?.value || 0),
        membershipTier: $('#manualBonusMembershipTierSelect')?.value || null,
        expiresDays: Number($('#manualBonusExpiresInput')?.value || 0),
        notes: $('#manualBonusReasonInput').value.trim()
      })
    });

    showToast(result.message || 'Bono entregado');
    $('#manualBonusMemberSearchInput').value = '';
    $('#manualBonusReasonInput').value = '';
    state.manualBonusMember = null;
    renderManualBonusMember();
  } catch (error) {
    showToast(error.message);
  }
}

  window.ClubVersusModules['prices'] = {
    openTimePricesModule,
    closeTimePricesModule,
    loadKidsCourtesySettings,
    saveKidsCourtesySettings,
    getTimePriceScopeRows,
    getTimePriceScopeName,
    renderTimePriceEditorRows,
    renderTimePricesModule,
    collectTimePriceRows,
    saveTimePrices,
    applyTimePricesToAll,
    renderGroupEventPriceRows,
    addGroupEventPriceRow,
    collectGroupEventPriceRows,
    saveGroupEventPrices,
    canManagePromotions,
    inputDate,
    todayInputDate,
    getPromotionScopeLabel,
    getPromotionTypeLabel,
    openPromotionsModule,
    closePromotionsModule,
    resetPromotionForm,
    renderPromotionStationOptions,
    renderPromotionDays,
    updatePromotionFormVisibility,
    selectPromotion,
    renderTournamentEntryDiscountRules,
    saveTournamentEntryDiscountRules,
    renderPromotionsModule,
    savePromotion,
    deletePromotion,
    renderMembershipPlansModule,
    getMembershipPlanFormPayload,
    openMembershipPlanModal,
    closeMembershipPlanModal,
    saveMembershipPlan,
    archiveMembershipPlan,
    restoreMembershipPlan,
    getMemberPriceRows,
    renderMemberPricesModule,
    saveMemberTimePrices,
    renderManualBonusMembershipOptions,
    getManualBonusProductCategoryOptions,
    renderManualBonusProductOptions,
    renderManualBonusProductItemOptions,
    getBonusTierOptions,
    renderBonusRulesModule,
    saveBonusRule,
    renderManualBonusMember,
    updateManualBonusFields,
    searchManualBonusMember,
    grantManualBonus
  };
})();
