ALTER TABLE station_games
  ADD COLUMN IF NOT EXISTS allows_extra_controllers BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS max_extra_controllers INT NOT NULL DEFAULT 2,
  ADD COLUMN IF NOT EXISTS extra_controller_price NUMERIC(12,2) NOT NULL DEFAULT 0;

ALTER TABLE station_games
  DROP CONSTRAINT IF EXISTS station_games_max_extra_controllers_check;

ALTER TABLE station_games
  ADD CONSTRAINT station_games_max_extra_controllers_check
  CHECK (max_extra_controllers >= 0 AND max_extra_controllers <= 4);

ALTER TABLE station_games
  DROP CONSTRAINT IF EXISTS station_games_extra_controller_price_check;

ALTER TABLE station_games
  ADD CONSTRAINT station_games_extra_controller_price_check
  CHECK (extra_controller_price >= 0);

UPDATE station_games
SET allows_extra_controllers = TRUE,
    max_extra_controllers = CASE WHEN max_extra_controllers < 1 THEN 2 ELSE LEAST(max_extra_controllers, 4) END,
    updated_at = NOW()
WHERE LOWER(name) LIKE '%mario kart%'
   OR LOWER(name) LIKE '%smash%'
   OR LOWER(name) LIKE '%mario party%'
   OR LOWER(name) LIKE '%overcooked%'
   OR LOWER(name) LIKE '%switch sports%';
