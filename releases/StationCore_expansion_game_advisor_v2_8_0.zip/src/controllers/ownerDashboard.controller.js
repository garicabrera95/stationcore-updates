import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query, withTransaction } from '../db/pool.js';
import { env } from '../config/env.js';
import {
  loadPrintingPricingRules,
  normalizePrintingPricingRule,
  resolvePrintingPricingRule,
  savePrintingPricingRules
} from '../services/printing-pricing.service.js';
import {
  PRINTER_MAINTENANCE_EVENT_TYPES,
  buildPaperDisplayName,
  buildPrinterMaintenanceSummary,
  calculatePrintRecipeEconomics,
  estimateEpsonL3250Ink,
  getEpsonL3250Catalog,
  resolveEpsonPaperSelection
} from '../services/epson-l3250-printing.service.js';
import {
  buildGrowthAdvisor,
  saveGrowthAdvisorSettings
} from '../services/growth-advisor.service.js';

const OWNER_DASHBOARD_TOKEN_PURPOSE = 'owner_dashboard';

function toNumber(value) {
  return Number(value || 0);
}

function printNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : fallback;
}

function printInteger(value, fallback = 0) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : fallback;
}

function normalizePrintServicePayload(body = {}) {
  const name = String(body.name || '').trim();
  if (!name) {
    const error = new Error('Escribe el nombre del servicio.');
    error.status = 400;
    throw error;
  }

  const regularPrice = printNumber(body.price ?? body.regularPrice, 0);
  const rawBulkFrom = printInteger(body.bulkFrom, 0);
  const bulkFrom = rawBulkFrom >= 2 ? rawBulkFrom : 0;
  const paperSupplyType = String(body.paperSupplyType || body.paper_supply_type || 'PAPER').trim().toUpperCase() || 'PAPER';

  const autoInkEstimate = body.autoInkEstimate !== false && body.auto_ink_estimate !== false;

  return {
    name,
    regularPrice,
    bulkFrom,
    bulkPrice: bulkFrom ? printNumber(body.bulkPrice, regularPrice) : regularPrice,
    paperSupplyType,
    paperSheets: printNumber(body.paperSheets, 1),
    blackInkUnits: printNumber(body.blackInkUnits, 0),
    colorInkUnits: printNumber(body.colorInkUnits, 0),
    wastePercent: Math.min(100, printNumber(body.wastePercent, 15)),
    outputType: String(body.outputType || body.output_type || 'DOCUMENT').trim().toUpperCase(),
    colorMode: String(body.colorMode || body.color_mode || 'COLOR').trim().toUpperCase(),
    printQuality: String(body.printQuality || body.print_quality || 'STANDARD').trim().toUpperCase(),
    coverageProfile: String(body.coverageProfile || body.coverage_profile || '').trim().toUpperCase(),
    borderless: body.borderless === true,
    autoInkEstimate,
    isActive: body.isActive !== false
  };
}

function normalizePrintSupplyPayload(body = {}) {
  const selection = resolveEpsonPaperSelection(body.mediaProfile || body.media_profile, body.paperSize || body.paper_size);
  const paperBrand = String(body.paperBrand || body.paper_brand || '').trim();
  const displayName = buildPaperDisplayName(selection, paperBrand, body.displayName || body.display_name);
  const yieldUnits = Math.max(1, printNumber(body.yieldUnits, 1));
  return {
    displayName,
    mediaProfile: selection.mediaProfile,
    paperSize: selection.paperSize,
    sheetWidthMm: selection.widthMm,
    sheetHeightMm: selection.heightMm,
    paperBrand,
    officialProfile: selection.officialProfile,
    purchaseCost: printNumber(body.purchaseCost, 0),
    yieldUnits,
    remainingUnits: printNumber(body.remainingUnits, yieldUnits),
    lowLevelUnits: printNumber(body.lowLevelUnits, Math.min(10, yieldUnits)),
    isActive: body.isActive !== false
  };
}

function resolvePrintRecipe(service, paperSupply = {}) {
  const paperSelection = resolveEpsonPaperSelection(paperSupply.media_profile, paperSupply.paper_size);
  if (!service.autoInkEstimate) {
    return {
      ...service,
      borderless: Boolean(service.borderless) && paperSelection.supportsBorderless,
      estimateSource: 'MANUAL_OWNER'
    };
  }
  const estimate = estimateEpsonL3250Ink({
    outputType: service.outputType,
    colorMode: service.colorMode,
    quality: service.printQuality,
    coverageProfile: service.coverageProfile,
    borderless: service.borderless
  }, paperSupply);
  return {
    ...service,
    outputType: estimate.outputType,
    colorMode: estimate.colorMode,
    printQuality: estimate.quality,
    coverageProfile: estimate.coverageProfile,
    borderless: estimate.borderless,
    blackInkUnits: estimate.blackInkUnits,
    colorInkUnits: estimate.colorInkUnits,
    estimateSource: estimate.estimateSource
  };
}

function createPrintServiceCode(name = '') {
  const slug = String(name)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 24) || 'SERVICIO';
  const suffix = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
  return `PRINT-${slug}-${suffix}`;
}

function createPrintSupplyCode(name = '') {
  const slug = String(name)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 22) || 'PAPEL';
  const suffix = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
  return `PAPER_${slug}_${suffix}`;
}



function pad2(value) {
  return String(value).padStart(2, '0');
}

function dateOnlyLocal(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function addDaysLocal(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function startOfWeekMonday(date) {
  const start = new Date(date);
  const day = start.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  start.setDate(start.getDate() + diff);
  return start;
}

function normalizeOwnerPeriod(value = 'today') {
  const period = String(value || 'today').trim().toLowerCase();
  const allowed = ['today', 'yesterday', 'before_yesterday', 'week', 'month', 'custom'];
  return allowed.includes(period) ? period : 'today';
}

function resolveOwnerDateRange(queryParams = {}) {
  const period = normalizeOwnerPeriod(queryParams.period);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let start = new Date(today);
  let end = addDaysLocal(today, 1);
  let label = 'Hoy';

  if (period === 'yesterday') {
    start = addDaysLocal(today, -1);
    end = new Date(today);
    label = 'Ayer';
  } else if (period === 'before_yesterday') {
    start = addDaysLocal(today, -2);
    end = addDaysLocal(today, -1);
    label = 'Antes de ayer';
  } else if (period === 'week') {
    start = startOfWeekMonday(today);
    end = addDaysLocal(today, 1);
    label = 'Esta semana';
  } else if (period === 'month') {
    start = new Date(today.getFullYear(), today.getMonth(), 1);
    end = addDaysLocal(today, 1);
    label = 'Este mes';
  } else if (period === 'custom') {
    const customStart = String(queryParams.startDate || '').trim();
    const customEnd = String(queryParams.endDate || '').trim();
    const validStart = /^\d{4}-\d{2}-\d{2}$/.test(customStart) ? customStart : dateOnlyLocal(today);
    const validEnd = /^\d{4}-\d{2}-\d{2}$/.test(customEnd) ? customEnd : validStart;
    const orderedStart = validEnd < validStart ? validEnd : validStart;
    const orderedEnd = validEnd < validStart ? validStart : validEnd;
    return {
      period,
      startParam: orderedStart,
      endParam: dateOnlyLocal(addDaysLocal(new Date(`${orderedEnd}T00:00:00`), 1)),
      startDate: orderedStart,
      endDate: orderedEnd,
      isShift: false,
      label: orderedStart === orderedEnd ? orderedStart : `${orderedStart} a ${orderedEnd}`
    };
  }

  return {
    period,
    startParam: dateOnlyLocal(start),
    endParam: dateOnlyLocal(end),
    startDate: dateOnlyLocal(start),
    endDate: dateOnlyLocal(addDaysLocal(end, -1)),
    isShift: false,
    label
  };
}

async function resolveOwnerDashboardRange(queryParams = {}) {
  const baseRange = resolveOwnerDateRange(queryParams);
  const shiftId = String(queryParams.shiftId || '').trim();
  if (!shiftId) return baseRange;

  const { rows } = await query(
    `SELECT cd.*, ou.full_name AS opened_by_name, cu.full_name AS closed_by_name
     FROM cash_drawers cd
     LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
     LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
     WHERE cd.id = $1
     LIMIT 1`,
    [shiftId]
  );

  const drawer = rows[0];
  if (!drawer) return baseRange;

  return {
    ...baseRange,
    isShift: true,
    shiftId: drawer.id,
    shift: drawer,
    startParam: drawer.opened_at,
    endParam: drawer.closed_at || new Date(),
    label: `Turno ${drawer.opened_at ? new Date(drawer.opened_at).toLocaleString('es-DO', { dateStyle: 'short', timeStyle: 'short' }) : ''}`
  };
}

function salesTimeFilter(alias = 's', range) {
  return range.isShift
    ? `${alias}.created_at >= $1::timestamptz AND ${alias}.created_at < $2::timestamptz`
    : `${alias}.created_at >= $1::date AND ${alias}.created_at < $2::date`;
}

function movementTimeFilter(alias = 'dm', range) {
  return range.isShift
    ? `${alias}.created_at >= $1::timestamptz AND ${alias}.created_at < $2::timestamptz`
    : `${alias}.created_at >= $1::date AND ${alias}.created_at < $2::date`;
}

async function getOwnerShiftRows(range) {
  const params = range.isShift ? [range.shiftId] : [range.startParam, range.endParam];
  const whereClause = range.isShift
    ? 'cd.id = $1'
    : 'cd.opened_at >= $1::date AND cd.opened_at < $2::date';

  const { rows } = await query(
    `SELECT
       cd.id,
       cd.status,
       cd.opening_amount,
       cd.closing_amount,
       cd.expected_cash,
       cd.cash_difference,
       cd.opened_at,
       cd.closed_at,
       ou.full_name AS opened_by_name,
       cu.full_name AS closed_by_name,
       COALESCE(sales.cash_sales, 0)::numeric(12,2) AS cash_sales,
       COALESCE(sales.transfer_sales, 0)::numeric(12,2) AS transfer_sales,
       COALESCE(sales.total_sales, 0)::numeric(12,2) AS total_sales,
       COALESCE(movements.drawer_in, 0)::numeric(12,2) AS drawer_in,
       COALESCE(movements.drawer_out, 0)::numeric(12,2) AS drawer_out,
       (COALESCE(cd.opening_amount, 0) + COALESCE(sales.cash_sales, 0) + COALESCE(movements.drawer_in, 0) - COALESCE(movements.drawer_out, 0))::numeric(12,2) AS expected_cash_live,
       (COALESCE(sales.cash_sales, 0) + COALESCE(movements.drawer_in, 0) - COALESCE(movements.drawer_out, 0))::numeric(12,2) AS cash_to_withdraw
     FROM cash_drawers cd
     LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
     LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
     LEFT JOIN LATERAL (
       SELECT
         COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
       FROM sales s
       WHERE s.status = 'PAID'
         AND s.created_at >= cd.opened_at
         AND s.created_at < COALESCE(cd.closed_at, NOW())
     ) sales ON true
     LEFT JOIN LATERAL (
       SELECT
         COALESCE(SUM(CASE WHEN dm.type = 'IN' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
         COALESCE(SUM(CASE WHEN dm.type = 'OUT' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
       FROM drawer_movements dm
       WHERE dm.drawer_id = cd.id
     ) movements ON true
     WHERE ${whereClause}
     ORDER BY cd.opened_at DESC
     LIMIT 60`,
    params
  );

  return rows.map((row) => ({
    id: row.id,
    status: row.status || 'CLOSED',
    opening_amount: toNumber(row.opening_amount),
    closing_amount: toNumber(row.closing_amount),
    expected_cash: toNumber(row.expected_cash_live || row.expected_cash),
    cash_difference: toNumber(row.cash_difference),
    cash_sales: toNumber(row.cash_sales),
    transfer_sales: toNumber(row.transfer_sales),
    total_sales: toNumber(row.total_sales),
    drawer_in: toNumber(row.drawer_in),
    drawer_out: toNumber(row.drawer_out),
    cash_to_withdraw: toNumber(row.cash_to_withdraw),
    opened_at: row.opened_at,
    closed_at: row.closed_at,
    opened_by_name: row.opened_by_name,
    closed_by_name: row.closed_by_name
  }));
}

function ownerComparisonWindow(range) {
  if (range.isShift) {
    return {
      available: false,
      reason: 'La comparación inteligente se muestra al elegir un período, no un turno individual.'
    };
  }

  const now = new Date();
  const currentStart = new Date(`${range.startDate}T00:00:00`);
  const selectedEnd = addDaysLocal(new Date(`${range.endDate}T00:00:00`), 1);
  const currentEnd = currentStart <= now && selectedEnd > now ? now : selectedEnd;
  const durationMs = Math.max(60 * 1000, currentEnd.getTime() - currentStart.getTime());
  const durationDays = durationMs / (24 * 60 * 60 * 1000);

  let previousStart;
  let previousEnd;
  let comparisonLabel = 'Período anterior equivalente';

  if (range.period === 'month') {
    previousStart = new Date(currentStart.getFullYear(), currentStart.getMonth() - 1, 1);
    const previousNaturalEnd = new Date(currentStart.getFullYear(), currentStart.getMonth(), 1);
    previousEnd = new Date(Math.min(previousStart.getTime() + durationMs, previousNaturalEnd.getTime()));
    comparisonLabel = 'Mes pasado al mismo avance';
  } else if (range.period === 'custom') {
    previousEnd = new Date(currentStart);
    previousStart = new Date(currentStart.getTime() - durationMs);
  } else {
    previousStart = addDaysLocal(currentStart, -7);
    previousEnd = addDaysLocal(currentEnd, -7);
    comparisonLabel = range.period === 'week'
      ? 'Semana pasada al mismo avance'
      : `${previousStart.toLocaleDateString('es-DO', { weekday: 'long' })} pasado a la misma hora`;
  }

  const chartUnit = durationDays <= 1.05 ? 'hour' : durationDays <= 45 ? 'day' : 'week';
  const unitMs = chartUnit === 'hour' ? 60 * 60 * 1000 : chartUnit === 'day' ? 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000;
  const pointCount = chartUnit === 'hour' ? 24 : Math.min(53, Math.max(1, Math.ceil(durationMs / unitMs)));
  const singleDay = durationDays <= 1.05;

  return {
    available: true,
    currentStart,
    currentEnd,
    previousStart,
    previousEnd,
    currentLabel: range.label,
    comparisonLabel,
    throughLabel: currentEnd.getTime() <= now.getTime() && selectedEnd > now
      ? `Hasta ${now.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit' })}`
      : 'Período completo',
    chartUnit,
    pointCount,
    targetDow: singleDay ? currentStart.getDay() : null
  };
}

function comparisonPointLabel(window, bucket) {
  if (window.chartUnit === 'hour') {
    const hour = Number(bucket || 0);
    return new Date(2026, 0, 1, hour).toLocaleTimeString('es-DO', { hour: 'numeric' });
  }
  if (window.chartUnit === 'week') return `Sem ${Number(bucket || 0) + 1}`;
  const date = addDaysLocal(window.currentStart, Number(bucket || 0));
  return date.toLocaleDateString('es-DO', { day: 'numeric', month: 'short' });
}

async function getOwnerDashboardIntelligence(range) {
  const window = ownerComparisonWindow(range);
  if (!window.available) return {
    comparison: window,
    peakHours: { available: false, hours: [] },
    dayProjection: { available: false },
    weeklyHeatmap: { available: false, cells: [] },
    stationPerformance: { available: false, stations: [] }
  };

  const comparisonParams = [window.currentStart, window.currentEnd, window.previousStart, window.previousEnd];
  const bucketExpression = window.chartUnit === 'hour'
    ? 'EXTRACT(HOUR FROM s.created_at)::int'
    : window.chartUnit === 'day'
      ? '(s.created_at::date - p.start_at::date)::int'
      : 'FLOOR(EXTRACT(EPOCH FROM (s.created_at - p.start_at)) / 604800)::int';

  const analysisNow = new Date();
  const historyEnd = new Date(analysisNow);
  historyEnd.setHours(0, 0, 0, 0);
  const historyStart = addDaysLocal(historyEnd, -56);
  const stationHistoryStart = addDaysLocal(analysisNow, -30);
  const [
    comparisonTotalsResult,
    comparisonChartResult,
    peakHoursResult,
    projectionResult,
    weeklyHeatmapResult,
    stationPerformanceResult
  ] = await Promise.all([
    query(
      `WITH periods(period_key, start_at, end_at) AS (
         VALUES
           ('current'::text, $1::timestamptz, $2::timestamptz),
           ('previous'::text, $3::timestamptz, $4::timestamptz)
       )
       SELECT
         p.period_key,
         COUNT(s.id)::int AS sale_count,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales,
         COALESCE(AVG(s.total), 0)::numeric(12,2) AS average_ticket
       FROM periods p
       LEFT JOIN sales s
         ON s.status = 'PAID'
        AND s.created_at >= p.start_at
        AND s.created_at < p.end_at
       GROUP BY p.period_key`,
      comparisonParams
    ),
    query(
      `WITH periods(period_key, start_at, end_at) AS (
         VALUES
           ('current'::text, $1::timestamptz, $2::timestamptz),
           ('previous'::text, $3::timestamptz, $4::timestamptz)
       )
       SELECT
         p.period_key,
         ${bucketExpression} AS bucket,
         COUNT(s.id)::int AS sale_count,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
       FROM periods p
       JOIN sales s
         ON s.status = 'PAID'
        AND s.created_at >= p.start_at
        AND s.created_at < p.end_at
       GROUP BY p.period_key, bucket
       ORDER BY bucket, p.period_key`,
      comparisonParams
    ),
    query(
      `WITH drawer_bounds AS (
         SELECT
           cd.id,
           GREATEST(cd.opened_at, $1::timestamptz) AS open_at,
           LEAST(COALESCE(cd.closed_at, $2::timestamptz), $2::timestamptz) AS close_at
         FROM cash_drawers cd
         WHERE cd.opened_at < $2::timestamptz
           AND COALESCE(cd.closed_at, $2::timestamptz) > $1::timestamptz
       ), open_slots AS (
         SELECT EXTRACT(HOUR FROM slot)::int AS hour, slot::date AS open_date
         FROM drawer_bounds db
         CROSS JOIN LATERAL generate_series(
           date_trunc('hour', db.open_at),
           date_trunc('hour', db.close_at),
           INTERVAL '1 hour'
         ) slot
         WHERE slot < db.close_at
           AND ($3::int IS NULL OR EXTRACT(DOW FROM slot)::int = $3::int)
       ), open_by_hour AS (
         SELECT hour, COUNT(DISTINCT open_date)::int AS open_days
         FROM open_slots
         GROUP BY hour
       ), sales_by_hour AS (
         SELECT
           EXTRACT(HOUR FROM s.created_at)::int AS hour,
           COUNT(s.id)::int AS sale_count,
           COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
         FROM sales s
         WHERE s.status = 'PAID'
           AND s.created_at >= $1::timestamptz
           AND s.created_at < $2::timestamptz
           AND ($3::int IS NULL OR EXTRACT(DOW FROM s.created_at)::int = $3::int)
         GROUP BY hour
       ), session_bounds AS (
         SELECT
           gs.id,
           GREATEST(gs.started_at, $1::timestamptz) AS start_at,
           LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz) AS end_at
         FROM game_sessions gs
         WHERE gs.started_at < $2::timestamptz
           AND COALESCE(gs.ended_at, $2::timestamptz) > $1::timestamptz
       ), session_slots AS (
         SELECT
           sb.id,
           EXTRACT(HOUR FROM slot)::int AS hour,
           GREATEST(0, EXTRACT(EPOCH FROM (
             LEAST(sb.end_at, slot + INTERVAL '1 hour') - GREATEST(sb.start_at, slot)
           )) / 60.0) AS occupied_minutes
         FROM session_bounds sb
         CROSS JOIN LATERAL generate_series(
           date_trunc('hour', sb.start_at),
           date_trunc('hour', sb.end_at),
           INTERVAL '1 hour'
         ) slot
         WHERE slot < sb.end_at
           AND ($3::int IS NULL OR EXTRACT(DOW FROM slot)::int = $3::int)
       ), sessions_by_hour AS (
         SELECT
           hour,
           COUNT(DISTINCT id)::int AS session_count,
           COALESCE(SUM(occupied_minutes), 0)::numeric(12,2) AS occupied_minutes
         FROM session_slots
         GROUP BY hour
       ), station_capacity AS (
         SELECT GREATEST(COUNT(*)::int, 1) AS station_count
         FROM stations
         WHERE deleted_at IS NULL
       )
       SELECT
         oh.hour,
         oh.open_days,
         sc.station_count,
         COALESCE(sh.sale_count, 0)::int AS sale_count,
         COALESCE(sh.total_sales, 0)::numeric(12,2) AS total_sales,
         COALESCE(ss.session_count, 0)::int AS session_count,
         COALESCE(ss.occupied_minutes, 0)::numeric(12,2) AS occupied_minutes,
         (COALESCE(sh.total_sales, 0) / NULLIF(oh.open_days, 0))::numeric(12,2) AS average_revenue,
         (COALESCE(sh.sale_count, 0)::numeric / NULLIF(oh.open_days, 0))::numeric(12,2) AS average_sales,
         (COALESCE(ss.occupied_minutes, 0) / NULLIF(oh.open_days, 0))::numeric(12,2) AS average_station_minutes,
         LEAST(100, (COALESCE(ss.occupied_minutes, 0) * 100.0) /
           NULLIF(oh.open_days * 60 * sc.station_count, 0))::numeric(6,2) AS utilization_percent
       FROM open_by_hour oh
       CROSS JOIN station_capacity sc
       LEFT JOIN sales_by_hour sh ON sh.hour = oh.hour
       LEFT JOIN sessions_by_hour ss ON ss.hour = oh.hour
       ORDER BY oh.hour`,
      [historyStart, historyEnd, window.targetDow]
    ),
    query(
      `WITH variables AS (
         SELECT
           date_trunc('day', $1::timestamptz) AS today_start,
           $1::timestamptz AS now_at,
           ($1::timestamptz - date_trunc('day', $1::timestamptz)) AS elapsed_today
       ), candidate_days AS (
         SELECT day_slot::date AS day_date
         FROM variables v
         CROSS JOIN LATERAL generate_series(
           v.today_start - INTERVAL '56 days',
           v.today_start - INTERVAL '7 days',
           INTERVAL '7 days'
         ) day_slot
       ), open_days AS (
         SELECT
           cd_day.day_date,
           MAX(LEAST(COALESCE(cd.closed_at, cd_day.day_date::timestamptz + INTERVAL '1 day'),
                     cd_day.day_date::timestamptz + INTERVAL '2 days')) AS last_close
         FROM candidate_days cd_day
         JOIN cash_drawers cd
           ON cd.opened_at < cd_day.day_date::timestamptz + INTERVAL '1 day'
          AND COALESCE(cd.closed_at, cd_day.day_date::timestamptz + INTERVAL '1 day') > cd_day.day_date::timestamptz
         GROUP BY cd_day.day_date
       ), history_sales AS (
         SELECT
           od.day_date,
           od.last_close,
           COALESCE(SUM(s.total) FILTER (
             WHERE s.created_at < od.day_date::timestamptz + v.elapsed_today
           ), 0)::numeric(12,2) AS through_total,
           COALESCE(SUM(s.total), 0)::numeric(12,2) AS full_total
         FROM open_days od
         CROSS JOIN variables v
         LEFT JOIN sales s
           ON s.status = 'PAID'
          AND s.created_at >= od.day_date::timestamptz
          AND s.created_at < od.day_date::timestamptz + INTERVAL '1 day'
         GROUP BY od.day_date, od.last_close, v.elapsed_today
       ), current_sales AS (
         SELECT
           COUNT(s.id)::int AS sale_count,
           COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
         FROM variables v
         LEFT JOIN sales s
           ON s.status = 'PAID'
          AND s.created_at >= v.today_start
          AND s.created_at < v.now_at
       )
       SELECT
         cs.sale_count,
         cs.total_sales,
         COUNT(hs.day_date)::int AS comparable_days,
         COALESCE(AVG(hs.through_total), 0)::numeric(12,2) AS average_through,
         COALESCE(AVG(hs.full_total), 0)::numeric(12,2) AS average_full_day,
         COALESCE(AVG(GREATEST(hs.full_total - hs.through_total, 0)), 0)::numeric(12,2) AS average_remaining,
         COALESCE(AVG(EXTRACT(EPOCH FROM (hs.last_close - hs.day_date::timestamptz))), 0)::numeric(12,2) AS average_close_seconds
       FROM current_sales cs
       LEFT JOIN history_sales hs ON true
       GROUP BY cs.sale_count, cs.total_sales`,
      [analysisNow]
    ),
    query(
      `WITH drawer_bounds AS (
         SELECT
           GREATEST(cd.opened_at, $1::timestamptz) AS open_at,
           LEAST(COALESCE(cd.closed_at, $2::timestamptz), $2::timestamptz) AS close_at
         FROM cash_drawers cd
         WHERE cd.opened_at < $2::timestamptz
           AND COALESCE(cd.closed_at, $2::timestamptz) > $1::timestamptz
       ), open_slots AS (
         SELECT
           EXTRACT(DOW FROM slot)::int AS day_of_week,
           EXTRACT(HOUR FROM slot)::int AS hour,
           slot::date AS open_date
         FROM drawer_bounds db
         CROSS JOIN LATERAL generate_series(
           date_trunc('hour', db.open_at),
           date_trunc('hour', db.close_at),
           INTERVAL '1 hour'
         ) slot
         WHERE slot < db.close_at
       ), open_by_cell AS (
         SELECT day_of_week, hour, COUNT(DISTINCT open_date)::int AS open_days
         FROM open_slots
         GROUP BY day_of_week, hour
       ), sales_by_cell AS (
         SELECT
           EXTRACT(DOW FROM s.created_at)::int AS day_of_week,
           EXTRACT(HOUR FROM s.created_at)::int AS hour,
           COUNT(s.id)::int AS sale_count,
           COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
         FROM sales s
         WHERE s.status = 'PAID'
           AND s.created_at >= $1::timestamptz
           AND s.created_at < $2::timestamptz
         GROUP BY day_of_week, hour
       ), session_bounds AS (
         SELECT
           gs.id,
           GREATEST(gs.started_at, $1::timestamptz) AS start_at,
           LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz) AS end_at
         FROM game_sessions gs
         WHERE gs.status <> 'VOID'
           AND gs.started_at < $2::timestamptz
           AND COALESCE(gs.ended_at, $2::timestamptz) > $1::timestamptz
       ), session_slots AS (
         SELECT
           sb.id,
           EXTRACT(DOW FROM slot)::int AS day_of_week,
           EXTRACT(HOUR FROM slot)::int AS hour,
           GREATEST(0, EXTRACT(EPOCH FROM (
             LEAST(sb.end_at, slot + INTERVAL '1 hour') - GREATEST(sb.start_at, slot)
           )) / 60.0) AS occupied_minutes
         FROM session_bounds sb
         CROSS JOIN LATERAL generate_series(
           date_trunc('hour', sb.start_at),
           date_trunc('hour', sb.end_at),
           INTERVAL '1 hour'
         ) slot
         WHERE slot < sb.end_at
       ), sessions_by_cell AS (
         SELECT
           day_of_week,
           hour,
           COUNT(DISTINCT id)::int AS session_count,
           COALESCE(SUM(occupied_minutes), 0)::numeric(12,2) AS occupied_minutes
         FROM session_slots
         GROUP BY day_of_week, hour
       ), station_capacity AS (
         SELECT GREATEST(COUNT(*)::int, 1) AS station_count
         FROM stations
         WHERE deleted_at IS NULL
       )
       SELECT
         oc.day_of_week,
         oc.hour,
         oc.open_days,
         sc.station_count,
         COALESCE(sales.sale_count, 0)::int AS sale_count,
         COALESCE(sales.total_sales, 0)::numeric(12,2) AS total_sales,
         COALESCE(sessions.session_count, 0)::int AS session_count,
         COALESCE(sessions.occupied_minutes, 0)::numeric(12,2) AS occupied_minutes,
         (COALESCE(sales.total_sales, 0) / NULLIF(oc.open_days, 0))::numeric(12,2) AS average_revenue,
         LEAST(100, (COALESCE(sessions.occupied_minutes, 0) * 100.0) /
           NULLIF(oc.open_days * 60 * sc.station_count, 0))::numeric(6,2) AS utilization_percent
       FROM open_by_cell oc
       CROSS JOIN station_capacity sc
       LEFT JOIN sales_by_cell sales
         ON sales.day_of_week = oc.day_of_week AND sales.hour = oc.hour
       LEFT JOIN sessions_by_cell sessions
         ON sessions.day_of_week = oc.day_of_week AND sessions.hour = oc.hour
       ORDER BY oc.day_of_week, oc.hour`,
      [historyStart, historyEnd]
    ),
    query(
      `WITH drawer_capacity AS (
         SELECT COALESCE(SUM(EXTRACT(EPOCH FROM (
           LEAST(COALESCE(cd.closed_at, $2::timestamptz), $2::timestamptz)
           - GREATEST(cd.opened_at, $1::timestamptz)
         )) / 60.0), 0)::numeric(14,2) AS open_minutes
         FROM cash_drawers cd
         WHERE cd.opened_at < $2::timestamptz
           AND COALESCE(cd.closed_at, $2::timestamptz) > $1::timestamptz
       ), session_performance AS (
         SELECT
           gs.station_id,
           COUNT(gs.id)::int AS session_count,
           COALESCE(SUM(GREATEST(0, EXTRACT(EPOCH FROM (
             LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz)
             - GREATEST(gs.started_at, $1::timestamptz)
           )) / 60.0)), 0)::numeric(14,2) AS occupied_minutes,
           MAX(gs.started_at) AS last_used_at
         FROM game_sessions gs
         WHERE gs.status <> 'VOID'
           AND gs.started_at < $2::timestamptz
           AND COALESCE(gs.ended_at, $2::timestamptz) > $1::timestamptz
         GROUP BY gs.station_id
       ), revenue_per_station AS (
         SELECT
           gs.station_id,
           COALESCE(SUM(ssi.total), 0)::numeric(12,2) AS game_revenue
         FROM station_session_items ssi
         JOIN game_sessions gs ON gs.id = ssi.session_id
         JOIN sales s ON s.id = ssi.sale_id
         WHERE ssi.line_type = 'GAME_TIME'
           AND s.status = 'PAID'
           AND s.created_at >= $1::timestamptz
           AND s.created_at < $2::timestamptz
         GROUP BY gs.station_id
       )
       SELECT
         st.id,
         st.name,
         st.console_type,
         dc.open_minutes,
         COALESCE(sp.session_count, 0)::int AS session_count,
         COALESCE(sp.occupied_minutes, 0)::numeric(14,2) AS occupied_minutes,
         COALESCE(rps.game_revenue, 0)::numeric(12,2) AS game_revenue,
         sp.last_used_at,
         LEAST(100, COALESCE(sp.occupied_minutes, 0) * 100.0 /
           NULLIF(dc.open_minutes, 0))::numeric(6,2) AS utilization_percent,
         (COALESCE(rps.game_revenue, 0) * 60.0 /
           NULLIF(sp.occupied_minutes, 0))::numeric(12,2) AS revenue_per_occupied_hour
       FROM stations st
       CROSS JOIN drawer_capacity dc
       LEFT JOIN session_performance sp ON sp.station_id = st.id
       LEFT JOIN revenue_per_station rps ON rps.station_id = st.id
       WHERE st.deleted_at IS NULL
       ORDER BY COALESCE(rps.game_revenue, 0) DESC, COALESCE(sp.occupied_minutes, 0) DESC, st.sort_order, st.name`,
      [stationHistoryStart, analysisNow]
    )
  ]);

  const peakHourRows = peakHoursResult.rows.map((row) => ({
    hour: toNumber(row.hour),
    openDays: toNumber(row.open_days),
    stationCount: toNumber(row.station_count),
    saleCount: toNumber(row.sale_count),
    totalSales: toNumber(row.total_sales),
    sessionCount: toNumber(row.session_count),
    occupiedMinutes: toNumber(row.occupied_minutes),
    averageRevenue: toNumber(row.average_revenue),
    averageSales: toNumber(row.average_sales),
    averageStationMinutes: toNumber(row.average_station_minutes),
    utilizationPercent: toNumber(row.utilization_percent)
  }));

  const totalsByKey = Object.fromEntries(comparisonTotalsResult.rows.map((row) => [row.period_key, {
    totalSales: toNumber(row.total_sales),
    saleCount: toNumber(row.sale_count),
    averageTicket: toNumber(row.average_ticket)
  }]));
  const chartByKey = { current: new Map(), previous: new Map() };
  comparisonChartResult.rows.forEach((row) => {
    chartByKey[row.period_key]?.set(Number(row.bucket), {
      totalSales: toNumber(row.total_sales),
      saleCount: toNumber(row.sale_count)
    });
  });
  const points = Array.from({ length: window.pointCount }, (_, bucket) => ({
    bucket,
    label: comparisonPointLabel(window, bucket),
    current: chartByKey.current.get(bucket) || { totalSales: 0, saleCount: 0 },
    previous: chartByKey.previous.get(bucket) || { totalSales: 0, saleCount: 0 }
  }));

  const historyDayLabel = window.targetDow == null
    ? 'todos los días abiertos'
    : `los últimos 8 ${window.currentStart.toLocaleDateString('es-DO', { weekday: 'long' })}`;

  const projectionRow = projectionResult.rows[0] || {};
  const projectionCurrent = toNumber(projectionRow.total_sales);
  const projectionAverageThrough = toNumber(projectionRow.average_through);
  const projectionAverageRemaining = toNumber(projectionRow.average_remaining);
  const projectionPace = projectionAverageThrough > 0
    ? projectionCurrent / projectionAverageThrough
    : 1;
  const adjustedProjectionPace = Math.min(1.5, Math.max(0.5, projectionPace));
  const projectionComparableDays = toNumber(projectionRow.comparable_days);
  const projectedClose = projectionCurrent + (projectionAverageRemaining * adjustedProjectionPace);
  const weeklyHeatmap = weeklyHeatmapResult.rows.map((row) => ({
    dayOfWeek: toNumber(row.day_of_week),
    hour: toNumber(row.hour),
    openDays: toNumber(row.open_days),
    stationCount: toNumber(row.station_count),
    saleCount: toNumber(row.sale_count),
    totalSales: toNumber(row.total_sales),
    sessionCount: toNumber(row.session_count),
    occupiedMinutes: toNumber(row.occupied_minutes),
    averageRevenue: toNumber(row.average_revenue),
    utilizationPercent: toNumber(row.utilization_percent)
  }));
  const stationPerformance = stationPerformanceResult.rows.map((row) => ({
    id: row.id,
    name: row.name,
    consoleType: row.console_type,
    openMinutes: toNumber(row.open_minutes),
    sessionCount: toNumber(row.session_count),
    occupiedMinutes: toNumber(row.occupied_minutes),
    gameRevenue: toNumber(row.game_revenue),
    lastUsedAt: row.last_used_at,
    utilizationPercent: toNumber(row.utilization_percent),
    revenuePerOccupiedHour: toNumber(row.revenue_per_occupied_hour)
  }));

  return {
    comparison: {
      available: true,
      currentLabel: window.currentLabel,
      comparisonLabel: window.comparisonLabel,
      throughLabel: window.throughLabel,
      chartUnit: window.chartUnit,
      current: totalsByKey.current || { totalSales: 0, saleCount: 0, averageTicket: 0 },
      previous: totalsByKey.previous || { totalSales: 0, saleCount: 0, averageTicket: 0 },
      points
    },
    peakHours: {
      available: peakHourRows.filter((row) => row.openDays >= 3).length >= 2,
      historyLabel: `Basado en ${historyDayLabel}`,
      hours: peakHourRows
    },
    dayProjection: {
      available: projectionComparableDays >= 3 && toNumber(projectionRow.average_full_day) > 0,
      currentSales: projectionCurrent,
      currentSaleCount: toNumber(projectionRow.sale_count),
      comparableDays: projectionComparableDays,
      averageThrough: projectionAverageThrough,
      averageFullDay: toNumber(projectionRow.average_full_day),
      averageRemaining: projectionAverageRemaining,
      projectedClose,
      pacePercent: projectionAverageThrough > 0
        ? ((projectionCurrent - projectionAverageThrough) / projectionAverageThrough) * 100
        : 0,
      averageCloseSeconds: toNumber(projectionRow.average_close_seconds),
      confidence: projectionComparableDays >= 6 ? 'HIGH' : projectionComparableDays >= 4 ? 'MEDIUM' : 'LIMITED'
    },
    weeklyHeatmap: {
      available: weeklyHeatmap.filter((row) => row.openDays >= 3).length >= 4,
      historyLabel: 'Últimas ocho semanas completas',
      cells: weeklyHeatmap
    },
    stationPerformance: {
      available: stationPerformance.some((row) => row.openMinutes > 0),
      historyLabel: 'Últimos 30 días',
      stations: stationPerformance
    }
  };
}

function normalizeCodeType(value) {
  const type = String(value || 'TRANSFER').trim().toUpperCase();
  return type === 'PAYMENT' ? 'PAYMENT' : 'TRANSFER';
}


function normalizeGameRequestStatus(value = '') {
  const status = String(value || '').trim().toUpperCase();
  const allowed = ['PENDIENTE', 'ESPERANDO', 'REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO'];
  return allowed.includes(status) ? status : '';
}

function normalizeOwnerText(value = '', max = 220) {
  return String(value || '').trim().slice(0, max) || null;
}

async function createOwnerUniqueCode() {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const { rowCount } = await query(
      `SELECT id FROM admin_one_time_codes WHERE code = $1 AND is_used = false AND expires_at > NOW() LIMIT 1`,
      [code]
    );
    if (rowCount === 0) return code;
  }
  const error = new Error('No se pudo generar el código. Intenta de nuevo.');
  error.status = 500;
  throw error;
}

export async function ownerDashboardCreateAuthorizationCode(req, res) {
  try {
    const codeType = normalizeCodeType(req.body?.codeType);
    const expiresMinutes = Math.min(60, Math.max(1, Number(req.body?.expiresMinutes || 15)));
    const purposeNote = String(req.body?.purposeNote || '').trim().slice(0, 160) || null;
    const code = await createOwnerUniqueCode();
    const { rows } = await query(
      `INSERT INTO admin_one_time_codes (code, code_type, created_by_user_id, expires_at, purpose_note)
       VALUES ($1, $2, $3, NOW() + ($4::int * INTERVAL '1 minute'), $5)
       RETURNING id, code, code_type, purpose_note, expires_at, created_at`,
      [code, codeType, req.ownerUser.id, expiresMinutes, purposeNote]
    );
    res.status(201).json({ authorizationCode: rows[0] });
  } catch (error) {
    console.error('Owner dashboard create code error:', error.message);
    res.status(error.status || 500).json({ error: error.message || 'No se pudo generar el código.' });
  }
}

export async function ownerDashboardAuthorizationCodes(_req, res) {
  try {
    const { rows } = await query(
      `SELECT c.id, c.code, c.code_type, c.purpose_note, c.is_used, c.expires_at, c.used_at, c.created_at,
              creator.full_name AS created_by_name,
              used_by.full_name AS used_by_name
       FROM admin_one_time_codes c
       LEFT JOIN users creator ON creator.id = c.created_by_user_id
       LEFT JOIN users used_by ON used_by.id = c.used_by_user_id
       ORDER BY c.created_at DESC
       LIMIT 20`
    );
    res.json({ codes: rows });
  } catch (error) {
    console.error('Owner dashboard codes error:', error.message);
    res.status(500).json({ error: 'No se pudieron cargar los códigos.' });
  }
}


function normalizeFamilyDiscountCode(value = '') {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 20);
}

function normalizeFamilyDiscountPercent(value) {
  const percent = Number.parseInt(String(value || 0), 10);
  return [50, 100].includes(percent) ? percent : 50;
}

function normalizeFamilyDiscountExpiresDays(value) {
  const days = Number.parseInt(String(value || 7), 10);
  return [1, 7, 15, 30].includes(days) ? days : 7;
}

async function createOwnerFamilyDiscountUniqueCode(prefix = 'FAM') {
  const cleanPrefix = normalizeFamilyDiscountCode(prefix || 'FAM').slice(0, 8) || 'FAM';
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const suffix = String(Math.floor(1000 + Math.random() * 9000));
    const code = `${cleanPrefix}${suffix}`;
    const { rowCount } = await query(`SELECT id FROM family_discount_codes WHERE code = $1 LIMIT 1`, [code]);
    if (rowCount === 0) return code;
  }
  const error = new Error('No se pudo generar el código familiar. Intenta de nuevo.');
  error.status = 500;
  throw error;
}

export async function ownerDashboardCreateFamilyDiscountCode(req, res) {
  try {
    const discountPercent = normalizeFamilyDiscountPercent(req.body?.discountPercent || req.body?.discount_percent);
    const expiresDays = normalizeFamilyDiscountExpiresDays(req.body?.expiresDays || req.body?.expires_days);
    const maxUsesRaw = Number.parseInt(String(req.body?.maxUses || req.body?.max_uses || 1), 10);
    const maxUses = Number.isFinite(maxUsesRaw) ? Math.max(1, Math.min(50, maxUsesRaw)) : 1;
    const note = String(req.body?.note || req.body?.purposeNote || '').trim().slice(0, 180) || null;
    let code = normalizeFamilyDiscountCode(req.body?.code || '');
    if (!code) code = await createOwnerFamilyDiscountUniqueCode('FAM');
    if (code.length < 4) return res.status(400).json({ error: 'El código debe tener al menos 4 caracteres.' });

    const { rows } = await query(
      `INSERT INTO family_discount_codes
         (code, discount_percent, max_uses, expires_at, note, created_by_user_id)
       VALUES ($1, $2, $3, NOW() + ($4::int * INTERVAL '1 day'), $5, $6)
       RETURNING id, code, discount_percent, applies_to, max_uses, used_count, is_active, expires_at, note, created_at`,
      [code, discountPercent, maxUses, expiresDays, note, req.ownerUser.id]
    );

    res.status(201).json({ discountCode: rows[0] });
  } catch (error) {
    console.error('Owner dashboard family discount create error:', error.message);
    const message = error.code === '23505' ? 'Ese código ya existe. Usa otro nombre.' : (error.message || 'No se pudo generar el código de descuento.');
    res.status(error.status || (error.code === '23505' ? 409 : 500)).json({ error: message });
  }
}

export async function ownerDashboardFamilyDiscountCodes(_req, res) {
  try {
    const { rows } = await query(
      `SELECT c.id, c.code, c.discount_percent, c.applies_to, c.max_uses,
              GREATEST(
                COALESCE(c.used_count, 0),
                COALESCE(usage_summary.usage_count, 0),
                COALESCE(sale_item_summary.usage_count, 0)
              )::int AS used_count,
              c.is_active,
              c.expires_at, c.note, c.created_at,
              creator.full_name AS created_by_name,
              GREATEST(
                COALESCE(usage_summary.discount_amount, 0),
                COALESCE(sale_item_summary.discount_amount, 0)
              )::numeric(12,2) AS discount_amount,
              GREATEST(
                COALESCE(usage_summary.usage_count, 0),
                COALESCE(sale_item_summary.usage_count, 0)
              )::int AS usage_count
       FROM family_discount_codes c
       LEFT JOIN users creator ON creator.id = c.created_by_user_id
       LEFT JOIN LATERAL (
         SELECT COUNT(u.id)::int AS usage_count,
                COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount
         FROM family_discount_code_usages u
         WHERE u.code_id = c.id
       ) usage_summary ON true
       LEFT JOIN LATERAL (
         SELECT COUNT(DISTINCT si.sale_id)::int AS usage_count,
                COALESCE(SUM(ABS(si.total)), 0)::numeric(12,2) AS discount_amount
         FROM sale_items si
         JOIN sales s ON s.id = si.sale_id AND s.status = 'PAID'
         WHERE si.item_type = 'ADJUSTMENT'
           AND si.description ILIKE ('%' || c.code || '%')
       ) sale_item_summary ON true
       ORDER BY c.created_at DESC
       LIMIT 40`
    );
    res.json({ discountCodes: rows });
  } catch (error) {
    console.error('Owner dashboard family discount list error:', error.message);
    res.status(500).json({ error: 'No se pudieron cargar los códigos familiares.' });
  }
}

function normalizeStationStatus(row = {}) {
  if (row.active_session_id) return 'BUSY';
  return row.status || 'AVAILABLE';
}

function buildOwnerToken(user) {
  return jwt.sign(
    {
      purpose: OWNER_DASHBOARD_TOKEN_PURPOSE,
      id: user.id,
      name: user.full_name,
      role: user.role
    },
    env.jwtSecret,
    { expiresIn: '12h' }
  );
}

function getBearerToken(req) {
  const header = String(req.headers.authorization || '');
  return header.startsWith('Bearer ') ? header.slice(7) : null;
}

export function requireOwnerDashboardAuth(req, res, next) {
  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Inicia sesión para ver el panel owner.' });

  try {
    const payload = jwt.verify(token, env.jwtSecret);
    if (payload?.purpose !== OWNER_DASHBOARD_TOKEN_PURPOSE) {
      return res.status(401).json({ error: 'Sesión inválida para este panel.' });
    }
    if (!['OWNER', 'MANAGER'].includes(String(payload.role || '').toUpperCase())) {
      return res.status(403).json({ error: 'No tienes permiso para ver el panel owner.' });
    }
    req.ownerUser = payload;
    next();
  } catch (_error) {
    return res.status(401).json({ error: 'Sesión expirada. Vuelve a iniciar sesión.' });
  }
}

export async function ownerDashboardLogin(req, res) {
  try {
    const pin = String(req.body?.pin || '').trim();
    if (!pin) return res.status(400).json({ error: 'Ingresa el PIN owner/admin.' });

    const { rows } = await query(
      `SELECT id, full_name, role, pin_hash, is_active
       FROM users
       WHERE is_active = true
       ORDER BY created_at ASC`
    );

    const user = rows.find((row) => bcrypt.compareSync(pin, row.pin_hash));
    if (!user) return res.status(401).json({ error: 'PIN incorrecto.' });

    const role = String(user.role || '').toUpperCase();
    if (!['OWNER', 'MANAGER'].includes(role)) {
      return res.status(403).json({ error: 'Este PIN no tiene permiso para reportes remotos.' });
    }

    res.json({
      token: buildOwnerToken(user),
      user: {
        id: user.id,
        name: user.full_name,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Owner dashboard login error:', error.message);
    res.status(500).json({ error: 'No se pudo iniciar sesión en el panel owner.' });
  }
}

export async function ownerDashboardPosSecurity(_req, res) {
  try {
    const settingsResult = await query(`SELECT value FROM app_settings WHERE key = 'pos_access_security' LIMIT 1`);
    const value = settingsResult.rows[0]?.value || {};
    const devicesResult = await query(
      `SELECT id, device_id, device_name, last_ip, authorized_at, last_seen_at, expires_at, is_active, revoked_at
       FROM pos_access_devices ORDER BY last_seen_at DESC LIMIT 100`
    );
    res.json({ settings: { remoteMode: String(value.remoteMode || 'READ_ONLY').toUpperCase(), rememberDays: Number(value.rememberDays || 7) }, devices: devicesResult.rows });
  } catch (error) {
    res.status(500).json({ error: 'No se pudo cargar la seguridad del POS.' });
  }
}

export async function ownerDashboardUpdatePosSecurity(req, res) {
  try {
    const remoteMode = ['READ_ONLY', 'FULL', 'DISABLED'].includes(String(req.body?.remoteMode || '').toUpperCase())
      ? String(req.body.remoteMode).toUpperCase() : 'READ_ONLY';
    const rememberDays = Math.max(1, Math.min(30, Number(req.body?.rememberDays || 7)));
    const { rows } = await query(
      `UPDATE app_settings SET value = COALESCE(value, '{}'::jsonb) || jsonb_build_object('remoteMode', $1::text, 'rememberDays', $2::int), updated_at = NOW()
       WHERE key = 'pos_access_security' RETURNING value`,
      [remoteMode, rememberDays]
    );
    res.json({ settings: { remoteMode, rememberDays }, saved: Boolean(rows.length) });
  } catch (error) {
    res.status(500).json({ error: 'No se pudo guardar la seguridad del POS.' });
  }
}

export async function ownerDashboardRevokePosDevice(req, res) {
  try {
    const { rowCount } = await query(
      `UPDATE pos_access_devices SET is_active = false, revoked_at = NOW(), revoked_by_user_id = $2 WHERE id = $1`,
      [req.params.deviceId, req.ownerUser.id]
    );
    if (!rowCount) return res.status(404).json({ error: 'Dispositivo no encontrado.' });
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: 'No se pudo revocar el dispositivo.' });
  }
}

export async function ownerDashboardRevokeAllPosDevices(req, res) {
  try {
    const { rowCount } = await query(
      `UPDATE pos_access_devices SET is_active = false, revoked_at = NOW(), revoked_by_user_id = $1 WHERE is_active = true`,
      [req.ownerUser.id]
    );
    res.json({ ok: true, revoked: rowCount });
  } catch (error) {
    res.status(500).json({ error: 'No se pudieron cerrar los accesos remotos.' });
  }
}

async function loadPrinterMaintenanceData() {
  try {
    const [eventsResult, statsResult, settingsResult] = await Promise.all([
      query(`SELECT id, printer_model, event_type, result, printer_sheet_counter,
                    stationcore_sheet_count, notes, performed_at, created_at
             FROM printer_maintenance_events
             WHERE printer_model = 'Epson L3250'
             ORDER BY performed_at DESC, created_at DESC
             LIMIT 100`),
      query(`SELECT COALESCE(SUM(paper_sheets), 0)::numeric(14,2) AS total_sheets,
                    MAX(created_at) AS last_print_at
             FROM print_jobs`),
      query(`SELECT value FROM app_settings WHERE key = 'printing_maintenance_settings'`)
    ]);
    return buildPrinterMaintenanceSummary({
      events: eventsResult.rows,
      printStats: statsResult.rows[0] || {},
      settings: settingsResult.rows[0]?.value || {}
    });
  } catch (error) {
    if (error.code === '42P01' || error.code === '42703') {
      return buildPrinterMaintenanceSummary();
    }
    throw error;
  }
}

export async function ownerDashboardPrintingSettings(_req, res) {
  try {
    const [supplies, recipes, storedRules, maintenance] = await Promise.all([
      query(`SELECT * FROM print_supply_settings ORDER BY supply_group, is_system DESC, display_name, supply_type`),
      query(`SELECT r.*, p.name, p.price, p.sku, p.is_active
             FROM print_service_recipes r
             JOIN products p ON p.id = r.product_id
             ORDER BY p.is_active DESC, p.price, p.name`),
      loadPrintingPricingRules({ query }).catch(() => ({})),
      loadPrinterMaintenanceData()
    ]);

    const supplyMap = Object.fromEntries(supplies.rows.map((supply) => [String(supply.supply_type), supply]));

    res.json({
      supplies: supplies.rows,
      recipes: recipes.rows.map((recipe) => {
        const pricing = resolvePrintingPricingRule(recipe, storedRules);
        return {
          ...recipe,
          regular_price: pricing.regularPrice,
          bulk_from: pricing.bulkFrom,
          bulk_price: pricing.bulkPrice,
          paper_mode: pricing.paperMode,
          material_cost_per_sheet: pricing.materialCostPerSheet,
          calculation: calculatePrintRecipeEconomics(recipe, supplyMap)
        };
      }),
      catalog: getEpsonL3250Catalog(),
      maintenance
    });
  } catch (error) {
    console.error('No se pudo cargar Impresiones:', error);
    res.status(500).json({ error: 'No se pudo cargar Impresiones.' });
  }
}

export async function ownerDashboardSavePrintingSettings(req, res) {
  try {
    await withTransaction(async (client) => {
      for (const item of req.body?.supplies || []) {
        const isPaper = String(item.supplyGroup || item.supply_group || '').toUpperCase() === 'PAPER';
        const paperSelection = isPaper
          ? resolveEpsonPaperSelection(item.mediaProfile || item.media_profile, item.paperSize || item.paper_size)
          : null;
        await client.query(
          `UPDATE print_supply_settings
           SET display_name = COALESCE(NULLIF($2, ''), display_name),
               purchase_quantity = $3, purchase_cost = $4, yield_units = $5,
               remaining_units = $6, low_level_units = $7,
               media_profile = CASE WHEN supply_group = 'PAPER' THEN $8 ELSE media_profile END,
               paper_size = CASE WHEN supply_group = 'PAPER' THEN $9 ELSE paper_size END,
               sheet_width_mm = CASE WHEN supply_group = 'PAPER' THEN $10 ELSE sheet_width_mm END,
               sheet_height_mm = CASE WHEN supply_group = 'PAPER' THEN $11 ELSE sheet_height_mm END,
               paper_brand = CASE WHEN supply_group = 'PAPER' THEN $12 ELSE paper_brand END,
               official_profile = CASE WHEN supply_group = 'PAPER' THEN $13 ELSE official_profile END,
               updated_at = NOW()
           WHERE supply_type = $1`,
          [
            item.supplyType, String(item.displayName || '').trim(), item.purchaseQuantity,
            item.purchaseCost, item.yieldUnits, item.remainingUnits, item.lowLevelUnits,
            paperSelection?.mediaProfile || null, paperSelection?.paperSize || null,
            paperSelection?.widthMm || null, paperSelection?.heightMm || null,
            isPaper ? String(item.paperBrand || item.paper_brand || '').trim() || null : null,
            paperSelection?.officialProfile || false
          ]
        );
      }

      const storedRules = await loadPrintingPricingRules(client, { forUpdate: true }).catch(() => ({}));
      for (const item of req.body?.recipes || []) {
        const requestedService = normalizePrintServicePayload(item);
        const productResult = await client.query(
          `UPDATE products
           SET name = $2, price = $3, is_active = $4, product_kind = 'PRINT_SERVICE', updated_at = NOW()
           WHERE id = $1 AND category = 'PRINTING'
           RETURNING id, sku, price`,
          [item.productId, requestedService.name, requestedService.regularPrice, requestedService.isActive]
        );
        if (!productResult.rowCount) {
          const error = new Error('Servicio de impresión no encontrado.');
          error.status = 404;
          throw error;
        }

        const paperResult = await client.query(
          `SELECT * FROM print_supply_settings
           WHERE supply_type = $1 AND supply_group = 'PAPER' AND is_active = true`,
          [requestedService.paperSupplyType]
        );
        if (!paperResult.rowCount) {
          const error = new Error(`El papel seleccionado para ${requestedService.name} no está disponible.`);
          error.status = 400;
          throw error;
        }
        const service = resolvePrintRecipe(requestedService, paperResult.rows[0]);

        await client.query(
          `UPDATE print_service_recipes
           SET paper_sheets = $2, black_ink_units = $3, color_ink_units = $4,
               waste_percent = $5, paper_supply_type = $6,
               output_type = $7, color_mode = $8, print_quality = $9,
               coverage_profile = $10, borderless = $11,
               auto_ink_estimate = $12, estimate_source = $13
           WHERE product_id = $1`,
          [
            item.productId, service.paperSheets, service.blackInkUnits, service.colorInkUnits,
            service.wastePercent, service.paperSupplyType, service.outputType, service.colorMode,
            service.printQuality, service.coverageProfile, service.borderless,
            service.autoInkEstimate, service.estimateSource
          ]
        );

        storedRules[String(item.productId)] = normalizePrintingPricingRule(service, productResult.rows[0]);
      }

      await savePrintingPricingRules(client, storedRules, req.ownerUser?.id || null);
    });

    res.json({ ok: true });
  } catch (error) {
    console.error('No se pudo guardar Impresiones:', error);
    res.status(error.status || 500).json({ error: error.message || 'No se pudo guardar Impresiones.' });
  }
}

export async function ownerDashboardCreatePrintingService(req, res) {
  try {
    const requestedService = normalizePrintServicePayload(req.body || {});
    const created = await withTransaction(async (client) => {
      const paperResult = await client.query(
        `SELECT * FROM print_supply_settings
         WHERE supply_type = $1 AND supply_group = 'PAPER' AND is_active = true`,
        [requestedService.paperSupplyType]
      );
      if (!paperResult.rowCount) {
        const error = new Error('Selecciona un papel disponible para este servicio.');
        error.status = 400;
        throw error;
      }
      const service = resolvePrintRecipe(requestedService, paperResult.rows[0]);
      const serviceCode = createPrintServiceCode(service.name);
      const productResult = await client.query(
        `INSERT INTO products (
           name, category, sku, price, cost, stock_qty, track_stock, is_active, product_kind
         ) VALUES ($1, 'PRINTING', $2, $3, 0, 0, false, $4, 'PRINT_SERVICE')
         RETURNING *`,
        [service.name, serviceCode, service.regularPrice, service.isActive]
      );
      const product = productResult.rows[0];

      await client.query(
        `INSERT INTO print_service_recipes (
           product_id, service_code, paper_sheets, black_ink_units, color_ink_units,
           waste_percent, paper_supply_type, output_type, color_mode, print_quality,
           coverage_profile, borderless, auto_ink_estimate, estimate_source
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [
          product.id, serviceCode, service.paperSheets, service.blackInkUnits,
          service.colorInkUnits, service.wastePercent, service.paperSupplyType,
          service.outputType, service.colorMode, service.printQuality,
          service.coverageProfile, service.borderless, service.autoInkEstimate,
          service.estimateSource
        ]
      );

      const storedRules = await loadPrintingPricingRules(client, { forUpdate: true }).catch(() => ({}));
      storedRules[String(product.id)] = normalizePrintingPricingRule(service, product);
      await savePrintingPricingRules(client, storedRules, req.ownerUser?.id || null);
      return product;
    });

    res.status(201).json({ ok: true, service: created });
  } catch (error) {
    console.error('No se pudo crear el servicio de impresión:', error);
    if (error.code === '23505') return res.status(409).json({ error: 'Ya existe un servicio con ese código.' });
    res.status(error.status || 500).json({ error: error.message || 'No se pudo crear el servicio de impresión.' });
  }
}

export async function ownerDashboardCreatePrintingSupply(req, res) {
  try {
    const supply = normalizePrintSupplyPayload(req.body || {});
    const duplicate = await query(
      `SELECT id FROM print_supply_settings
       WHERE supply_group = 'PAPER' AND LOWER(display_name) = LOWER($1)
       LIMIT 1`,
      [supply.displayName]
    );
    if (duplicate.rowCount) return res.status(409).json({ error: 'Ya existe un papel con ese nombre.' });
    const supplyType = createPrintSupplyCode(supply.displayName);
    const { rows } = await query(
      `INSERT INTO print_supply_settings (
         supply_type, display_name, supply_group, unit_label, is_system, is_active,
         purchase_quantity, purchase_cost, yield_units, remaining_units, low_level_units,
         media_profile, paper_size, sheet_width_mm, sheet_height_mm, paper_brand,
         official_profile, updated_at
       ) VALUES ($1, $2, 'PAPER', 'hojas', false, $3, 1, $4, $5, $6, $7,
                 $8, $9, $10, $11, $12, $13, NOW())
       RETURNING *`,
      [
        supplyType, supply.displayName, supply.isActive, supply.purchaseCost,
        supply.yieldUnits, supply.remainingUnits, supply.lowLevelUnits,
        supply.mediaProfile, supply.paperSize, supply.sheetWidthMm,
        supply.sheetHeightMm, supply.paperBrand || null, supply.officialProfile
      ]
    );
    res.status(201).json({ ok: true, supply: rows[0] });
  } catch (error) {
    console.error('No se pudo crear el papel de impresión:', error);
    if (error.code === '23505') return res.status(409).json({ error: 'Ya existe un papel con ese nombre o código.' });
    res.status(error.status || 500).json({ error: error.message || 'No se pudo crear el papel.' });
  }
}

export async function ownerDashboardCreatePrinterMaintenanceEvent(req, res) {
  try {
    const eventType = String(req.body?.eventType || '').trim().toUpperCase();
    if (!PRINTER_MAINTENANCE_EVENT_TYPES.includes(eventType)) {
      return res.status(400).json({ error: 'Selecciona un mantenimiento válido.' });
    }
    const allowedResults = ['CLEAN', 'GAPS', 'MOSTLY_MISSING'];
    const result = String(req.body?.result || '').trim().toUpperCase() || null;
    if (eventType === 'NOZZLE_CHECK' && !allowedResults.includes(result)) {
      return res.status(400).json({ error: 'Indica cómo salió el patrón de inyectores.' });
    }
    if (eventType === 'POWER_CLEANING' && req.body?.safetyConfirmed !== true) {
      return res.status(400).json({ error: 'Confirma que esperaste el tiempo indicado y que todos los tanques tienen al menos un tercio.' });
    }
    if (eventType === 'POWER_CLEANING') {
      const maintenance = await loadPrinterMaintenanceData();
      if (maintenance.waitUntil && new Date(maintenance.waitUntil) > new Date()) {
        return res.status(409).json({ error: `Después de tres limpiezas normales debes esperar hasta ${new Date(maintenance.waitUntil).toLocaleString('es-DO')}.` });
      }
    }

    await withTransaction(async (client) => {
      if (eventType === 'POWER_CLEANING') {
        const { rows } = await client.query(
          `SELECT performed_at FROM printer_maintenance_events
           WHERE printer_model = 'Epson L3250' AND event_type = 'POWER_CLEANING'
           ORDER BY performed_at DESC LIMIT 1
           FOR UPDATE`
        );
        const lastPowerCleaning = rows[0]?.performed_at ? new Date(rows[0].performed_at) : null;
        if (lastPowerCleaning && Date.now() - lastPowerCleaning.getTime() < 12 * 60 * 60 * 1000) {
          const error = new Error('Epson exige esperar al menos 12 horas entre limpiezas a fondo.');
          error.status = 409;
          throw error;
        }
      }

      const stats = await client.query(`SELECT COALESCE(SUM(paper_sheets), 0)::numeric(14,2) AS total_sheets FROM print_jobs`);
      const printerSheetCounter = req.body?.printerSheetCounter === '' || req.body?.printerSheetCounter == null
        ? null : printInteger(req.body.printerSheetCounter, 0);
      await client.query(
        `INSERT INTO printer_maintenance_events (
           printer_model, event_type, result, printer_sheet_counter,
           stationcore_sheet_count, notes, performed_at, created_by_user_id
         ) VALUES ('Epson L3250', $1, $2, $3, $4, $5, NOW(), $6)`,
        [
          eventType,
          eventType === 'NOZZLE_CHECK' ? result : null,
          printerSheetCounter,
          Number(stats.rows[0]?.total_sheets || 0),
          String(req.body?.notes || '').trim() || null,
          req.ownerUser?.id || null
        ]
      );
    });

    res.status(201).json({ ok: true, maintenance: await loadPrinterMaintenanceData() });
  } catch (error) {
    console.error('No se pudo registrar el mantenimiento Epson:', error);
    res.status(error.status || 500).json({ error: error.message || 'No se pudo registrar el mantenimiento.' });
  }
}

export async function ownerDashboardSavePrinterMaintenanceSettings(req, res) {
  try {
    const settings = {
      printerModel: 'Epson L3250',
      nozzleCheckDays: Math.max(1, printInteger(req.body?.nozzleCheckDays, 30)),
      nozzleCheckSheets: Math.max(1, printInteger(req.body?.nozzleCheckSheets, 500)),
      inactivityDays: Math.max(1, printInteger(req.body?.inactivityDays, 14)),
      exteriorCleaningDays: Math.max(30, printInteger(req.body?.exteriorCleaningDays, 120))
    };
    await query(
      `INSERT INTO app_settings (key, value, updated_by_user_id, updated_at)
       VALUES ('printing_maintenance_settings', $1::jsonb, $2, NOW())
       ON CONFLICT (key) DO UPDATE
       SET value = EXCLUDED.value,
           updated_by_user_id = EXCLUDED.updated_by_user_id,
           updated_at = NOW()`,
      [JSON.stringify(settings), req.ownerUser?.id || null]
    );
    res.json({ ok: true, maintenance: await loadPrinterMaintenanceData() });
  } catch (error) {
    console.error('No se pudo guardar el plan de mantenimiento Epson:', error);
    res.status(500).json({ error: 'No se pudo guardar el plan de mantenimiento.' });
  }
}

export async function ownerDashboardInventoryAlerts(_req, res) {
  try {
    const productResult = await query(
      `WITH usage AS (
         SELECT im.product_id,
                ABS(COALESCE(SUM(im.quantity_change) FILTER (WHERE im.created_at >= NOW() - INTERVAL '7 days'), 0))::numeric AS used_7_days,
                ABS(COALESCE(SUM(im.quantity_change) FILTER (WHERE im.created_at >= NOW() - INTERVAL '30 days'), 0))::numeric AS used_30_days,
                MAX(im.created_at) FILTER (WHERE im.quantity_change < 0) AS last_usage_at
         FROM inventory_movements im
         WHERE im.quantity_change < 0
           AND im.movement_type IN ('SALE', 'COMBO_COMPONENT')
         GROUP BY im.product_id
       ), base AS (
         SELECT p.id AS product_id, p.name AS product_name, p.stock_qty, p.cost,
                p.low_stock_threshold AS safety_stock,
                p.supplier_lead_days, p.reorder_cover_days,
                COALESCE(u.used_7_days, 0) AS used_7_days,
                COALESCE(u.used_30_days, 0) AS used_30_days,
                u.last_usage_at,
                CASE
                  WHEN COALESCE(u.used_30_days, 0) > 0
                    THEN GREATEST(u.used_30_days / 30.0, (u.used_7_days / 7.0 * 0.60) + (u.used_30_days / 30.0 * 0.40))
                  ELSE 0
                END AS daily_velocity
         FROM products p
         LEFT JOIN usage u ON u.product_id = p.id
         WHERE p.is_active = true AND p.track_stock = true
           AND p.is_combo = false AND p.category <> 'MEMBERSHIP'
       )
       SELECT *,
              CASE WHEN daily_velocity > 0 THEN (stock_qty / daily_velocity)::numeric(10,1) ELSE NULL END AS days_remaining,
              GREATEST(0, CEIL(daily_velocity * (supplier_lead_days + reorder_cover_days) + safety_stock - stock_qty))::int AS suggested_order_qty,
              CASE
                WHEN stock_qty <= 0 THEN 'OUT_OF_STOCK'
                WHEN daily_velocity > 0 AND stock_qty <= CEIL(daily_velocity * supplier_lead_days) THEN 'URGENT'
                WHEN daily_velocity > 0 AND stock_qty <= CEIL(daily_velocity * supplier_lead_days + safety_stock) THEN 'ORDER_SOON'
                ELSE 'HEALTHY'
              END AS reorder_status,
              CASE
                WHEN stock_qty > 0 AND last_usage_at IS NULL THEN 'NEVER_SOLD'
                WHEN stock_qty > 0 AND last_usage_at < NOW() - INTERVAL '30 days' THEN 'NO_MOVEMENT_30'
                WHEN stock_qty > 0 AND last_usage_at < NOW() - INTERVAL '15 days' THEN 'NO_MOVEMENT_15'
                ELSE 'MOVING'
              END AS movement_status
       FROM base
       ORDER BY CASE
         WHEN stock_qty <= 0 THEN 1
         WHEN daily_velocity > 0 AND stock_qty <= CEIL(daily_velocity * supplier_lead_days) THEN 2
         WHEN daily_velocity > 0 AND stock_qty <= CEIL(daily_velocity * supplier_lead_days + safety_stock) THEN 3
         WHEN stock_qty > 0 AND last_usage_at IS NULL THEN 4
         WHEN stock_qty > 0 AND last_usage_at < NOW() - INTERVAL '30 days' THEN 5
         ELSE 6 END,
         product_name`
    );

    const [suppliesResult, printerMaintenance] = await Promise.all([
      query(
        `SELECT supply_type, display_name, unit_label, remaining_units, low_level_units
         FROM print_supply_settings
         WHERE is_active = true AND remaining_units <= low_level_units
         ORDER BY remaining_units ASC`
      ).catch(() => ({ rows: [] })),
      loadPrinterMaintenanceData().catch(() => buildPrinterMaintenanceSummary())
    ]);

    const products = productResult.rows;
    const actionable = products.filter((row) => ['OUT_OF_STOCK', 'URGENT', 'ORDER_SOON'].includes(row.reorder_status));
    const stagnant = products.filter((row) => ['NEVER_SOLD', 'NO_MOVEMENT_30', 'NO_MOVEMENT_15'].includes(row.movement_status));
    const summary = products.reduce((total, row) => {
      if (row.reorder_status === 'OUT_OF_STOCK') total.outOfStock += 1;
      if (row.reorder_status === 'URGENT') total.urgent += 1;
      if (row.reorder_status === 'ORDER_SOON') total.orderSoon += 1;
      if (row.movement_status !== 'MOVING') total.stagnant += 1;
      if (['OUT_OF_STOCK', 'URGENT', 'ORDER_SOON'].includes(row.reorder_status)) {
        total.suggestedUnits += toNumber(row.suggested_order_qty);
        total.suggestedInvestment += toNumber(row.suggested_order_qty) * toNumber(row.cost);
      }
      return total;
    }, { outOfStock: 0, urgent: 0, orderSoon: 0, stagnant: 0, suggestedUnits: 0, suggestedInvestment: 0 });

    summary.printSupplies = suppliesResult.rows.length;
    summary.maintenanceAlerts = Number(printerMaintenance.dueCount || 0);
    summary.totalAlerts = new Set([...actionable, ...stagnant].map((row) => String(row.product_id))).size
      + summary.printSupplies + summary.maintenanceAlerts;

    res.json({
      generatedAt: new Date().toISOString(),
      summary,
      reorder: actionable.slice(0, 12),
      stagnant: stagnant.slice(0, 12),
      printSupplies: suppliesResult.rows,
      printerMaintenance
    });
  } catch (error) {
    console.error('Owner inventory alerts error:', error.message);
    res.status(500).json({ error: 'No se pudieron cargar las alertas de inventario.' });
  }
}

export async function ownerDashboardSummary(req, res) {
  try {
    const range = await resolveOwnerDashboardRange(req.query || {});
    const rangeParams = [range.startParam, range.endParam];
    const saleFilter = salesTimeFilter('s', range);
    const drawerMovementFilter = movementTimeFilter('dm', range);
    const shifts = await getOwnerShiftRows(range);
    const intelligencePromise = getOwnerDashboardIntelligence(range).catch((error) => {
      console.error('Owner dashboard intelligence error:', error.message);
      return {
        comparison: {
          available: false,
          reason: 'El análisis inteligente no pudo cargarse; los demás datos del panel siguen disponibles.'
        },
        peakHours: { available: false, hours: [] },
        dayProjection: { available: false },
        weeklyHeatmap: { available: false, cells: [] },
        stationPerformance: { available: false, stations: [] }
      };
    });
    const salesResult = await query(
      `SELECT
         COUNT(s.id)::int AS sale_count,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'MIXED' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS mixed_sales,
         COALESCE(SUM(s.discount_total), 0)::numeric(12,2) AS discount_total,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'CASH')::int AS cash_count,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'TRANSFER')::int AS transfer_count,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'MIXED')::int AS mixed_count
       FROM sales s
       WHERE s.status = 'PAID'
         AND ${saleFilter}` ,
      rangeParams
    );

    const familyDiscountsResult = await query(
      `SELECT
         COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount,
         COALESCE(SUM(u.total_after_discount), 0)::numeric(12,2) AS paid_after_discount,
         COUNT(u.id)::int AS usage_count,
         COUNT(DISTINCT u.code_id)::int AS code_count
       FROM family_discount_code_usages u
       JOIN sales s ON s.id = u.sale_id
       WHERE s.status = 'PAID'
         AND ${saleFilter}`,
      rangeParams
    );

    const familyDiscountRowsResult = await query(
      `SELECT u.id, u.discount_amount, u.discountable_amount, u.total_after_discount, u.used_at,
              c.code, c.discount_percent, c.note,
              cashier.full_name AS cashier_name,
              COALESCE(m.full_name, 'General') AS member_name
       FROM family_discount_code_usages u
       JOIN family_discount_codes c ON c.id = u.code_id
       JOIN sales s ON s.id = u.sale_id
       LEFT JOIN users cashier ON cashier.id = u.user_id
       LEFT JOIN members m ON m.id = s.member_id
       WHERE s.status = 'PAID'
         AND ${saleFilter.replaceAll('s.', 's.')}
       ORDER BY u.used_at DESC
       LIMIT 25`,
      rangeParams
    );

    const recentSalesResult = await query(
      `SELECT
         s.id,
         s.subtotal,
         s.discount_total,
         s.total,
         s.payment_method,
         s.created_at,
         u.full_name AS cashier_name,
         COALESCE(m.full_name, 'General') AS member_name,
         COALESCE(items.items, '[]'::json) AS items
       FROM sales s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN members m ON m.id = s.member_id
       LEFT JOIN LATERAL (
         SELECT json_agg(json_build_object(
           'description', si.description,
           'quantity', si.quantity,
           'total', si.total,
           'item_type', si.item_type
         ) ORDER BY si.created_at ASC, si.id ASC) AS items
         FROM sale_items si
         WHERE si.sale_id = s.id
       ) items ON true
       WHERE s.status = 'PAID'
         AND ${saleFilter}
       ORDER BY s.created_at DESC
       LIMIT 20`,
      rangeParams
    );

    const stationsResult = await query(
      `SELECT
         st.id,
         st.name,
         st.console_type,
         st.status,
         gs.id AS active_session_id,
         gs.started_at,
         gs.rate_type,
         gs.prepaid_minutes,
         gs.total_amount,
         gs.player_count,
         sg.name AS game_name,
         COALESCE(m.full_name, 'General') AS member_name,
         u.full_name AS cashier_name,
         COALESCE(account.pending_total, 0)::numeric(12,2) AS pending_total,
         COALESCE(account.paid_total, 0)::numeric(12,2) AS paid_total,
         COALESCE(account.item_count, 0)::int AS item_count
       FROM stations st
       LEFT JOIN game_sessions gs ON gs.station_id = st.id AND gs.status = 'ACTIVE'
       LEFT JOIN station_games sg ON sg.id = gs.game_id
       LEFT JOIN members m ON m.id = gs.member_id
       LEFT JOIN users u ON u.id = gs.started_by_user_id
       LEFT JOIN LATERAL (
         SELECT
           COUNT(ssi.id)::int AS item_count,
           COALESCE(SUM(CASE WHEN ssi.payment_status = 'PENDING' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS pending_total,
           COALESCE(SUM(CASE WHEN ssi.payment_status = 'PAID' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS paid_total
         FROM station_session_items ssi
         WHERE ssi.session_id = gs.id
       ) account ON true
       WHERE st.deleted_at IS NULL
       ORDER BY st.sort_order, st.name`
    );

    const drawerResult = await query(
      `WITH range_sales AS (
         SELECT
           COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
           COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales
         FROM sales s
         WHERE s.status = 'PAID'
           AND ${saleFilter}
       ), range_drawers AS (
         SELECT cd.*, ou.full_name AS opened_by_name, cu.full_name AS closed_by_name
         FROM cash_drawers cd
         LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
         LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
         WHERE ${range.isShift ? 'cd.id = $3' : 'cd.opened_at >= $1::date AND cd.opened_at < $2::date'}
       ), range_movements AS (
         SELECT
           COALESCE(SUM(CASE WHEN dm.type = 'IN' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
           COALESCE(SUM(CASE WHEN dm.type = 'OUT' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
         FROM drawer_movements dm
         JOIN range_drawers cd ON cd.id = dm.drawer_id
         WHERE ${range.isShift ? 'dm.drawer_id = $3' : drawerMovementFilter}
       )
       SELECT
         COUNT(rd.id)::int AS drawer_count,
         COUNT(*) FILTER (WHERE rd.status = 'OPEN')::int AS open_drawer_count,
         MAX(rd.id::text) FILTER (WHERE rd.status = 'OPEN') AS open_drawer_id,
         COALESCE((ARRAY_AGG(rd.opening_amount ORDER BY CASE WHEN rd.status = 'OPEN' THEN 0 ELSE 1 END, rd.opened_at DESC))[1], 0)::numeric(12,2) AS opening_amount,
         COALESCE(SUM(rd.closing_amount), 0)::numeric(12,2) AS closing_amount,
         MIN(rd.opened_at) AS opened_at,
         MAX(rd.closed_at) AS closed_at,
         MAX(rd.opened_by_name) AS opened_by_name,
         MAX(rd.closed_by_name) AS closed_by_name,
         rs.cash_sales,
         rs.transfer_sales,
         rm.drawer_in,
         rm.drawer_out,
         (COALESCE((ARRAY_AGG(rd.opening_amount ORDER BY CASE WHEN rd.status = 'OPEN' THEN 0 ELSE 1 END, rd.opened_at DESC))[1], 0) + COALESCE(rs.cash_sales, 0) + COALESCE(rm.drawer_in, 0) - COALESCE(rm.drawer_out, 0))::numeric(12,2) AS expected_cash,
         (COALESCE(rs.cash_sales, 0) + COALESCE(rm.drawer_in, 0) - COALESCE(rm.drawer_out, 0))::numeric(12,2) AS cash_to_withdraw
       FROM range_sales rs
       CROSS JOIN range_movements rm
       LEFT JOIN range_drawers rd ON true
       GROUP BY rs.cash_sales, rs.transfer_sales, rm.drawer_in, rm.drawer_out`,
      range.isShift ? [...rangeParams, range.shiftId] : rangeParams
    );

    const expensesResult = await query(
      `SELECT
         COALESCE(SUM(amount), 0)::numeric(12,2) AS total_expenses,
         COUNT(id)::int AS expense_count,
         COALESCE(SUM(CASE WHEN payment_method = 'CASH' THEN amount ELSE 0 END), 0)::numeric(12,2) AS cash_expenses,
         COALESCE(SUM(CASE WHEN payment_method = 'TRANSFER' THEN amount ELSE 0 END), 0)::numeric(12,2) AS transfer_expenses
       FROM finance_expenses
       WHERE is_active = true
         AND expense_date >= $1::date
         AND expense_date < $2::date`,
      [range.startDate, dateOnlyLocal(addDaysLocal(new Date(`${range.endDate}T00:00:00`), 1))]
    );

    const todayPaymentsResult = await query(
      `SELECT dm.id, dm.amount, dm.reason, dm.created_at, u.full_name AS user_name
       FROM drawer_movements dm
       JOIN cash_drawers cd ON cd.id = dm.drawer_id
       LEFT JOIN users u ON u.id = dm.user_id
       WHERE dm.type = 'OUT'
         AND ${range.isShift ? 'dm.drawer_id = $3' : drawerMovementFilter}
       ORDER BY dm.created_at DESC
       LIMIT 30`,
      range.isShift ? [...rangeParams, range.shiftId] : rangeParams
    );

    const gameRequestsResult = await query(
      `SELECT
         gr.id,
         gr.request_type,
         gr.request_scope,
         gr.requested_game_name,
         gr.platform,
         gr.unavailable_reason,
         gr.customer_decision,
         gr.status,
         gr.eta_text,
         gr.member_note,
         gr.admin_note,
         gr.purchase_method,
         gr.purchased_at,
         gr.reviewed_at,
         gr.created_at,
         gr.updated_at,
         sg.name AS game_name,
         st.name AS station_name,
         COALESCE(m.full_name, gr.customer_name, 'Cliente') AS customer_name,
         u.full_name AS cashier_name
       FROM game_requests gr
       LEFT JOIN station_games sg ON sg.id = gr.game_id
       LEFT JOIN stations st ON st.id = gr.station_id
       LEFT JOIN members m ON m.id = gr.member_id
       LEFT JOIN users u ON u.id = gr.cashier_id
       WHERE gr.status IN ('PENDIENTE', 'ESPERANDO', 'REVISADO', 'COMPRADO')
          OR gr.created_at >= CURRENT_DATE - INTERVAL '7 days'
       ORDER BY
         CASE gr.status
           WHEN 'PENDIENTE' THEN 1
           WHEN 'ESPERANDO' THEN 2
           WHEN 'REVISADO' THEN 3
           WHEN 'COMPRADO' THEN 4
           ELSE 9
         END,
         gr.created_at DESC
       LIMIT 30`
    );

    const activeStations = stationsResult.rows.filter((row) => row.active_session_id);
    const sales = salesResult.rows[0] || {};
    const expenses = expensesResult.rows[0] || {};
    const drawer = drawerResult.rows[0] || null;
    const drawerOutToday = toNumber(drawer?.drawer_out);
    const intelligence = await intelligencePromise;

    res.json({
      generatedAt: new Date().toISOString(),
      intelligence,
      range: {
        period: range.period,
        label: range.label,
        startDate: range.startDate,
        endDate: range.endDate,
        shiftId: range.shiftId || null,
        isShift: Boolean(range.isShift)
      },
      shifts,
      sales: {
        sale_count: toNumber(sales.sale_count),
        total_sales: toNumber(sales.total_sales),
        cash_sales: toNumber(sales.cash_sales),
        transfer_sales: toNumber(sales.transfer_sales),
        mixed_sales: toNumber(sales.mixed_sales),
        discount_total: toNumber(sales.discount_total),
        cash_count: toNumber(sales.cash_count),
        transfer_count: toNumber(sales.transfer_count),
        mixed_count: toNumber(sales.mixed_count)
      },
      familyDiscounts: {
        discount_amount: toNumber(familyDiscountsResult.rows[0]?.discount_amount),
        paid_after_discount: toNumber(familyDiscountsResult.rows[0]?.paid_after_discount),
        usage_count: toNumber(familyDiscountsResult.rows[0]?.usage_count),
        code_count: toNumber(familyDiscountsResult.rows[0]?.code_count),
        rows: familyDiscountRowsResult.rows.map((row) => ({
          ...row,
          discount_amount: toNumber(row.discount_amount),
          discountable_amount: toNumber(row.discountable_amount),
          total_after_discount: toNumber(row.total_after_discount)
        }))
      },
      expenses: {
        total_expenses: drawerOutToday || toNumber(expenses.total_expenses),
        expense_count: todayPaymentsResult.rows.length || toNumber(expenses.expense_count),
        cash_expenses: drawerOutToday || toNumber(expenses.cash_expenses),
        transfer_expenses: toNumber(expenses.transfer_expenses),
        drawer_out: drawerOutToday
      },
      payments: todayPaymentsResult.rows,
      drawer: drawer ? {
        id: drawer.id,
        status: toNumber(drawer.open_drawer_count) > 0 ? 'OPEN' : 'CLOSED',
        drawer_count: toNumber(drawer.drawer_count),
        open_drawer_count: toNumber(drawer.open_drawer_count),
        opening_amount: toNumber(drawer.opening_amount),
        closing_amount: toNumber(drawer.closing_amount),
        cash_sales: toNumber(drawer.cash_sales),
        transfer_sales: toNumber(drawer.transfer_sales),
        drawer_in: toNumber(drawer.drawer_in),
        drawer_out: toNumber(drawer.drawer_out),
        expected_cash: toNumber(drawer.expected_cash),
        cash_to_withdraw: toNumber(drawer.cash_to_withdraw),
        opened_at: drawer.opened_at,
        closed_at: drawer.closed_at,
        opened_by_name: drawer.opened_by_name,
        closed_by_name: drawer.closed_by_name
      } : null,
      stations: stationsResult.rows.map((row) => ({
        id: row.id,
        name: row.name,
        console_type: row.console_type,
        status: normalizeStationStatus(row),
        active_session_id: row.active_session_id,
        started_at: row.started_at,
        rate_type: row.rate_type,
        prepaid_minutes: row.prepaid_minutes,
        total_amount: toNumber(row.total_amount),
        player_count: row.player_count,
        game_name: row.game_name,
        member_name: row.member_name,
        cashier_name: row.cashier_name,
        pending_total: toNumber(row.pending_total),
        paid_total: toNumber(row.paid_total),
        item_count: toNumber(row.item_count)
      })),
      stationSummary: {
        total: stationsResult.rows.length,
        active: activeStations.length,
        available: stationsResult.rows.filter((row) => !row.active_session_id && row.status === 'AVAILABLE').length,
        maintenance: stationsResult.rows.filter((row) => row.status === 'MAINTENANCE').length,
        offline: stationsResult.rows.filter((row) => row.status === 'OFFLINE').length
      },
      gameRequests: gameRequestsResult.rows,
      recentSales: recentSalesResult.rows
    });
  } catch (error) {
    console.error('Owner dashboard summary error:', error.message);
    res.status(500).json({ error: 'No se pudo cargar el panel owner.', detail: error.message });
  }
}


export async function ownerDashboardUpdateGameRequest(req, res) {
  try {
    const { requestId } = req.params;
    const status = normalizeGameRequestStatus(req.body?.status);
    const adminNote = normalizeOwnerText(req.body?.adminNote, 260);
    const etaText = normalizeOwnerText(req.body?.etaText, 80);
    const purchaseMethodInput = String(req.body?.purchaseMethod || '').trim().toUpperCase();
    const purchaseMethod = ['DIGITAL', 'FISICO', 'PENDIENTE'].includes(purchaseMethodInput) ? purchaseMethodInput : null;

    if (!status) return res.status(400).json({ error: 'Estado inválido para solicitud.' });

    const { rows } = await query(
      `UPDATE game_requests
       SET status = $2,
           admin_note = COALESCE($3::text, admin_note),
           eta_text = CASE WHEN $4::text IS NULL THEN eta_text ELSE $4::text END,
           purchase_method = CASE WHEN $2 = 'COMPRADO' THEN COALESCE($5::text, purchase_method, 'PENDIENTE') ELSE purchase_method END,
           purchased_at = CASE WHEN $2 = 'COMPRADO' THEN COALESCE(purchased_at, NOW()) ELSE purchased_at END,
           reviewed_at = CASE WHEN $2 IN ('REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO') THEN COALESCE(reviewed_at, NOW()) ELSE reviewed_at END,
           updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [requestId, status, adminNote, etaText, purchaseMethod]
    );

    if (!rows[0]) return res.status(404).json({ error: 'Solicitud no encontrada.' });
    res.json({ request: rows[0] });
  } catch (error) {
    console.error('Owner dashboard update game request error:', error.message);
    res.status(500).json({ error: 'No se pudo actualizar la solicitud.' });
  }
}

export async function ownerDashboardGrowthAdvisor(_req, res) {
  try {
    res.json(await buildGrowthAdvisor());
  } catch (error) {
    console.error('Owner dashboard growth advisor error:', error.message);
    res.status(500).json({ error: 'No se pudo calcular el asesor de crecimiento.', detail: error.message });
  }
}

export async function ownerDashboardSaveGrowthAdvisor(req, res) {
  try {
    const settings = await saveGrowthAdvisorSettings(req.body || {}, req.ownerUser?.id || null);
    res.json({ settings, advisor: await buildGrowthAdvisor() });
  } catch (error) {
    console.error('Owner dashboard save growth advisor error:', error.message);
    res.status(500).json({ error: 'No se pudo guardar la configuración del asesor.' });
  }
}
