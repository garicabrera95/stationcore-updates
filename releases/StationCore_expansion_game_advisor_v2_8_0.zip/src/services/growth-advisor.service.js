const SETTINGS_KEY = 'growth_advisor_v1';
const DAY_MS = 24 * 60 * 60 * 1000;
let defaultQueryFunction = null;

async function resolveQueryFunction(queryFn) {
  if (typeof queryFn === 'function') return queryFn;
  if (!defaultQueryFunction) {
    const database = await import('../db/pool.js');
    defaultQueryFunction = database.query;
  }
  return defaultQueryFunction;
}

const DEFAULT_CONSOLES = [
  { id: 'ps4', name: 'PlayStation 4', family: 'PS4', purchaseCost: 0, setupCost: 0, active: true },
  { id: 'ps5', name: 'PlayStation 5', family: 'PS5', purchaseCost: 0, setupCost: 0, active: true },
  { id: 'switch', name: 'Nintendo Switch', family: 'SWITCH', purchaseCost: 0, setupCost: 0, active: true },
  { id: 'switch-2', name: 'Nintendo Switch 2', family: 'SWITCH2', purchaseCost: 0, setupCost: 0, active: true },
  { id: 'xbox-one', name: 'Xbox One', family: 'XBOX_ONE', purchaseCost: 0, setupCost: 0, active: true },
  { id: 'xbox-series-s', name: 'Xbox Series S', family: 'XBOX_SERIES', purchaseCost: 0, setupCost: 0, active: true }
];

function numberBetween(value, min, max, fallback = 0) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function cleanText(value, max = 100) {
  return String(value || '').trim().slice(0, max);
}

function safeId(value, fallback = '') {
  const normalized = cleanText(value, 60).toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
  return normalized || fallback;
}

function validDateOnly(value) {
  const text = cleanText(value, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : '';
}

function dateOnlyValue(value) {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) return value.slice(0, 10);
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${date.getFullYear()}-${month}-${day}`;
}

function normalizeFamily(value, name = '') {
  const explicit = cleanText(value, 30).toUpperCase();
  if (['PS4', 'PS5', 'SWITCH', 'SWITCH2', 'XBOX_ONE', 'XBOX_SERIES', 'OTHER'].includes(explicit)) return explicit;
  return platformFamily(name);
}

function normalizeConsoleCandidate(row = {}, index = 0) {
  const name = cleanText(row.name, 80) || `Consola candidata ${index + 1}`;
  return {
    id: safeId(row.id, `console-${index + 1}`),
    name,
    family: normalizeFamily(row.family, name),
    purchaseCost: numberBetween(row.purchaseCost, 0, 1000000),
    setupCost: numberBetween(row.setupCost, 0, 1000000),
    active: row.active !== false
  };
}

function normalizeInvestment(row = {}, index = 0) {
  const gameId = cleanText(row.gameId, 80);
  const gameName = cleanText(row.gameName, 120);
  const purchasedAt = validDateOnly(row.purchasedAt);
  if (!gameId || !gameName || !purchasedAt) return null;
  return {
    id: safeId(row.id, `game-${index + 1}`),
    gameId,
    gameName,
    platform: cleanText(row.platform, 80),
    purchasedAt,
    purchaseCost: numberBetween(row.purchaseCost, 0, 1000000)
  };
}

export function normalizeGrowthAdvisorSettings(value = {}) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const candidatesInput = Array.isArray(source.consoleCandidates) ? source.consoleCandidates.slice(0, 20) : DEFAULT_CONSOLES;
  const consoleCandidates = candidatesInput.map(normalizeConsoleCandidate);
  const investments = (Array.isArray(source.gameInvestments) ? source.gameInvestments : [])
    .slice(0, 40)
    .map(normalizeInvestment)
    .filter(Boolean);
  return {
    availableSpaces: Math.round(numberBetween(source.availableSpaces, 0, 20)),
    availableTvs: Math.round(numberBetween(source.availableTvs, 0, 20)),
    tvCost: numberBetween(source.tvCost, 0, 1000000),
    targetPaybackMonths: Math.round(numberBetween(source.targetPaybackMonths, 1, 36, 9)),
    consoleCandidates: consoleCandidates.length ? consoleCandidates : DEFAULT_CONSOLES.map(normalizeConsoleCandidate),
    gameInvestments: investments
  };
}

export async function loadGrowthAdvisorSettings(queryFn) {
  queryFn = await resolveQueryFunction(queryFn);
  const { rows } = await queryFn(`SELECT value FROM app_settings WHERE key = $1 LIMIT 1`, [SETTINGS_KEY]);
  return normalizeGrowthAdvisorSettings(rows[0]?.value || {});
}

export async function saveGrowthAdvisorSettings(value, userId = null, queryFn) {
  queryFn = await resolveQueryFunction(queryFn);
  const settings = normalizeGrowthAdvisorSettings(value);
  await queryFn(
    `INSERT INTO app_settings (key, value, updated_by_user_id, updated_at)
     VALUES ($1, $2::jsonb, $3, NOW())
     ON CONFLICT (key) DO UPDATE
       SET value = EXCLUDED.value,
           updated_by_user_id = EXCLUDED.updated_by_user_id,
           updated_at = NOW()`,
    [SETTINGS_KEY, JSON.stringify(settings), userId || null]
  );
  return settings;
}

export function platformFamily(value = '') {
  const normalized = String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  if (/switch\s*2|nintendo\s*2/.test(normalized)) return 'SWITCH2';
  if (/switch|nintendo/.test(normalized)) return 'SWITCH';
  if (/playstation\s*5|\bps\s*5\b|\bps5\b/.test(normalized)) return 'PS5';
  if (/playstation\s*4|\bps\s*4\b|\bps4\b/.test(normalized)) return 'PS4';
  if (/series\s*[sx]|xbox\s*series/.test(normalized)) return 'XBOX_SERIES';
  if (/xbox\s*one/.test(normalized)) return 'XBOX_ONE';
  if (/playstation/.test(normalized)) return 'PLAYSTATION';
  if (/xbox/.test(normalized)) return 'XBOX';
  return normalized ? `OTHER:${normalized.slice(0, 40)}` : 'UNSPECIFIED';
}

function sumRowsByFamily(rows = [], family, fields = []) {
  return rows.reduce((totals, row) => {
    const rowFamily = platformFamily(row.console_type || row.platform);
    const genericMatch = (family === 'PS4' || family === 'PS5') && rowFamily === 'PLAYSTATION'
      || (family === 'XBOX_ONE' || family === 'XBOX_SERIES') && rowFamily === 'XBOX';
    if (rowFamily !== family && !genericMatch) return totals;
    fields.forEach((field) => { totals[field] = Number(totals[field] || 0) + Number(row[field] || 0); });
    return totals;
  }, Object.fromEntries(fields.map((field) => [field, 0])));
}

function peakRowsByFamily(rows = [], family) {
  return rows.reduce((totals, row) => {
    const rowFamily = platformFamily(row.console_type || row.platform);
    const genericMatch = (family === 'PS4' || family === 'PS5') && rowFamily === 'PLAYSTATION'
      || (family === 'XBOX_ONE' || family === 'XBOX_SERIES') && rowFamily === 'XBOX';
    if (rowFamily !== family && !genericMatch) return totals;
    totals.open_hours = Math.max(totals.open_hours, Number(row.open_hours || 0));
    totals.saturated_hours = Math.max(totals.saturated_hours, Number(row.saturated_hours || 0));
    totals.peak_utilization_percent = Math.max(totals.peak_utilization_percent, Number(row.peak_utilization_percent || 0));
    return totals;
  }, { open_hours: 0, saturated_hours: 0, peak_utilization_percent: 0 });
}

function ratioScore(value, maxValue) {
  return maxValue > 0 ? Math.min(100, Math.max(0, Number(value || 0) * 100 / maxValue)) : 0;
}

function round(value, decimals = 1) {
  const factor = 10 ** decimals;
  return Math.round(Number(value || 0) * factor) / factor;
}

function buildConsoleRecommendations(settings, metricsRows, peakRows, requestRows, daysObserved) {
  const activeCandidates = settings.consoleCandidates.filter((candidate) => candidate.active !== false);
  const enriched = activeCandidates.map((candidate) => {
    const metrics = sumRowsByFamily(metricsRows, candidate.family, [
      'station_count', 'session_count', 'occupied_minutes', 'game_revenue', 'open_minutes', 'average_session_minutes'
    ]);
    const peaks = peakRowsByFamily(peakRows, candidate.family);
    const requests = sumRowsByFamily(requestRows, candidate.family, ['request_count', 'lost_count', 'waited_count', 'new_game_count']);
    const stationCount = metrics.station_count;
    const utilizationPercent = metrics.open_minutes > 0 ? Math.min(100, metrics.occupied_minutes * 100 / metrics.open_minutes) : 0;
    const monthlyRevenuePerStation = stationCount > 0 && daysObserved > 0
      ? (metrics.game_revenue / stationCount) * (30 / daysObserved)
      : 0;
    return {
      ...candidate,
      stationCount,
      sessionCount: metrics.session_count,
      utilizationPercent,
      peakUtilizationPercent: Math.min(100, peaks.peak_utilization_percent),
      saturatedHours: peaks.saturated_hours,
      openHours: peaks.open_hours,
      requestCount: requests.request_count,
      lostCount: requests.lost_count,
      waitedCount: requests.waited_count,
      newGameRequests: requests.new_game_count,
      gameRevenue: metrics.game_revenue,
      monthlyRevenuePerStation,
      averageSessionMinutes: stationCount > 0 ? metrics.average_session_minutes / stationCount : metrics.average_session_minutes
    };
  });

  const maxima = {
    requests: Math.max(1, ...enriched.map((row) => row.requestCount)),
    lost: Math.max(1, ...enriched.map((row) => row.lostCount)),
    revenue: Math.max(1, ...enriched.map((row) => row.monthlyRevenuePerStation))
  };

  return enriched.map((row) => {
    const utilizationScore = Math.min(100, row.peakUtilizationPercent * 1.2);
    const saturationScore = Math.min(100, row.saturatedHours * 12.5);
    const requestScore = ratioScore(row.requestCount, maxima.requests);
    const lostScore = ratioScore(row.lostCount, maxima.lost);
    const revenueScore = ratioScore(row.monthlyRevenuePerStation, maxima.revenue);
    const demandFactor = Math.min(1, Math.max(.12,
      (row.peakUtilizationPercent / 100) * .72
      + Math.min(.20, row.lostCount * .06)
      + Math.min(.12, row.requestCount * .025)
    ));
    const estimatedMonthlyRevenue = row.monthlyRevenuePerStation > 0
      ? row.monthlyRevenuePerStation * demandFactor
      : 0;
    const investment = Number(row.purchaseCost || 0) + Number(row.setupCost || 0)
      + (settings.availableTvs > 0 ? 0 : Number(settings.tvCost || 0));
    const paybackMonths = investment > 0 && estimatedMonthlyRevenue > 0 ? investment / estimatedMonthlyRevenue : null;
    const recoveryScore = paybackMonths == null
      ? 30
      : Math.min(100, settings.targetPaybackMonths * 100 / Math.max(.25, paybackMonths));
    const score = round(
      utilizationScore * .28
      + saturationScore * .17
      + requestScore * .18
      + lostScore * .17
      + revenueScore * .10
      + recoveryScore * .10
    );
    const hasEvidence = row.sessionCount >= 8 || row.requestCount >= 2 || row.lostCount >= 1;
    let status = 'NO_AUN';
    if (!hasEvidence) status = 'SIN_DATOS';
    else if (score >= 68 && (row.peakUtilizationPercent >= 70 || row.lostCount >= 2)) status = 'HACE_FALTA';
    else if (score >= 43 || row.peakUtilizationPercent >= 60 || row.requestCount >= 2) status = 'OBSERVAR';
    const reasons = [];
    if (row.stationCount > 0) reasons.push(`${row.stationCount} estación(es) actuales · pico ${round(row.peakUtilizationPercent, 0)}%`);
    else reasons.push('No existe una estación de este tipo actualmente');
    if (row.saturatedHours > 0) reasons.push(`${row.saturatedHours} hora(s) con 70% o más de ocupación`);
    if (row.requestCount > 0) reasons.push(`${row.requestCount} solicitud(es), ${row.lostCount} no atendida(s)`);
    if (row.monthlyRevenuePerStation > 0) reasons.push(`Referencia mensual por estación ${round(row.monthlyRevenuePerStation, 0)}`);
    if (paybackMonths != null) reasons.push(`Recuperación estimada en ${round(paybackMonths, 1)} meses`);
    if (!hasEvidence) reasons.push('Todavía no hay suficiente uso o solicitudes para justificar la compra');
    return {
      ...row,
      score,
      status,
      estimatedMonthlyRevenue: round(estimatedMonthlyRevenue, 2),
      investment: round(investment, 2),
      paybackMonths: paybackMonths == null ? null : round(paybackMonths, 1),
      meetsPaybackTarget: paybackMonths != null && paybackMonths <= settings.targetPaybackMonths,
      reasons
    };
  }).sort((a, b) => b.score - a.score || b.requestCount - a.requestCount || a.name.localeCompare(b.name));
}

function gameRequestKey(name = '', platform = '') {
  return `${String(name || '').trim().toLowerCase()}|${platformFamily(platform)}`;
}

function buildGameRecommendations(requestRows, affinityRows) {
  const affinityByRequest = new Map();
  affinityRows.forEach((row) => {
    const key = gameRequestKey(row.requested_game_name, row.platform);
    if (!affinityByRequest.has(key)) affinityByRequest.set(key, []);
    affinityByRequest.get(key).push({
      gameName: row.favorite_game_name,
      playerCount: Number(row.player_count || 0),
      minutes: Number(row.played_minutes || 0)
    });
  });
  const maxRequests = Math.max(1, ...requestRows.map((row) => Number(row.request_count || 0)));
  const maxLost = Math.max(1, ...requestRows.map((row) => Number(row.left_count || 0)));
  const maxMembers = Math.max(1, ...requestRows.map((row) => Number(row.member_count || 0)));

  return requestRows.map((row) => {
    const key = gameRequestKey(row.requested_game_name, row.platform);
    const affinities = (affinityByRequest.get(key) || []).sort((a, b) => b.playerCount - a.playerCount || b.minutes - a.minutes);
    const requestCount = Number(row.request_count || 0);
    const leftCount = Number(row.left_count || 0);
    const memberCount = Number(row.member_count || 0);
    const affinityPlayers = Math.max(0, ...affinities.map((item) => item.playerCount));
    const score = round(
      ratioScore(requestCount, maxRequests) * .45
      + ratioScore(leftCount, maxLost) * .20
      + ratioScore(memberCount, maxMembers) * .15
      + Math.min(100, affinityPlayers * 25) * .20
    );
    let status = 'OBSERVAR';
    if (requestCount >= 3 || leftCount >= 2) status = 'PROBAR_COMPRA';
    else if (requestCount >= 2 || (requestCount >= 1 && memberCount >= 1)) status = 'EVALUAR';
    return {
      gameName: row.requested_game_name,
      platform: row.platform || 'Sin plataforma',
      requestCount,
      memberCount,
      leftCount,
      waitedCount: Number(row.waited_count || 0),
      lastRequestedAt: row.last_requested_at,
      score,
      status,
      affinities: affinities.slice(0, 3),
      confidence: requestCount >= 4 || memberCount >= 3 ? 'ALTA' : requestCount >= 2 || memberCount >= 1 ? 'MEDIA' : 'INICIAL'
    };
  }).sort((a, b) => b.score - a.score || b.requestCount - a.requestCount || a.gameName.localeCompare(b.gameName));
}

function buildGameTrends(rows) {
  return rows.map((row) => {
    const currentSessions = Number(row.current_sessions || 0);
    const previousSessions = Number(row.previous_sessions || 0);
    const trendPercent = previousSessions > 0 ? (currentSessions - previousSessions) * 100 / previousSessions : currentSessions > 0 ? 100 : 0;
    return {
      gameId: row.id,
      gameName: row.name,
      platform: row.platform,
      compatibleConsoles: row.compatible_consoles || [],
      isStoryMode: row.is_story_mode === true,
      allowsExtraControllers: row.allows_extra_controllers === true,
      currentSessions,
      previousSessions,
      currentMinutes: Number(row.current_minutes || 0),
      previousMinutes: Number(row.previous_minutes || 0),
      memberCount: Number(row.member_count || 0),
      trendPercent: round(trendPercent),
      fatigueRisk: previousSessions >= 5 && currentSessions <= previousSessions * .7
    };
  }).sort((a, b) => b.currentMinutes - a.currentMinutes || b.currentSessions - a.currentSessions);
}

function buildTasteProfile(gameTrends) {
  const active = gameTrends.filter((row) => row.currentMinutes > 0);
  if (!active.length) return null;
  const leading = active[0];
  const localMinutes = active.filter((row) => row.allowsExtraControllers).reduce((total, row) => total + row.currentMinutes, 0);
  const storyMinutes = active.filter((row) => row.isStoryMode).reduce((total, row) => total + row.currentMinutes, 0);
  const platformMinutes = new Map();
  active.forEach((row) => platformMinutes.set(row.platform || 'Sin plataforma', (platformMinutes.get(row.platform || 'Sin plataforma') || 0) + row.currentMinutes));
  const preferredPlatform = [...platformMinutes.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || leading.platform;
  let experience = 'VARIEDAD';
  let label = `Novedades para ${preferredPlatform}`;
  if (localMinutes >= storyMinutes && localMinutes >= leading.currentMinutes * .5) {
    experience = 'MULTIJUGADOR_LOCAL';
    label = `Multijugador local para ${preferredPlatform}`;
  } else if (storyMinutes > localMinutes && storyMinutes >= leading.currentMinutes * .5) {
    experience = 'HISTORIA_PROGRESO';
    label = `Historia y progreso para ${preferredPlatform}`;
  }
  return {
    experience,
    label,
    preferredPlatform,
    leadingGame: leading.gameName,
    leadingMinutes: leading.currentMinutes,
    explanation: `${leading.gameName} lidera el uso reciente. Este perfil orienta qué tipo de novedad conviene buscar, pero una solicitud concreta aporta más confianza.`
  };
}

function dateInWindow(value, start, end) {
  const dateText = dateOnlyValue(value);
  const timestamp = new Date(`${dateText}T12:00:00`).getTime();
  return timestamp >= start.getTime() && timestamp < end.getTime();
}

function buildInvestmentOutcomes(settings, purchaseRows, gameDailyRows, now) {
  const configured = settings.gameInvestments.map((row) => ({ ...row, source: 'OWNER' }));
  const configuredKeys = new Set(configured.map((row) => row.gameId));
  const automatic = purchaseRows
    .filter((row) => row.game_id && !configuredKeys.has(String(row.game_id)))
    .map((row, index) => ({
      id: `request-${index}-${String(row.game_id).slice(0, 8)}`,
      gameId: String(row.game_id),
      gameName: row.game_name,
      platform: row.platform || '',
      purchasedAt: dateOnlyValue(row.purchased_at),
      purchaseCost: 0,
      source: 'REQUEST'
    }));
  const rowsByGame = new Map();
  gameDailyRows.forEach((row) => {
    const key = String(row.game_id);
    if (!rowsByGame.has(key)) rowsByGame.set(key, []);
    rowsByGame.get(key).push(row);
  });

  return [...configured, ...automatic].map((investment) => {
    const purchaseDate = new Date(`${investment.purchasedAt}T00:00:00`);
    const beforeStart = new Date(purchaseDate.getTime() - 30 * DAY_MS);
    const afterEndNatural = new Date(purchaseDate.getTime() + 30 * DAY_MS);
    const afterEnd = new Date(Math.min(afterEndNatural.getTime(), now.getTime()));
    const observedDays = Math.max(0, Math.min(30, Math.ceil((afterEnd.getTime() - purchaseDate.getTime()) / DAY_MS)));
    const gameRows = rowsByGame.get(String(investment.gameId)) || [];
    const before = gameRows.filter((row) => dateInWindow(row.play_date, beforeStart, purchaseDate));
    const after = gameRows.filter((row) => dateInWindow(row.play_date, purchaseDate, afterEnd));
    const sum = (items, field) => items.reduce((total, item) => total + Number(item[field] || 0), 0);
    const beforeSessions = sum(before, 'session_count');
    const afterSessions = sum(after, 'session_count');
    const beforeRevenue = sum(before, 'game_revenue');
    const afterRevenue = sum(after, 'game_revenue');
    const normalizedBeforeSessions = beforeSessions * observedDays / 30;
    const normalizedBeforeRevenue = beforeRevenue * observedDays / 30;
    const sessionLift = normalizedBeforeSessions > 0
      ? (afterSessions - normalizedBeforeSessions) * 100 / normalizedBeforeSessions
      : afterSessions > 0 ? 100 : 0;
    const monthlyIncrementalRevenue = observedDays >= 7
      ? Math.max(0, (afterRevenue - normalizedBeforeRevenue) * 30 / observedDays)
      : 0;
    let result = 'MUY_PRONTO';
    if (observedDays >= 14) {
      if (afterSessions >= Math.max(3, normalizedBeforeSessions * 1.25)) result = 'BUEN_RESULTADO';
      else if (afterSessions > normalizedBeforeSessions) result = 'RESULTADO_MODERADO';
      else result = 'SIN_IMPULSO';
    }
    return {
      ...investment,
      observedDays,
      beforeSessions: round(normalizedBeforeSessions),
      afterSessions,
      beforeRevenue: round(normalizedBeforeRevenue, 2),
      afterRevenue: round(afterRevenue, 2),
      sessionLiftPercent: round(sessionLift),
      monthlyIncrementalRevenue: round(monthlyIncrementalRevenue, 2),
      paybackMonths: Number(investment.purchaseCost || 0) > 0 && monthlyIncrementalRevenue > 0
        ? round(Number(investment.purchaseCost) / monthlyIncrementalRevenue, 1)
        : null,
      result
    };
  }).sort((a, b) => String(b.purchasedAt).localeCompare(String(a.purchasedAt)));
}

export async function buildGrowthAdvisor(queryFn) {
  queryFn = await resolveQueryFunction(queryFn);
  const settings = await loadGrowthAdvisorSettings(queryFn);
  const now = new Date();
  const analysisStart = new Date(now.getTime() - 56 * DAY_MS);
  const requestStart = new Date(now.getTime() - 120 * DAY_MS);
  const trendStart = new Date(now.getTime() - 60 * DAY_MS);
  const currentTrendStart = new Date(now.getTime() - 30 * DAY_MS);
  const dailyStart = new Date(now.getTime() - 365 * DAY_MS);

  const [metricsResult, peakResult, requestsByPlatformResult, gameTrendResult, gameRequestsResult, affinityResult, purchaseResult, gameDailyResult, catalogResult] = await Promise.all([
    queryFn(
      `WITH drawer_capacity AS (
         SELECT COALESCE(SUM(GREATEST(0, EXTRACT(EPOCH FROM (
           LEAST(COALESCE(cd.closed_at, $2::timestamptz), $2::timestamptz)
           - GREATEST(cd.opened_at, $1::timestamptz)
         )) / 60.0)), 0)::numeric AS open_minutes
         FROM cash_drawers cd
         WHERE cd.opened_at < $2::timestamptz
           AND COALESCE(cd.closed_at, $2::timestamptz) > $1::timestamptz
       ), station_counts AS (
         SELECT console_type, COUNT(*)::int AS station_count
         FROM stations WHERE deleted_at IS NULL GROUP BY console_type
       ), sessions AS (
         SELECT st.console_type,
                COUNT(gs.id)::int AS session_count,
                COALESCE(SUM(GREATEST(0, EXTRACT(EPOCH FROM (
                  LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz)
                  - GREATEST(gs.started_at, $1::timestamptz)
                )) / 60.0)), 0)::numeric AS occupied_minutes,
                COALESCE(AVG(NULLIF(gs.total_minutes, 0)), 0)::numeric AS average_session_minutes
         FROM stations st
         LEFT JOIN game_sessions gs ON gs.station_id = st.id
          AND gs.status <> 'VOID' AND gs.started_at < $2::timestamptz
          AND COALESCE(gs.ended_at, $2::timestamptz) > $1::timestamptz
         WHERE st.deleted_at IS NULL
         GROUP BY st.console_type
       ), revenue AS (
         SELECT st.console_type, COALESCE(SUM(ssi.total), 0)::numeric AS game_revenue
         FROM station_session_items ssi
         JOIN game_sessions gs ON gs.id = ssi.session_id
         JOIN stations st ON st.id = gs.station_id
         JOIN sales s ON s.id = ssi.sale_id
         WHERE ssi.line_type = 'GAME_TIME' AND s.status = 'PAID'
           AND s.created_at >= $1::timestamptz AND s.created_at < $2::timestamptz
           AND st.deleted_at IS NULL
         GROUP BY st.console_type
       )
       SELECT sc.console_type, sc.station_count, ses.session_count, ses.occupied_minutes,
              COALESCE(rev.game_revenue, 0)::numeric AS game_revenue,
              (dc.open_minutes * sc.station_count)::numeric AS open_minutes,
              ses.average_session_minutes
       FROM station_counts sc CROSS JOIN drawer_capacity dc
       LEFT JOIN sessions ses ON ses.console_type = sc.console_type
       LEFT JOIN revenue rev ON rev.console_type = sc.console_type`,
      [analysisStart, now]
    ),
    queryFn(
      `WITH drawer_bounds AS (
         SELECT GREATEST(cd.opened_at, $1::timestamptz) AS open_at,
                LEAST(COALESCE(cd.closed_at, $2::timestamptz), $2::timestamptz) AS close_at
         FROM cash_drawers cd
         WHERE cd.opened_at < $2::timestamptz AND COALESCE(cd.closed_at, $2::timestamptz) > $1::timestamptz
       ), open_slots AS (
         SELECT DISTINCT slot
         FROM drawer_bounds db
         CROSS JOIN LATERAL generate_series(date_trunc('hour', db.open_at), date_trunc('hour', db.close_at), INTERVAL '1 hour') slot
         WHERE slot < db.close_at
       ), station_counts AS (
         SELECT console_type, COUNT(*)::int AS station_count
         FROM stations WHERE deleted_at IS NULL GROUP BY console_type
       ), session_slots AS (
         SELECT st.console_type, slot,
                SUM(GREATEST(0, EXTRACT(EPOCH FROM (
                  LEAST(COALESCE(gs.ended_at, $2::timestamptz), slot + INTERVAL '1 hour', $2::timestamptz)
                  - GREATEST(gs.started_at, slot, $1::timestamptz)
                )) / 60.0))::numeric AS occupied_minutes
         FROM game_sessions gs
         JOIN stations st ON st.id = gs.station_id
         CROSS JOIN LATERAL generate_series(date_trunc('hour', GREATEST(gs.started_at, $1::timestamptz)), date_trunc('hour', LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz)), INTERVAL '1 hour') slot
         WHERE gs.status <> 'VOID' AND st.deleted_at IS NULL
           AND gs.started_at < $2::timestamptz AND COALESCE(gs.ended_at, $2::timestamptz) > $1::timestamptz
           AND slot < LEAST(COALESCE(gs.ended_at, $2::timestamptz), $2::timestamptz)
         GROUP BY st.console_type, slot
       ), hourly AS (
         SELECT sc.console_type, os.slot, sc.station_count,
                COALESCE(ss.occupied_minutes, 0)::numeric AS occupied_minutes,
                LEAST(100, COALESCE(ss.occupied_minutes, 0) * 100.0 / NULLIF(sc.station_count * 60, 0))::numeric AS utilization
         FROM station_counts sc CROSS JOIN open_slots os
         LEFT JOIN session_slots ss ON ss.console_type = sc.console_type AND ss.slot = os.slot
       )
       SELECT console_type, COUNT(*)::int AS open_hours,
              COUNT(*) FILTER (WHERE utilization >= 70)::int AS saturated_hours,
              COALESCE(MAX(utilization), 0)::numeric AS peak_utilization_percent
       FROM hourly GROUP BY console_type`,
      [analysisStart, now]
    ),
    queryFn(
      `SELECT COALESCE(gr.platform, sg.platform, 'Sin plataforma') AS platform,
              COUNT(gr.id)::int AS request_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE')::int AS lost_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ESPERA')::int AS waited_count,
              COUNT(gr.id) FILTER (WHERE gr.request_type = 'NEW_GAME')::int AS new_game_count
       FROM game_requests gr LEFT JOIN station_games sg ON sg.id = gr.game_id
       WHERE gr.created_at >= $1::timestamptz AND gr.created_at < $2::timestamptz
       GROUP BY COALESCE(gr.platform, sg.platform, 'Sin plataforma')`,
      [analysisStart, now]
    ),
    queryFn(
      `SELECT sg.id, sg.name, sg.platform, sg.compatible_consoles, sg.is_story_mode, sg.allows_extra_controllers,
              COUNT(gs.id) FILTER (WHERE gs.started_at >= $2::timestamptz)::int AS current_sessions,
              COUNT(gs.id) FILTER (WHERE gs.started_at >= $1::timestamptz AND gs.started_at < $2::timestamptz)::int AS previous_sessions,
              COALESCE(SUM(gs.total_minutes) FILTER (WHERE gs.started_at >= $2::timestamptz), 0)::numeric AS current_minutes,
              COALESCE(SUM(gs.total_minutes) FILTER (WHERE gs.started_at >= $1::timestamptz AND gs.started_at < $2::timestamptz), 0)::numeric AS previous_minutes,
              COUNT(DISTINCT gs.member_id) FILTER (WHERE gs.started_at >= $2::timestamptz AND gs.member_id IS NOT NULL)::int AS member_count
       FROM station_games sg
       LEFT JOIN game_sessions gs ON gs.game_id = sg.id AND gs.status <> 'VOID' AND gs.started_at >= $1::timestamptz AND gs.started_at < $3::timestamptz
       WHERE sg.is_active = true
       GROUP BY sg.id, sg.name, sg.platform, sg.compatible_consoles, sg.is_story_mode, sg.allows_extra_controllers
       HAVING COUNT(gs.id) > 0
       ORDER BY current_minutes DESC, current_sessions DESC`,
      [trendStart, currentTrendStart, now]
    ),
    queryFn(
      `SELECT MIN(COALESCE(NULLIF(TRIM(gr.requested_game_name), ''), 'Juego sin nombre')) AS requested_game_name,
              MIN(COALESCE(NULLIF(TRIM(gr.platform), ''), 'Sin plataforma')) AS platform,
              COUNT(gr.id)::int AS request_count,
              COUNT(DISTINCT gr.member_id) FILTER (WHERE gr.member_id IS NOT NULL)::int AS member_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE')::int AS left_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ESPERA')::int AS waited_count,
              MAX(gr.created_at) AS last_requested_at
       FROM game_requests gr
       WHERE gr.request_type = 'NEW_GAME' AND gr.created_at >= $1::timestamptz AND gr.created_at < $2::timestamptz
         AND gr.status NOT IN ('COMPRADO', 'DESCARTADO', 'CONVERTIDO')
       GROUP BY LOWER(COALESCE(NULLIF(TRIM(gr.requested_game_name), ''), 'Juego sin nombre')),
                LOWER(COALESCE(NULLIF(TRIM(gr.platform), ''), 'Sin plataforma'))
       ORDER BY request_count DESC, left_count DESC LIMIT 30`,
      [requestStart, now]
    ),
    queryFn(
      `WITH requested_members AS (
         SELECT
           LOWER(COALESCE(NULLIF(TRIM(gr.requested_game_name), ''), 'Juego sin nombre')) AS request_key,
           LOWER(COALESCE(NULLIF(TRIM(gr.platform), ''), 'Sin plataforma')) AS platform_key,
           MIN(COALESCE(NULLIF(TRIM(gr.requested_game_name), ''), 'Juego sin nombre')) AS requested_game_name,
           MIN(COALESCE(NULLIF(TRIM(gr.platform), ''), 'Sin plataforma')) AS platform,
           gr.member_id
         FROM game_requests gr
         WHERE gr.request_type = 'NEW_GAME' AND gr.member_id IS NOT NULL
           AND gr.created_at >= $1::timestamptz AND gr.created_at < $2::timestamptz
           AND gr.status NOT IN ('COMPRADO', 'DESCARTADO', 'CONVERTIDO')
         GROUP BY LOWER(COALESCE(NULLIF(TRIM(gr.requested_game_name), ''), 'Juego sin nombre')),
                  LOWER(COALESCE(NULLIF(TRIM(gr.platform), ''), 'Sin plataforma')), gr.member_id
       )
       SELECT MIN(rm.requested_game_name) AS requested_game_name,
              MIN(rm.platform) AS platform,
              sg.name AS favorite_game_name,
              COUNT(DISTINCT rm.member_id)::int AS player_count,
              COALESCE(SUM(gs.total_minutes), 0)::numeric AS played_minutes
       FROM requested_members rm
       JOIN game_sessions gs ON gs.member_id = rm.member_id AND gs.status <> 'VOID'
        AND gs.started_at >= $1::timestamptz AND gs.started_at < $2::timestamptz
       JOIN station_games sg ON sg.id = gs.game_id
       GROUP BY rm.request_key, rm.platform_key, sg.name
       ORDER BY player_count DESC, played_minutes DESC`,
      [requestStart, now]
    ),
    queryFn(
      `SELECT DISTINCT ON (COALESCE(gr.game_id::text, LOWER(gr.requested_game_name)))
              COALESCE(gr.game_id, sg.id) AS game_id,
              COALESCE(sg.name, gr.requested_game_name, 'Juego comprado') AS game_name,
              COALESCE(sg.platform, gr.platform, '') AS platform,
              gr.purchased_at
       FROM game_requests gr
       LEFT JOIN station_games sg ON sg.id = gr.game_id OR (gr.game_id IS NULL AND LOWER(sg.name) = LOWER(gr.requested_game_name))
       WHERE gr.status = 'COMPRADO' AND gr.purchased_at IS NOT NULL
       ORDER BY COALESCE(gr.game_id::text, LOWER(gr.requested_game_name)), gr.purchased_at DESC`,
      []
    ),
    queryFn(
      `WITH revenue_by_session AS (
         SELECT ssi.session_id, COALESCE(SUM(ssi.total), 0)::numeric AS game_revenue
         FROM station_session_items ssi JOIN sales s ON s.id = ssi.sale_id
         WHERE ssi.line_type = 'GAME_TIME' AND s.status = 'PAID'
         GROUP BY ssi.session_id
       )
       SELECT gs.game_id, gs.started_at::date AS play_date, COUNT(gs.id)::int AS session_count,
              COALESCE(SUM(gs.total_minutes), 0)::numeric AS played_minutes,
              COALESCE(SUM(rbs.game_revenue), 0)::numeric AS game_revenue
       FROM game_sessions gs LEFT JOIN revenue_by_session rbs ON rbs.session_id = gs.id
       WHERE gs.status <> 'VOID' AND gs.game_id IS NOT NULL
         AND gs.started_at >= $1::timestamptz AND gs.started_at < $2::timestamptz
       GROUP BY gs.game_id, gs.started_at::date`,
      [dailyStart, now]
    ),
    queryFn(
      `SELECT id, name, platform, compatible_consoles FROM station_games WHERE is_active = true ORDER BY name`,
      []
    )
  ]);

  const daysObserved = Math.max(1, (now.getTime() - analysisStart.getTime()) / DAY_MS);
  const consoleRecommendations = buildConsoleRecommendations(
    settings,
    metricsResult.rows,
    peakResult.rows,
    requestsByPlatformResult.rows,
    daysObserved
  );
  const gameRecommendations = buildGameRecommendations(gameRequestsResult.rows, affinityResult.rows);
  const gameTrends = buildGameTrends(gameTrendResult.rows);
  const tasteProfile = buildTasteProfile(gameTrends);
  const investmentOutcomes = buildInvestmentOutcomes(settings, purchaseResult.rows, gameDailyResult.rows, now);
  const bestConsole = consoleRecommendations[0] || null;
  const urgentConsole = consoleRecommendations.find((row) => row.status === 'HACE_FALTA') || null;
  const physicalReady = settings.availableSpaces > 0;

  return {
    generatedAt: now,
    settings,
    catalog: catalogResult.rows.map((row) => ({
      id: row.id,
      name: row.name,
      platform: row.platform,
      compatibleConsoles: row.compatible_consoles || []
    })),
    expansion: {
      available: consoleRecommendations.some((row) => row.sessionCount > 0 || row.requestCount > 0),
      status: !physicalReady ? 'CONFIGURAR_ESPACIO' : urgentConsole ? 'HACE_FALTA' : bestConsole?.status || 'SIN_DATOS',
      recommendedConsole: urgentConsole || bestConsole,
      candidates: consoleRecommendations,
      historyLabel: 'Uso de 56 días · solicitudes de 56 días',
      note: !physicalReady
        ? 'Indica cuántos espacios físicos quedan antes de autorizar una expansión.'
        : urgentConsole
          ? `La evidencia más fuerte favorece ${urgentConsole.name}. La compra todavía debe validarse contra costo y recuperación.`
          : 'No hay evidencia suficiente para comprar otra estación inmediatamente; continúa observando las señales.'
    },
    games: {
      available: gameTrends.length > 0 || gameRecommendations.length > 0,
      historyLabel: 'Uso: últimos 30 vs. 30 anteriores · solicitudes: últimos 120 días',
      topGames: gameTrends.slice(0, 12),
      tasteProfile,
      recommendations: gameRecommendations,
      investments: investmentOutcomes,
      fatigueAlerts: gameTrends.filter((row) => row.fatigueRisk).slice(0, 6)
    }
  };
}
