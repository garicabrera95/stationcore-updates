ALTER TABLE products
  ADD COLUMN IF NOT EXISTS low_stock_threshold INT NOT NULL DEFAULT 5;

-- Permite el nuevo permiso de Inventario en instalaciones existentes.
ALTER TABLE user_permissions
  DROP CONSTRAINT IF EXISTS user_permissions_permission_key_check;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

CREATE TABLE IF NOT EXISTS inventory_movements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES products(id),
  user_id UUID REFERENCES users(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN ('SALE', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT', 'RECEIVE', 'COMBO_COMPONENT')),
  quantity_change INT NOT NULL,
  quantity_before INT NOT NULL DEFAULT 0,
  quantity_after INT NOT NULL DEFAULT 0,
  reference_type TEXT,
  reference_id UUID,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_inventory_movements_product_id ON inventory_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_created_at ON inventory_movements(created_at);

CREATE TABLE IF NOT EXISTS product_combo_components (
  combo_product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  component_product_id UUID NOT NULL REFERENCES products(id),
  quantity INT NOT NULL DEFAULT 1,
  PRIMARY KEY (combo_product_id, component_product_id)
);

INSERT INTO user_permissions (user_id, permission_key, is_enabled)
SELECT id, 'inventory', true
FROM users
WHERE role IN ('OWNER', 'MANAGER')
ON CONFLICT (user_id, permission_key) DO NOTHING;
