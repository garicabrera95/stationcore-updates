DO $$
DECLARE
  constraint_name TEXT;
BEGIN
  SELECT conname INTO constraint_name
  FROM pg_constraint
  WHERE conrelid = 'user_permissions'::regclass
    AND contype = 'c'
    AND pg_get_constraintdef(oid) ILIKE '%permission_key%';

  IF constraint_name IS NOT NULL THEN
    EXECUTE format('ALTER TABLE user_permissions DROP CONSTRAINT %I', constraint_name);
  END IF;
END $$;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

CREATE TABLE IF NOT EXISTS payroll_employee_settings (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  payroll_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  pay_type TEXT NOT NULL DEFAULT 'MONTHLY' CHECK (pay_type IN ('HOURLY', 'DAILY', 'MONTHLY')),
  pay_rate NUMERIC(12,2) NOT NULL DEFAULT 0,
  default_start_time TIME,
  default_end_time TIME,
  notes TEXT,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payroll_shift_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  color TEXT DEFAULT '#2563eb',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payroll_shifts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  work_date DATE NOT NULL,
  shift_name TEXT NOT NULL DEFAULT 'Turno',
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  source TEXT NOT NULL DEFAULT 'MANUAL' CHECK (source IN ('MANUAL', 'ROTATION')),
  status TEXT NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'WORKED', 'MISSED', 'PAID')),
  notes TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS payroll_shifts_unique_active
ON payroll_shifts (user_id, work_date, start_time)
WHERE is_active = true;

CREATE TABLE IF NOT EXISTS payroll_rotation_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  employee_ids UUID[] NOT NULL DEFAULT '{}',
  weekdays INT[] NOT NULL DEFAULT '{}',
  shift_templates JSONB NOT NULL DEFAULT '[]'::jsonb,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  rotate_every_weeks INT NOT NULL DEFAULT 1,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payroll_payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'CASH' CHECK (payment_method IN ('CASH', 'TRANSFER', 'CARD', 'OTHER')),
  paid_at DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  finance_expense_id UUID REFERENCES finance_expenses(id) ON DELETE SET NULL,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO payroll_shift_templates (name, start_time, end_time, color)
VALUES
  ('Mañana', '10:00', '16:00', '#0ea5e9'),
  ('Noche', '16:00', '22:00', '#8b5cf6'),
  ('Día completo', '10:00', '22:00', '#f59e0b')
ON CONFLICT DO NOTHING;
