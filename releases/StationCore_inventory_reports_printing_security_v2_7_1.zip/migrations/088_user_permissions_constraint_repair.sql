DO $$
DECLARE
  constraint_name TEXT;
BEGIN
  FOR constraint_name IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'user_permissions'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%permission_key%'
  LOOP
    EXECUTE format('ALTER TABLE user_permissions DROP CONSTRAINT %I', constraint_name);
  END LOOP;
END $$;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN (
    'stations', 'drawer', 'members', 'inventory', 'prices', 'promotions',
    'reports', 'employees', 'permissions', 'tournaments', 'finances',
    'versus', 'updates'
  ));
