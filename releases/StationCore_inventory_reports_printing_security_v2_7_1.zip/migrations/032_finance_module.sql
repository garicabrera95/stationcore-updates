DO $$
DECLARE
  constraint_name TEXT;
BEGIN
  SELECT conname INTO constraint_name
  FROM pg_constraint
  WHERE conrelid = 'user_permissions'::regclass
    AND contype = 'c'
    AND pg_get_constraintdef(oid) ILIKE '%permission_key%';

  IF constraint_name IS NOT NULL THEN
    EXECUTE format('ALTER TABLE user_permissions DROP CONSTRAINT %I', constraint_name);
  END IF;
END $$;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

INSERT INTO user_permissions (user_id, permission_key, is_enabled)
SELECT id, 'finances', true
FROM users
WHERE role IN ('OWNER', 'MANAGER')
ON CONFLICT (user_id, permission_key) DO NOTHING;

CREATE TABLE IF NOT EXISTS finance_investments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'GENERAL',
  investment_type TEXT NOT NULL DEFAULT 'INITIAL' CHECK (investment_type IN ('INITIAL', 'REINVESTMENT')),
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  invested_at DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS finance_expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'GENERAL',
  expense_type TEXT NOT NULL DEFAULT 'VARIABLE' CHECK (expense_type IN ('FIXED', 'VARIABLE')),
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
  payment_method TEXT NOT NULL DEFAULT 'CASH' CHECK (payment_method IN ('CASH', 'TRANSFER', 'CARD', 'OTHER')),
  notes TEXT,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS finance_recurring_expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'GENERAL',
  monthly_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  due_day INT CHECK (due_day IS NULL OR (due_day >= 1 AND due_day <= 31)),
  notes TEXT,
  created_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
