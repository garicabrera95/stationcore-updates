ALTER TABLE user_permissions
  DROP CONSTRAINT IF EXISTS user_permissions_permission_key_check;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

ALTER TABLE tournaments
  ADD COLUMN IF NOT EXISTS payment_deadline_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS versus_visible_until TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS versus_closed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS versus_closed_by_user_id UUID REFERENCES users(id);

ALTER TABLE tournament_participants
  ADD COLUMN IF NOT EXISTS payment_deadline_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'PENDING',
  ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS cancelled_by_user_id UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tournament_participants_payment_status_check'
  ) THEN
    ALTER TABLE tournament_participants DROP CONSTRAINT tournament_participants_payment_status_check;
  END IF;

  ALTER TABLE tournament_participants
    ADD CONSTRAINT tournament_participants_payment_status_check
    CHECK (payment_status IN ('PENDING', 'PAID', 'EXPIRED', 'CANCELLED'));
END $$;

UPDATE tournament_participants
SET payment_status = CASE WHEN is_paid THEN 'PAID' ELSE COALESCE(NULLIF(payment_status, ''), 'PENDING') END;

ALTER TABLE sale_items
  DROP CONSTRAINT IF EXISTS sale_items_item_type_check;

ALTER TABLE sale_items
  ADD CONSTRAINT sale_items_item_type_check
  CHECK (item_type IN ('PRODUCT', 'GAME_TIME', 'COMBO', 'ADJUSTMENT', 'TOURNAMENT_ENTRY'));

CREATE INDEX IF NOT EXISTS idx_tournament_participants_payment_status ON tournament_participants(payment_status);
CREATE INDEX IF NOT EXISTS idx_tournaments_payment_deadline_at ON tournaments(payment_deadline_at);
CREATE INDEX IF NOT EXISTS idx_tournaments_versus_visible_until ON tournaments(versus_visible_until);

INSERT INTO user_permissions (user_id, permission_key, is_enabled)
SELECT id, 'versus', true
FROM users
WHERE role IN ('OWNER', 'MANAGER')
ON CONFLICT (user_id, permission_key) DO NOTHING;
