ALTER TABLE user_permissions
  DROP CONSTRAINT IF EXISTS user_permissions_permission_key_check;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

CREATE TABLE IF NOT EXISTS station_promotions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('PERCENT', 'FIXED_PRICE')),
  discount_value NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (discount_value >= 0),
  scope_type TEXT NOT NULL DEFAULT 'ALL' CHECK (scope_type IN ('ALL', 'CONSOLE', 'STATION')),
  console_type TEXT,
  station_id UUID REFERENCES stations(id) ON DELETE CASCADE,
  starts_on DATE NOT NULL DEFAULT CURRENT_DATE,
  ends_on DATE,
  all_day BOOLEAN NOT NULL DEFAULT TRUE,
  start_time TIME,
  end_time TIME,
  days_of_week INT[] NOT NULL DEFAULT ARRAY[0,1,2,3,4,5,6],
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (scope_type <> 'CONSOLE' OR console_type IS NOT NULL),
  CHECK (scope_type <> 'STATION' OR station_id IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_station_promotions_active ON station_promotions(is_active, starts_on, ends_on);
CREATE INDEX IF NOT EXISTS idx_station_promotions_station_id ON station_promotions(station_id);
CREATE INDEX IF NOT EXISTS idx_station_promotions_console_type ON station_promotions(console_type);

INSERT INTO user_permissions (user_id, permission_key, is_enabled)
SELECT id, 'promotions', true
FROM users
WHERE role IN ('OWNER', 'MANAGER')
ON CONFLICT (user_id, permission_key) DO NOTHING;
