ALTER TABLE user_permissions
  DROP CONSTRAINT IF EXISTS user_permissions_permission_key_check;

ALTER TABLE user_permissions
  ADD CONSTRAINT user_permissions_permission_key_check
  CHECK (permission_key IN ('stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus', 'updates'));

CREATE TABLE IF NOT EXISTS tournaments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  game TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'PlayStation',
  scheduled_at TIMESTAMPTZ,
  entry_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  prize_text TEXT,
  max_players INT,
  status TEXT NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'ACTIVE', 'FINISHED', 'CANCELLED')),
  created_by_user_id UUID REFERENCES users(id),
  winner_participant_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS tournament_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tournament_id UUID NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  member_id UUID REFERENCES members(id),
  player_name TEXT NOT NULL,
  phone TEXT,
  nickname TEXT,
  is_paid BOOLEAN NOT NULL DEFAULT FALSE,
  paid_at TIMESTAMPTZ,
  paid_by_user_id UUID REFERENCES users(id),
  sale_id UUID REFERENCES sales(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_tournaments_winner_participant'
  ) THEN
    ALTER TABLE tournaments
      ADD CONSTRAINT fk_tournaments_winner_participant
      FOREIGN KEY (winner_participant_id) REFERENCES tournament_participants(id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_tournaments_status ON tournaments(status);
CREATE INDEX IF NOT EXISTS idx_tournaments_scheduled_at ON tournaments(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_tournament_id ON tournament_participants(tournament_id);

INSERT INTO user_permissions (user_id, permission_key, is_enabled)
SELECT id, 'tournaments', true
FROM users
WHERE role IN ('OWNER', 'MANAGER')
ON CONFLICT (user_id, permission_key) DO NOTHING;
