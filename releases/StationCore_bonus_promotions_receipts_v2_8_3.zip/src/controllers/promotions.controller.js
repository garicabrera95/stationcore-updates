import { query, withTransaction } from '../db/pool.js';

const ALLOWED_CONSOLES = ['PlayStation 4', 'PlayStation 5', 'Xbox One', 'Xbox Series', 'Nintendo Switch'];
const ALLOWED_SCOPE_TYPES = ['ALL', 'CONSOLE', 'STATION'];
const ALLOWED_DISCOUNT_TYPES = ['PERCENT', 'FIXED_PRICE'];

function canManagePromotions(req) {
  return req.user?.role === 'OWNER' || req.user?.role === 'MANAGER' || req.user?.permissions?.includes('promotions');
}

function normalizeDays(value) {
  const source = Array.isArray(value) && value.length ? value : [0, 1, 2, 3, 4, 5, 6];
  const days = [...new Set(source.map((day) => Number.parseInt(String(day), 10)).filter((day) => day >= 0 && day <= 6))];
  return days.length ? days.sort((a, b) => a - b) : [0, 1, 2, 3, 4, 5, 6];
}

function normalizeDate(value, fallbackToday = false) {
  const raw = String(value || '').trim();
  if (raw) return raw.slice(0, 10);
  if (!fallbackToday) return null;
  return new Date().toISOString().slice(0, 10);
}

function normalizeTime(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  return raw.slice(0, 5);
}

function normalizeTargetMinutes(value) {
  if (!Array.isArray(value) || !value.length) return null;
  const minutes = [...new Set(
    value
      .map((item) => Number.parseInt(String(item), 10))
      .filter((item) => Number.isFinite(item) && item > 0)
  )].sort((a, b) => a - b);
  return minutes.length ? minutes : null;
}

function normalizePromotionPayload(body) {
  const name = String(body.name || '').trim();
  const discountType = String(body.discountType || body.discount_type || '').toUpperCase();
  const discountValue = Number(body.discountValue ?? body.discount_value ?? 0);
  const scopeType = String(body.scopeType || body.scope_type || 'ALL').toUpperCase();
  const consoleType = String(body.consoleType || body.console_type || '').trim();
  const stationId = body.stationId || body.station_id || null;
  const startsOn = normalizeDate(body.startsOn || body.starts_on, true);
  const endsOn = normalizeDate(body.endsOn || body.ends_on, false);
  const allDay = Boolean(body.allDay ?? body.all_day ?? true);
  const startTime = allDay ? null : normalizeTime(body.startTime || body.start_time);
  const endTime = allDay ? null : normalizeTime(body.endTime || body.end_time);
  const daysOfWeek = normalizeDays(body.daysOfWeek || body.days_of_week);
  const isActive = Boolean(body.isActive ?? body.is_active ?? true);
  const sortOrder = Number.parseInt(String(body.sortOrder ?? body.sort_order ?? 0), 10);
  const targetMinutes = normalizeTargetMinutes(body.targetMinutes ?? body.target_minutes);

  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  if (!ALLOWED_DISCOUNT_TYPES.includes(discountType)) {
    const error = new Error('Tipo inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(discountValue) || discountValue < 0) {
    const error = new Error('Descuento inválido');
    error.status = 400;
    throw error;
  }

  if (discountType === 'PERCENT' && discountValue > 100) {
    const error = new Error('Porcentaje inválido');
    error.status = 400;
    throw error;
  }

  if (!ALLOWED_SCOPE_TYPES.includes(scopeType)) {
    const error = new Error('Alcance inválido');
    error.status = 400;
    throw error;
  }

  if (scopeType === 'CONSOLE' && !ALLOWED_CONSOLES.includes(consoleType)) {
    const error = new Error('Modelo inválido');
    error.status = 400;
    throw error;
  }

  if (scopeType === 'STATION' && !stationId) {
    const error = new Error('Selecciona estación');
    error.status = 400;
    throw error;
  }

  if (!allDay && (!startTime || !endTime)) {
    const error = new Error('Horario requerido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    discountType,
    discountValue: Number(discountValue.toFixed(2)),
    scopeType,
    consoleType: scopeType === 'CONSOLE' ? consoleType : null,
    stationId: scopeType === 'STATION' ? stationId : null,
    startsOn,
    endsOn,
    allDay,
    startTime,
    endTime,
    daysOfWeek,
    targetMinutes,
    isActive,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0
  };
}

async function validatePromotionTargetMinutes(promo) {
  if (!Array.isArray(promo.targetMinutes) || !promo.targetMinutes.length) return;

  const { rows } = await query(
    `SELECT DISTINCT stp.minutes
     FROM station_time_prices stp
     LEFT JOIN stations selected_station ON selected_station.id = $3::uuid
     WHERE stp.is_active = true
       AND stp.minutes = ANY($4::int[])
       AND (
         $1 = 'ALL'
         OR ($1 = 'CONSOLE' AND stp.station_id IS NULL AND stp.console_type = $2)
         OR (
           $1 = 'STATION'
           AND (
             stp.station_id = $3::uuid
             OR (stp.station_id IS NULL AND stp.console_type = selected_station.console_type)
           )
         )
       )`,
    [promo.scopeType, promo.consoleType, promo.stationId, promo.targetMinutes]
  );

  const available = new Set(rows.map((row) => Number(row.minutes)));
  const missing = promo.targetMinutes.filter((minutes) => !available.has(Number(minutes)));
  if (missing.length) {
    const error = new Error(`Hay tiempos no disponibles para esta selección: ${missing.map((minutes) => `${minutes} min`).join(', ')}`);
    error.status = 400;
    throw error;
  }
}

export async function listPromotions(_req, res) {
  const { rows } = await query(`
    SELECT
      sp.*,
      s.name AS station_name,
      s.console_type AS station_console_type
    FROM station_promotions sp
    LEFT JOIN stations s ON s.id = sp.station_id
    ORDER BY sp.is_active DESC, sp.sort_order, sp.starts_on DESC, sp.name
  `);

  res.json({ promotions: rows });
}

export async function createPromotion(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const promo = normalizePromotionPayload(req.body);
  await validatePromotionTargetMinutes(promo);
  const { rows } = await query(
    `INSERT INTO station_promotions (
       name, discount_type, discount_value, scope_type, console_type, station_id,
       starts_on, ends_on, all_day, start_time, end_time, days_of_week, target_minutes, is_active, sort_order
     )
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::int[], $13::int[], $14, $15)
     RETURNING *`,
    [
      promo.name,
      promo.discountType,
      promo.discountValue,
      promo.scopeType,
      promo.consoleType,
      promo.stationId,
      promo.startsOn,
      promo.endsOn,
      promo.allDay,
      promo.startTime,
      promo.endTime,
      promo.daysOfWeek,
      promo.targetMinutes,
      promo.isActive,
      promo.sortOrder
    ]
  );

  res.status(201).json({ promotion: rows[0] });
}

export async function updatePromotion(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const promo = normalizePromotionPayload(req.body);
  await validatePromotionTargetMinutes(promo);
  const { promotionId } = req.params;
  const { rows } = await query(
    `UPDATE station_promotions
     SET name = $2,
         discount_type = $3,
         discount_value = $4,
         scope_type = $5,
         console_type = $6,
         station_id = $7,
         starts_on = $8,
         ends_on = $9,
         all_day = $10,
         start_time = $11,
         end_time = $12,
         days_of_week = $13::int[],
         target_minutes = $14::int[],
         is_active = $15,
         sort_order = $16,
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [
      promotionId,
      promo.name,
      promo.discountType,
      promo.discountValue,
      promo.scopeType,
      promo.consoleType,
      promo.stationId,
      promo.startsOn,
      promo.endsOn,
      promo.allDay,
      promo.startTime,
      promo.endTime,
      promo.daysOfWeek,
      promo.targetMinutes,
      promo.isActive,
      promo.sortOrder
    ]
  );

  if (!rows[0]) return res.status(404).json({ error: 'Promoción no encontrada' });
  res.json({ promotion: rows[0] });
}

export async function deletePromotion(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { promotionId } = req.params;
  const { rowCount } = await query(`DELETE FROM station_promotions WHERE id = $1`, [promotionId]);
  if (!rowCount) return res.status(404).json({ error: 'Promoción no encontrada' });
  res.json({ ok: true });
}


const BONUS_RULE_KEYS = ['WELCOME_MEMBERSHIP', 'VISIT_REWARD', 'MANUAL_BONUS'];
const BONUS_TIERS = ['ALL', 'GENERAL', 'PAID_MEMBERS', 'GAMER', 'GAMER_PRO', 'CHAMPION'];
const MANUAL_BONUS_TYPES = ['TIME', 'PRODUCT', 'SNACK', 'DRINK', 'MEMBERSHIP'];

function normalizeMembershipPlanCode(value = '') {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}



const TOURNAMENT_ENTRY_TIERS = ['GAMER', 'GAMER_PRO', 'CHAMPION'];
const TOURNAMENT_ENTRY_DISCOUNT_TYPES = ['NONE', 'PERCENT', 'FIXED_AMOUNT', 'FREE'];

function normalizeTournamentEntryDiscountRule(rule = {}) {
  const membershipTier = normalizeMembershipPlanCode(rule.membershipTier || rule.membership_tier || '');
  const discountType = String(rule.discountType || rule.discount_type || 'NONE').toUpperCase();
  const discountValue = Number(rule.discountValue ?? rule.discount_value ?? 0);
  const isActive = Boolean(rule.isActive ?? rule.is_active ?? true);

  if (!TOURNAMENT_ENTRY_TIERS.includes(membershipTier)) {
    const error = new Error('Membresía inválida');
    error.status = 400;
    throw error;
  }
  if (!TOURNAMENT_ENTRY_DISCOUNT_TYPES.includes(discountType)) {
    const error = new Error('Tipo de descuento inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(discountValue) || discountValue < 0) {
    const error = new Error('Valor de descuento inválido');
    error.status = 400;
    throw error;
  }
  if (discountType === 'PERCENT' && discountValue > 100) {
    const error = new Error('Porcentaje inválido');
    error.status = 400;
    throw error;
  }

  return { membershipTier, discountType, discountValue: Number(discountValue.toFixed(2)), isActive };
}

export async function listTournamentEntryDiscounts(_req, res) {
  const { rows } = await query(`
    SELECT membership_tier, discount_type, discount_value, is_active, updated_at
    FROM tournament_entry_discounts
    ORDER BY CASE membership_tier WHEN 'GAMER' THEN 1 WHEN 'GAMER_PRO' THEN 2 WHEN 'CHAMPION' THEN 3 ELSE 99 END
  `);
  res.json({ discounts: rows });
}

export async function saveTournamentEntryDiscounts(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const rules = Array.isArray(req.body?.discounts) ? req.body.discounts : [];
  const normalized = rules.map(normalizeTournamentEntryDiscountRule);

  await withTransaction(async (client) => {
    for (const rule of normalized) {
      await client.query(
        `INSERT INTO tournament_entry_discounts (membership_tier, discount_type, discount_value, is_active, updated_at)
         VALUES ($1, $2, $3, $4, NOW())
         ON CONFLICT (membership_tier)
         DO UPDATE SET discount_type = EXCLUDED.discount_type,
                       discount_value = EXCLUDED.discount_value,
                       is_active = EXCLUDED.is_active,
                       updated_at = NOW()`,
        [rule.membershipTier, rule.discountType, rule.discountValue, rule.isActive]
      );
    }
  });

  return listTournamentEntryDiscounts(req, res);
}

async function isValidMembershipTier(client, tier, requireActive = true) {
  const code = normalizeMembershipPlanCode(tier);
  if (!code) return false;
  const result = await client.query(
    `SELECT code FROM membership_plans WHERE code = $1 ${requireActive ? 'AND is_active = true AND archived_at IS NULL' : ''} LIMIT 1`,
    [code]
  );
  return result.rowCount > 0;
}


function normalizeMembershipPlanPayload(body, forcedCode = null) {
  const name = String(body.name || '').trim();
  const code = normalizeMembershipPlanCode(forcedCode || body.code || name);
  const color = String(body.color || '#2563eb').trim() || '#2563eb';
  const monthlyPrice = Number(body.monthlyPrice ?? body.monthly_price ?? 0);
  const durationDays = Number.parseInt(String(body.durationDays ?? body.duration_days ?? 30), 10);
  const sortOrder = Number.parseInt(String(body.sortOrder ?? body.sort_order ?? 100), 10);
  const priorityOrder = Number.parseInt(String(body.priorityOrder ?? body.priority_order ?? sortOrder), 10);
  const isActive = Boolean(body.isActive ?? body.is_active ?? true);
  const showInPos = Boolean(body.showInPos ?? body.show_in_pos ?? true);
  const savedGameEnabled = Boolean(body.savedGameEnabled ?? body.saved_game_enabled ?? false);
  const savedGameLimit = Number.parseInt(String(body.savedGameLimit ?? body.saved_game_limit ?? 0), 10);
  const savedGameUnlimited = Boolean(body.savedGameUnlimited ?? body.saved_game_unlimited ?? false);
  const featuredGamePriority = Boolean(body.featuredGamePriority ?? body.featured_game_priority ?? false);
  const savedGameUpgradeMessage = String(body.savedGameUpgradeMessage || body.saved_game_upgrade_message || 'Hazte miembro y guarda tu progreso en Club Versus.').trim() || 'Hazte miembro y guarda tu progreso en Club Versus.';

  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }
  if (!code) {
    const error = new Error('Código requerido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(monthlyPrice) || monthlyPrice < 0) {
    const error = new Error('Precio inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(durationDays) || durationDays <= 0) {
    const error = new Error('Duración inválida');
    error.status = 400;
    throw error;
  }

  return {
    code,
    name,
    color,
    monthlyPrice: Number(monthlyPrice.toFixed(2)),
    durationDays,
    priorityOrder: Number.isFinite(priorityOrder) ? priorityOrder : sortOrder,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 100,
    isActive,
    showInPos,
    savedGameEnabled,
    savedGameLimit: Number.isFinite(savedGameLimit) && savedGameLimit > 0 ? savedGameLimit : 0,
    savedGameUnlimited,
    featuredGamePriority,
    savedGameUpgradeMessage,
    isArchived: Boolean(body.isArchived ?? body.is_archived ?? false)
  };
}

async function ensureMembershipProduct(client, plan) {
  const productName = plan.name;
  const sku = `MEMB-${plan.code}`;
  await client.query(
    `INSERT INTO products (name, category, sku, price, cost, stock_qty, track_stock, is_combo, is_active, membership_plan_code)
     SELECT $1, 'MEMBERSHIP', $2, $3, 0, 0, false, false, $4, $5
     WHERE NOT EXISTS (SELECT 1 FROM products WHERE membership_plan_code = $5)`,
    [productName, sku, plan.monthlyPrice, plan.isActive && plan.showInPos && !plan.isArchived, plan.code]
  );

  await client.query(
    `UPDATE products
     SET name = $2,
         sku = COALESCE(NULLIF(sku, ''), $3),
         price = $4,
         track_stock = false,
         is_active = $5,
         category = 'MEMBERSHIP',
         updated_at = NOW()
     WHERE membership_plan_code = $1`,
    [plan.code, productName, sku, plan.monthlyPrice, plan.isActive && plan.showInPos && !plan.isArchived]
  );
}

async function ensureMembershipTimeRows(client, planCode) {
  await client.query(
    `INSERT INTO membership_time_prices (membership_tier, label, minutes, player_count, price, is_active, sort_order)
     SELECT $1, pkg.label, pkg.minutes, pc.player_count, 0, false, pkg.sort_order
     FROM (VALUES (1), (2)) AS pc(player_count)
     CROSS JOIN (VALUES
       ('15 min', 15, 10),
       ('30 min', 30, 20),
       ('1 hora', 60, 30),
       ('2 horas', 120, 40),
       ('3 horas', 180, 50)
     ) AS pkg(label, minutes, sort_order)
     ON CONFLICT (membership_tier, player_count, minutes) DO NOTHING`,
    [planCode]
  );
}

export async function listMembershipPlans(_req, res) {
  const { rows } = await query(`
    SELECT *
    FROM membership_plans
    ORDER BY (archived_at IS NOT NULL), sort_order, name
  `);
  res.json({ plans: rows });
}

export async function createMembershipPlan(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const plan = normalizeMembershipPlanPayload(req.body);

  try {
    const result = await withTransaction(async (client) => {
      const existing = await client.query('SELECT code FROM membership_plans WHERE code = $1 LIMIT 1', [plan.code]);
      if (existing.rowCount) {
        const error = new Error(`Ya existe una membresía con el código ${plan.code}`);
        error.status = 409;
        throw error;
      }

      const saved = await client.query(
        `INSERT INTO membership_plans (
           code, name, color, monthly_price, duration_days, priority_order, is_active, show_in_pos, sort_order,
           saved_game_enabled, saved_game_limit, saved_game_unlimited, featured_game_priority, saved_game_upgrade_message, archived_at
         )
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NULL)
         RETURNING *`,
        [
          plan.code, plan.name, plan.color, plan.monthlyPrice, plan.durationDays, plan.priorityOrder, plan.isActive, plan.showInPos, plan.sortOrder,
          plan.savedGameEnabled, plan.savedGameLimit, plan.savedGameUnlimited, plan.featuredGamePriority, plan.savedGameUpgradeMessage
        ]
      );
      await ensureMembershipTimeRows(client, plan.code);
      await ensureMembershipProduct(client, plan);
      return saved.rows[0];
    });

    res.status(201).json({ plan: result });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: `Ya existe una membresía con el código ${plan.code}` });
    }
    if (error.status) return res.status(error.status).json({ error: error.message });
    console.error(error);
    return res.status(500).json({ error: 'No se pudo guardar el plan' });
  }
}

export async function updateMembershipPlan(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const plan = normalizeMembershipPlanPayload(req.body, req.params.code);

  try {
    const result = await withTransaction(async (client) => {
      const saved = await client.query(
        `UPDATE membership_plans
         SET name = $2,
             color = $3,
             monthly_price = $4,
             duration_days = $5,
             priority_order = $6,
             is_active = $7,
             show_in_pos = $8,
             sort_order = $9,
             saved_game_enabled = $10,
             saved_game_limit = $11,
             saved_game_unlimited = $12,
             featured_game_priority = $13,
             saved_game_upgrade_message = $14,
             archived_at = CASE WHEN $15 THEN NOW() ELSE archived_at END,
             updated_at = NOW()
         WHERE code = $1
         RETURNING *`,
        [
          plan.code, plan.name, plan.color, plan.monthlyPrice, plan.durationDays, plan.priorityOrder, plan.isActive, plan.showInPos, plan.sortOrder,
          plan.savedGameEnabled, plan.savedGameLimit, plan.savedGameUnlimited, plan.featuredGamePriority, plan.savedGameUpgradeMessage, plan.isArchived
        ]
      );
      if (!saved.rows[0]) {
        const error = new Error('Plan no encontrado');
        error.status = 404;
        throw error;
      }
      await ensureMembershipTimeRows(client, plan.code);
      await ensureMembershipProduct(client, plan);
      return saved.rows[0];
    });

    res.json({ plan: result });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ error: error.message });
    console.error(error);
    return res.status(500).json({ error: 'No se pudo actualizar el plan' });
  }
}

export async function archiveMembershipPlan(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const code = normalizeMembershipPlanCode(req.params.code);
  if (!code) return res.status(400).json({ error: 'Código requerido' });

  try {
    const result = await withTransaction(async (client) => {
      const saved = await client.query(
        `UPDATE membership_plans
         SET is_active = false,
             show_in_pos = false,
             archived_at = COALESCE(archived_at, NOW()),
             updated_at = NOW()
         WHERE code = $1
         RETURNING *`,
        [code]
      );
      if (!saved.rows[0]) {
        const error = new Error('Plan no encontrado');
        error.status = 404;
        throw error;
      }
      await ensureMembershipProduct(client, { ...saved.rows[0], monthlyPrice: Number(saved.rows[0].monthly_price || 0), isActive: false, showInPos: false, isArchived: true });
      return saved.rows[0];
    });

    res.json({ plan: result });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ error: error.message });
    console.error(error);
    return res.status(500).json({ error: 'No se pudo archivar el plan' });
  }
}

export async function restoreMembershipPlan(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const code = normalizeMembershipPlanCode(req.params.code);
  if (!code) return res.status(400).json({ error: 'Código requerido' });

  try {
    const result = await withTransaction(async (client) => {
      const saved = await client.query(
        `UPDATE membership_plans
         SET is_active = true,
             show_in_pos = true,
             archived_at = NULL,
             updated_at = NOW()
         WHERE code = $1
         RETURNING *`,
        [code]
      );
      if (!saved.rows[0]) {
        const error = new Error('Plan no encontrado');
        error.status = 404;
        throw error;
      }
      await ensureMembershipTimeRows(client, code);
      await ensureMembershipProduct(client, { ...saved.rows[0], monthlyPrice: Number(saved.rows[0].monthly_price || 0), isActive: true, showInPos: true, isArchived: false });
      return saved.rows[0];
    });

    res.json({ plan: result });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ error: error.message });
    console.error(error);
    return res.status(500).json({ error: 'No se pudo restaurar el plan' });
  }
}

function normalizeBonusRulePayload(ruleKey, body) {
  const name = String(body.name || '').trim();
  const rewardMinutes = Number.parseInt(String(body.rewardMinutes ?? body.reward_minutes ?? 0), 10);
  const expiresDays = Number.parseInt(String(body.expiresDays ?? body.expires_days ?? 0), 10);
  const requiredVisits = Number.parseInt(String(body.requiredVisits ?? body.required_visits ?? 0), 10);
  const minGameMinutes = Number.parseInt(String(body.minGameMinutes ?? body.min_game_minutes ?? 0), 10);
  const minPurchaseAmount = Number(body.minPurchaseAmount ?? body.min_purchase_amount ?? 0);
  const appliesToTier = String(body.appliesToTier || body.applies_to_tier || 'ALL').toUpperCase();
  const repeatable = Boolean(body.repeatable ?? true);
  const isActive = Boolean(body.isActive ?? body.is_active ?? true);

  if (!BONUS_RULE_KEYS.includes(ruleKey)) {
    const error = new Error('Bono inválido');
    error.status = 400;
    throw error;
  }

  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(rewardMinutes) || rewardMinutes < 0) {
    const error = new Error('Minutos inválidos');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(expiresDays) || expiresDays < 0) {
    const error = new Error('Vencimiento inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(requiredVisits) || requiredVisits < 0) {
    const error = new Error('Visitas inválidas');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(minGameMinutes) || minGameMinutes < 0) {
    const error = new Error('Tiempo mínimo inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(minPurchaseAmount) || minPurchaseAmount < 0) {
    const error = new Error('Monto mínimo inválido');
    error.status = 400;
    throw error;
  }

  if (!BONUS_TIERS.includes(appliesToTier)) {
    const error = new Error('Alcance inválido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    rewardMinutes,
    expiresDays,
    requiredVisits,
    minGameMinutes,
    minPurchaseAmount: Number(minPurchaseAmount.toFixed(2)),
    appliesToTier,
    repeatable,
    isActive
  };
}

export async function listBonusRules(_req, res) {
  await query(`
    INSERT INTO bonus_rules (rule_key, name, rule_type, reward_minutes, expires_days, required_visits, min_game_minutes, applies_to_tier, repeatable, is_active, sort_order)
    VALUES
      ('WELCOME_MEMBERSHIP', 'Bono de bienvenida', 'WELCOME', 30, 7, 0, 0, 'PAID_MEMBERS', false, true, 10),
      ('VISIT_REWARD', 'Bono por visitas', 'VISIT', 30, 30, 5, 0, 'PAID_MEMBERS', true, true, 20),
      ('MANUAL_BONUS', 'Bono manual', 'MANUAL', 30, 7, 0, 0, 'ALL', true, true, 30)
    ON CONFLICT (rule_key) DO NOTHING
  `);

  const { rows } = await query(`
    SELECT *
    FROM bonus_rules
    WHERE rule_key IN ('WELCOME_MEMBERSHIP', 'VISIT_REWARD', 'MANUAL_BONUS')
    ORDER BY sort_order, name
  `);

  res.json({ rules: rows });
}

export async function updateBonusRule(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const ruleKey = String(req.params.ruleKey || '').toUpperCase();
  const rule = normalizeBonusRulePayload(ruleKey, req.body);

  const ruleType = ruleKey === 'WELCOME_MEMBERSHIP' ? 'WELCOME' : ruleKey === 'VISIT_REWARD' ? 'VISIT' : 'MANUAL';
  const sortOrder = ruleKey === 'WELCOME_MEMBERSHIP' ? 10 : ruleKey === 'VISIT_REWARD' ? 20 : 30;
  const { rows } = await query(
    `INSERT INTO bonus_rules (
       rule_key, name, rule_type, reward_minutes, expires_days, required_visits,
       min_game_minutes, min_purchase_amount, applies_to_tier, repeatable, is_active, sort_order
     )
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
     ON CONFLICT (rule_key)
     DO UPDATE SET name = EXCLUDED.name,
                   reward_minutes = EXCLUDED.reward_minutes,
                   expires_days = EXCLUDED.expires_days,
                   required_visits = EXCLUDED.required_visits,
                   min_game_minutes = EXCLUDED.min_game_minutes,
                   min_purchase_amount = EXCLUDED.min_purchase_amount,
                   applies_to_tier = EXCLUDED.applies_to_tier,
                   repeatable = EXCLUDED.repeatable,
                   is_active = EXCLUDED.is_active,
                   updated_at = NOW()
     RETURNING *`,
    [
      ruleKey,
      rule.name,
      ruleType,
      rule.rewardMinutes,
      rule.expiresDays,
      rule.requiredVisits,
      rule.minGameMinutes,
      rule.minPurchaseAmount,
      rule.appliesToTier,
      rule.repeatable,
      rule.isActive,
      sortOrder
    ]
  );

  res.json({ rule: rows[0] });
}

export async function grantManualBonus(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const memberId = req.body.memberId || req.body.member_id || null;
  const bonusType = String(req.body.bonusType || req.body.bonus_type || 'TIME').toUpperCase();
  const minutes = Number.parseInt(String(req.body.minutes || 0), 10);
  const productCategory = String(req.body.productCategory || req.body.product_category || '').toUpperCase();
  const productId = req.body.productId || req.body.product_id || null;
  const productQty = Number.parseInt(String(req.body.productQty ?? req.body.product_qty ?? 0), 10);
  const snackQty = Number.parseInt(String(req.body.snackQty ?? req.body.snack_qty ?? 0), 10);
  const drinkQty = Number.parseInt(String(req.body.drinkQty ?? req.body.drink_qty ?? 0), 10);
  const membershipTier = String(req.body.membershipTier || req.body.membership_tier || '').toUpperCase();
  const expiresDays = Number.parseInt(String(req.body.expiresDays ?? req.body.expires_days ?? 7), 10);
  const notes = String(req.body.notes || '').trim();

  if (!memberId) return res.status(400).json({ error: 'Selecciona miembro' });
  if (!MANUAL_BONUS_TYPES.includes(bonusType)) return res.status(400).json({ error: 'Tipo de bono inválido' });
  if (bonusType === 'TIME' && (!Number.isFinite(minutes) || minutes <= 0)) return res.status(400).json({ error: 'Minutos inválidos' });
  if (bonusType === 'SNACK' && (!Number.isFinite(snackQty) || snackQty <= 0)) return res.status(400).json({ error: 'Cantidad de snacks inválida' });
  if (bonusType === 'DRINK' && (!Number.isFinite(drinkQty) || drinkQty <= 0)) return res.status(400).json({ error: 'Cantidad de bebidas inválida' });
  if (bonusType === 'PRODUCT' && (!productId || !Number.isFinite(productQty) || productQty <= 0)) return res.status(400).json({ error: 'Producto / servicio inválido' });
  if (bonusType === 'MEMBERSHIP' && !(await isValidMembershipTier({ query: (sql, params) => query(sql, params) }, membershipTier))) return res.status(400).json({ error: 'Membresía inválida' });
  if (bonusType !== 'MEMBERSHIP' && (!Number.isFinite(expiresDays) || expiresDays < 0)) return res.status(400).json({ error: 'Vencimiento inválido' });

  const result = await withTransaction(async (client) => {
    const member = await client.query(`SELECT id, full_name FROM members WHERE id = $1 AND is_active = true`, [memberId]);
    if (member.rowCount === 0) {
      const error = new Error('Miembro no encontrado');
      error.status = 404;
      throw error;
    }

    if (bonusType === 'MEMBERSHIP') {
      await client.query(
        `UPDATE members
         SET membership_tier = $2,
             membership_active = true,
             membership_source = 'MANUAL',
             membership_started_at = COALESCE(membership_started_at, NOW()),
             membership_updated_at = NOW(),
             membership_cancelled_at = NULL,
             membership_cancelled_by_user_id = NULL,
             membership_cancel_reason = NULL,
             updated_at = NOW()
         WHERE id = $1`,
        [memberId, membershipTier]
      );
      await client.query(
        `INSERT INTO member_membership_history (member_id, tier, amount, is_renewal)
         VALUES ($1, $2, 0, true)`,
        [memberId, membershipTier]
      );
      return { member: member.rows[0], membershipTier, message: `Membresía ${membershipTier.replace('_', ' ')} entregada` };
    }

    const rule = await client.query(`SELECT id FROM bonus_rules WHERE rule_key = 'MANUAL_BONUS' LIMIT 1`);
    const sourceRuleId = rule.rows[0]?.id || null;
    const rewardMinutes = bonusType === 'TIME' ? minutes : 0;
    let rewardProduct = null;

    if (bonusType === 'PRODUCT') {
      const productResult = await client.query(
        `SELECT id, name, category FROM products WHERE id = $1 AND is_active = true LIMIT 1`,
        [productId]
      );
      if (productResult.rowCount === 0) {
        const error = new Error('Producto / servicio no encontrado');
        error.status = 404;
        throw error;
      }
      rewardProduct = productResult.rows[0];
      if (productCategory && String(rewardProduct.category || '').toUpperCase() !== productCategory) {
        const error = new Error('El producto no pertenece a esa categoría');
        error.status = 400;
        throw error;
      }
      if (String(rewardProduct.category || '').toUpperCase() === 'MEMBERSHIP') {
        const error = new Error('Para regalar membresía usa el tipo Membresía');
        error.status = 400;
        throw error;
      }
    }

    const reward = await client.query(
      `INSERT INTO member_rewards (
         member_id, reward_type, reward_minutes, prize_snack_qty, prize_drink_qty,
         prize_product_id, prize_product_qty, status, expires_at, source_rule_id, notes, created_by_user_id
       )
       VALUES ($1, 'MANUAL', $2, 0, 0, $3, $4, 'AVAILABLE', NOW() + ($5 || ' days')::interval, $6, $7, $8)
       RETURNING *`,
      [memberId, rewardMinutes, rewardProduct?.id || null, bonusType === 'PRODUCT' ? productQty : 0, expiresDays, sourceRuleId, notes || 'Bono manual', req.user.id]
    );

    const message = bonusType === 'TIME'
      ? `Bono entregado: ${rewardMinutes} min`
      : `Bono entregado: ${productQty} ${rewardProduct?.name || 'producto'}`;

    return { member: member.rows[0], reward: reward.rows[0], message };
  });

  res.status(201).json(result);
}


function normalizePlayerCount(value) {
  const playerCount = Number.parseInt(String(value || 1), 10);
  return playerCount === 2 ? 2 : 1;
}


function normalizeMemberTimePriceRow(row) {
  const label = String(row.label || '').trim();
  const minutes = Number.parseInt(String(row.minutes || 0), 10);
  const price = Number(row.price ?? 0);
  const playerCount = normalizePlayerCount(row.playerCount ?? row.player_count ?? 1);
  const sortOrder = Number.parseInt(String(row.sortOrder ?? row.sort_order ?? minutes), 10);
  const isActive = Boolean(row.isActive ?? row.is_active ?? true);

  if (!label) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(minutes) || minutes <= 0) {
    const error = new Error('Tiempo inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(price) || price < 0) {
    const error = new Error('Precio inválido');
    error.status = 400;
    throw error;
  }

  return {
    label,
    minutes,
    price: Number(price.toFixed(2)),
    playerCount,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : minutes,
    isActive
  };
}

export async function listMemberTimePrices(_req, res) {
  const { rows } = await query(`
    SELECT *
    FROM membership_time_prices
    ORDER BY
      COALESCE((SELECT sort_order FROM membership_plans mp WHERE mp.code = membership_time_prices.membership_tier), 999),
      player_count,
      sort_order,
      minutes
  `);

  res.json({ prices: rows });
}

export async function saveMemberTimePrices(req, res) {
  if (!canManagePromotions(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const tier = String(req.params.tier || '').toUpperCase();
  const prices = Array.isArray(req.body.prices) ? req.body.prices.map(normalizeMemberTimePriceRow) : [];

  if (!(await isValidMembershipTier({ query: (sql, params) => query(sql, params) }, tier, false))) {
    return res.status(400).json({ error: 'Membresía inválida' });
  }

  if (!prices.length) {
    return res.status(400).json({ error: 'Agrega precios' });
  }

  const saved = [];
  for (const row of prices) {
    const result = await query(
      `INSERT INTO membership_time_prices (membership_tier, label, minutes, player_count, price, is_active, sort_order)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (membership_tier, player_count, minutes)
       DO UPDATE SET
         label = EXCLUDED.label,
         price = EXCLUDED.price,
         is_active = EXCLUDED.is_active,
         sort_order = EXCLUDED.sort_order,
         updated_at = NOW()
       RETURNING *`,
      [tier, row.label, row.minutes, row.playerCount, row.price, row.isActive, row.sortOrder]
    );

    saved.push(result.rows[0]);
  }

  res.json({ prices: saved });
}
