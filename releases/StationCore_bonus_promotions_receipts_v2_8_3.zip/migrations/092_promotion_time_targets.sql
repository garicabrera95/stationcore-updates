-- v2.8.2: permite limitar una promoción a duraciones específicas.
-- NULL conserva el comportamiento anterior: la promoción aplica a todos los tiempos.

ALTER TABLE station_promotions
  ADD COLUMN IF NOT EXISTS target_minutes INT[];

-- Si una instalación quedó con una columna parcial creada manualmente, normaliza
-- valores vacíos o inválidos antes de agregar la restricción.
UPDATE station_promotions
SET target_minutes = NULL
WHERE target_minutes IS NOT NULL
  AND (
    cardinality(target_minutes) = 0
    OR NOT (0 < ALL(target_minutes))
  );

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conrelid = 'station_promotions'::regclass
      AND conname = 'station_promotions_target_minutes_check'
  ) THEN
    ALTER TABLE station_promotions
      ADD CONSTRAINT station_promotions_target_minutes_check
      CHECK (
        target_minutes IS NULL
        OR (
          cardinality(target_minutes) > 0
          AND 0 < ALL(target_minutes)
        )
      );
  END IF;
END $$;
