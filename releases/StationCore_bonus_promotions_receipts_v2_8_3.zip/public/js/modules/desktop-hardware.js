(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

  const desktop = () => window.clubVersusDesktop || null;

  function isDesktopReady() {
    const api = desktop();
    return Boolean(api?.listPrinters && api?.kickCashDrawer && api?.getHardwareConfig);
  }

  function getDesktopMissingMessage() {
    return 'Puente nativo de Windows no disponible. Cierra completamente Club Versus POS Desktop y vuelve a abrir con npm run desktop. Si sigue pasando, el preload de Electron no cargó.';
  }

  function printerSelects() {
    return [
      document.querySelector('#hardwareReceiptPrinterSelect'),
      document.querySelector('#hardwareCashDrawerPrinterSelect')
    ].filter(Boolean);
  }

  function getReceiptPrinterName() {
    return document.querySelector('#hardwareReceiptPrinterSelect')?.value || '';
  }

  function getCashDrawerPrinterName() {
    return document.querySelector('#hardwareCashDrawerPrinterSelect')?.value || getReceiptPrinterName();
  }

  function getSaleReceiptPromptEnabled() {
    return document.querySelector('#hardwareSaleReceiptPromptToggle')?.checked !== false;
  }

  async function shouldAskSaleReceipt() {
    const desktopApi = desktop();
    if (!desktopApi?.getHardwareConfig) return true;
    try {
      const result = await desktopApi.getHardwareConfig();
      return result?.config?.saleReceiptPromptEnabled !== false;
    } catch (error) {
      console.warn('No se pudo leer la preferencia de recibos:', error?.message || error);
      return true;
    }
  }

  const CASH_DRAWER_EVENT_MAP = {
    'drawer-open-count': 'drawerOpenCount',
    'cash-payment': 'cashPayment',
    'drawer-close-count': 'drawerCloseCount'
  };

  function getCashDrawerEventToggles() {
    return {
      drawerOpenCount: document.querySelector('#hardwareCashDrawerOpenCountToggle')?.checked !== false,
      cashPayment: document.querySelector('#hardwareCashDrawerPaymentToggle')?.checked !== false,
      drawerCloseCount: document.querySelector('#hardwareCashDrawerCloseCountToggle')?.checked !== false
    };
  }

  function setCashDrawerEventToggles(events = {}) {
    const openToggle = document.querySelector('#hardwareCashDrawerOpenCountToggle');
    const paymentToggle = document.querySelector('#hardwareCashDrawerPaymentToggle');
    const closeToggle = document.querySelector('#hardwareCashDrawerCloseCountToggle');
    if (openToggle) openToggle.checked = events.drawerOpenCount !== false;
    if (paymentToggle) paymentToggle.checked = events.cashPayment !== false;
    if (closeToggle) closeToggle.checked = events.drawerCloseCount !== false;
  }

  function setHardwareStatus(message, type = '') {
    const el = document.querySelector('#hardwareStatusMessage');
    if (!el) return;
    el.textContent = message || '';
    el.classList.toggle('success', type === 'success');
    el.classList.toggle('error', type === 'error');
    el.classList.toggle('hidden', !message);
  }

  function setActiveHardwareTab(tabName) {
    const isPrinter = tabName !== 'cashDrawer';
    document.querySelector('#hardwarePrinterTabBtn')?.classList.toggle('active', isPrinter);
    document.querySelector('#hardwareCashDrawerTabBtn')?.classList.toggle('active', !isPrinter);
    document.querySelector('#hardwarePrinterPanel')?.classList.toggle('hidden', !isPrinter);
    document.querySelector('#hardwareCashDrawerPanel')?.classList.toggle('hidden', isPrinter);
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function buildPrinterOptions(printers, selectedName, fallbackText) {
    if (!printers.length) return '<option value="">No se encontraron impresoras instaladas</option>';
    const options = printers.map((printer) => {
      const selected = printer.name === selectedName ? 'selected' : '';
      const badges = [];
      if (printer.isDefault) badges.push('Predeterminada');
      if (printer.isOffline) badges.push('Offline');
      const meta = badges.length ? ` · ${badges.join(' · ')}` : '';
      const label = `${printer.displayName || printer.name}${meta}`;
      return `<option value="${escapeHtml(printer.name)}" ${selected}>${escapeHtml(label)}</option>`;
    }).join('');
    if (selectedName && !printers.some((printer) => printer.name === selectedName)) {
      return `<option value="${escapeHtml(selectedName)}" selected>${escapeHtml(selectedName)} · guardada</option>${options}`;
    }
    return options || `<option value="">${escapeHtml(fallbackText || 'Selecciona una impresora')}</option>`;
  }

  async function loadHardwareModule() {
    const desktopApi = desktop();
    const desktopBadge = document.querySelector('#hardwareDesktopStatus');
    const receiptSelect = document.querySelector('#hardwareReceiptPrinterSelect');
    const cashDrawerSelect = document.querySelector('#hardwareCashDrawerPrinterSelect');
    const saleReceiptPrompt = document.querySelector('#hardwareSaleReceiptPromptToggle');
    const enabled = document.querySelector('#hardwareCashDrawerEnabledToggle');
    const kickHex = document.querySelector('#hardwareCashDrawerCommandInput');

    if (desktopBadge) desktopBadge.textContent = isDesktopReady() ? 'App Windows detectada' : 'Puente nativo no cargado';
    if (!isDesktopReady()) {
      const message = getDesktopMissingMessage();
      setHardwareStatus(message, 'error');
      for (const select of printerSelects()) select.innerHTML = '<option value="">Puente nativo no cargado</option>';
      return;
    }

    try {
      setHardwareStatus('Cargando impresoras instaladas en Windows...');
      const [printersResult, configResult] = await Promise.all([
        desktopApi.listPrinters(),
        desktopApi.getHardwareConfig()
      ]);
      const printers = printersResult?.printers || [];
      const config = configResult?.config || {};
      const receiptPrinterName = config.receiptPrinterName || '';
      const cashDrawerPrinterName = config.cashDrawerPrinterName || receiptPrinterName || '';

      if (receiptSelect) receiptSelect.innerHTML = buildPrinterOptions(printers, receiptPrinterName, 'Selecciona impresora de recibos');
      if (cashDrawerSelect) cashDrawerSelect.innerHTML = buildPrinterOptions(printers, cashDrawerPrinterName, 'Selecciona impresora de caja');
      if (saleReceiptPrompt) saleReceiptPrompt.checked = config.saleReceiptPromptEnabled !== false;
      if (enabled) enabled.checked = config.cashDrawerEnabled !== false;
      if (kickHex) kickHex.value = config.cashDrawerKickHex || '1B700019FA';
      setCashDrawerEventToggles(config.cashDrawerEvents || {});

      const offlineCount = printers.filter((printer) => printer.isOffline).length;
      const extra = offlineCount ? ` ${offlineCount} aparece(n) offline, pero igual se muestran para configuración.` : '';
      setHardwareStatus(printers.length ? `Se encontraron ${printers.length} impresora(s).${extra}` : 'Windows no reportó impresoras instaladas.', printers.length ? 'success' : 'error');
    } catch (error) {
      console.error('Error cargando hardware:', error);
      setHardwareStatus(error.message || 'No se pudo cargar hardware.', 'error');
    }
  }

  function openHardwareModule() {
    if (typeof closeModuleHub === 'function') closeModuleHub();
    const modal = document.querySelector('#hardwareModuleModal');
    if (!modal) return;
    if (window.ClubVersusCore?.modalManager?.open) {
      window.ClubVersusCore.modalManager.open(modal, { base: 9000 });
    } else {
      modal.classList.remove('hidden');
      modal.setAttribute('aria-hidden', 'false');
    }
    setActiveHardwareTab('printer');
    loadHardwareModule();
  }

  function closeHardwareModule() {
    if (typeof closeConfigModule === 'function') closeConfigModule('#hardwareModuleModal');
    else document.querySelector('#hardwareModuleModal')?.classList.add('hidden');
  }

  async function saveHardwareSettings() {
    if (!isDesktopReady()) {
      setHardwareStatus(getDesktopMissingMessage(), 'error');
      return null;
    }
    try {
      const receiptPrinterName = getReceiptPrinterName();
      const saleReceiptPromptEnabled = getSaleReceiptPromptEnabled();
      const cashDrawerPrinterName = getCashDrawerPrinterName();
      const cashDrawerEnabled = document.querySelector('#hardwareCashDrawerEnabledToggle')?.checked !== false;
      const cashDrawerKickHex = document.querySelector('#hardwareCashDrawerCommandInput')?.value || '1B700019FA';
      const cashDrawerEvents = getCashDrawerEventToggles();
      const result = await desktop().saveHardwareConfig({ receiptPrinterName, saleReceiptPromptEnabled, cashDrawerPrinterName, cashDrawerEnabled, cashDrawerKickHex, cashDrawerEvents });
      setHardwareStatus('Hardware guardado.', 'success');
      if (typeof showToast === 'function') showToast('Hardware guardado');
      return result;
    } catch (error) {
      setHardwareStatus(error.message || 'No se pudo guardar hardware.', 'error');
      return null;
    }
  }

  async function testReceiptPrinter() {
    if (!isDesktopReady()) return setHardwareStatus(getDesktopMissingMessage(), 'error');
    try {
      await saveHardwareSettings();
      await desktop().testReceiptPrinter({ printerName: getReceiptPrinterName() });
      setHardwareStatus('Prueba enviada a la impresora de recibos.', 'success');
    } catch (error) {
      setHardwareStatus(error.message || 'No se pudo imprimir prueba.', 'error');
    }
  }

  async function kickCashDrawer(reason = 'manual') {
    if (!isDesktopReady()) return { ok: false, skipped: true, message: 'Desktop no disponible' };
    try {
      const result = await desktop().kickCashDrawer({ reason, printerName: getCashDrawerPrinterName() });
      return result || { ok: true };
    } catch (error) {
      console.error('No se pudo abrir caja:', error);
      return { ok: false, message: error.message || 'No se pudo abrir caja' };
    }
  }

  async function testCashDrawer() {
    if (!isDesktopReady()) return setHardwareStatus(getDesktopMissingMessage(), 'error');
    try {
      await saveHardwareSettings();
      const result = await kickCashDrawer('test');
      if (!result.ok) throw new Error(result.message || 'No se pudo abrir caja');
      setHardwareStatus('Comando de apertura enviado a la caja.', 'success');
    } catch (error) {
      setHardwareStatus(error.message || 'No se pudo probar caja.', 'error');
    }
  }

  async function kickCashDrawerForEvent(eventName, options = {}) {
    const eventKey = CASH_DRAWER_EVENT_MAP[eventName] || eventName;
    const eventToggles = getCashDrawerEventToggles();
    if (eventKey && eventToggles[eventKey] === false) {
      return { ok: true, skipped: true, message: 'Evento de caja desactivado.' };
    }
    const result = await kickCashDrawer(eventName);
    if (!result.ok && !result.skipped && options.toast !== false && typeof showToast === 'function') {
      showToast(result.message || 'No se pudo abrir la caja automáticamente');
    }
    return result;
  }

  window.openHardwareModule = openHardwareModule;
  window.closeHardwareModule = closeHardwareModule;
  window.loadHardwareModule = loadHardwareModule;
  window.saveHardwareSettings = saveHardwareSettings;
  window.testReceiptPrinter = testReceiptPrinter;
  window.testCashDrawer = testCashDrawer;
  window.setActiveHardwareTab = setActiveHardwareTab;

  window.ClubVersusHardware = {
    isDesktopReady,
    openHardwareModule,
    closeHardwareModule,
    loadHardwareModule,
    saveHardwareSettings,
    testReceiptPrinter,
    testCashDrawer,
    shouldAskSaleReceipt,
    kickCashDrawerForEvent
  };

  window.ClubVersusModules.desktopHardware = window.ClubVersusHardware;
})();
