import fs from 'fs/promises';
import path from 'path';
import { app } from 'electron';

const DEFAULT_CONFIG = {
  receiptPrinterName: '',
  saleReceiptPromptEnabled: true,
  cashDrawerPrinterName: '',
  cashDrawerEnabled: true,
  cashDrawerKickHex: '1B700019FA',
  cashDrawerEvents: {
    drawerOpenCount: true,
    cashPayment: true,
    drawerCloseCount: true
  }
};

function getConfigPath() {
  return path.join(app.getPath('userData'), 'hardware-config.json');
}

export async function getHardwareConfig() {
  try {
    const raw = await fs.readFile(getConfigPath(), 'utf8');
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_CONFIG, ...(parsed || {}) };
  } catch (_error) {
    return { ...DEFAULT_CONFIG };
  }
}

export async function saveHardwareConfig(config = {}) {
  const current = await getHardwareConfig();
  const requestedEvents = config.cashDrawerEvents && typeof config.cashDrawerEvents === 'object' ? config.cashDrawerEvents : {};
  const nextEvents = {
    ...DEFAULT_CONFIG.cashDrawerEvents,
    ...(current.cashDrawerEvents || {}),
    drawerOpenCount: requestedEvents.drawerOpenCount !== false,
    cashPayment: requestedEvents.cashPayment !== false,
    drawerCloseCount: requestedEvents.drawerCloseCount !== false
  };
  const next = {
    ...current,
    receiptPrinterName: String(config.receiptPrinterName || '').trim(),
    saleReceiptPromptEnabled: config.saleReceiptPromptEnabled === undefined
      ? current.saleReceiptPromptEnabled !== false
      : config.saleReceiptPromptEnabled !== false,
    cashDrawerPrinterName: String(config.cashDrawerPrinterName || config.receiptPrinterName || '').trim(),
    cashDrawerEnabled: config.cashDrawerEnabled !== false,
    cashDrawerKickHex: String(config.cashDrawerKickHex || current.cashDrawerKickHex || DEFAULT_CONFIG.cashDrawerKickHex).replace(/[^0-9a-f]/gi, '').toUpperCase(),
    cashDrawerEvents: nextEvents
  };
  await fs.mkdir(path.dirname(getConfigPath()), { recursive: true });
  await fs.writeFile(getConfigPath(), JSON.stringify(next, null, 2), 'utf8');
  return next;
}
