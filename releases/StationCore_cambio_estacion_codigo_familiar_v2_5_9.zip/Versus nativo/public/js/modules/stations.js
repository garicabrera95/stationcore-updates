(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

function getStationMenuCategories() {
  const categories = [
    { id: 'TIME', label: 'Horas' },
    ...getProductCategories().filter((category) => category.is_active !== false && category.show_in_station !== false).map((category) => ({
      id: category.code,
      label: category.name,
      color: category.color,
      buttonSize: category.button_size
    }))
  ];
  const stationId = state.selectedStation?.id;
  const assignedExtras = (state.stationExtras || []).filter((extra) => extra.is_active !== false && (Array.isArray(extra.station_ids) ? extra.station_ids : []).map(String).includes(String(stationId)));
  if (assignedExtras.length) {
    categories.push({ id: 'EXTRAS', label: 'Extras', color: '#f59e0b', buttonSize: 'wide' });
  }
  if ((state.posTournaments || []).length) {
    categories.push({ id: 'TOURNAMENT', label: 'Torneos', color: '#8b5cf6', buttonSize: 'wide' });
  }
  return categories;
}

function getStationMembershipLogo(tier = '') {
  const key = getMembershipKey(tier);
  if (key === 'general') return '';
  return `/assets/memberships/${key}-logo.png`;
}

function getStationMembershipMarkup(station) {
  if (!station?.member_id || !station?.member_membership_active) {
    return '<div class="station-customer-pill membership-general">General</div>';
  }

  const membership = getMembershipLabel(station.member_membership_tier);
  const membershipKey = getMembershipKey(station.member_membership_tier);
  return `
    <div class="station-member-logo-wrap membership-${membershipKey}">
      <img src="${getStationMembershipLogo(station.member_membership_tier)}" alt="${membership}" />
      <span>${membership}</span>
    </div>
  `;
}

function canManageStations() {
  return state.user?.role === 'OWNER' || state.user?.role === 'MANAGER';
}

function getStationEmployeeMarkup(station) {
  const name = String(station?.session_started_by_name || '').trim();
  if (!name || station?.status !== 'BUSY') return '';
  return `<div class="station-employee-pill">${escapeHtml(name)}</div>`;
}

function getStationSessionBadgesMarkup(station) {
  const badges = [getStationMembershipMarkup(station), getStationEmployeeMarkup(station)].filter(Boolean).join('');
  if (!badges) return '';
  return `<div class="station-session-pills">${badges}</div>`;
}


function getStationExtraIcon(extra = {}) {
  const name = String(extra.name || '').toLowerCase();
  if (name.includes('racing') || name.includes('wheel') || name.includes('volante') || name.includes('carrera')) return '🏎️';
  if (name.includes('vr') || name.includes('realidad')) return '🥽';
  if (name.includes('stream') || name.includes('live')) return '📡';
  if (name.includes('control') || name.includes('mando')) return '🎮';
  return '⭐';
}

function getAssignedExtrasForStation(station) {
  if (!station?.id) return [];
  return (state.stationExtras || [])
    .filter((extra) => extra.is_active !== false)
    .filter((extra) => (Array.isArray(extra.station_ids) ? extra.station_ids : []).map(String).includes(String(station.id)))
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
}

function getStationExtrasBadgesMarkup(station) {
  const extras = getAssignedExtrasForStation(station);
  if (!extras.length) return '';
  const visible = extras.slice(0, 3).map((extra) => `
    <span class="station-extra-badge" title="${escapeAttr(extra.name || 'Extra')}">
      <b>${getStationExtraIcon(extra)}</b>${escapeHtml(extra.name || 'Extra')}
    </span>
  `).join('');
  const rest = extras.length > 3 ? `<span class="station-extra-badge station-extra-badge-more">+${extras.length - 3}</span>` : '';
  return `<div class="station-extra-badges">${visible}${rest}</div>`;
}



function getVersusMatchType(matchOrStation = {}) {
  return String(matchOrStation.match_type || matchOrStation.tournament_match_type || 'BRACKET').toUpperCase();
}

function getVersusBracketTotalRounds(matchOrStation = {}, matches = []) {
  const bracketMatches = (Array.isArray(matches) ? matches : [])
    .filter((match) => getVersusMatchType(match) !== 'THIRD_PLACE')
    .filter((match) => Number(match.round_number || 0) > 0);

  if (bracketMatches.length) {
    const roundCounts = bracketMatches.reduce((counts, match) => {
      const round = Number(match.round_number || 0);
      counts[round] = (counts[round] || 0) + 1;
      return counts;
    }, {});
    return Object.entries(roundCounts).reduce((total, [round, count]) => {
      const estimated = Number(round) + Math.ceil(Math.log2(Math.max(1, Number(count || 1))));
      return Math.max(total, estimated);
    }, 1);
  }

  const stationTotal = Number(matchOrStation.tournament_total_bracket_rounds || 0);
  if (stationTotal > 0) return stationTotal;
  return 0;
}

function getVersusMatchRoundNumber(matchOrStation = {}) {
  return Number(matchOrStation.round_number || matchOrStation.tournament_round_number || 0);
}

function getVersusMatchStageLabel(matchOrStation = {}, matches = []) {
  if (getVersusMatchType(matchOrStation) === 'THIRD_PLACE') return 'Partido por 3er lugar';
  const roundNumber = getVersusMatchRoundNumber(matchOrStation);
  const totalRounds = getVersusBracketTotalRounds(matchOrStation, matches);
  if (totalRounds > 0 && roundNumber === totalRounds) return 'Final';
  if (totalRounds > 0 && roundNumber === totalRounds - 1) return 'Semifinal';
  return roundNumber ? `Ronda ${roundNumber}` : 'Partida Versus';
}

function getStationTournamentMeta(station) {
  const tournamentName = station?.tournament_name || 'Torneo';
  const matches = state.activeVersus?.matches || [];
  return `${tournamentName} · ${getVersusMatchStageLabel(station, matches)}`;
}

function getSessionRemainingMs(station) {
  if (!station?.started_at || !station?.prepaid_minutes) return null;
  const started = new Date(station.started_at).getTime();
  const totalMs = Number(station.prepaid_minutes || 0) * 60000;
  return Math.max(0, started + totalMs - Date.now());
}


function getVersusPendingAwardsCount(versus) {
  const awards = Array.isArray(versus?.awards) ? versus.awards : [];
  return awards.filter((award) => ['cash_status', 'membership_status', 'bonus_status', 'goods_status'].some((key) => award?.[key] === 'PENDING')).length;
}

function getFinishedPosTournamentForVersusBoard() {
  return (state.posTournaments || []).find((tournament) => {
    if (String(tournament?.status || '').toUpperCase() !== 'FINISHED') return false;
    if (tournament?.versus_closed_at) return false;
    if (!tournament?.winner_name && !tournament?.winner_participant_id) return false;
    if (!tournament?.versus_visible_until) return true;
    const visibleUntil = new Date(tournament.versus_visible_until).getTime();
    return Number.isNaN(visibleUntil) || visibleUntil >= Date.now();
  }) || null;
}

function renderFinishedVersusBoard(board, tournament, pendingAwardsCount = 0) {
  board.classList.remove('hidden');
  board.classList.add('versus-finished');
  board.innerHTML = `
    <div class="versus-board-head">
      <div>
        <span class="versus-kicker">TORNEO FINALIZADO</span>
        <h3>${escapeHtml(tournament.name || 'Torneo')}</h3>
        <p>${escapeHtml(tournament.game || '')} · ${escapeHtml(tournament.platform || 'Multiplataforma')}</p>
      </div>
      <div class="versus-stats">
        <article><span>Campeón</span><strong>🏆</strong></article>
        <article><span>Premios</span><strong>${pendingAwardsCount}</strong></article>
      </div>
    </div>
    <section class="versus-champion-card">
      <span>Ganador oficial</span>
      <strong>${escapeHtml(tournament.winner_name || 'Campeón')}</strong>
      <button type="button" data-versus-awards="${escapeAttr(tournament.id)}">${pendingAwardsCount > 0 ? `Entregar premios (${pendingAwardsCount})` : 'Entregar premios'}</button>
    </section>
  `;
  board.querySelector('[data-versus-awards]')?.addEventListener('click', (event) => openVersusAwardsDelivery(event.currentTarget.dataset.versusAwards));
}

async function openVersusAwardsDelivery(tournamentId) {
  if (!tournamentId) return showToast('Selecciona un torneo');
  if (typeof window.openTournamentAwardsDelivery === 'function') {
    await window.openTournamentAwardsDelivery(tournamentId);
    return;
  }
  try {
    await api(`/tournaments/${tournamentId}/awards/auto`, { method: 'POST' });
    showToast('Premios listos para entregar');
  } catch (error) {
    showToast(error.message || 'No se pudieron preparar los premios');
  }
}

async function confirmVersusWinner(winnerName, opponentName) {
  const dialog = window.ClubVersusCore?.modalManager?.showAppDialog;
  if (typeof dialog !== 'function') return window.confirm(`¿Registrar que ganó ${winnerName}?`);
  const response = await dialog({
    title: `Ganó ${winnerName}`,
    subtitle: 'Confirmar ganador de la partida Versus',
    message: opponentName ? `${winnerName} avanzará sobre ${opponentName}.` : 'Esta acción avanzará el bracket.',
    primaryText: 'Confirmar ganador',
    secondaryText: 'Cancelar'
  });
  return response === 'primary';
}

function getStationTimeState(station) {
  const remainingMs = getSessionRemainingMs(station);
  if (remainingMs === null || station.status !== 'BUSY') return 'normal';
  if (remainingMs <= 0) return 'expired';
  if (remainingMs <= 5 * 60000) return 'warning';
  return 'busy-active';
}

async function loadStations() {
  const { stations, versus } = await api('/stations');
  state.stations = stations || [];
  state.activeVersus = versus || null;
  renderVersusBoard();
  renderStations(state.stations);
}

function renderVersusBoard() {
  const board = $('#versusBoard');
  if (!board) return;
  const versus = state.activeVersus;
  if (!versus?.tournament) {
    const finishedTournament = getFinishedPosTournamentForVersusBoard();
    if (finishedTournament) {
      renderFinishedVersusBoard(board, finishedTournament, Number(finishedTournament.pending_award_count || 0));
      return;
    }
    board.classList.add('hidden');
    board.classList.remove('versus-finished');
    board.innerHTML = '';
    return;
  }

  const tournament = versus.tournament;
  const active = versus.activeMatches || [];
  const pending = versus.pendingMatches || [];
  const waiting = versus.waitingAdvancers || [];
  const last = versus.lastResults || [];
  const nextRows = pending.slice(0, 4).map((match) => `
    <div class="versus-mini-row">
      <span>${escapeHtml(getVersusMatchStageLabel(match, versus.matches))}</span>
      <strong>${match.player1_name || 'Jugador 1'} VS ${match.player2_name || 'Jugador 2'}</strong>
      <em>${match.station_name ? match.station_name : 'En cola'}</em>
    </div>
  `).join('');
  const activeRows = active.slice(0, 4).map((match) => `
    <div class="versus-mini-row live">
      <span>${escapeHtml(getVersusMatchStageLabel(match, versus.matches))}</span>
      <strong>${match.player1_name || 'Jugador 1'} VS ${match.player2_name || 'Jugador 2'}</strong>
      <em>${match.station_name || 'Estación'}</em>
    </div>
  `).join('');
  const waitingRows = waiting.slice(0, 3).map((item) => `
    <div class="versus-mini-row waiting">
      <span>Espera</span>
      <strong>${item.player_name || 'Jugador'}</strong>
      <em>${item.message || ''}</em>
    </div>
  `).join('');
  const lastRows = last.slice(0, 2).map((match) => `
    <div class="versus-result-pill">${match.winner_name || 'Ganador'} ganó vs ${String(match.winner_participant_id) === String(match.player1_participant_id) ? (match.player2_name || 'Jugador') : (match.player1_name || 'Jugador')}</div>
  `).join('');
  const isFinished = tournament.status === 'FINISHED' || Boolean(tournament.winner_participant_id || tournament.winner_name);
  const pendingAwardsCount = getVersusPendingAwardsCount(versus);

  board.classList.remove('hidden');
  board.classList.toggle('versus-finished', isFinished);
  if (isFinished) {
    renderFinishedVersusBoard(board, tournament, pendingAwardsCount);
    return;
  }

  board.innerHTML = `
    <div class="versus-board-head">
      <div>
        <span class="versus-kicker">MODO VERSUS ACTIVO</span>
        <h3>${tournament.name || 'Torneo'}</h3>
        <p>${tournament.game || ''} · ${tournament.platform || 'Multiplataforma'}</p>
      </div>
      <div class="versus-stats">
        <article><span>En juego</span><strong>${active.length}</strong></article>
        <article><span>En cola</span><strong>${pending.length}</strong></article>
      </div>
    </div>
    ${lastRows ? `<div class="versus-results-strip">${lastRows}</div>` : ''}
    <div class="versus-flow-grid">
      <section><h4>En juego</h4>${activeRows || '<p>Sin partidas activas</p>'}</section>
      <section><h4>Próximos VS</h4>${nextRows || '<p>Esperando cruces</p>'}</section>
      <section><h4>Esperando rival</h4>${waitingRows || '<p>Sin jugadores esperando</p>'}</section>
    </div>
  `;
}

async function startVersusMode() {
  if (!state.selectedTournamentId) return showToast('Selecciona un torneo');
  try {
    const result = await api(`/tournaments/${state.selectedTournamentId}/versus/start`, { method: 'POST' });
    showToast(`Modo Versus iniciado${Number(result.assigned || 0) ? ` · ${result.assigned} partida(s) asignada(s)` : ''}`);
    await loadStations().catch(() => {});
    await loadTournaments();
    await loadTournamentDetail(state.selectedTournamentId);
  } catch (error) {
    showToast(error.message || 'No se pudo iniciar Modo Versus');
  }
}

async function setVersusStationWinner(tournamentId, matchId, winnerParticipantId) {
  if (!tournamentId || !matchId || !winnerParticipantId) return;
  try {
    const result = await api(`/tournaments/${tournamentId}/matches/${matchId}/winner`, {
      method: 'PATCH',
      body: JSON.stringify({ winnerParticipantId })
    });
    const finished = result?.tournament?.status === 'FINISHED';
    showToast(finished ? 'Torneo finalizado · campeón registrado' : 'Ganador registrado y próxima partida asignada');
    await loadStations().catch(() => {});
    if (typeof loadPosTournaments === 'function') await loadPosTournaments().catch(() => {});
    if (typeof loadTournaments === 'function') await loadTournaments().catch(() => {});
  } catch (error) {
    showToast(error.message || 'No se pudo registrar ganador');
  }
}

function renderStations(stations) {
  const grid = $('#stationsGrid');
  if (!grid) return;
  grid.innerHTML = '';

  if (!Array.isArray(stations) || stations.length === 0) {
    grid.innerHTML = '<div class="stations-empty">No hay estaciones configuradas</div>';
    return;
  }

  stations.forEach((station) => {
    const status = station.status.toLowerCase();
    const consoleClass = getConsoleClass(station.console_type);
    const timeState = getStationTimeState(station);
    const remainingMs = getSessionRemainingMs(station);
    const isBusy = station.status === 'BUSY';
    const isTournamentBusy = Boolean(station.tournament_match_id);
    const sessionGame = getSelectedSessionGame(station);
    const playingNow = getStationPlayingNowMarkup(sessionGame, station);
    const card = document.createElement('article');

    card.className = `station-card ${status} ${consoleClass} station-time-${timeState}`;
    card.innerHTML = `
      <div class="station-top">
        <div class="station-title">
          <span class="status-pill ${status}">${isTournamentBusy ? 'TORNEO' : getStatusLabel(station.status)}</span>
          <h3>${station.name}</h3>
          <div class="console-name">${station.console_type}</div>
        </div>
        <div class="console-badge brand-badge">${getConsoleLogo(station.console_type)}</div>
      </div>
      ${getStationExtrasBadgesMarkup(station)}

      <div class="station-body">
        ${isTournamentBusy ? `
          <div class="station-timer-label">MODO VERSUS</div>
          <div class="station-tournament-label">${station.tournament_player1_name || 'Jugador 1'} vs ${station.tournament_player2_name || 'Jugador 2'}</div>
          <div class="station-meta">${escapeHtml(getStationTournamentMeta(station))}</div>
          ${getStationEmployeeMarkup(station)}
          <div class="station-versus-actions">
            <button type="button" data-versus-winner="${station.tournament_player1_participant_id || ''}" data-versus-match="${station.tournament_match_id || ''}" data-versus-tournament="${station.tournament_id || ''}">Ganó ${station.tournament_player1_name || 'J1'}</button>
            <button type="button" data-versus-winner="${station.tournament_player2_participant_id || ''}" data-versus-match="${station.tournament_match_id || ''}" data-versus-tournament="${station.tournament_id || ''}">Ganó ${station.tournament_player2_name || 'J2'}</button>
          </div>
        ` : isBusy && isStationOpenMode(station) ? `
          ${playingNow}
          <div class="station-timer-label">MODO LIBRE</div>
          <div class="station-timer" data-station-timer="elapsed" data-station-id="${escapeAttr(station.id)}">${formatDuration(getOpenModeElapsedMs(station))}</div>
          <div class="station-meta" data-station-open-charge="${escapeAttr(station.id)}">Cobro aprox: ${money(getOpenModeChargePreview(station).amount)}</div>
          ${getStationSessionBadgesMarkup(station)}
        ` : isBusy ? `
          ${playingNow}
          <div class="station-timer-label">TIEMPO RESTANTE</div>
          <div class="station-timer" data-station-timer="remaining" data-station-id="${escapeAttr(station.id)}">${formatDuration(remainingMs)}</div>
          <div class="station-meta station-meta-spacer" aria-hidden="true">&nbsp;</div>
          ${getStationSessionBadgesMarkup(station)}
        ` : `
          <div class="station-idle-space"></div>
        `}
      </div>
    `;

    card.addEventListener('click', () => {
      if (station.status === 'MAINTENANCE' || station.status === 'OFFLINE') return showToast('Estación no disponible');
      if (isTournamentBusy) return showToast('Usa los botones de ganador para controlar esta partida Versus');
      if (!state.drawer && station.status !== 'BUSY' && !requireOpenDrawerForSales(true)) return;
      openStationModal(station.id);
    });
    card.querySelectorAll('[data-versus-winner]').forEach((btn) => {
      btn.addEventListener('click', async (event) => {
        event.stopPropagation();
        const winnerName = btn.textContent.replace('Ganó ', '').trim();
        const buttons = Array.from(card.querySelectorAll('[data-versus-winner]'));
        const opponentBtn = buttons.find((item) => item !== btn);
        const opponentName = opponentBtn ? opponentBtn.textContent.replace('Ganó ', '').trim() : '';
        const confirmed = await confirmVersusWinner(winnerName, opponentName);
        if (confirmed) {
          setVersusStationWinner(btn.dataset.versusTournament, btn.dataset.versusMatch, btn.dataset.versusWinner);
        }
      });
    });
    grid.appendChild(card);
  });

  checkStationTimeAlerts();
}

function updateStationLiveTimers() {
  const cards = document.querySelectorAll('#stationsGrid .station-card');
  if (!cards.length || !Array.isArray(state.stations)) return;

  cards.forEach((card) => {
    const timer = card.querySelector('[data-station-timer]');
    if (!timer) return;
    const station = state.stations.find((item) => String(item.id) === String(timer.dataset.stationId));
    if (!station) return;

    const mode = timer.dataset.stationTimer;
    if (mode === 'elapsed') {
      timer.textContent = formatDuration(getOpenModeElapsedMs(station));
      const chargeLabel = Array.from(card.querySelectorAll('[data-station-open-charge]')).find((item) => String(item.dataset.stationOpenCharge) === String(station.id));
      if (chargeLabel) chargeLabel.textContent = `Cobro aprox: ${money(getOpenModeChargePreview(station).amount)}`;
      return;
    }

    const remainingMs = getSessionRemainingMs(station);
    if (remainingMs === null) return;
    timer.textContent = formatDuration(remainingMs);

    card.classList.remove('station-time-normal', 'station-time-busy-active', 'station-time-warning', 'station-time-expired');
    card.classList.add(`station-time-${getStationTimeState(station)}`);
  });

  checkStationTimeAlerts();
}

if (!window.__arenaOsStationTimerInterval) {
  window.__arenaOsStationTimerInterval = window.setInterval(updateStationLiveTimers, 1000);
}

function checkStationTimeAlerts() {
  if (!Array.isArray(state.stations)) return;

  state.stations.forEach((station) => {
    const remainingMs = getSessionRemainingMs(station);
    if (remainingMs === null || station.status !== 'BUSY' || !station.active_session_id) return;

    if (remainingMs > 5 * 60000) {
      state.timeAlertedSessions.delete(station.active_session_id);
      return;
    }

    if (remainingMs <= 5 * 60000 && remainingMs > 0 && !state.timeAlertedSessions.has(station.active_session_id)) {
      state.timeAlertedSessions.add(station.active_session_id);
      openTimeWarning(station, false);
    }

    if (remainingMs <= 0 && !state.timeAlertedSessions.has(`${station.active_session_id}:ended`)) {
      state.timeAlertedSessions.add(`${station.active_session_id}:ended`);
      openTimeWarning(station, true);
    }
  });
}

function openStationsConfigModule() {
  if (!canManageStations()) return showToast('No tienes permiso');
  closeModuleHub();
  document.documentElement.classList.add('cv-config-module-open');
  document.body.classList.add('cv-config-module-open');
  resetStationConfigForm();
  resetStationExtraForm();
  $('#stationsConfigModal').classList.remove('hidden');
  $('#stationsConfigModal').setAttribute('aria-hidden', 'false');
}

function closeStationsConfigModule() {
  closeConfigModule('#stationsConfigModal');
}

function openStationConfigEditorModal() {
  const modal = $('#stationConfigEditorModal');
  if (modal) openModalElement(modal, { base: 2147482900 });
}

function closeStationConfigEditorModal() {
  const modal = $('#stationConfigEditorModal');
  if (modal) closeModalElement(modal);
}

function openStationGamesConfigModal() {
  renderStationGamesConfigModule();
  const modal = $('#stationGamesConfigModal');
  if (modal) openModalElement(modal, { base: 2147482850 });
}

function closeStationGamesConfigModal() {
  const modal = $('#stationGamesConfigModal');
  if (modal) closeModalElement(modal);
  closeStationGameEditorModal();
  closeGameDevicesModal();
}

function openGameDevicesModal() {
  renderGameDevicesModule();
  resetGameDeviceForm(false);
  const modal = $('#gameDevicesModal');
  if (modal) openModalElement(modal, { base: 2147482925 });
}

function closeGameDevicesModal() {
  const modal = $('#gameDevicesModal');
  if (modal) closeModalElement(modal);
}

function openStationGameEditorModal() {
  const modal = $('#stationGameEditorModal');
  if (modal) openModalElement(modal, { base: 2147482920 });
}

function closeStationGameEditorModal() {
  const modal = $('#stationGameEditorModal');
  if (modal) closeModalElement(modal);
}

function openStationExtrasConfigModal() {
  renderStationExtrasConfigModule();
  const modal = $('#stationExtrasConfigModal');
  if (modal) openModalElement(modal, { base: 2147482850 });
}

function closeStationExtrasConfigModal() {
  const modal = $('#stationExtrasConfigModal');
  if (modal) closeModalElement(modal);
  closeStationExtraEditorModal();
}

function openStationExtraEditorModal() {
  const modal = $('#stationExtraEditorModal');
  if (modal) openModalElement(modal, { base: 2147482920 });
}

function closeStationExtraEditorModal() {
  const modal = $('#stationExtraEditorModal');
  if (modal) closeModalElement(modal);
}

function openNewStationConfigModal() {
  resetStationConfigForm();
  openStationConfigEditorModal();
}

function resetStationConfigForm() {
  state.selectedStationConfigId = null;
  $('#stationConfigFormTitle').textContent = 'Nueva estación';
  $('#stationConfigNameInput').value = `Estación ${state.stations.length + 1}`;
  $('#stationConfigPlatformSelect').value = 'PlayStation';
  renderStationModelOptions('PlayStation', 'PlayStation 4');
  $('#stationConfigOrderInput').value = String((state.stations.length + 1) * 10);
  $('#stationConfigStatusSelect').value = 'AVAILABLE';
  const deleteBtn = $('#deleteStationConfigBtn');
  if (deleteBtn) deleteBtn.classList.add('hidden');
  renderStationsConfigModule();
  renderStationGamesConfigModule();
  renderStationExtrasConfigModule();
}

function renderStationModelOptions(platform, selectedModel) {
  const select = $('#stationConfigModelSelect');
  if (!select) return;
  const models = getPlatformModels(platform);
  select.innerHTML = models.map((model) => `<option value="${model}">${model}</option>`).join('');
  select.value = models.includes(selectedModel) ? selectedModel : models[0];
}

function selectStationConfig(stationId) {
  const station = state.stations.find((item) => item.id === stationId);
  if (!station) return;
  state.selectedStationConfigId = station.id;
  const platform = getPlatform(station.console_type);
  $('#stationConfigFormTitle').textContent = station.name;
  $('#stationConfigNameInput').value = station.name;
  $('#stationConfigPlatformSelect').value = platform;
  renderStationModelOptions(platform, station.console_type);
  $('#stationConfigOrderInput').value = String(station.sort_order || 0);
  $('#stationConfigStatusSelect').value = station.status === 'BUSY' ? 'AVAILABLE' : station.status;
  const deleteBtn = $('#deleteStationConfigBtn');
  if (deleteBtn) deleteBtn.classList.remove('hidden');
  renderStationsConfigModule();
  renderStationGamesConfigModule();
  renderStationExtrasConfigModule();
  openStationConfigEditorModal();
}

function renderStationsConfigModule() {
  const list = $('#stationsConfigList');
  if (!list) return;
  $('#stationsConfigCount').textContent = `${state.stations.length} estaciones`;



  list.innerHTML = state.stations.map((station) => {
    const consoleClass = getConsoleClass(station.console_type);
    return `
      <button type="button" class="station-config-row ${consoleClass} ${station.id === state.selectedStationConfigId ? 'active-selection' : ''}" data-station-config-id="${station.id}">
        <span class="mini-brand-badge">${getConsoleLogo(station.console_type)}</span>
        <span>
          <strong>${station.name}</strong>
          <small>${station.console_type}</small>
        </span>
        <em>${getStatusLabel(station.status)}</em>
      </button>
    `;
  }).join('');

  list.querySelectorAll('[data-station-config-id]').forEach((btn) => {
    btn.addEventListener('click', () => selectStationConfig(btn.dataset.stationConfigId));
  });
  renderStationGamesConfigModule();
}



const GAME_COMPATIBLE_CONSOLES = ['PlayStation 4', 'PlayStation 5', 'Xbox One', 'Xbox Series', 'Nintendo Switch'];
function getReservationConsoleLabel(consoleName = '') {
  const value = String(consoleName || '');
  if (value === 'PlayStation 4') return 'PS4';
  if (value === 'PlayStation 5') return 'PS5';
  if (value === 'Xbox Series') return 'Xbox Series';
  if (value === 'Nintendo Switch') return 'Nintendo Switch';
  return value || 'Plataforma';
}
const GAME_LOCATION_TYPES = ['Instalado en consola', 'Disco físico', 'Cartucho', 'SSD externo', 'Disco duro externo', 'Micro SD', 'Cuenta/perfil específico', 'No instalado'];
const GAME_LOCATION_STATUSES = ['Disponible', 'No instalado', 'Actualización pendiente'];

function getGameCompatibleConsoles(game = {}) {
  if (Array.isArray(game.compatible_consoles) && game.compatible_consoles.length) return game.compatible_consoles;
  if (Array.isArray(game.compatibleConsoles) && game.compatibleConsoles.length) return game.compatibleConsoles;
  const platform = String(game.platform || 'Multiplataforma').toLowerCase();
  if (platform.includes('playstation 4') || platform.includes('ps4')) return ['PlayStation 4'];
  if (platform.includes('playstation 5') || platform.includes('ps5')) return ['PlayStation 5'];
  if (platform.includes('playstation')) return ['PlayStation 4', 'PlayStation 5'];
  if (platform.includes('xbox')) return ['Xbox One', 'Xbox Series'];
  if (platform.includes('switch') || platform.includes('nintendo')) return ['Nintendo Switch'];
  return [...GAME_COMPATIBLE_CONSOLES];
}

function getSelectedGameCompatibilityValues() {
  return Array.from(document.querySelectorAll('[data-station-game-console]:checked')).map((input) => input.value);
}

function setSelectedGameCompatibilityValues(values = []) {
  const selected = new Set((Array.isArray(values) && values.length ? values : GAME_COMPATIBLE_CONSOLES).map(String));
  document.querySelectorAll('[data-station-game-console]').forEach((input) => {
    input.checked = selected.has(input.value);
  });
}

function getGameCopySummary(game = {}) {
  if (game.unlimited_copies === true || game.unlimitedCopies === true) return 'Ilimitado';
  const copies = Math.max(0, Number(game.copy_quantity ?? game.copyQuantity ?? 1));
  const active = Math.max(0, Number(game.active_sessions_count ?? game.activeSessionsCount ?? 0));
  const available = Math.max(0, Number(game.available_copies ?? game.availableCopies ?? (copies - active)));
  return `${available}/${copies} disponible${copies === 1 ? '' : 's'}`;
}

function getGameAvailabilityInfo(game = {}, station = state.selectedStation) {
  const compatible = isGameCompatibleWithStation(game, station);
  const currentId = state.order?.gameId || station?.session_game_id || null;
  const isCurrentSelection = currentId && String(currentId) === String(game.id);
  if (!compatible) return { compatible: false, selectable: false, label: 'No compatible', reason: getGameLocationMessage(game, station) || 'No instalado para esta consola' };
  if (game.unlimited_copies === true || game.unlimitedCopies === true) return { compatible: true, selectable: true, label: 'Ilimitado', reason: getGameLocationMessage(game, station) || 'Juego digital/gratis' };
  const copies = Math.max(0, Number(game.copy_quantity ?? game.copyQuantity ?? 1));
  const active = Math.max(0, Number(game.active_sessions_count ?? game.activeSessionsCount ?? 0));
  const available = Math.max(0, Number(game.available_copies ?? game.availableCopies ?? (copies - active)));
  if (available <= 0 && !isCurrentSelection) {
    return { compatible: true, selectable: false, label: `En uso · 0 disponibles`, reason: 'Todas las copias están ocupadas' };
  }
  return { compatible: true, selectable: true, label: `${available}/${copies} disponible${copies === 1 ? '' : 's'}`, reason: getGameLocationMessage(game, station) || (active > 0 ? `${active} en uso` : 'Disponible ahora') };
}

function getStationGameIcon(game = {}) {
  const name = String(game.name || '').toLowerCase();
  if (name.includes('gta')) return '🚗';
  if (name.includes('warzone') || name.includes('fortnite')) return '🔫';
  if (name.includes('fifa') || name.includes('fc') || name.includes('mlb')) return '🏟️';
  if (name.includes('mario') || name.includes('kart')) return '🏁';
  if (name.includes('smash')) return '⚔️';
  return '🎮';
}

function getStationGameCoverMarkup(game = {}, extraClass = '') {
  const cover = String(game.cover_url || game.coverUrl || '').trim();
  if (cover) {
    return `<span class="station-game-cover ${extraClass}" style="background-image:url('${escapeAttr(cover)}')"></span>`;
  }
  return `<span class="station-game-cover station-game-cover-fallback ${extraClass}">${getStationGameIcon(game)}</span>`;
}


function getGameHighlightLabel(game = {}) {
  const value = String(game.highlight_type || game.highlightType || 'NORMAL').toUpperCase();
  const map = {
    NORMAL: '',
    DESTACADO: 'Destacado',
    JUEGO_DEL_MES: 'Juego del mes',
    LANZAMIENTO: 'Lanzamiento',
    PREMIUM: 'Premium',
    ALTA_DEMANDA: 'Alta demanda'
  };
  return map[value] || value.replace(/_/g, ' ').toLowerCase();
}

function getStationPlayingNowMarkup(game = {}, station = {}) {
  if (!game?.name) return '';
  const platform = game.platform || station.console_type || '';
  return `
    <div class="station-playing-now">
      <div class="station-playing-label">Jugando ahora</div>
      <div class="station-playing-card">
        ${getStationGameCoverMarkup(game, 'playing')}
        <div class="station-playing-info">
          <strong>${escapeHtml(game.name)}</strong>
          <span>${escapeHtml(platform)}</span>
        </div>
      </div>
    </div>
  `;
}

function normalizeSavedGameText(value = '') {
  return String(value || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function getSavedGameAlertKey(memberId, gameId, stationId) {
  return [memberId || 'general', gameId || 'sin-juego', stationId || 'sin-estacion'].join(':');
}

function shouldShowSavedGameAlertForGame(game = {}) {
  return Boolean(game?.is_story_mode || game?.isStoryMode || game?.requires_profile_alert || game?.requiresProfileAlert);
}

function matchSavedGameForSelectedGame(savedGames = [], game = {}, station = {}) {
  if (!game?.name) return null;
  const gameName = normalizeSavedGameText(game.name);
  const gamePlatform = normalizeSavedGameText(game.platform || station?.console_type || '');
  return (savedGames || []).find((saved) => {
    const status = String(saved.status || '').toUpperCase();
    if (status && status !== 'ACTIVE') return false;
    const sameId = saved.game_id && game.id && String(saved.game_id) === String(game.id);
    const savedName = normalizeSavedGameText(saved.game_name || saved.catalog_game_name || '');
    const sameName = savedName && gameName && savedName === gameName;
    if (!sameId && !sameName) return false;
    const savedPlatform = normalizeSavedGameText(saved.platform || saved.station_console_type || '');
    return !savedPlatform || !gamePlatform || savedPlatform === gamePlatform || savedPlatform.includes(gamePlatform) || gamePlatform.includes(savedPlatform);
  }) || null;
}

function getSelectedMemberName() {
  return state.selectedMember?.full_name || state.selectedMember?.name || state.selectedStation?.member_name || 'Miembro';
}

function normalizeSavedGameTier(value = '') {
  return String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_');
}

function getMembershipPlanForSavedGameBenefit(member = state.selectedMember) {
  const tier = normalizeSavedGameTier(member?.membership_tier || '');
  return (state.membershipPlans || []).find((plan) => normalizeSavedGameTier(plan.code) === tier) || null;
}

function getSavedGameBenefitConfig(member = state.selectedMember) {
  const plan = getMembershipPlanForSavedGameBenefit(member);
  if (!member?.membership_active || !plan) {
    return {
      limit: 0,
      unlimited: false,
      canSave: false,
      message: 'Este cliente puede usar perfil invitado. Las partidas guardadas dependen de la membresía configurada.'
    };
  }
  const enabled = plan.saved_game_enabled === true;
  const unlimited = enabled && plan.saved_game_unlimited === true;
  const rawLimit = Number(plan.saved_game_limit || 0);
  const limit = enabled ? (unlimited ? 999 : Math.max(0, rawLimit)) : 0;
  const message = String(plan.saved_game_upgrade_message || '').trim() || (limit > 0
    ? `${plan.name || plan.code} permite guardar partidas según la configuración del POS.`
    : 'Esta membresía no tiene partidas guardadas activas.');
  return { limit, unlimited, canSave: limit > 0, message, plan };
}

function getSavedGameLimitForSelectedMember(member = state.selectedMember) {
  return getSavedGameBenefitConfig(member).limit;
}

function getActiveSavedGamesCount(savedGames = []) {
  return (savedGames || []).filter((item) => String(item.status || '').toUpperCase() === 'ACTIVE').length;
}

function getSavedGameBenefitInfo(member = state.selectedMember, savedGames = []) {
  const config = getSavedGameBenefitConfig(member);
  const activeCount = getActiveSavedGamesCount(savedGames);
  const canCreate = config.limit > 0 && (config.unlimited || activeCount < config.limit);
  let message = config.message;
  if (config.limit > 0 && !config.unlimited && activeCount >= config.limit) {
    message = `Límite alcanzado: ${activeCount}/${config.limit} partida(s) guardada(s).`;
  }
  return { limit: config.limit, activeCount, canCreate, message, unlimited: config.unlimited, plan: config.plan };
}

function getSuggestedConsoleProfileName(member = state.selectedMember) {
  const raw = String(member?.portal_username || member?.full_name || member?.name || 'Jugador').trim();
  const clean = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]+/g, '').slice(0, 18) || 'Jugador';
  return `CV_${clean}`;
}

function setSavedGameAlertFooter(html = '') {
  const footer = $('#savedGameAlertActions');
  if (footer) footer.innerHTML = html;
}

function renderSavedGameUpgradeNotice({ game = {}, savedGames = [] } = {}) {
  const title = $('#savedGameAlertTitle');
  const subtitle = $('#savedGameAlertSubtitle');
  const body = $('#savedGameAlertBody');
  const benefit = getSavedGameBenefitInfo(state.selectedMember, savedGames);
  if (!title || !subtitle || !body) return;
  title.textContent = 'Beneficio de membresía';
  subtitle.textContent = `${getSelectedMemberName()} no puede crear otra partida guardada ahora.`;
  body.innerHTML = `
    <div class="saved-game-alert-empty saved-game-benefit-card">
      ${getStationGameCoverMarkup(game, 'saved-alert')}
      <div>
        <strong>Activa un beneficio de partidas guardadas</strong>
        <span>Guarda tu progreso de ${escapeHtml(game?.name || 'este juego')} según la membresía configurada en el POS.</span>
      </div>
    </div>
    <div class="saved-game-alert-note"><b>Regla actual</b><span>${escapeHtml(benefit.message)}</span></div>
    <p class="saved-game-alert-message">La cajera puede continuar con perfil invitado y ofrecer el upgrade sin salir de la estación.</p>
  `;
  setSavedGameAlertFooter(`
    <button id="savedGameGuestBtn" type="button" class="secondary">Usar perfil invitado</button>
    <button id="savedGameAlertOkBtn" type="button">Entendido</button>
  `);
  $('#savedGameGuestBtn')?.addEventListener('click', closeSavedGameAlertModal);
  $('#savedGameAlertOkBtn')?.addEventListener('click', closeSavedGameAlertModal);
}

function renderSavedGameCreateForm({ game = {}, savedGames = [] } = {}) {
  const title = $('#savedGameAlertTitle');
  const subtitle = $('#savedGameAlertSubtitle');
  const body = $('#savedGameAlertBody');
  const station = state.selectedStation || {};
  const benefit = getSavedGameBenefitInfo(state.selectedMember, savedGames);
  if (!title || !subtitle || !body) return;

  if (!benefit.canCreate) {
    renderSavedGameUpgradeNotice({ game, savedGames });
    return;
  }

  title.textContent = 'Crear partida guardada';
  subtitle.textContent = `Guarda el perfil de ${getSelectedMemberName()} para ${game?.name || 'este juego'}.`;
  const suggestedProfile = getSuggestedConsoleProfileName(state.selectedMember);
  body.innerHTML = `
    <div class="saved-game-alert-empty">
      ${getStationGameCoverMarkup(game, 'saved-alert')}
      <div>
        <strong>${escapeHtml(game?.name || 'Juego')}</strong>
        <span>${escapeHtml(station.console_type || game?.platform || 'Plataforma')}</span>
      </div>
    </div>
    <div class="quick-saved-game-form">
      <label><span>Perfil en consola</span><input id="quickSavedGameProfileInput" type="text" value="${escapeAttr(suggestedProfile)}" autocomplete="off" /></label>
      <label><span>Estación</span><input type="text" value="${escapeAttr(station.name || 'Estación actual')}" disabled /></label>
      <label class="wide"><span>Nota interna / PIN si aplica</span><input id="quickSavedGameNoteInput" type="text" placeholder="Ej. No usar perfil invitado" autocomplete="off" /></label>
    </div>
    <div class="saved-game-alert-note"><b>Beneficio</b><span>${escapeHtml(benefit.message)}</span></div>
  `;
  setSavedGameAlertFooter(`
    <button id="cancelQuickSavedGameBtn" type="button" class="secondary">Cancelar</button>
    <button id="saveQuickSavedGameBtn" type="button">Guardar e iniciar</button>
  `);
  $('#cancelQuickSavedGameBtn')?.addEventListener('click', () => renderSavedGameAlertContent({ game, savedGame: null, hasSavedGame: false, savedGames }));
  $('#saveQuickSavedGameBtn')?.addEventListener('click', () => saveQuickSavedGameFromStation({ game, savedGames }));
  setTimeout(() => $('#quickSavedGameProfileInput')?.focus(), 60);
}

async function saveQuickSavedGameFromStation({ game = {}, savedGames = [] } = {}) {
  const member = state.selectedMember;
  const station = state.selectedStation;
  if (!member?.id || !game?.id || !station?.id) return showToast('Selecciona miembro, juego y estación');
  const profile = ($('#quickSavedGameProfileInput')?.value || '').trim();
  const note = ($('#quickSavedGameNoteInput')?.value || '').trim();
  if (!profile) return showToast('Ingresa el perfil en consola');

  try {
    const result = await api(`/members/${member.id}/saved-games`, {
      method: 'POST',
      body: JSON.stringify({
        gameId: game.id,
        gameName: game.name || '',
        platform: station.console_type || game.platform || '',
        stationId: station.id,
        consoleProfileName: profile,
        internalNote: note,
        lastPlayedAt: new Date().toISOString(),
        status: 'ACTIVE'
      })
    });
    const savedGame = result.savedGame || null;
    state.savedGameAlertsCache = state.savedGameAlertsCache || {};
    state.savedGameAlertsCache[member.id] = [savedGame, ...(savedGames || [])].filter(Boolean);
    showToast('Partida guardada creada');
    renderSavedGameAlertContent({ game, savedGame, hasSavedGame: Boolean(savedGame), savedGames: state.savedGameAlertsCache[member.id] });
  } catch (error) {
    showToast(error.message || 'No se pudo crear la partida guardada');
    renderSavedGameUpgradeNotice({ game, savedGames });
  }
}

function renderSavedGameAlertContent({ game = {}, savedGame = null, hasSavedGame = false, savedGames = [] } = {}) {
  const title = $('#savedGameAlertTitle');
  const subtitle = $('#savedGameAlertSubtitle');
  const body = $('#savedGameAlertBody');
  if (!title || !subtitle || !body) return;

  if (hasSavedGame && savedGame) {
    const stationText = savedGame.station_name || savedGame.station_console_type || 'estación indicada';
    const profileText = savedGame.console_profile_name || 'perfil guardado';
    title.textContent = 'Partida guardada encontrada';
    subtitle.textContent = `${getSelectedMemberName()} tiene progreso para ${game.name}.`;
    body.innerHTML = `
      <div class="saved-game-alert-hero">
        ${getStationGameCoverMarkup(game, 'saved-alert')}
        <div>
          <small>Usar este perfil</small>
          <strong>${escapeHtml(profileText)}</strong>
          <span>${escapeHtml(stationText)}</span>
        </div>
      </div>
      ${savedGame.internal_note ? `<div class="saved-game-alert-note"><b>Nota para cajera</b><span>${escapeHtml(savedGame.internal_note)}</span></div>` : ''}
      <p class="saved-game-alert-message">Antes de iniciar, confirma que la consola esté en el perfil correcto para no abrir una partida equivocada.</p>
    `;
    setSavedGameAlertFooter(`<button id="savedGameAlertOkBtn" type="button">Entendido</button>`);
    $('#savedGameAlertOkBtn')?.addEventListener('click', closeSavedGameAlertModal);
    return;
  }

  const benefit = getSavedGameBenefitInfo(state.selectedMember, savedGames);
  title.textContent = 'Sin partida guardada';
  subtitle.textContent = `${getSelectedMemberName()} no tiene partida guardada de ${game?.name || 'este juego'}.`;
  body.innerHTML = `
    <div class="saved-game-alert-empty">
      ${getStationGameCoverMarkup(game, 'saved-alert')}
      <div>
        <strong>Usar perfil invitado</strong>
        <span>O crear una partida guardada si el miembro quiere conservar su progreso.</span>
      </div>
    </div>
    <div class="saved-game-alert-note"><b>Beneficio</b><span>${escapeHtml(benefit.message)}</span></div>
    <p class="saved-game-alert-message">Esta alerta aparece para juegos de historia/progreso para evitar abrir el perfil incorrecto.</p>
  `;
  setSavedGameAlertFooter(`
    <button id="savedGameGuestBtn" type="button" class="secondary">Usar perfil invitado</button>
    <button id="createQuickSavedGameBtn" type="button">Crear partida guardada</button>
  `);
  $('#savedGameGuestBtn')?.addEventListener('click', closeSavedGameAlertModal);
  $('#createQuickSavedGameBtn')?.addEventListener('click', () => renderSavedGameCreateForm({ game, savedGames }));
}

function closeSavedGameAlertModal() {
  closeModalElement($('#savedGameAlertModal'));
}

async function maybeShowSavedGameAlert({ force = false } = {}) {
  const station = state.selectedStation;
  const member = state.selectedMember;
  const game = getSelectedSessionGame();
  if (!station || !member?.id || !game?.id || !shouldShowSavedGameAlertForGame(game)) return;

  const alertKey = getSavedGameAlertKey(member.id, game.id, station.id);
  state.savedGameAlertShownKeys = state.savedGameAlertShownKeys || new Set();
  if (!force && state.savedGameAlertShownKeys.has(alertKey)) return;

  try {
    state.savedGameAlertShownKeys.add(alertKey);
    state.savedGameAlertsCache = state.savedGameAlertsCache || {};
    let savedGames = state.savedGameAlertsCache[member.id];
    if (!savedGames) {
      const result = await api(`/members/${member.id}/saved-games`);
      savedGames = result.savedGames || [];
      state.savedGameAlertsCache[member.id] = savedGames;
    }
    const savedGame = matchSavedGameForSelectedGame(savedGames, game, station);
    renderSavedGameAlertContent({ game, savedGame, hasSavedGame: Boolean(savedGame), savedGames });
    openModalElement($('#savedGameAlertModal'), { base: 2147483400 });
  } catch (error) {
    showToast(error.message || 'No se pudo revisar partida guardada');
  }
}

function handleStationSavedGameAlert() {
  maybeShowSavedGameAlert();
}

function getActiveStationGames() {
  return (state.stationGames || [])
    .filter((game) => game.is_active !== false)
    .sort((a, b) => Number(b.is_featured === true) - Number(a.is_featured === true) || Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
}

function isGameCompatibleWithStation(game = {}, station = state.selectedStation) {
  if (!station || !game) return true;
  const consoleType = String(station.console_type || '').trim();
  if (!consoleType) return true;
  return getGameCompatibleConsoles(game).includes(consoleType);
}


function getGameLocations(game = {}) {
  return Array.isArray(game.locations) ? game.locations : [];
}

function getGameLocationSummary(game = {}) {
  const locations = getGameLocations(game).filter((location) => String(location.status || 'Disponible') !== 'No instalado');
  if (!locations.length) return 'No instalado';
  const first = locations[0];
  if (first.location_type === 'Instalado en consola' && first.station_name) return `Instalado: ${first.station_name}`;
  if (first.device_name) return `${first.location_type}: ${first.device_name}`;
  if (first.account_label) return `Cuenta: ${first.account_label}`;
  return first.location_type || 'Ubicación registrada';
}

function getGameLocationMessage(game = {}, station = state.selectedStation) {
  const locations = getGameLocations(game);
  const stationId = String(station?.id || '');
  const consoleType = String(station?.console_type || '');
  const pending = locations.find((location) => String(location.status || '') === 'Actualización pendiente');
  if (pending) return 'Actualización pendiente';

  const installedHere = locations.find((location) => location.location_type === 'Instalado en consola' && String(location.station_id || '') === stationId);
  if (installedHere) return 'Instalado en esta consola';

  const account = locations.find((location) => location.location_type === 'Cuenta/perfil específico' && String(location.account_label || '').trim());
  if (account) return `Requiere cuenta ${account.account_label}`;

  const device = locations.find((location) => ['SSD externo', 'Disco duro externo', 'Micro SD'].includes(location.location_type) && String(location.device_name || '').trim());
  if (device) {
    if (device.location_type === 'Micro SD') return `Está en ${device.device_name}`;
    return `Conectar ${device.device_name}`;
  }

  const physical = locations.find((location) => ['Disco físico', 'Cartucho'].includes(location.location_type));
  if (physical) {
    const qty = Math.max(1, Number(physical.quantity || game.copy_quantity || 1));
    const active = Math.max(0, Number(game.active_sessions_count || 0));
    const available = Math.max(0, qty - active);
    return `${physical.location_type} disponible ${available}/${qty}`;
  }

  const installedGeneric = locations.find((location) => location.location_type === 'Instalado en consola' && !location.station_id);
  if (installedGeneric) return 'Instalado en consola compatible';

  const installedOther = locations.find((location) => location.location_type === 'Instalado en consola');
  if (installedOther && consoleType) return 'No instalado en esta consola';
  if (locations.some((location) => location.location_type === 'No instalado' || location.status === 'No instalado')) return 'No instalado en esta consola';
  return 'Ubicación sin especificar';
}

function getStationOptionsMarkup(selectedId = '') {
  const selected = String(selectedId || '');
  return `<option value="">Ninguna específica</option>${(state.stations || []).map((station) => `<option value="${escapeAttr(station.id)}" ${String(station.id) === selected ? 'selected' : ''}>${escapeHtml(station.name)} · ${escapeHtml(station.console_type || '')}</option>`).join('')}`;
}

function getGameDeviceOptionsMarkup(selectedId = '') {
  const selected = String(selectedId || '');
  return `<option value="">Sin dispositivo</option>${(state.gameStorageDevices || []).filter((device) => device.is_active !== false).map((device) => `<option value="${escapeAttr(device.id)}" ${String(device.id) === selected ? 'selected' : ''}>${escapeHtml(device.name)} · ${escapeHtml(device.device_type || '')}</option>`).join('')}`;
}

function getLocationTypeOptionsMarkup(selectedValue = 'No instalado') {
  return GAME_LOCATION_TYPES.map((type) => `<option value="${escapeAttr(type)}" ${type === selectedValue ? 'selected' : ''}>${escapeHtml(type)}</option>`).join('');
}

function getLocationStatusOptionsMarkup(selectedValue = 'Disponible') {
  return GAME_LOCATION_STATUSES.map((status) => `<option value="${escapeAttr(status)}" ${status === selectedValue ? 'selected' : ''}>${escapeHtml(status)}</option>`).join('');
}

function renderStationGameLocations(locations = []) {
  const list = $('#stationGameLocationsList');
  if (!list) return;
  const rows = Array.isArray(locations) && locations.length ? locations : [{ location_type: 'No instalado', status: 'No instalado', quantity: 1 }];
  list.innerHTML = rows.map((location, index) => `
    <article class="station-game-location-row" data-game-location-row>
      <div class="station-game-location-row-top">
        <strong>Ubicación ${index + 1}</strong>
        <button type="button" class="danger-light" data-remove-game-location>Quitar</button>
      </div>
      <div class="station-game-location-grid">
        <label><span>Tipo</span><select data-game-location-type>${getLocationTypeOptionsMarkup(location.location_type || location.locationType || 'No instalado')}</select></label>
        <label><span>Estado manual</span><select data-game-location-status>${getLocationStatusOptionsMarkup(location.status || 'Disponible')}</select></label>
        <label><span>Estación</span><select data-game-location-station>${getStationOptionsMarkup(location.station_id || location.stationId || '')}</select></label>
        <label><span>Dispositivo</span><select data-game-location-device>${getGameDeviceOptionsMarkup(location.device_id || location.deviceId || '')}</select></label>
        <label><span>Cantidad</span><input data-game-location-quantity type="number" min="1" step="1" value="${escapeAttr(location.quantity || 1)}" /></label>
        <label><span>Cuenta/perfil</span><input data-game-location-account type="text" value="${escapeAttr(location.account_label || location.accountLabel || '')}" placeholder="PS5 Principal" autocomplete="off" /></label>
      </div>
      <label><span>Nota para cajera</span><input data-game-location-notes type="text" value="${escapeAttr(location.notes || '')}" placeholder="Conectar SSD Azul antes de iniciar" autocomplete="off" /></label>
    </article>
  `).join('');
  list.querySelectorAll('[data-remove-game-location]').forEach((btn) => {
    btn.addEventListener('click', () => {
      btn.closest('[data-game-location-row]')?.remove();
      if (!list.querySelector('[data-game-location-row]')) renderStationGameLocations([]);
    });
  });
}

function addStationGameLocationRow() {
  const locations = getStationGameLocationsPayload();
  locations.push({ locationType: 'No instalado', status: 'No instalado', quantity: 1 });
  renderStationGameLocations(locations.map((location) => ({
    location_type: location.locationType,
    station_id: location.stationId,
    device_id: location.deviceId,
    quantity: location.quantity,
    account_label: location.accountLabel,
    status: location.status,
    notes: location.notes
  })));
}

function getStationGameLocationsPayload() {
  return Array.from(document.querySelectorAll('[data-game-location-row]')).map((row) => ({
    locationType: row.querySelector('[data-game-location-type]')?.value || 'No instalado',
    status: row.querySelector('[data-game-location-status]')?.value || 'Disponible',
    stationId: row.querySelector('[data-game-location-station]')?.value || null,
    deviceId: row.querySelector('[data-game-location-device]')?.value || null,
    quantity: Math.max(1, Number(row.querySelector('[data-game-location-quantity]')?.value || 1)),
    accountLabel: row.querySelector('[data-game-location-account]')?.value?.trim() || null,
    notes: row.querySelector('[data-game-location-notes]')?.value?.trim() || null
  }));
}

function resetGameDeviceForm(clearSelection = true) {
  if (clearSelection) state.selectedGameDeviceId = null;
  if ($('#gameDeviceIdInput')) $('#gameDeviceIdInput').value = state.selectedGameDeviceId || '';
  if ($('#gameDeviceNameInput')) $('#gameDeviceNameInput').value = '';
  if ($('#gameDeviceTypeSelect')) $('#gameDeviceTypeSelect').value = 'SSD externo';
  if ($('#gameDevicePlatformInput')) $('#gameDevicePlatformInput').value = 'Multiplataforma';
  if ($('#gameDeviceNotesInput')) $('#gameDeviceNotesInput').value = '';
  if ($('#gameDeviceActiveInput')) $('#gameDeviceActiveInput').checked = true;
}

function selectGameDevice(deviceId) {
  const device = (state.gameStorageDevices || []).find((item) => String(item.id) === String(deviceId));
  if (!device) return;
  state.selectedGameDeviceId = device.id;
  if ($('#gameDeviceIdInput')) $('#gameDeviceIdInput').value = device.id;
  if ($('#gameDeviceNameInput')) $('#gameDeviceNameInput').value = device.name || '';
  if ($('#gameDeviceTypeSelect')) $('#gameDeviceTypeSelect').value = device.device_type || 'SSD externo';
  if ($('#gameDevicePlatformInput')) $('#gameDevicePlatformInput').value = device.platform || 'Multiplataforma';
  if ($('#gameDeviceNotesInput')) $('#gameDeviceNotesInput').value = device.notes || '';
  if ($('#gameDeviceActiveInput')) $('#gameDeviceActiveInput').checked = device.is_active !== false;
  renderGameDevicesModule();
}

function renderGameDevicesModule() {
  const list = $('#gameDevicesList');
  if (!list) return;
  const term = String($('#gameDevicesSearchInput')?.value || '').trim().toLowerCase();
  const typeFilter = String($('#gameDevicesTypeFilter')?.value || '').trim();
  const devices = (state.gameStorageDevices || [])
    .slice()
    .filter((device) => {
      const haystack = [device.name, device.device_type, device.platform, device.notes].join(' ').toLowerCase();
      return (!term || haystack.includes(term)) && (!typeFilter || device.device_type === typeFilter);
    })
    .sort((a, b) => Number(a.is_active === false) - Number(b.is_active === false) || String(a.device_type || '').localeCompare(String(b.device_type || '')) || String(a.name || '').localeCompare(String(b.name || '')));
  list.innerHTML = devices.length ? devices.map((device) => `
    <button type="button" class="station-game-config-row ${String(device.id) === String(state.selectedGameDeviceId) ? 'active-selection' : ''}" data-game-device-id="${escapeAttr(device.id)}">
      <span class="station-game-cover mini station-game-cover-fallback">💾</span>
      <span><strong>${escapeHtml(device.name)}</strong><small>${escapeHtml(device.device_type || '')} · ${escapeHtml(device.platform || 'Multiplataforma')}${device.notes ? ` · ${escapeHtml(device.notes)}` : ''}</small></span>
      <em>${device.is_active === false ? 'Inactivo' : 'Activo'}</em>
    </button>
  `).join('') : '<div class="empty-state">Sin dispositivos con ese filtro</div>';
  list.querySelectorAll('[data-game-device-id]').forEach((btn) => {
    btn.addEventListener('click', () => selectGameDevice(btn.dataset.gameDeviceId));
  });
}

async function reloadGameDevices() {
  const { devices } = await api('/stations/game-devices');
  state.gameStorageDevices = devices || [];
  renderGameDevicesModule();
  renderStationGameLocations(getStationGameLocationsPayload().map((location) => ({
    location_type: location.locationType,
    station_id: location.stationId,
    device_id: location.deviceId,
    quantity: location.quantity,
    account_label: location.accountLabel,
    status: location.status,
    notes: location.notes
  })));
}

async function saveGameDeviceConfig() {
  if (!canManageStations()) return showToast('No tienes permiso');
  const payload = {
    name: $('#gameDeviceNameInput')?.value?.trim() || '',
    deviceType: $('#gameDeviceTypeSelect')?.value || 'SSD externo',
    platform: $('#gameDevicePlatformInput')?.value?.trim() || 'Multiplataforma',
    notes: $('#gameDeviceNotesInput')?.value?.trim() || '',
    isActive: Boolean($('#gameDeviceActiveInput')?.checked)
  };
  try {
    if (state.selectedGameDeviceId) {
      await api(`/stations/game-devices/${state.selectedGameDeviceId}`, { method: 'PUT', body: JSON.stringify(payload) });
      showToast('Dispositivo actualizado');
    } else {
      await api('/stations/game-devices', { method: 'POST', body: JSON.stringify(payload) });
      showToast('Dispositivo creado');
    }
    resetGameDeviceForm();
    await reloadGameDevices();
  } catch (error) {
    showToast(error.message || 'No se pudo guardar el dispositivo');
  }
}

function resetStationGameForm() {
  state.selectedStationGameId = null;
  if ($('#stationGameFormTitle')) $('#stationGameFormTitle').textContent = 'Nuevo juego';
  if ($('#stationGameNameInput')) $('#stationGameNameInput').value = '';
  if ($('#stationGameCoverInput')) $('#stationGameCoverInput').value = '';
  if ($('#stationGamePlatformSelect')) $('#stationGamePlatformSelect').value = 'Multiplataforma';
  if ($('#stationGameOrderInput')) $('#stationGameOrderInput').value = String(((state.stationGames || []).length + 1) * 10);
  if ($('#stationGameCopyQuantityInput')) $('#stationGameCopyQuantityInput').value = '1';
  if ($('#stationGameUnlimitedInput')) $('#stationGameUnlimitedInput').checked = true;
  setSelectedGameCompatibilityValues(GAME_COMPATIBLE_CONSOLES);
  if ($('#stationGameFeaturedInput')) $('#stationGameFeaturedInput').checked = false;
  if ($('#stationGameHighlightTypeSelect')) $('#stationGameHighlightTypeSelect').value = 'NORMAL';
  if ($('#stationGamePriorityInput')) $('#stationGamePriorityInput').checked = false;
  if ($('#stationGameStoryInput')) $('#stationGameStoryInput').checked = false;
  if ($('#stationGameProfileAlertInput')) $('#stationGameProfileAlertInput').checked = false;
  if ($('#stationGameExtraControllersInput')) $('#stationGameExtraControllersInput').checked = false;
  if ($('#stationGameMaxExtraControllersInput')) $('#stationGameMaxExtraControllersInput').value = '2';
  if ($('#stationGameExtraControllerPriceInput')) $('#stationGameExtraControllerPriceInput').value = '0';
  if ($('#stationGameActiveInput')) $('#stationGameActiveInput').checked = true;
  renderStationGameLocations([]);
  renderStationGamesConfigModule();
}


function formatGameRequestDecision(decision = '') {
  const map = {
    ESPERA: 'Esperó',
    ACEPTO_OTRO: 'Aceptó otro juego',
    SE_FUE: 'Se fue',
    SOLO_REGISTRAR: 'Solo registrado'
  };
  return map[String(decision || '').toUpperCase()] || 'Registrado';
}

function formatGameRequestStatus(status = '') {
  const map = {
    PENDIENTE: 'Pendiente',
    ESPERANDO: 'Esperando',
    REVISADO: 'Revisado',
    COMPRADO: 'Comprado',
    DESCARTADO: 'Descartado',
    CONVERTIDO: 'Disponible'
  };
  return map[String(status || '').toUpperCase()] || 'Pendiente';
}

function formatGameRequestPurchaseMethod(method = '') {
  const map = {
    DIGITAL: 'Digital',
    FISICO: 'Físico',
    PENDIENTE: 'Pendiente de confirmar'
  };
  return map[String(method || '').toUpperCase()] || '';
}

function normalizeGameRequestPhone(phone = '') {
  const digits = String(phone || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return `1${digits}`;
  return digits;
}

function buildGameRequestAvailableWhatsappMessage(request = {}) {
  const name = request.member_name || request.customer_name || 'jugador';
  const game = getGameRequestDisplayName(request);
  const platform = request.platform && request.platform !== 'Sin especificar' ? ` para ${request.platform}` : '';
  return `Hola ${name}, ${game}${platform} ya está disponible en Club Versus. Puedes pasar cuando quieras para jugarlo. 🎮`;
}

async function copyGameRequestWhatsappMessage(request = {}) {
  const message = buildGameRequestAvailableWhatsappMessage(request);
  try {
    await navigator.clipboard?.writeText(message);
    showToast('Mensaje copiado');
  } catch (_) {
    showToast(message);
  }
}

function openGameRequestWhatsapp(request = {}) {
  const phone = normalizeGameRequestPhone(request.member_phone || request.customer_phone || '');
  const message = encodeURIComponent(buildGameRequestAvailableWhatsappMessage(request));
  const url = phone ? `https://wa.me/${phone}?text=${message}` : `https://wa.me/?text=${message}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

function getPendingGameAvailableRequests(requests = state.gameRequests || []) {
  return (Array.isArray(requests) ? requests : []).filter((request) => (
    String(request.status || '').toUpperCase() === 'CONVERTIDO'
    && !request.available_notified_at
  ));
}

function normalizePendingNoticeGameKey(request = {}) {
  return String(getGameRequestDisplayName(request) || request.requested_game_name || request.game_name || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

function buildPendingGameAvailableNotices(requests = state.gameRequests || []) {
  const pending = getPendingGameAvailableRequests(requests);
  const map = new Map();
  pending.forEach((request) => {
    const key = normalizePendingNoticeGameKey(request) || `solicitud-${request.id}`;
    if (!map.has(key)) {
      map.set(key, {
        type: 'GAME_AVAILABLE',
        key,
        title: getGameRequestDisplayName(request),
        platformSet: new Set(),
        requests: [],
        latestTime: 0
      });
    }
    const group = map.get(key);
    group.requests.push(request);
    if (request.platform) group.platformSet.add(String(request.platform));
    const created = new Date(request.updated_at || request.converted_at || request.created_at || 0).getTime();
    group.latestTime = Math.max(group.latestTime || 0, Number.isNaN(created) ? 0 : created);
  });
  return Array.from(map.values())
    .map((group) => ({
      ...group,
      platforms: Array.from(group.platformSet).filter(Boolean)
    }))
    .sort((a, b) => (b.requests.length - a.requests.length) || (b.latestTime - a.latestTime) || a.title.localeCompare(b.title));
}

function getPendingNoticesCount() {
  return getPendingGameAvailableRequests().length;
}

function syncPendingNoticesBadge() {
  const btn = $('#openPendingNoticesBtn');
  if (!btn) return;
  const count = getPendingNoticesCount();
  btn.classList.toggle('has-pending-notices', count > 0);
  btn.dataset.pendingNotices = String(count);
  btn.title = count > 0 ? `${count} aviso(s) pendiente(s)` : 'Sin avisos pendientes';
}

async function loadPendingNotices(options = {}) {
  try {
    const { requests } = await api('/stations/game-requests');
    state.gameRequests = requests || [];
    syncPendingNoticesBadge();
    renderPendingNoticesModalContent();
  } catch (error) {
    syncPendingNoticesBadge();
    if (!options.silent) showToast(error.message || 'No se pudieron cargar avisos pendientes');
  }
}

function getPendingNoticeSummaryText(notice = {}) {
  if (notice.type === 'GAME_AVAILABLE') {
    const total = notice.requests?.length || 0;
    const phones = (notice.requests || []).filter((request) => normalizeGameRequestPhone(request.member_phone || request.customer_phone || '')).length;
    const platforms = notice.platforms?.length ? notice.platforms.join(' / ') : 'Plataforma libre';
    return `${total} ${total === 1 ? 'cliente por avisar' : 'clientes por avisar'} · ${phones} con WhatsApp · ${platforms}`;
  }
  return 'Aviso pendiente';
}

function renderPendingNoticesModalContent() {
  const modal = document.querySelector('.pending-notices-modal');
  if (!modal) return;
  const body = modal.querySelector('[data-pending-notices-body]');
  if (!body) return;
  const notices = buildPendingGameAvailableNotices();
  const total = getPendingNoticesCount();
  const subtitle = modal.querySelector('[data-pending-notices-subtitle]');
  if (subtitle) subtitle.textContent = total > 0 ? `${total} aviso(s) pendiente(s)` : 'Todo al día';
  if (!notices.length) {
    body.innerHTML = `
      <div class="pending-notices-empty">
        <strong>Sin avisos pendientes</strong>
        <span>Cuando un juego solicitado esté disponible y falte avisar clientes, aparecerá aquí.</span>
      </div>
    `;
    return;
  }
  body.innerHTML = `
    <section class="pending-notices-section">
      <div class="pending-notices-section-head">
        <span>Juegos disponibles</span>
        <em>${total} pendiente${total === 1 ? '' : 's'}</em>
      </div>
      <div class="pending-notices-list">
        ${notices.map((notice) => {
          const ids = (notice.requests || []).map((request) => request.id).join(',');
          const preview = (notice.requests || []).slice(0, 3).map((request) => request.member_name || request.customer_name || 'Cliente sin nombre').join(' · ');
          return `
            <article class="pending-notice-card" data-pending-notice-key="${escapeAttr(notice.key)}">
              <div>
                <strong>${escapeHtml(notice.title || 'Juego disponible')}</strong>
                <span>${escapeHtml(getPendingNoticeSummaryText(notice))}</span>
                ${preview ? `<small>${escapeHtml(preview)}${notice.requests.length > 3 ? ` · +${notice.requests.length - 3}` : ''}</small>` : ''}
              </div>
              <button type="button" data-pending-notice-whatsapp="${escapeAttr(ids)}">Avisar</button>
            </article>
          `;
        }).join('')}
      </div>
    </section>
  `;
  body.querySelectorAll('[data-pending-notice-whatsapp]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const ids = String(btn.dataset.pendingNoticeWhatsapp || '').split(',').map((id) => id.trim()).filter(Boolean);
      openGameRequestWhatsappModal(ids);
    });
  });
}

function openPendingNoticesModal() {
  document.querySelector('.pending-notices-modal')?.remove();
  const modal = document.createElement('div');
  modal.className = 'pending-notices-modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="modal-backdrop" data-pending-notices-close></div>
    <div class="modal-shell pending-notices-shell">
      <div class="modal-header compact pending-notices-header">
        <div>
          <h3>Avisos pendientes</h3>
          <p data-pending-notices-subtitle>Cargando...</p>
        </div>
        <button type="button" class="modal-close" data-pending-notices-close aria-label="Cerrar">×</button>
      </div>
      <div class="pending-notices-body" data-pending-notices-body>
        <div class="stations-empty">Cargando avisos...</div>
      </div>
    </div>
  `;
  const close = () => {
    closeModalElement(modal);
    modal.remove();
  };
  modal.querySelectorAll('[data-pending-notices-close]').forEach((btn) => btn.addEventListener('click', close));
  document.body.appendChild(modal);
  openModalElement(modal, { base: 2147483300 });
  renderPendingNoticesModalContent();
  loadPendingNotices({ silent: true });
}

function getGameRequestPurchaseOptions(method = '') {
  const normalized = String(method || 'PENDIENTE').toUpperCase();
  return ['PENDIENTE', 'DIGITAL', 'FISICO'].map((item) => `
    <option value="${item}" ${item === normalized ? 'selected' : ''}>${escapeHtml(formatGameRequestPurchaseMethod(item))}</option>
  `).join('');
}

function formatGameRequestDate(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleDateString('es-DO', { day: '2-digit', month: 'short' });
}

function formatGameRequestScope(scope = '') {
  const normalized = String(scope || '').toUpperCase();
  if (normalized === 'OFFICIAL') return 'Oficial miembro';
  return 'Sugerencia';
}

function getGameRequestMemberId() {
  return state.selectedMember?.id || state.selectedStation?.member_id || null;
}

function getGameRequestMemberName() {
  return state.selectedMember?.full_name || state.selectedMember?.name || state.selectedStation?.member_name || '';
}

function syncGameRequestMemberFields() {
  const memberId = getGameRequestMemberId();
  const memberName = getGameRequestMemberName();
  const customerLabel = $('#gameRequestCustomerLabel');
  const customerInput = $('#gameRequestCustomerInput');
  if (customerLabel) customerLabel.classList.toggle('hidden', Boolean(memberId));
  if (customerInput && memberId) customerInput.value = '';
  const hint = $('#gameRequestScopeHint');
  const scope = String($('#gameRequestScopeInput')?.value || 'SUGGESTION').toUpperCase();
  if (hint) {
    hint.textContent = scope === 'OFFICIAL'
      ? `Solicitud oficial vinculada a ${memberName || 'miembro'}.`
      : memberId
        ? `Miembro seleccionado: ${memberName || 'miembro'}. Puedes dejarlo como sugerencia o marcarlo oficial.`
        : 'Sin miembro seleccionado: se guardará como sugerencia.';
  }
}

function setGameRequestScope(scope = 'SUGGESTION') {
  const memberId = getGameRequestMemberId();
  const normalized = String(scope || '').toUpperCase() === 'OFFICIAL' && memberId ? 'OFFICIAL' : 'SUGGESTION';
  const input = $('#gameRequestScopeInput');
  if (input) input.value = normalized;
  document.querySelectorAll('[data-game-request-scope]').forEach((btn) => {
    const value = String(btn.dataset.gameRequestScope || '').toUpperCase();
    const isOfficial = value === 'OFFICIAL';
    btn.classList.toggle('active', value === normalized);
    btn.disabled = isOfficial && !memberId;
    if (isOfficial && !memberId) {
      btn.title = 'Selecciona un miembro para crear una solicitud oficial';
    } else {
      btn.removeAttribute('title');
    }
  });
  syncGameRequestMemberFields();
}

function normalizeGameRequestGroupKey(request = {}) {
  const name = String(request.game_name || request.requested_game_name || 'Juego solicitado')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
  return name || 'juego solicitado';
}

function getGameRequestDisplayName(request = {}) {
  return String(request.game_name || request.requested_game_name || 'Juego solicitado').trim() || 'Juego solicitado';
}

function getGameRequestFilters() {
  state.gameRequestAdminFilters = state.gameRequestAdminFilters || {
    scope: 'ALL',
    status: 'ACTIVE',
    platform: 'ALL',
    order: 'COUNT'
  };
  return state.gameRequestAdminFilters;
}

function getGameRequestStatusOptions(status = 'PENDIENTE') {
  const normalized = String(status || 'PENDIENTE').toUpperCase();
  return ['PENDIENTE', 'REVISADO', 'COMPRADO', 'CONVERTIDO', 'DESCARTADO'].map((item) => `
    <option value="${item}" ${item === normalized ? 'selected' : ''}>${escapeHtml(formatGameRequestStatus(item))}</option>
  `).join('');
}

function filterGameRequestsForAdmin(requests = []) {
  const filters = getGameRequestFilters();
  return (requests || []).filter((request) => {
    const scope = String(request.request_scope || 'SUGGESTION').toUpperCase();
    const status = String(request.status || 'PENDIENTE').toUpperCase();
    const platform = String(request.platform || 'Sin especificar');
    if (filters.scope === 'OFFICIAL' && scope !== 'OFFICIAL') return false;
    if (filters.scope === 'SUGGESTION' && scope === 'OFFICIAL') return false;
    if (filters.status === 'ACTIVE' && ['CONVERTIDO', 'DESCARTADO'].includes(status)) return false;
    if (filters.status !== 'ALL' && filters.status !== 'ACTIVE' && status !== filters.status) return false;
    if (filters.platform !== 'ALL' && platform !== filters.platform) return false;
    return true;
  });
}

function buildGameRequestGroups(requests = []) {
  const map = new Map();
  requests.forEach((request) => {
    const key = normalizeGameRequestGroupKey(request);
    if (!map.has(key)) {
      map.set(key, {
        key,
        name: getGameRequestDisplayName(request),
        requests: [],
        latestTime: 0,
        officialCount: 0,
        suggestionCount: 0,
        platforms: new Set(),
        reasons: new Set(),
        statuses: new Set()
      });
    }
    const group = map.get(key);
    group.requests.push(request);
    const created = new Date(request.created_at || 0).getTime() || 0;
    group.latestTime = Math.max(group.latestTime, created);
    const scope = String(request.request_scope || 'SUGGESTION').toUpperCase();
    if (scope === 'OFFICIAL') group.officialCount += 1;
    else group.suggestionCount += 1;
    if (request.platform) group.platforms.add(String(request.platform));
    if (request.unavailable_reason) group.reasons.add(String(request.unavailable_reason));
    group.statuses.add(String(request.status || 'PENDIENTE').toUpperCase());
  });
  const groups = Array.from(map.values());
  const filters = getGameRequestFilters();
  groups.sort((a, b) => {
    if (filters.order === 'RECENT') return b.latestTime - a.latestTime;
    if (filters.order === 'OFFICIAL') return (b.officialCount - a.officialCount) || (b.requests.length - a.requests.length) || (b.latestTime - a.latestTime);
    if (filters.order === 'NAME') return a.name.localeCompare(b.name);
    return (b.requests.length - a.requests.length) || (b.latestTime - a.latestTime);
  });
  return groups;
}

function renderGameRequestAdminFilters(requests = []) {
  const filters = getGameRequestFilters();
  const platforms = Array.from(new Set((requests || []).map((request) => request.platform).filter(Boolean))).sort();
  const selected = (value, current) => String(value) === String(current) ? 'selected' : '';
  return `
    <div class="game-requests-admin-toolbar">
      <label><span>Tipo</span><select data-game-request-filter="scope">
        <option value="ALL" ${selected('ALL', filters.scope)}>Todos</option>
        <option value="OFFICIAL" ${selected('OFFICIAL', filters.scope)}>Oficiales miembros</option>
        <option value="SUGGESTION" ${selected('SUGGESTION', filters.scope)}>Sugerencias</option>
      </select></label>
      <label><span>Estado</span><select data-game-request-filter="status">
        <option value="ACTIVE" ${selected('ACTIVE', filters.status)}>Activas</option>
        <option value="ALL" ${selected('ALL', filters.status)}>Todos</option>
        <option value="PENDIENTE" ${selected('PENDIENTE', filters.status)}>Pendiente</option>
        <option value="REVISADO" ${selected('REVISADO', filters.status)}>Revisado</option>
        <option value="COMPRADO" ${selected('COMPRADO', filters.status)}>Comprado</option>
        <option value="CONVERTIDO" ${selected('CONVERTIDO', filters.status)}>Disponible</option>
        <option value="DESCARTADO" ${selected('DESCARTADO', filters.status)}>Descartado</option>
      </select></label>
      <label><span>Plataforma</span><select data-game-request-filter="platform">
        <option value="ALL" ${selected('ALL', filters.platform)}>Todas</option>
        ${platforms.map((platform) => `<option value="${escapeAttr(platform)}" ${selected(platform, filters.platform)}>${escapeHtml(platform)}</option>`).join('')}
      </select></label>
      <label><span>Orden</span><select data-game-request-filter="order">
        <option value="COUNT" ${selected('COUNT', filters.order)}>Más pedidos</option>
        <option value="RECENT" ${selected('RECENT', filters.order)}>Más recientes</option>
        <option value="OFFICIAL" ${selected('OFFICIAL', filters.order)}>Oficiales primero</option>
        <option value="NAME" ${selected('NAME', filters.order)}>Nombre</option>
      </select></label>
    </div>
  `;
}

function renderGameRequestGroup(group, section = 'mixed') {
  const requests = group.requests || [];
  const latest = requests.slice().sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0))[0] || {};
  const requestIds = requests.map((request) => request.id).filter(Boolean).join(',');
  const status = String(latest.status || 'PENDIENTE').toUpperCase();
  const platforms = Array.from(group.platforms || []).slice(0, 4).join(' · ') || 'Sin plataforma';
  const reasons = Array.from(group.reasons || []).slice(0, 2).join(' · ') || 'Solicitud registrada';
  const purchaseMethod = formatGameRequestPurchaseMethod(latest.purchase_method);
  const officialMeta = group.officialCount ? `${group.officialCount} oficiales` : '';
  const suggestionMeta = group.suggestionCount ? `${group.suggestionCount} sugerencias` : '';
  const countLabel = `${requests.length} ${requests.length === 1 ? 'vez' : 'veces'}`;
  const scopeBadge = section === 'official' ? 'Oficial miembro' : section === 'suggestion' ? 'Sugerencias' : 'Mixto';
  const isAvailable = status === 'CONVERTIDO';
  const notifiedCount = requests.filter((request) => request.available_notified_at).length;
  const whatsappButton = isAvailable ? `<button type="button" class="secondary game-request-whatsapp-btn" data-game-request-whatsapp-group="${escapeAttr(requestIds)}">WhatsApp disponible${notifiedCount ? ` · ${notifiedCount}/${requests.length} avisados` : ''}</button>` : '';
  return `
    <details class="game-request-group-card ${section === 'official' ? 'official-request' : ''}" data-game-request-group="${escapeAttr(group.key)}">
      <summary class="game-request-group-summary">
        <div>
          <strong>${escapeHtml(group.name)}</strong>
          <span>${escapeHtml(countLabel)} · ${escapeHtml([officialMeta, suggestionMeta].filter(Boolean).join(' · ') || scopeBadge)}</span>
          <small>${escapeHtml([platforms, reasons, purchaseMethod ? `Compra: ${purchaseMethod}` : ''].filter(Boolean).join(' · '))}</small>
        </div>
        <div class="game-request-group-pills">
          <em class="game-request-scope-badge ${section === 'official' ? 'official' : 'suggestion'}">${escapeHtml(scopeBadge)}</em>
          <b>${escapeHtml(formatGameRequestStatus(status))}</b>
        </div>
      </summary>
      <div class="game-request-group-body">
        <div class="game-request-admin-tools game-request-group-tools" data-game-request-ids="${escapeAttr(requestIds)}">
          <label><span>Estado</span><select data-game-request-status>${getGameRequestStatusOptions(status)}</select></label>
          <label><span>Método compra</span><select data-game-request-purchase-method>${getGameRequestPurchaseOptions(latest.purchase_method)}</select></label>
          <label><span>ETA visible</span><input data-game-request-eta type="text" placeholder="Ej. llega el viernes" value="${escapeHtml(latest.eta_text || '')}" /></label>
          <label><span>Nota al miembro</span><input data-game-request-member-note type="text" placeholder="Ej. comprado, lo estamos preparando" value="${escapeHtml(latest.member_note || '')}" /></label>
          <label><span>Nota interna</span><input data-game-request-admin-note type="text" placeholder="Proveedor, cuenta, costo, pendiente" value="${escapeHtml(latest.admin_note || '')}" /></label>
          <button type="button" data-save-game-request-group>Guardar cambios para ${escapeHtml(countLabel)}</button>
          ${whatsappButton}
        </div>
        <div class="game-request-group-details">
          ${requests.map((request) => {
            const scope = String(request.request_scope || 'SUGGESTION').toUpperCase();
            const meta = [request.platform, request.station_name, request.member_name || request.customer_name, formatGameRequestDate(request.created_at)].filter(Boolean).join(' · ');
            const reason = request.unavailable_reason || request.notes || 'Solicitud registrada';
            const purchaseLabel = formatGameRequestPurchaseMethod(request.purchase_method);
            return `
              <div class="game-request-mini-row" data-game-request-id="${escapeAttr(request.id || '')}">
                <div>
                  <strong>${escapeHtml(request.member_name || request.customer_name || 'Cliente sin nombre')}</strong>
                  <small>${escapeHtml(meta || 'Sin detalle')}</small>
                  <span>${escapeHtml([reason, purchaseLabel ? `Compra: ${purchaseLabel}` : ''].filter(Boolean).join(' · '))}</span>
                </div>
                <em class="game-request-scope-badge ${scope === 'OFFICIAL' ? 'official' : 'suggestion'}">${escapeHtml(formatGameRequestScope(scope))}</em>
                ${request.available_notified_at ? `<em class="game-request-notified-badge">Avisado ${escapeHtml(formatGameRequestDate(request.available_notified_at))}</em>` : ''}
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </details>
  `;
}

function renderGameRequestSection(title, groups = [], emptyText, section) {
  return `
    <section class="game-request-admin-section">
      <div class="game-request-section-heading">
        <h4>${escapeHtml(title)}</h4>
        <span>${groups.reduce((sum, group) => sum + group.requests.length, 0)} registros · ${groups.length} juegos</span>
      </div>
      <div class="game-request-group-list">
        ${groups.length ? groups.map((group) => renderGameRequestGroup(group, section)).join('') : `<div class="empty-state compact">${escapeHtml(emptyText)}</div>`}
      </div>
    </section>
  `;
}

function renderGameRequestsList(requests = []) {
  const list = $('#gameRequestsList');
  if (!list) return;
  if (!requests.length) {
    list.innerHTML = `${renderGameRequestAdminFilters(requests)}<div class="empty-state">Todavía no hay solicitudes registradas</div>`;
    return;
  }
  const filtered = filterGameRequestsForAdmin(requests);
  const official = filtered.filter((request) => String(request.request_scope || '').toUpperCase() === 'OFFICIAL');
  const suggestions = filtered.filter((request) => String(request.request_scope || '').toUpperCase() !== 'OFFICIAL');
  const officialGroups = buildGameRequestGroups(official);
  const suggestionGroups = buildGameRequestGroups(suggestions);
  list.innerHTML = `
    ${renderGameRequestAdminFilters(requests)}
    ${filtered.length ? `
      <div class="game-requests-admin-layout">
        ${renderGameRequestSection('Solicitudes oficiales de miembros', officialGroups, 'No hay solicitudes oficiales con este filtro.', 'official')}
        ${renderGameRequestSection('Sugerencias / demanda general', suggestionGroups, 'No hay sugerencias con este filtro.', 'suggestion')}
      </div>
    ` : '<div class="empty-state">No hay resultados con esos filtros</div>'}
  `;
}


function syncGameRequestStatusHelper(select) {
  const panel = select?.closest('.game-request-admin-tools');
  if (!panel) return;
  const status = String(select.value || '').toUpperCase();
  const eta = panel.querySelector('[data-game-request-eta]');
  const memberNote = panel.querySelector('[data-game-request-member-note]');
  const purchaseMethod = panel.querySelector('[data-game-request-purchase-method]');
  if (status === 'COMPRADO') {
    if (purchaseMethod && !purchaseMethod.value) purchaseMethod.value = 'PENDIENTE';
    if (eta && !String(eta.value || '').trim()) eta.value = 'Pendiente de llegada / instalación';
    if (memberNote && !String(memberNote.value || '').trim()) memberNote.value = 'Ya fue comprado. Estamos preparando el juego.';
  }
}


function getAvailabilityStationOptionsMarkup(compatibleConsoles = GAME_COMPATIBLE_CONSOLES) {
  const selectedConsoles = new Set((Array.isArray(compatibleConsoles) && compatibleConsoles.length ? compatibleConsoles : GAME_COMPATIBLE_CONSOLES).map(String));
  const stations = (state.stations || []).filter((station) => !station.console_type || selectedConsoles.has(station.console_type));
  if (!stations.length) return '<p class="muted tiny">No hay estaciones compatibles cargadas. Puedes guardar sin estación específica y completar luego en Biblioteca.</p>';
  return stations.map((station) => `
    <label class="game-request-available-check">
      <input type="checkbox" value="${escapeAttr(station.id)}" data-availability-station />
      <span>${escapeHtml(station.name)} · ${escapeHtml(station.console_type || 'Consola')}</span>
    </label>
  `).join('');
}

function getAvailabilityConsoleChecksMarkup(selectedPlatform = '') {
  const selected = new Set(getGameCompatibleConsoles({ platform: selectedPlatform }));
  return GAME_COMPATIBLE_CONSOLES.map((consoleName) => `
    <label class="game-request-available-check">
      <input type="checkbox" value="${escapeAttr(consoleName)}" data-availability-console ${selected.has(consoleName) ? 'checked' : ''} />
      <span>${escapeHtml(getReservationConsoleLabel(consoleName))}</span>
    </label>
  `).join('');
}

function getAvailabilityDevicesOptionsMarkup() {
  return `<option value="">Selecciona dispositivo</option>${(state.gameStorageDevices || []).filter((device) => device.is_active !== false).map((device) => `<option value="${escapeAttr(device.id)}">${escapeHtml(device.name)} · ${escapeHtml(device.device_type || '')}</option>`).join('')}`;
}

function getAvailabilityPlatformFromConsoles(consoles = []) {
  const clean = [...new Set((Array.isArray(consoles) ? consoles : []).map((item) => String(item || '').trim()).filter(Boolean))];
  if (!clean.length || clean.length > 1) return 'Multiplataforma';
  return clean[0];
}

function isAvailabilityExternalDeviceType(locationType = '') {
  return ['SSD externo', 'Disco duro externo', 'Micro SD'].includes(String(locationType || '').trim());
}

function supportsAvailabilityUnlimited(locationType = '') {
  return ['Instalado en consola', 'Cuenta/perfil específico'].includes(String(locationType || '').trim());
}

function getAvailabilityPayloadFromModal(modal) {
  const name = modal.querySelector('[data-availability-name]')?.value?.trim() || '';
  const locationType = modal.querySelector('[data-availability-location-type]')?.value || 'Instalado en consola';
  const compatibleConsoles = Array.from(modal.querySelectorAll('[data-availability-console]:checked')).map((input) => input.value);
  const platform = getAvailabilityPlatformFromConsoles(compatibleConsoles);
  const stationIds = Array.from(modal.querySelectorAll('[data-availability-station]:checked')).map((input) => input.value);
  const canBeUnlimited = supportsAvailabilityUnlimited(locationType);
  const unlimitedCopies = canBeUnlimited && modal.querySelector('[data-availability-unlimited]')?.checked === true;
  const copyQuantity = Math.max(1, Number(modal.querySelector('[data-availability-copy-quantity]')?.value || 1));
  const deviceId = isAvailabilityExternalDeviceType(locationType) ? (modal.querySelector('[data-availability-device]')?.value || null) : null;
  const coverUrl = modal.querySelector('[data-availability-cover-url]')?.value?.trim() || '';
  const notes = modal.querySelector('[data-availability-notes]')?.value?.trim() || '';
  return { name, platform, locationType, compatibleConsoles, stationIds, unlimitedCopies, copyQuantity, deviceId, coverUrl, notes };
}

function promptGameRequestAvailabilityDetails({ name = '', platform = '', count = 1 } = {}) {
  return new Promise((resolve) => {
    const previous = document.querySelector('.game-request-availability-modal');
    previous?.remove();
    const initialName = String(name || '').trim();
    const initialPlatform = String(platform || 'Multiplataforma').trim() || 'Multiplataforma';
    const initialConsoles = getGameCompatibleConsoles({ platform: initialPlatform });
    const modal = document.createElement('div');
    modal.className = 'game-request-availability-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-hidden', 'true');
    modal.innerHTML = `
      <div class="modal-backdrop" data-availability-cancel></div>
      <div class="modal-shell game-request-availability-shell">
        <div class="modal-header compact">
          <div>
            <h3>Marcar juego disponible</h3>
            <p>Completa la biblioteca antes de avisar que ya se puede jugar.</p>
          </div>
          <button type="button" class="modal-close" data-availability-cancel aria-label="Cerrar">×</button>
        </div>
        <div class="game-request-availability-body">
          <div class="game-request-availability-grid">
            <label><span>Nombre final del juego</span><input data-availability-name type="text" value="${escapeAttr(initialName)}" placeholder="Ej. Minecraft" autofocus /></label>
            <label><span>Tipo de disponibilidad</span><select data-availability-location-type>${GAME_LOCATION_TYPES.filter((type) => type !== 'No instalado').map((type) => `<option value="${escapeAttr(type)}">${escapeHtml(type)}</option>`).join('')}</select></label>
            <label><span>Copias</span><input data-availability-copy-quantity type="number" min="1" step="1" value="1" /></label>
            <label data-availability-device-wrap><span>Dispositivo obligatorio</span><select data-availability-device>${getAvailabilityDevicesOptionsMarkup()}</select></label>
            <label><span>URL de imagen / carátula</span><input data-availability-cover-url type="url" placeholder="https://.../imagen.jpg" /></label>
            <label class="game-request-availability-switch" data-availability-unlimited-wrap>
              <span>Ilimitado / digital general</span>
              <input data-availability-unlimited type="checkbox" />
              <b aria-hidden="true"></b>
            </label>
          </div>
          <div class="game-request-availability-block">
            <strong>Consolas compatibles</strong>
            <div class="game-request-available-checks" data-availability-console-list>${getAvailabilityConsoleChecksMarkup(initialPlatform)}</div>
          </div>
          <div class="game-request-availability-block">
            <strong>Estaciones donde está disponible</strong>
            <small>Selecciona estaciones específicas o déjalo vacío para completar luego en Biblioteca.</small>
            <div class="game-request-available-checks stations" data-availability-station-list>${getAvailabilityStationOptionsMarkup(initialConsoles)}</div>
          </div>
          <label class="game-request-availability-notes"><span>Nota para cajera</span><input data-availability-notes type="text" placeholder="Ej. instalado en Switch 1 / usar Micro SD Roja" /></label>
          <div class="game-request-availability-summary">
            Se actualizarán ${Number(count || 1)} ${Number(count || 1) === 1 ? 'solicitud' : 'solicitudes'} y el juego quedará visible en el catálogo.
          </div>
        </div>
        <div class="game-request-availability-actions">
          <button type="button" class="secondary" data-availability-cancel>Cancelar</button>
          <button type="button" data-availability-save>Agregar al catálogo y marcar disponible</button>
        </div>
      </div>
    `;
    const close = (value = null) => {
      closeModalElement(modal);
      modal.remove();
      resolve(value);
    };
    modal.querySelectorAll('[data-availability-cancel]').forEach((btn) => btn.addEventListener('click', () => close(null)));
    modal.querySelector('[data-availability-save]')?.addEventListener('click', () => {
      const payload = getAvailabilityPayloadFromModal(modal);
      if (!payload.name) return showToast('Escribe el nombre final del juego');
      if (!payload.compatibleConsoles.length) return showToast('Selecciona al menos una consola compatible');
      if (isAvailabilityExternalDeviceType(payload.locationType) && !payload.deviceId) return showToast('Selecciona el dispositivo externo donde estará el juego');
      close(payload);
    });
    const refreshAvailabilityFields = () => {
      const locationType = modal.querySelector('[data-availability-location-type]')?.value || 'Instalado en consola';
      const deviceWrap = modal.querySelector('[data-availability-device-wrap]');
      const deviceSelect = modal.querySelector('[data-availability-device]');
      const unlimitedWrap = modal.querySelector('[data-availability-unlimited-wrap]');
      const unlimitedInput = modal.querySelector('[data-availability-unlimited]');
      const needsDevice = isAvailabilityExternalDeviceType(locationType);
      if (deviceWrap) deviceWrap.hidden = !needsDevice;
      if (!needsDevice && deviceSelect) deviceSelect.value = '';
      const showUnlimited = supportsAvailabilityUnlimited(locationType);
      if (unlimitedWrap) unlimitedWrap.hidden = !showUnlimited;
      if (!showUnlimited && unlimitedInput) unlimitedInput.checked = false;
    };
    const refreshStations = () => {
      const consoles = Array.from(modal.querySelectorAll('[data-availability-console]:checked')).map((input) => input.value);
      const target = modal.querySelector('[data-availability-station-list]');
      if (target) target.innerHTML = getAvailabilityStationOptionsMarkup(consoles);
    };
    modal.querySelectorAll('[data-availability-console]').forEach((input) => input.addEventListener('change', refreshStations));
    modal.querySelector('[data-availability-location-type]')?.addEventListener('change', refreshAvailabilityFields);
    refreshAvailabilityFields();
    document.body.appendChild(modal);
    openModalElement(modal, { base: 2147483400 });
  });
}

async function patchGameRequestAdminUpdate(requestId, payload) {
  return api(`/stations/game-requests/${requestId}`, {
    method: 'PATCH',
    body: JSON.stringify(payload)
  });
}

async function refreshGameRequestsAdminList(status = '') {
  if (String(status || '').toUpperCase() === 'CONVERTIDO') {
    const { games } = await api('/stations/games');
    state.stationGames = games || [];
    renderStationGamesConfigModule();
    renderGameQuickSelection();
  }
  const { requests } = await api('/stations/game-requests');
  state.gameRequests = requests || [];
  renderGameRequestsList(state.gameRequests);
  syncPendingNoticesBadge();
  renderPendingNoticesModalContent();
}

function openGameRequestWhatsappModal(requestIds = []) {
  const ids = new Set((Array.isArray(requestIds) ? requestIds : []).map(String));
  const requests = (state.gameRequests || [])
    .filter((request) => ids.has(String(request.id)))
    .filter((request) => String(request.status || '').toUpperCase() === 'CONVERTIDO');
  if (!requests.length) return showToast('No hay solicitudes disponibles para avisar');
  document.querySelector('.game-request-whatsapp-modal')?.remove();
  const gameName = getGameRequestDisplayName(requests[0]);
  const modal = document.createElement('div');
  modal.className = 'game-request-whatsapp-modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="modal-backdrop" data-game-request-whatsapp-close></div>
    <div class="modal-shell game-request-whatsapp-shell">
      <div class="modal-header compact">
        <div>
          <h3>Avisar juego disponible</h3>
          <p>${escapeHtml(gameName)} · ${requests.length} ${requests.length === 1 ? 'solicitud' : 'solicitudes'}</p>
        </div>
        <button type="button" class="modal-close" data-game-request-whatsapp-close aria-label="Cerrar">×</button>
      </div>
      <div class="game-request-whatsapp-body">
        <p class="muted">Abre WhatsApp o copia el mensaje. Luego marca como avisado para dejar historial.</p>
        <div class="game-request-whatsapp-list">
          ${requests.map((request) => {
            const phone = normalizeGameRequestPhone(request.member_phone || request.customer_phone || '');
            return `
              <div class="game-request-whatsapp-row" data-game-request-whatsapp-id="${escapeAttr(request.id)}">
                <div>
                  <strong>${escapeHtml(request.member_name || request.customer_name || 'Cliente sin nombre')}</strong>
                  <small>${escapeHtml(phone ? `WhatsApp: ${phone}` : 'Sin teléfono guardado · puedes copiar el mensaje')}</small>
                  <span>${escapeHtml(buildGameRequestAvailableWhatsappMessage(request))}</span>
                </div>
                <div>
                  <button type="button" class="secondary" data-game-request-copy-one>Copiar</button>
                  <button type="button" data-game-request-open-one>${phone ? 'Abrir WhatsApp' : 'Abrir'}</button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
      <div class="game-request-whatsapp-actions">
        <button type="button" class="secondary" data-game-request-copy-all>Copiar todos</button>
        <button type="button" data-game-request-mark-notified>Marcar avisados</button>
      </div>
    </div>
  `;
  const close = () => {
    closeModalElement(modal);
    modal.remove();
  };
  modal.querySelectorAll('[data-game-request-whatsapp-close]').forEach((btn) => btn.addEventListener('click', close));
  modal.querySelectorAll('[data-game-request-copy-one]').forEach((btn) => btn.addEventListener('click', async () => {
    const row = btn.closest('[data-game-request-whatsapp-id]');
    const request = requests.find((item) => String(item.id) === String(row?.dataset.gameRequestWhatsappId));
    await copyGameRequestWhatsappMessage(request || {});
  }));
  modal.querySelectorAll('[data-game-request-open-one]').forEach((btn) => btn.addEventListener('click', () => {
    const row = btn.closest('[data-game-request-whatsapp-id]');
    const request = requests.find((item) => String(item.id) === String(row?.dataset.gameRequestWhatsappId));
    openGameRequestWhatsapp(request || {});
  }));
  modal.querySelector('[data-game-request-copy-all]')?.addEventListener('click', async () => {
    const text = requests.map((request) => `${request.member_name || request.customer_name || 'Cliente'}: ${buildGameRequestAvailableWhatsappMessage(request)}`).join('\n\n');
    try {
      await navigator.clipboard?.writeText(text);
      showToast('Mensajes copiados');
    } catch (_) {
      showToast(text.slice(0, 240));
    }
  });
  modal.querySelector('[data-game-request-mark-notified]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = 'Marcando...';
    try {
      for (const request of requests) {
        await patchGameRequestAdminUpdate(request.id, {
          status: request.status || 'CONVERTIDO',
          etaText: request.eta_text || '',
          memberNote: request.member_note || '',
          adminNote: request.admin_note || '',
          purchaseMethod: request.purchase_method || '',
          availableNotified: true,
          availableNotificationNote: 'Avisado manualmente por WhatsApp'
        });
      }
      await refreshGameRequestsAdminList('CONVERTIDO');
      showToast('Solicitudes marcadas como avisadas');
      close();
    } catch (error) {
      showToast(error.message || 'No se pudo marcar como avisado');
      button.disabled = false;
      button.textContent = 'Marcar avisados';
    }
  });
  document.body.appendChild(modal);
  openModalElement(modal, { base: 2147483450 });
}

async function saveGameRequestAdminUpdate(button) {
  const row = button?.closest('[data-game-request-id]');
  const requestId = row?.dataset.gameRequestId;
  if (!row || !requestId) return;
  const status = row.querySelector('[data-game-request-status]')?.value || 'PENDIENTE';
  const etaText = row.querySelector('[data-game-request-eta]')?.value || '';
  const memberNote = row.querySelector('[data-game-request-member-note]')?.value || '';
  const adminNote = row.querySelector('[data-game-request-admin-note]')?.value || '';
  const purchaseMethod = row.querySelector('[data-game-request-purchase-method]')?.value || '';
  button.disabled = true;
  const previousText = button.textContent;
  button.textContent = 'Guardando...';
  try {
    let availability = null;
    if (String(status || '').toUpperCase() === 'CONVERTIDO') {
      const request = (state.gameRequests || []).find((item) => String(item.id) === String(requestId)) || {};
      availability = await promptGameRequestAvailabilityDetails({
        name: getGameRequestDisplayName(request),
        platform: request.platform || '',
        count: 1
      });
      if (!availability) return;
    }
    const result = await patchGameRequestAdminUpdate(requestId, { status, etaText, memberNote, adminNote, purchaseMethod, availability });
    await refreshGameRequestsAdminList(status);
    showToast(String(status || '').toUpperCase() === 'CONVERTIDO' && result?.game
      ? 'Solicitud marcada disponible y juego agregado al catálogo'
      : 'Solicitud actualizada');
  } catch (error) {
    showToast(error.message || 'No se pudo actualizar la solicitud');
  } finally {
    button.disabled = false;
    button.textContent = previousText || 'Guardar';
  }
}

async function saveGameRequestGroupAdminUpdate(button) {
  const panel = button?.closest('[data-game-request-ids]');
  const requestIds = String(panel?.dataset.gameRequestIds || '').split(',').map((id) => id.trim()).filter(Boolean);
  if (!panel || !requestIds.length) return;
  const status = panel.querySelector('[data-game-request-status]')?.value || 'PENDIENTE';
  const etaText = panel.querySelector('[data-game-request-eta]')?.value || '';
  const memberNote = panel.querySelector('[data-game-request-member-note]')?.value || '';
  const adminNote = panel.querySelector('[data-game-request-admin-note]')?.value || '';
  const purchaseMethod = panel.querySelector('[data-game-request-purchase-method]')?.value || '';
  button.disabled = true;
  const previousText = button.textContent;
  button.textContent = 'Guardando grupo...';
  try {
    const normalizedStatus = String(status || '').toUpperCase();
    let availability = null;
    if (normalizedStatus === 'CONVERTIDO') {
      const firstRequest = (state.gameRequests || []).find((item) => requestIds.includes(String(item.id))) || {};
      const groupCard = panel.closest('.game-request-group-card');
      availability = await promptGameRequestAvailabilityDetails({
        name: groupCard?.querySelector('.game-request-group-summary strong')?.textContent || getGameRequestDisplayName(firstRequest),
        platform: firstRequest.platform || '',
        count: requestIds.length
      });
      if (!availability) return;
    }
    let convertedCount = 0;
    for (const requestId of requestIds) {
      const result = await patchGameRequestAdminUpdate(requestId, { status, etaText, memberNote, adminNote, purchaseMethod, availability });
      if (normalizedStatus === 'CONVERTIDO' && result?.game) convertedCount += 1;
    }
    await refreshGameRequestsAdminList(status);
    showToast(String(status || '').toUpperCase() === 'CONVERTIDO'
      ? `Juego marcado disponible para ${requestIds.length} solicitudes`
      : `Se actualizaron ${requestIds.length} solicitudes`);
  } catch (error) {
    showToast(error.message || 'No se pudo actualizar el grupo');
  } finally {
    button.disabled = false;
    button.textContent = previousText || 'Guardar cambios';
  }
}

async function openGameRequestsListModal() {
  const modal = $('#gameRequestsListModal');
  if (!modal) return;
  renderGameRequestsList([]);
  openModalElement(modal, { base: 2147483000 });
  try {
    const { requests } = await api('/stations/game-requests');
    state.gameRequests = requests || [];
    renderGameRequestsList(state.gameRequests);
  } catch (error) {
    showToast(error.message || 'No se pudieron cargar las solicitudes');
  }
}

function closeGameRequestsListModal() {
  const modal = $('#gameRequestsListModal');
  if (modal) closeModalElement(modal);
}

function openGameRequestsAdminModule() {
  if (!canManageStations()) return showToast('No tienes permiso');
  if (typeof closeModuleHub === 'function') closeModuleHub();
  openGameRequestsListModal();
}

function selectStationGameConfig(gameId) {
  const game = (state.stationGames || []).find((item) => String(item.id) === String(gameId));
  if (!game) return;
  state.selectedStationGameId = game.id;
  if ($('#stationGameFormTitle')) $('#stationGameFormTitle').textContent = game.name || 'Juego';
  if ($('#stationGameNameInput')) $('#stationGameNameInput').value = game.name || '';
  if ($('#stationGameCoverInput')) $('#stationGameCoverInput').value = game.cover_url || '';
  if ($('#stationGamePlatformSelect')) $('#stationGamePlatformSelect').value = game.platform || 'Multiplataforma';
  if ($('#stationGameOrderInput')) $('#stationGameOrderInput').value = String(Number(game.sort_order || 0));
  if ($('#stationGameCopyQuantityInput')) $('#stationGameCopyQuantityInput').value = String(Math.max(1, Number(game.copy_quantity || 1)));
  if ($('#stationGameUnlimitedInput')) $('#stationGameUnlimitedInput').checked = game.unlimited_copies === true;
  setSelectedGameCompatibilityValues(getGameCompatibleConsoles(game));
  if ($('#stationGameFeaturedInput')) $('#stationGameFeaturedInput').checked = game.is_featured === true;
  if ($('#stationGameHighlightTypeSelect')) $('#stationGameHighlightTypeSelect').value = game.highlight_type || (game.is_featured ? 'DESTACADO' : 'NORMAL');
  if ($('#stationGamePriorityInput')) $('#stationGamePriorityInput').checked = game.priority_enabled === true;
  if ($('#stationGameStoryInput')) $('#stationGameStoryInput').checked = game.is_story_mode === true;
  if ($('#stationGameProfileAlertInput')) $('#stationGameProfileAlertInput').checked = game.requires_profile_alert === true;
  if ($('#stationGameExtraControllersInput')) $('#stationGameExtraControllersInput').checked = game.allows_extra_controllers === true;
  if ($('#stationGameMaxExtraControllersInput')) $('#stationGameMaxExtraControllersInput').value = String(Math.max(0, Math.min(4, Number(game.max_extra_controllers ?? 2))));
  if ($('#stationGameExtraControllerPriceInput')) $('#stationGameExtraControllerPriceInput').value = String(Number(game.extra_controller_price || 0));
  if ($('#stationGameActiveInput')) $('#stationGameActiveInput').checked = game.is_active !== false;
  renderStationGameLocations(getGameLocations(game));
  renderStationGamesConfigModule();
  openStationGameEditorModal();
}

function renderStationGamesConfigModule() {
  const list = $('#stationGamesConfigList');
  if (!list) return;
  const searchTerm = String($('#stationGamesSearchInput')?.value || '').trim().toLowerCase();
  const platformFilter = String($('#stationGamesPlatformFilter')?.value || '').trim();
  const games = (state.stationGames || [])
    .slice()
    .filter((game) => {
      const consoles = getGameCompatibleConsoles(game);
      const haystack = [game.name, game.platform, consoles.join(' '), getGameCopySummary(game)].join(' ').toLowerCase();
      const matchesSearch = !searchTerm || haystack.includes(searchTerm);
      const matchesPlatform = !platformFilter || consoles.includes(platformFilter);
      return matchesSearch && matchesPlatform;
    })
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
  const total = (state.stationGames || []).length;
  list.innerHTML = games.length ? games.map((game) => `
    <button type="button" class="station-game-config-row ${String(game.id) === String(state.selectedStationGameId) ? 'active-selection' : ''}" data-station-game-id="${escapeAttr(game.id)}">
      ${getStationGameCoverMarkup(game, 'mini')}
      <span><strong>${escapeHtml(game.name)}</strong><small>${escapeHtml([getGameCompatibleConsoles(game).join(' / '), getGameCopySummary(game), getGameLocationSummary(game), getGameHighlightLabel(game), game.priority_enabled ? 'prioridad membresía' : '', game.is_story_mode ? 'historia' : '', game.requires_profile_alert ? 'alerta perfil' : ''].filter(Boolean).join(' · '))}</small></span>
      <em>${game.is_active === false ? 'Inactivo' : 'Activo'}</em>
    </button>
  `).join('') : `<div class="empty-state">No hay juegos con ese filtro. Catálogo total: ${total}</div>`;
  list.querySelectorAll('[data-station-game-id]').forEach((btn) => {
    btn.addEventListener('click', () => selectStationGameConfig(btn.dataset.stationGameId));
  });
}

async function saveStationGameConfig() {
  if (!canManageStations()) return showToast('No tienes permiso');
  const payload = {
    name: $('#stationGameNameInput')?.value?.trim() || '',
    coverUrl: $('#stationGameCoverInput')?.value?.trim() || '',
    platform: $('#stationGamePlatformSelect')?.value || 'Multiplataforma',
    sortOrder: Number($('#stationGameOrderInput')?.value || 0),
    compatibleConsoles: getSelectedGameCompatibilityValues(),
    copyQuantity: Math.max(1, Number($('#stationGameCopyQuantityInput')?.value || 1)),
    unlimitedCopies: Boolean($('#stationGameUnlimitedInput')?.checked),
    isFeatured: Boolean($('#stationGameFeaturedInput')?.checked),
    highlightType: $('#stationGameHighlightTypeSelect')?.value || 'NORMAL',
    priorityEnabled: Boolean($('#stationGamePriorityInput')?.checked),
    isStoryMode: Boolean($('#stationGameStoryInput')?.checked),
    requiresProfileAlert: Boolean($('#stationGameProfileAlertInput')?.checked),
    allowsExtraControllers: Boolean($('#stationGameExtraControllersInput')?.checked),
    maxExtraControllers: Math.max(0, Math.min(4, Number($('#stationGameMaxExtraControllersInput')?.value || 2))),
    extraControllerPrice: Math.max(0, Number($('#stationGameExtraControllerPriceInput')?.value || 0)),
    isActive: Boolean($('#stationGameActiveInput')?.checked),
    locations: getStationGameLocationsPayload()
  };
  try {
    if (state.selectedStationGameId) {
      await api(`/stations/games/${state.selectedStationGameId}`, { method: 'PUT', body: JSON.stringify(payload) });
      showToast('Juego actualizado');
    } else {
      await api('/stations/games', { method: 'POST', body: JSON.stringify(payload) });
      showToast('Juego creado');
    }
    const { games } = await api('/stations/games');
    state.stationGames = games || [];
    renderStationGamesConfigModule();
    renderGameQuickSelection();
    closeStationGameEditorModal();
  } catch (error) {
    showToast(error.message || 'No se pudo guardar el juego');
  }
}

function bindStationConfigUiEvents() {
  $('#openStationCreateBtn')?.addEventListener('click', openNewStationConfigModal);
  $('#openStationGamesConfigBtn')?.addEventListener('click', openStationGamesConfigModal);
  $('#openStationExtrasConfigBtn')?.addEventListener('click', openStationExtrasConfigModal);
  $('#closeStationConfigEditorBtn')?.addEventListener('click', closeStationConfigEditorModal);
  $('#stationConfigEditorBackdrop')?.addEventListener('click', closeStationConfigEditorModal);
  $('#closeStationGamesConfigBtn')?.addEventListener('click', closeStationGamesConfigModal);
  $('#stationGamesConfigBackdrop')?.addEventListener('click', closeStationGamesConfigModal);
  $('#closeStationGameEditorBtn')?.addEventListener('click', closeStationGameEditorModal);
  $('#stationGameEditorBackdrop')?.addEventListener('click', closeStationGameEditorModal);
  $('#closeGameDevicesBtn')?.addEventListener('click', closeGameDevicesModal);
  $('#gameDevicesBackdrop')?.addEventListener('click', closeGameDevicesModal);
  $('#closeStationExtrasConfigBtn')?.addEventListener('click', closeStationExtrasConfigModal);
  $('#stationExtrasConfigBackdrop')?.addEventListener('click', closeStationExtrasConfigModal);
  $('#closeStationExtraEditorBtn')?.addEventListener('click', closeStationExtraEditorModal);
  $('#stationExtraEditorBackdrop')?.addEventListener('click', closeStationExtraEditorModal);
}

function bindStationGamesConfigEvents() {
  $('#saveStationGameBtn')?.addEventListener('click', saveStationGameConfig);
  $('#newStationGameBtn')?.addEventListener('click', () => {
    resetStationGameForm();
    openStationGameEditorModal();
  });
  $('#stationGamesSearchInput')?.addEventListener('input', renderStationGamesConfigModule);
  $('#stationGamesPlatformFilter')?.addEventListener('change', renderStationGamesConfigModule);
  $('#openGameRequestsBtn')?.addEventListener('click', openGameRequestsListModal);
  $('#closeGameRequestsListBtn')?.addEventListener('click', closeGameRequestsListModal);
  $('#gameRequestsListBackdrop')?.addEventListener('click', closeGameRequestsListModal);
  $('#gameRequestsList')?.addEventListener('click', (event) => {
    const whatsappGroupButton = event.target.closest('[data-game-request-whatsapp-group]');
    if (whatsappGroupButton) {
      const ids = String(whatsappGroupButton.dataset.gameRequestWhatsappGroup || '').split(',').map((id) => id.trim()).filter(Boolean);
      openGameRequestWhatsappModal(ids);
      return;
    }
    const groupButton = event.target.closest('[data-save-game-request-group]');
    if (groupButton) return saveGameRequestGroupAdminUpdate(groupButton);
    const button = event.target.closest('[data-save-game-request-admin]');
    if (button) saveGameRequestAdminUpdate(button);
  });
  $('#gameRequestsList')?.addEventListener('change', (event) => {
    const statusSelect = event.target.closest('[data-game-request-status]');
    if (statusSelect) {
      syncGameRequestStatusHelper(statusSelect);
      return;
    }
    const filter = event.target.closest('[data-game-request-filter]');
    if (!filter) return;
    const filters = getGameRequestFilters();
    filters[filter.dataset.gameRequestFilter] = filter.value;
    renderGameRequestsList(state.gameRequests || []);
  });
  $('#openGameDevicesBtn')?.addEventListener('click', openGameDevicesModal);
  $('#newGameDeviceBtn')?.addEventListener('click', () => { resetGameDeviceForm(); renderGameDevicesModule(); });
  $('#saveGameDeviceBtn')?.addEventListener('click', saveGameDeviceConfig);
  $('#gameDevicesSearchInput')?.addEventListener('input', renderGameDevicesModule);
  $('#gameDevicesTypeFilter')?.addEventListener('change', renderGameDevicesModule);
  $('#addStationGameLocationBtn')?.addEventListener('click', addStationGameLocationRow);
}

function resetStationExtraForm() {
  state.selectedStationExtraId = null;
  const title = $('#stationExtraFormTitle');
  if (title) title.textContent = 'Nuevo extra';
  if ($('#stationExtraNameInput')) $('#stationExtraNameInput').value = '';
  if ($('#stationExtraDescriptionInput')) $('#stationExtraDescriptionInput').value = '';
  if ($('#stationExtraPriceInput')) $('#stationExtraPriceInput').value = '0';
  if ($('#stationExtraPricingTypeSelect')) $('#stationExtraPricingTypeSelect').value = 'SESSION';
  if ($('#stationExtraOrderInput')) $('#stationExtraOrderInput').value = String(((state.stationExtras || []).length + 1) * 10);
  if ($('#stationExtraActiveInput')) $('#stationExtraActiveInput').checked = true;
  renderStationExtrasConfigModule();
}

function selectStationExtraConfig(extraId) {
  const extra = (state.stationExtras || []).find((item) => String(item.id) === String(extraId));
  if (!extra) return;
  state.selectedStationExtraId = extra.id;
  if ($('#stationExtraFormTitle')) $('#stationExtraFormTitle').textContent = extra.name || 'Extra';
  if ($('#stationExtraNameInput')) $('#stationExtraNameInput').value = extra.name || '';
  if ($('#stationExtraDescriptionInput')) $('#stationExtraDescriptionInput').value = extra.description || '';
  if ($('#stationExtraPriceInput')) $('#stationExtraPriceInput').value = String(Number(extra.price || 0));
  if ($('#stationExtraPricingTypeSelect')) $('#stationExtraPricingTypeSelect').value = extra.pricing_type || 'SESSION';
  if ($('#stationExtraOrderInput')) $('#stationExtraOrderInput').value = String(Number(extra.sort_order || 0));
  if ($('#stationExtraActiveInput')) $('#stationExtraActiveInput').checked = extra.is_active !== false;
  renderStationExtrasConfigModule();
  openStationExtraEditorModal();
}

function getStationExtraSelectedStationIds() {
  return Array.from(document.querySelectorAll('[data-station-extra-assignment]:checked')).map((input) => input.value);
}

function renderStationExtrasConfigModule() {
  const list = $('#stationExtrasConfigList');
  const assignments = $('#stationExtraAssignmentsList');
  if (!list || !assignments) return;

  const extras = (state.stationExtras || []).slice().sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
  list.innerHTML = extras.length ? extras.map((extra) => {
    const stationCount = Array.isArray(extra.station_ids) ? extra.station_ids.length : 0;
    return `
      <button type="button" class="station-extra-config-row ${String(extra.id) === String(state.selectedStationExtraId) ? 'active-selection' : ''}" data-station-extra-id="${escapeAttr(extra.id)}">
        <span><strong>${escapeHtml(extra.name)}</strong><small>${money(extra.price)} · ${extra.pricing_type === 'HOURLY' ? 'por hora' : (extra.pricing_type === 'FIXED' ? 'fijo' : 'por sesión')} · ${stationCount} estación(es)</small></span>
        <em>${extra.is_active === false ? 'Inactivo' : 'Activo'}</em>
      </button>
    `;
  }).join('') : '<div class="empty-state">Sin extras configurados</div>';

  list.querySelectorAll('[data-station-extra-id]').forEach((btn) => {
    btn.addEventListener('click', () => selectStationExtraConfig(btn.dataset.stationExtraId));
  });

  const selectedExtra = (state.stationExtras || []).find((extra) => String(extra.id) === String(state.selectedStationExtraId));
  const selectedIds = new Set((Array.isArray(selectedExtra?.station_ids) ? selectedExtra.station_ids : []).map(String));
  assignments.innerHTML = `
    <strong>Disponible en estaciones</strong>
    <div class="station-extra-assignment-grid">
      ${(state.stations || []).map((station) => `
        <label class="station-extra-assignment-pill">
          <input type="checkbox" data-station-extra-assignment value="${escapeAttr(station.id)}" ${selectedIds.has(String(station.id)) ? 'checked' : ''} />
          <span>${escapeHtml(station.name)}</span>
        </label>
      `).join('')}
    </div>
  `;
}

async function saveStationExtraConfig() {
  if (!canManageStations()) return showToast('No tienes permiso');
  const payload = {
    name: $('#stationExtraNameInput')?.value?.trim() || '',
    description: $('#stationExtraDescriptionInput')?.value?.trim() || '',
    price: Number($('#stationExtraPriceInput')?.value || 0),
    pricingType: $('#stationExtraPricingTypeSelect')?.value || 'SESSION',
    sortOrder: Number($('#stationExtraOrderInput')?.value || 0),
    isActive: Boolean($('#stationExtraActiveInput')?.checked),
    stationIds: getStationExtraSelectedStationIds()
  };
  try {
    if (state.selectedStationExtraId) {
      await api(`/stations/extras/${state.selectedStationExtraId}`, { method: 'PUT', body: JSON.stringify(payload) });
      showToast('Extra actualizado');
    } else {
      await api('/stations/extras', { method: 'POST', body: JSON.stringify(payload) });
      showToast('Extra creado');
    }
    const { extras } = await api('/stations/extras');
    state.stationExtras = extras || [];
    renderStationExtrasConfigModule();
    renderModalProducts();
    closeStationExtraEditorModal();
  } catch (error) {
    showToast(error.message || 'No se pudo guardar el extra');
  }
}

function bindStationExtrasConfigEvents() {
  $('#saveStationExtraBtn')?.addEventListener('click', saveStationExtraConfig);
  $('#newStationExtraBtn')?.addEventListener('click', () => {
    resetStationExtraForm();
    openStationExtraEditorModal();
  });
}

async function saveStationConfig() {
  if (!canManageStations()) return showToast('No tienes permiso');

  const selectedStation = state.selectedStationConfigId
    ? state.stations.find((item) => String(item.id) === String(state.selectedStationConfigId))
    : null;

  const payload = {
    name: $('#stationConfigNameInput').value.trim(),
    consoleType: $('#stationConfigModelSelect').value,
    hourlyRate: Number(selectedStation?.hourly_rate || 0),
    sortOrder: Number($('#stationConfigOrderInput').value || 0),
    status: $('#stationConfigStatusSelect').value
  };

  try {
    if (state.selectedStationConfigId) {
      await api(`/stations/${state.selectedStationConfigId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showToast('Estación actualizada');
    } else {
      await api('/stations', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showToast('Estación creada');
    }

    await loadStations();
    renderStationsConfigModule();
    closeStationConfigEditorModal();
  } catch (error) {
    showToast(error.message);
  }
}

async function deleteStationConfig() {
  if (!canManageStations()) return showToast('No tienes permiso');
  if (!state.selectedStationConfigId) return showToast('Selecciona una estación');

  const station = state.stations.find((item) => String(item.id) === String(state.selectedStationConfigId));
  if (!station) return showToast('Estación no encontrada');
  if (station.status === 'BUSY' || station.active_session_id) return showToast('No puedes eliminar una estación ocupada');

  const confirmed = window.confirm(`¿Eliminar ${station.name}? Se ocultará de la pantalla de estaciones y conservará el historial.`);
  if (!confirmed) return;

  try {
    await api(`/stations/${state.selectedStationConfigId}`, { method: 'DELETE' });
    showToast('Estación eliminada');
    await loadStations();
    resetStationConfigForm();
    closeStationConfigEditorModal();
  } catch (error) {
    showToast(error.message);
  }
}

function getSelectedSessionGame(station = state.selectedStation) {
  const activeGameId = station?.session_game_id || station?.game_id || null;
  const orderGameId = state.order?.gameId || null;
  const gameId = orderGameId || activeGameId;
  if (!gameId) return null;
  return (state.stationGames || []).find((game) => String(game.id) === String(gameId)) || {
    id: gameId,
    name: station?.session_game_name || 'Juego seleccionado',
    platform: station?.session_game_platform || '',
    cover_url: station?.session_game_cover_url || ''
  };
}

function renderGameQuickSelection() {
  const label = $('#gameQuickLabel');
  if (!label) return;
  const game = getSelectedSessionGame();
  if (game?.name) {
    label.textContent = game.name;
    $('#openGamePickerBtn')?.classList.add('selected');
  } else {
    label.textContent = 'Juego no especificado';
    $('#openGamePickerBtn')?.classList.remove('selected');
  }
}

function selectStationOrderGame(gameId = null) {
  state.order.gameId = gameId || null;
  state.order.extraControllerCount = normalizeExtraControllerCount(state.order.extraControllerCount);
  renderGameQuickSelection();
  renderTimeOptions();
  renderOrder();
  closeGamePickerModal();
  setTimeout(() => maybeShowSavedGameAlert(), 80);
}

function renderGamePickerGrid() {
  const grid = $('#gamePickerGrid');
  if (!grid) return;
  const term = String($('#gamePickerSearchInput')?.value || '').trim().toLowerCase();
  const currentId = state.order?.gameId || state.selectedStation?.session_game_id || null;
  const games = getActiveStationGames()
    .filter((game) => isGameCompatibleWithStation(game, state.selectedStation))
    .filter((game) => !term || String(game.name || '').toLowerCase().includes(term) || String(game.platform || '').toLowerCase().includes(term) || getGameCompatibleConsoles(game).join(' ').toLowerCase().includes(term));

  grid.innerHTML = games.length ? games.map((game) => {
    const availability = getGameAvailabilityInfo(game, state.selectedStation);
    return `
      <button type="button" class="game-card-option ${String(currentId) === String(game.id) ? 'selected' : ''} ${availability.selectable ? '' : 'disabled'}" data-game-select="${escapeAttr(game.id)}" data-game-selectable="${availability.selectable ? 'true' : 'false'}" data-game-unavailable-reason="${escapeAttr(`${availability.label} · ${availability.reason}`)}" ${availability.selectable ? '' : 'aria-disabled="true"'}>
        ${getStationGameCoverMarkup(game, 'large')}
        <span><strong>${escapeHtml(game.name)}</strong><small>${escapeHtml(getGameCompatibleConsoles(game).join(' / '))}</small></span>
        <b class="game-availability-pill">${escapeHtml(availability.label)}</b>
        <small class="game-availability-reason">${escapeHtml(availability.reason)}</small>
        ${availability.selectable ? '' : '<small class="game-request-hint">Cliente pidió este juego</small>'}
        ${game.requires_profile_alert ? '<em>Perfil</em>' : ''}
      </button>
    `;
  }).join('') : '<div class="empty-state">Sin juegos compatibles para esta estación</div>';
  grid.querySelectorAll('[data-game-select]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.dataset.gameSelectable === 'false') {
        const game = (state.stationGames || []).find((item) => String(item.id) === String(btn.dataset.gameSelect));
        openGameRequestModal({ game, reason: btn.dataset.gameUnavailableReason || 'No disponible ahora' });
        return;
      }
      selectStationOrderGame(btn.dataset.gameSelect);
    });
  });
}

function openGamePickerModal() {
  const modal = $('#gamePickerModal');
  if (!modal) return;
  if ($('#gamePickerSearchInput')) $('#gamePickerSearchInput').value = '';
  renderGamePickerGrid();
  openModalElement(modal, { base: 2147483000 });
}

function closeGamePickerModal() {
  const modal = $('#gamePickerModal');
  if (modal) closeModalElement(modal);
}


function openGameRequestModal({ game = null, reason = '', requestType = 'EXISTING' } = {}) {
  const modal = $('#gameRequestModal');
  if (!modal) return;
  const pickerModal = $('#gamePickerModal');
  const hadPickerOpen = pickerModal && !pickerModal.classList.contains('hidden');
  if (hadPickerOpen) {
    closeModalElement(pickerModal);
    state.returnToGamePickerAfterRequestClose = true;
  }
  const type = game?.id ? 'EXISTING' : requestType;
  $('#gameRequestTypeInput').value = type;
  $('#gameRequestGameIdInput').value = game?.id || '';
  $('#gameRequestTitle').textContent = game?.name ? `${game.name} no está disponible` : 'Solicitar juego nuevo';
  $('#gameRequestSubtitle').textContent = game?.name ? 'Registra demanda, espera o venta perdida.' : 'Guarda sugerencias y solicitudes oficiales de miembros.';
  $('#gameRequestNameLabel')?.classList.toggle('hidden', type !== 'NEW_GAME');
  setGameRequestScope(getGameRequestMemberId() ? 'OFFICIAL' : 'SUGGESTION');
  $('#gameRequestNameInput').value = game?.name || '';
  $('#gameRequestPlatformInput').value = state.selectedStation?.console_type || game?.platform || '';
  $('#gameRequestCustomerInput').value = '';
  syncGameRequestMemberFields();
  $('#gameRequestReasonInput').value = reason || (game?.name ? 'No disponible ahora' : 'Juego no está en catálogo');
  $('#gameRequestNotesInput').value = '';
  openModalElement(modal, { base: 2147483200 });
}

function closeGameRequestModal({ reopenPicker = false, closeStation = false } = {}) {
  const modal = $('#gameRequestModal');
  if (modal) closeModalElement(modal);
  closeGamePickerModal();
  const shouldReopenPicker = reopenPicker === true;
  state.returnToGamePickerAfterRequestClose = false;
  if (closeStation) {
    closeStationModal();
    return;
  }
  if (shouldReopenPicker) openGamePickerModal();
}

function getGameRequestDialog() {
  const dialog = window.ClubVersusCore?.modalManager?.showAppDialog;
  return typeof dialog === 'function' ? dialog : null;
}

async function shouldAddGameRequestToWaitlist(game = null) {
  const dialog = getGameRequestDialog();
  const gameName = game?.name || $('#gameRequestNameInput')?.value || 'este juego';
  closeGameRequestModal({ reopenPicker: false });
  await new Promise((resolve) => setTimeout(resolve, 80));
  if (!dialog) return window.confirm(`¿Agregar al cliente a la lista de espera para ${gameName}?`);
  const response = await dialog({
    title: 'Agregar a lista de espera',
    subtitle: gameName,
    message: 'El cliente puede esperar en el local sin entrar a la lista formal. ¿Quieres agregarlo para que el sistema avise cuando esté disponible?',
    primaryText: 'Sí, agregar a lista',
    secondaryText: 'No, solo registrar'
  });
  return response === 'primary';
}


function getGameStationLocationIds(game = {}) {
  const locations = Array.isArray(game.locations) ? game.locations : [];
  return locations
    .map((location) => location.station_id || location.stationId)
    .filter(Boolean)
    .map(String);
}

function findPaidWaitlistTargetStation(game = null, platform = '') {
  const locationIds = new Set(getGameStationLocationIds(game));
  const candidates = (state.stations || []).filter((station) => {
    if (platform && station.console_type !== platform) return false;
    if (game && !isGameCompatibleWithStation(game, station)) return false;
    if (locationIds.size && !locationIds.has(String(station.id))) return false;
    return true;
  }).sort((a, b) => Number(a.sort_order || 999) - Number(b.sort_order || 999) || String(a.name || '').localeCompare(String(b.name || '')));
  return candidates[0] || state.selectedStation || null;
}

function ensurePaidWaitlistModal() {
  let modal = document.querySelector('#paidWaitlistModal');
  if (modal) return modal;
  modal = document.createElement('section');
  modal.id = 'paidWaitlistModal';
  modal.className = 'modal hidden paid-waitlist-modal';
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="modal-backdrop" data-paid-waitlist-cancel></div>
    <div class="modal-card paid-waitlist-card">
      <header class="modal-header">
        <div>
          <h2 id="paidWaitlistTitle">Lista de espera pagada</h2>
          <p id="paidWaitlistMeta">Juego ocupado</p>
        </div>
        <button type="button" class="icon-btn" data-paid-waitlist-cancel>×</button>
      </header>
      <div class="paid-waitlist-body">
        <label>Nombre del cliente<input id="paidWaitlistNameInput" type="text" placeholder="Nombre" autocomplete="off" /></label>
        <label>Tiempo que desea<select id="paidWaitlistMinutesInput"></select></label>
        <label>Jugadores<select id="paidWaitlistPlayersInput"><option value="1">1 jugador</option><option value="2">2 jugadores</option></select></label>
        <label class="paid-waitlist-courtesy-row"><input id="paidWaitlistKidsCourtesyInput" type="checkbox" /> <span id="paidWaitlistKidsCourtesyLabel">Extensión niños</span></label>
        <div class="paid-waitlist-summary" id="paidWaitlistSummary">Total RD$0</div>
      </div>
      <div class="modal-actions drawer-actions-grid">
        <button type="button" id="paidWaitlistConfirmBtn">Registrar y cobrar</button>
        <button type="button" class="secondary" data-paid-waitlist-cancel>Cancelar</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
  return modal;
}

function getPaidWaitlistPriceOptions(station, playerCount = 1) {
  return getStationTimePrices(station, normalizePlayerCount(playerCount))
    .filter((price) => Number(price.minutes || 0) > 0)
    .sort((a, b) => Number(a.sort_order || a.minutes || 0) - Number(b.sort_order || b.minutes || 0));
}

async function openPaidWaitlistFromGameRequest(payload = {}, game = null) {
  const targetStation = findPaidWaitlistTargetStation(game, payload.platform || '');
  if (!targetStation) {
    showToast('No hay estación configurada para ese juego');
    return false;
  }
  const modal = ensurePaidWaitlistModal();
  const nameInput = modal.querySelector('#paidWaitlistNameInput');
  const minutesSelect = modal.querySelector('#paidWaitlistMinutesInput');
  const playersSelect = modal.querySelector('#paidWaitlistPlayersInput');
  const courtesyInput = modal.querySelector('#paidWaitlistKidsCourtesyInput');
  const courtesyLabel = modal.querySelector('#paidWaitlistKidsCourtesyLabel');
  const summary = modal.querySelector('#paidWaitlistSummary');
  const confirmBtn = modal.querySelector('#paidWaitlistConfirmBtn');
  const meta = modal.querySelector('#paidWaitlistMeta');
  const title = modal.querySelector('#paidWaitlistTitle');
  const settings = getKidsCourtesySettings();

  if (title) title.textContent = 'Lista de espera pagada';
  if (meta) meta.textContent = `${game?.name || payload.requestedGameName || 'Juego'} · ${targetStation.name || targetStation.console_type || ''}`;
  if (nameInput) nameInput.value = payload.customerName || '';

  const refreshOptions = () => {
    const playerCount = normalizePlayerCount(playersSelect?.value || 1);
    const options = getPaidWaitlistPriceOptions(targetStation, playerCount);
    if (minutesSelect) {
      minutesSelect.innerHTML = options.map((price) => `<option value="${Number(price.minutes || 0)}" data-price-id="${escapeAttr(price.id || '')}" data-price="${Number(getTimePriceWithPromotion(targetStation, price).finalPrice || price.price || 0)}">${escapeHtml(price.label || `${price.minutes} min`)} · ${money(Number(getTimePriceWithPromotion(targetStation, price).finalPrice || price.price || 0))}</option>`).join('');
    }
    refreshSummary();
  };

  const refreshSummary = () => {
    const selected = minutesSelect?.selectedOptions?.[0];
    const baseMinutes = Number(selected?.value || 0);
    const basePrice = Number(selected?.dataset?.price || 0);
    const courtesyAllowed = Boolean(settings.enabled && targetStation.console_type === settings.consoleType && baseMinutes === Number(settings.baseMinutes || 15));
    if (courtesyInput) {
      courtesyInput.disabled = !courtesyAllowed;
      if (!courtesyAllowed) courtesyInput.checked = false;
    }
    if (courtesyLabel) courtesyLabel.textContent = courtesyAllowed ? `${settings.label || 'Extensión niños'} +${Number(settings.extensionMinutes || 5)} min` : 'Extensión niños no aplica';
    const courtesyMinutes = courtesyInput?.checked ? Number(settings.extensionMinutes || 5) : 0;
    if (summary) summary.innerHTML = `<strong>Total ${money(basePrice)}</strong><small>Tiempo: ${baseMinutes + courtesyMinutes} min${courtesyMinutes ? ` (${baseMinutes} + ${courtesyMinutes} cortesía)` : ''}</small>`;
  };

  if (playersSelect) playersSelect.onchange = refreshOptions;
  if (minutesSelect) minutesSelect.onchange = refreshSummary;
  if (courtesyInput) courtesyInput.onchange = refreshSummary;
  refreshOptions();

  return new Promise((resolve) => {
    let settled = false;
    const close = (value) => {
      if (settled) return;
      settled = true;
      modal.querySelectorAll('[data-paid-waitlist-cancel]').forEach((btn) => btn.removeEventListener('click', onCancel));
      confirmBtn?.removeEventListener('click', onConfirm);
      closeModalElement?.(modal);
      resolve(value);
    };
    const onCancel = () => close(false);
    const onConfirm = () => {
      const customerName = String(nameInput?.value || '').trim();
      if (!customerName) {
        showToast('Escribe el nombre del cliente');
        nameInput?.focus();
        return;
      }
      const selected = minutesSelect?.selectedOptions?.[0];
      const baseMinutes = Number(selected?.value || 0);
      const basePrice = Number(selected?.dataset?.price || 0);
      if (baseMinutes <= 0 || basePrice < 0) return showToast('Selecciona un tiempo válido');
      const courtesyAllowed = Boolean(settings.enabled && targetStation.console_type === settings.consoleType && baseMinutes === Number(settings.baseMinutes || 15));
      const courtesyMinutes = courtesyAllowed && courtesyInput?.checked ? Number(settings.extensionMinutes || 5) : 0;
      const totalMinutes = baseMinutes + courtesyMinutes;
      const playerCount = normalizePlayerCount(playersSelect?.value || 1);
      closeModalElement?.(modal);
      state.customPaymentFlow = {
        active: true,
        total: basePrice,
        label: 'Lista de espera',
        onConfirm: async ({ paymentMethod = 'CASH', reference = '', transferAuthorizationCode = '' } = {}) => {
          try {
            await api('/stations/game-requests', { method: 'POST', body: JSON.stringify({ ...payload, customerName, notes: [payload.notes, `Lista de espera pagada ${totalMinutes} min`].filter(Boolean).join(' · ') }) });
            await api('/stations/game-reservations', {
              method: 'POST',
              body: JSON.stringify({
                reservationType: 'WAITLIST',
                gameId: payload.gameId || null,
                stationId: targetStation.id,
                memberId: payload.memberId || null,
                customerName,
                customerPhone: '',
                platform: targetStation.console_type || payload.platform || '',
                minMinutes: totalMinutes,
                reservedMinutes: totalMinutes,
                playerCount,
                paidAmount: basePrice,
                paymentMethod,
                paymentReference: reference,
                transferAuthorizationCode,
                notes: [payload.unavailableReason, `Pagó ${baseMinutes} min${courtesyMinutes ? ` + ${courtesyMinutes} min cortesía` : ''}`, `Juego: ${game?.name || payload.requestedGameName || ''}`].filter(Boolean).join(' · ')
              })
            });
            showToast('Lista de espera pagada registrada');
            await loadGameReservations();
            return true;
          } catch (error) {
            if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message || 'No se pudo cobrar transferencia');
            else showToast(error.message || 'No se pudo registrar la lista pagada');
            return false;
          }
        }
      };
      openCashPaymentModal();
      close(true);
    };
    modal.querySelectorAll('[data-paid-waitlist-cancel]').forEach((btn) => btn.addEventListener('click', onCancel));
    confirmBtn?.addEventListener('click', onConfirm);
    openModalElement(modal, { base: 2147483300 });
    setTimeout(() => nameInput?.focus(), 80);
  });
}

function buildWaitlistPayloadFromGameRequest(payload = {}) {
  const noteParts = [];
  if (payload.unavailableReason) noteParts.push(payload.unavailableReason);
  if (payload.notes) noteParts.push(payload.notes);
  if (state.selectedStation?.name) noteParts.push(`Solicitado desde ${state.selectedStation.name}`);
  return {
    reservationType: 'WAITLIST',
    gameId: payload.gameId || null,
    stationId: null,
    memberId: payload.memberId || null,
    customerName: payload.customerName || '',
    customerPhone: '',
    platform: payload.platform || '',
    desiredStartAt: null,
    minMinutes: 0,
    reservedMinutes: 0,
    playerCount: 1,
    paidAmount: 0,
    paymentMethod: 'CASH',
    priorityLevel: 0,
    notes: noteParts.filter(Boolean).join(' · ')
  };
}

async function submitGameRequest(customerDecision = 'SOLO_REGISTRAR') {
  const type = $('#gameRequestTypeInput')?.value || 'EXISTING';
  const gameId = $('#gameRequestGameIdInput')?.value || null;
  const game = gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
  const normalizedDecision = String(customerDecision || '').toUpperCase();
  const payload = {
    requestType: type,
    gameId,
    requestedGameName: type === 'NEW_GAME' ? ($('#gameRequestNameInput')?.value || '').trim() : (game?.name || ''),
    platform: $('#gameRequestPlatformInput')?.value || state.selectedStation?.console_type || '',
    stationId: state.selectedStation?.id || null,
    memberId: state.selectedMember?.id || state.selectedStation?.member_id || null,
    customerName: (state.selectedMember?.id || state.selectedStation?.member_id) ? '' : (($('#gameRequestCustomerInput')?.value || '').trim()),
    unavailableReason: ($('#gameRequestReasonInput')?.value || '').trim(),
    customerDecision: normalizedDecision,
    requestScope: $('#gameRequestScopeInput')?.value || 'SUGGESTION',
    notes: ($('#gameRequestNotesInput')?.value || '').trim()
  };
  if (payload.requestScope === 'OFFICIAL' && !payload.memberId) {
    showToast('Selecciona un miembro para solicitud oficial');
    return;
  }
  try {
    let addedToWaitlist = false;
    let requestPayload = { ...payload };
    if (normalizedDecision === 'ESPERA') {
      addedToWaitlist = await shouldAddGameRequestToWaitlist(game || { name: payload.requestedGameName });
      if (!addedToWaitlist) {
        requestPayload = {
          ...payload,
          notes: [payload.notes, 'Cliente decidió esperar en el local sin lista formal'].filter(Boolean).join(' · ')
        };
      }
    }

    if (normalizedDecision === 'ESPERA' && addedToWaitlist) {
      await openPaidWaitlistFromGameRequest(payload, game || { name: payload.requestedGameName });
      return;
    }

    await api('/stations/game-requests', { method: 'POST', body: JSON.stringify(requestPayload) });

    const message = normalizedDecision === 'ESPERA'
      ? 'Espera registrada sin lista formal'
      : normalizedDecision === 'ACEPTO_OTRO'
        ? 'Demanda registrada, elige otro juego'
        : normalizedDecision === 'SE_FUE'
          ? 'Posible venta perdida registrada'
          : 'Solicitud registrada';
    showToast(message);
    if (normalizedDecision === 'ACEPTO_OTRO') {
      closeGameRequestModal({ reopenPicker: true });
    } else if (!(normalizedDecision === 'ESPERA')) {
      closeGameRequestModal({ closeStation: true });
    } else {
      closeStationModal();
    }
  } catch (error) {
    showToast(error.message || 'No se pudo registrar la solicitud');
  }
}



function getAvailableWaitlistRows() {
  return (state.gameReservations || []).filter((item) => (
    String(item.reservation_type || '').toUpperCase() === 'WAITLIST'
    && ['WAITING', 'NOTIFIED'].includes(String(item.status || '').toUpperCase())
    && item.waitlist_available === true
  ));
}

function syncWaitlistAvailabilityBadge() {
  const btn = $('#openGameReservationsBtn');
  if (!btn) return;
  const availableCount = getAvailableWaitlistRows().length;
  btn.classList.toggle('has-waitlist-alert', availableCount > 0);
  btn.dataset.waitlistAvailable = String(availableCount);
  btn.title = availableCount > 0 ? `${availableCount} cliente(s) en espera con juego disponible` : '';
}

function notifyAvailableWaitlistRows() {
  const available = getAvailableWaitlistRows();
  if (!available.length) return;
  if (!state.waitlistAvailabilityNotifiedIds) state.waitlistAvailabilityNotifiedIds = new Set();
  const fresh = available.filter((item) => !state.waitlistAvailabilityNotifiedIds.has(String(item.id)));
  fresh.forEach((item) => state.waitlistAvailabilityNotifiedIds.add(String(item.id)));
  if (!fresh.length) return;
  const first = fresh[0];
  const name = first.customer_name || first.member_name || 'Cliente en espera';
  const game = first.game_name || 'el juego solicitado';
  const station = first.waitlist_available_station_name || first.station_name || 'una estación disponible';
  showToast(`${name}: ${game} ya está disponible en ${station}`);
}

async function loadGameReservations() {
  try {
    const { reservations } = await api('/stations/game-reservations');
    state.gameReservations = reservations || [];
    renderGameReservationsList();
    syncWaitlistAvailabilityBadge();
    notifyAvailableWaitlistRows();
  } catch (error) {
    state.gameReservations = [];
    syncWaitlistAvailabilityBadge();
    throw error;
  }
}

function getGameHighlightLabel(game = {}) {
  const type = String(game.highlight_type || '').toUpperCase();
  if (type === 'GAME_OF_MONTH') return 'Juego del mes';
  if (type === 'IMPORTANT_RELEASE') return 'Lanzamiento importante';
  if (type === 'PREMIUM') return 'Premium';
  if (type === 'HIGH_DEMAND') return 'Alta demanda';
  if (game.is_featured || game.priority_enabled) return 'Destacado';
  return '';
}


function getReservationSelectedGame() {
  const gameId = $('#gameReservationGameInput')?.value || '';
  return gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
}


function normalizeReservationPlayerCount(value) {
  const count = Number.parseInt(String(value || 1), 10);
  if (!Number.isFinite(count) || count < 1) return 1;
  return Math.min(20, count);
}

function getReservationGameAvailableConsoles(game = null) {
  if (!game) return [...GAME_COMPATIBLE_CONSOLES];
  const compatible = getGameCompatibleConsoles(game).filter((consoleName) => GAME_COMPATIBLE_CONSOLES.includes(consoleName));
  const activeLocations = Array.isArray(game.locations)
    ? game.locations.filter((location) => String(location.status || '').toLowerCase() !== 'no instalado')
    : [];
  const stationConsoles = activeLocations
    .map((location) => location.station_console_type)
    .filter(Boolean);
  const deviceConsoles = activeLocations
    .flatMap((location) => getGameCompatibleConsoles({ platform: location.device_platform || location.location_type || '' }))
    .filter((consoleName) => GAME_COMPATIBLE_CONSOLES.includes(consoleName));
  const locationConsoles = [...new Set([...stationConsoles, ...deviceConsoles])]
    .filter((consoleName) => compatible.includes(consoleName));
  return locationConsoles.length ? locationConsoles : compatible;
}

function getReservationGameAllowedStationIds(game = null) {
  if (!game || !Array.isArray(game.locations)) return null;
  const stationIds = game.locations
    .filter((location) => location.station_id && String(location.status || '').toLowerCase() !== 'no instalado')
    .map((location) => String(location.station_id));
  return stationIds.length ? new Set(stationIds) : null;
}

function getReservationCompatibleStations(game = getReservationSelectedGame()) {
  const platform = $('#gameReservationPlatformInput')?.value || '';
  const consoles = getReservationGameAvailableConsoles(game);
  const allowedStationIds = getReservationGameAllowedStationIds(game);
  return (state.stations || []).filter((station) => {
    if (!station || station.status === 'OFFLINE') return false;
    if (platform && station.console_type !== platform) return false;
    if (consoles.length && !consoles.includes(station.console_type)) return false;
    if (allowedStationIds && !allowedStationIds.has(String(station.id))) return false;
    return true;
  });
}

function syncReservationPlatformAndStations({ preservePlatform = true } = {}) {
  const game = getReservationSelectedGame();
  const platformSelect = $('#gameReservationPlatformInput');
  const stationSelect = $('#gameReservationStationInput');
  if (!platformSelect || !stationSelect) return;
  const consoles = getReservationGameAvailableConsoles(game);
  const currentPlatform = preservePlatform ? platformSelect.value : '';
  const hasOneConsole = game && consoles.length === 1;
  const options = hasOneConsole
    ? consoles.map((consoleName) => `<option value="${escapeAttr(consoleName)}">${escapeHtml(getReservationConsoleLabel(consoleName))}</option>`)
    : ['<option value="">Automática / sin especificar</option>', ...consoles.map((consoleName) => `<option value="${escapeAttr(consoleName)}">${escapeHtml(getReservationConsoleLabel(consoleName))}</option>`)];
  platformSelect.innerHTML = options.join('');
  platformSelect.value = hasOneConsole ? consoles[0] : (consoles.includes(currentPlatform) ? currentPlatform : '');

  const currentStation = stationSelect.value;
  const stations = getReservationCompatibleStations(game);
  stationSelect.innerHTML = '<option value="">Sin estación específica</option>' + stations.map((station) => (
    `<option value="${escapeAttr(station.id)}">${escapeHtml(station.name || 'Estación')} · ${escapeHtml(station.console_type || '')}</option>`
  )).join('');
  stationSelect.value = stations.some((station) => String(station.id) === String(currentStation)) ? currentStation : '';
  renderReservationMinuteOptions();
  renderGameReservationPaymentBox();
}

function openReservationDatePicker() {
  const input = $('#gameReservationDateInput');
  if (!input) return;
  try {
    if (typeof input.showPicker === 'function') input.showPicker();
  } catch (_) {}
  input.focus();
}

function fillReservationHourSelect() {
  ['#gameReservationHourInput', '#groupReservationHourInput'].forEach((selector) => {
    const hourInput = $(selector);
    if (!hourInput || hourInput.dataset.ready === '1') return;
    hourInput.innerHTML = '<option value="">Hora</option>' + Array.from({ length: 12 }, (_, index) => {
      const hour = index + 1;
      return `<option value="${hour}">${hour}</option>`;
    }).join('');
    hourInput.dataset.ready = '1';
  });
}

function buildReservationLocalDate() {
  const dateValue = $('#gameReservationDateInput')?.value || '';
  const hourValue = Number($('#gameReservationHourInput')?.value || 0);
  const minuteValue = Number($('#gameReservationMinuteInput')?.value || 0);
  const ampm = $('#gameReservationAmPmInput')?.value || 'AM';
  if (!dateValue || !hourValue) return null;
  const [year, month, day] = dateValue.split('-').map((part) => Number(part));
  if (!year || !month || !day) return null;
  let hour24 = hourValue % 12;
  if (ampm === 'PM') hour24 += 12;
  return new Date(year, month - 1, day, hour24, minuteValue, 0, 0);
}

function formatReservationLocalDate(date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  let hours = date.getHours();
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;
  return `${day}/${month}/${year} ${hours}:${minutes} ${ampm}`;
}

function syncReservationDesiredStart() {
  const hidden = $('#gameReservationTimeInput');
  const summary = $('#gameReservationTimeSummary');
  const type = $('#gameReservationTypeInput')?.value || 'WAITLIST';
  const isWaitlist = type !== 'RESERVATION';
  if (isWaitlist) {
    if (hidden) hidden.value = '';
    if (summary) {
      const minutes = Number($('#gameReservationMinutesInput')?.value || 0);
      summary.innerHTML = `<strong>Lista de espera</strong><small>${minutes ? `${minutes} min cuando se libere` : 'Selecciona el tiempo que desea pagar'}</small>`;
    }
    renderGameReservationPaymentBox();
    return;
  }

  const date = buildReservationLocalDate();
  if (hidden) hidden.value = date ? date.toISOString() : '';
  if (summary) {
    const minutes = Number($('#gameReservationMinutesInput')?.value || 0);
    if (!date) {
      summary.innerHTML = '<strong>Sin horario</strong><small>Elige fecha, hora y tiempo configurado.</small>';
    } else {
      summary.innerHTML = `<strong>${escapeHtml(formatReservationLocalDate(date))}</strong><small>${minutes ? `${minutes} min seleccionados` : 'Selecciona el tiempo reservado'}</small>`;
    }
  }
  renderGameReservationPaymentBox();
}

function getReservationTypeLabel(value = 'GROUP') {
  const type = String(value || '').toUpperCase();
  if (type === 'BIRTHDAY') return 'Cumpleaños';
  if (type === 'PRIVATE_EVENT') return 'Todo el club';
  return 'Grupo';
}

function formatReservationMinutesLabel(minutes = 0) {
  const value = Number(minutes || 0);
  if (value >= 60 && value % 60 === 0) return `${value / 60} hora${value === 60 ? '' : 's'}`;
  if (value >= 60) {
    const hours = Math.floor(value / 60);
    const rest = value % 60;
    return `${hours}h ${rest}m`;
  }
  return `${value} min`;
}

function getActiveGroupEventPrices() {
  return (state.groupEventPrices || [])
    .filter((row) => row && row.is_active !== false)
    .slice()
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0));
}

function getGroupReservationSelectedRule() {
  const id = $('#groupReservationPackageInput')?.value || '';
  return getActiveGroupEventPrices().find((row) => String(row.id) === String(id)) || null;
}

function getGroupReservationRuleType(row = {}) {
  const source = row || {};
  return String(source.price_type || source.priceType || 'GROUP').trim().toUpperCase();
}

function getGroupReservationRuleMinPlayers(row = {}) {
  const source = row || {};
  return Number(source.min_players ?? source.minPlayers ?? 1) || 1;
}

function getGroupReservationRuleStationCount(row = {}) {
  const source = row || {};
  return Number(source.station_count ?? source.stationCount ?? 0) || 0;
}

function isGroupReservationRuleFullClub(row = {}) {
  const source = row || {};
  return Boolean(source.is_full_club ?? source.isFullClub);
}

function getGroupReservationSelectedStationCount(rule = getGroupReservationSelectedRule()) {
  if (!rule || isGroupReservationRuleFullClub(rule)) return 0;
  const selected = Number($('#groupReservationStationCountInput')?.value || 0);
  return Math.max(1, selected || getGroupReservationRuleStationCount(rule) || 1);
}

function syncGroupReservationPlayerMinimum(type = $('#groupReservationTypeInput')?.value || 'GROUP') {
  const playerInput = $('#groupReservationPlayerCountInput');
  if (!playerInput) return;
  const normalizedType = String(type || 'GROUP').toUpperCase();
  const matchingRules = getActiveGroupEventPrices().filter((row) => getGroupReservationRuleType(row) === normalizedType);
  if (!matchingRules.length) return;
  const minPlayers = Math.min(...matchingRules.map(getGroupReservationRuleMinPlayers).filter(Boolean));
  if (minPlayers && Number(playerInput.value || 0) < minPlayers) playerInput.value = String(minPlayers);
}

function syncGroupReservationStationCountOptions(rule = getGroupReservationSelectedRule()) {
  const stationCountInput = $('#groupReservationStationCountInput');
  const hint = $('#groupReservationExtraHint');
  if (!stationCountInput) return;
  if (!rule) {
    stationCountInput.disabled = true;
    if (hint) hint.innerHTML = '<span>Extras automáticos</span><strong>Sin paquete</strong><small>Selecciona un paquete grupal para calcular extras.</small>';
    return;
  }
  const isFullClub = isGroupReservationRuleFullClub(rule);
  const baseStations = getGroupReservationRuleStationCount(rule) || 1;
  const current = Number(stationCountInput.value || 0);
  if (isFullClub) {
    stationCountInput.innerHTML = '<option value="0">Todo el club</option>';
    stationCountInput.value = '0';
    stationCountInput.disabled = true;
    if (hint) hint.innerHTML = '<span>Extras automáticos</span><strong>Todo el club</strong><small>Este paquete bloquea el club completo. No se cobran estaciones extra.</small>';
    return;
  }
  const maxStations = Math.max(5, baseStations + 3);
  stationCountInput.disabled = false;
  stationCountInput.innerHTML = Array.from({ length: maxStations }, (_, idx) => idx + 1)
    .filter((value) => value >= baseStations)
    .map((value) => `<option value="${value}">${value} estación${value === 1 ? '' : 'es'}</option>`)
    .join('');
  stationCountInput.value = String(Math.max(baseStations, current || baseStations));
  const extraStationPrice = Number(rule.extra_station_price ?? rule.extraStationPrice ?? 0);
  const extraPlayerPrice = Number(rule.extra_player_price ?? rule.extraPlayerPrice ?? 0);
  if (hint) {
    hint.innerHTML = `<span>Extras automáticos</span><strong>Incluye ${getGroupReservationRuleMinPlayers(rule)} personas · ${baseStations} estación${baseStations === 1 ? '' : 'es'}</strong><small>Persona extra RD$${extraPlayerPrice.toFixed(0)} · Estación extra RD$${extraStationPrice.toFixed(0)}</small>`;
  }
}

function getGroupReservationSelectedGame() {
  const gameId = $('#groupReservationGameInput')?.value || '';
  return gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
}

function getGroupReservationCompatibleStations() {
  const game = getGroupReservationSelectedGame();
  const consoles = getReservationGameAvailableConsoles(game);
  const allowedStationIds = getReservationGameAllowedStationIds(game);
  return (state.stations || []).filter((station) => {
    if (!station || station.status === 'OFFLINE') return false;
    if (game && consoles.length && !consoles.includes(station.console_type)) return false;
    if (allowedStationIds && !allowedStationIds.has(String(station.id))) return false;
    return true;
  });
}

function fillGroupReservationGameSelect() {
  const gameSelect = $('#groupReservationGameInput');
  if (gameSelect) {
    const games = (state.stationGames || []).filter((game) => game.is_active !== false)
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    gameSelect.innerHTML = '<option value="">Sin juego principal</option>' + games.map((game) => {
      const badge = getGameHighlightLabel(game);
      return `<option value="${escapeAttr(game.id)}">${escapeHtml(game.name || 'Juego')}${badge ? ` · ${escapeHtml(badge)}` : ''}</option>`;
    }).join('');
  }
  renderGroupReservationStations();
}

function renderGroupReservationStations() {
  const stationSelect = $('#groupReservationStationInput');
  if (!stationSelect) return;
  const currentValue = stationSelect.value || '';
  const rule = getGroupReservationSelectedRule();
  const stations = getGroupReservationCompatibleStations();
  if (isGroupReservationRuleFullClub(rule)) {
    stationSelect.innerHTML = '<option value="">Todo el club · automático</option>';
    stationSelect.value = '';
    return;
  }
  stationSelect.innerHTML = '<option value="">Automática / estaciones libres</option>' + stations.map((station) => (
    `<option value="${escapeAttr(station.id)}">${escapeHtml(station.name || 'Estación')} · ${escapeHtml(station.console_type || '')}</option>`
  )).join('');
  stationSelect.value = stations.some((station) => String(station.id) === String(currentValue)) ? currentValue : '';
}

function renderGroupReservationPackageOptions({ preserve = true } = {}) {
  const packageSelect = $('#groupReservationPackageInput');
  if (!packageSelect) return;
  const type = String($('#groupReservationTypeInput')?.value || 'GROUP').toUpperCase();
  const players = normalizeReservationPlayerCount($('#groupReservationPlayerCountInput')?.value || 5);
  const currentValue = preserve ? packageSelect.value : '';
  const allTypeRows = getActiveGroupEventPrices().filter((row) => getGroupReservationRuleType(row) === type);
  const rows = allTypeRows.filter((row) => players >= getGroupReservationRuleMinPlayers(row));
  packageSelect.innerHTML = rows.length
    ? '<option value="">Selecciona paquete</option>' + rows.map((row) => {
        const minutes = Number(row.duration_minutes ?? row.durationMinutes ?? 0);
        const stationCount = getGroupReservationRuleStationCount(row);
        const stationText = isGroupReservationRuleFullClub(row) ? 'Todo el club' : `${stationCount || 1} estación${stationCount === 1 ? '' : 'es'}`;
        const price = Number(row.price || 0);
        return `<option value="${escapeAttr(row.id)}">${escapeHtml(row.name || getReservationTypeLabel(type))} · incluye ${getGroupReservationRuleMinPlayers(row)} personas · ${formatReservationMinutesLabel(minutes)} · ${stationText} · RD$${price.toFixed(0)}</option>`;
      }).join('')
    : `<option value="">${allTypeRows.length ? 'Sube la cantidad de personas para ese paquete' : 'No hay precio para ese tipo'}</option>`;
  packageSelect.value = rows.some((row) => String(row.id) === String(currentValue)) ? currentValue : (rows[0]?.id ? String(rows[0].id) : '');
  syncGroupReservationStationCountOptions(getGroupReservationSelectedRule());
  renderGroupReservationStations();
  syncGroupReservationDesiredStart();
}

function buildGroupReservationLocalDate() {
  const dateValue = $('#groupReservationDateInput')?.value || '';
  const hourValue = Number($('#groupReservationHourInput')?.value || 0);
  const minuteValue = Number($('#groupReservationMinuteInput')?.value || 0);
  const ampm = $('#groupReservationAmPmInput')?.value || 'AM';
  if (!dateValue || !hourValue) return null;
  const [year, month, day] = dateValue.split('-').map((part) => Number(part));
  if (!year || !month || !day) return null;
  let hour24 = hourValue % 12;
  if (ampm === 'PM') hour24 += 12;
  return new Date(year, month - 1, day, hour24, minuteValue, 0, 0);
}

function syncGroupReservationDesiredStart() {
  const hidden = $('#groupReservationTimeInput');
  const date = buildGroupReservationLocalDate();
  if (hidden) hidden.value = date ? date.toISOString() : '';
  renderGroupReservationSummary();
}

function getGroupReservationAmounts(rule = getGroupReservationSelectedRule()) {
  if (!rule) return { total: 0, required: 0, pending: 0, extraPlayers: 0, extraStations: 0, extraPlayerAmount: 0, extraStationAmount: 0 };
  const players = normalizeReservationPlayerCount($('#groupReservationPlayerCountInput')?.value || getGroupReservationRuleMinPlayers(rule));
  const basePlayers = getGroupReservationRuleMinPlayers(rule);
  const selectedStations = getGroupReservationSelectedStationCount(rule);
  const baseStations = isGroupReservationRuleFullClub(rule) ? 0 : Math.max(1, getGroupReservationRuleStationCount(rule) || 1);
  const extraPlayers = Math.max(0, players - basePlayers);
  const extraStations = isGroupReservationRuleFullClub(rule) ? 0 : Math.max(0, selectedStations - baseStations);
  const extraPlayerPrice = Number(rule.extra_player_price ?? rule.extraPlayerPrice ?? 0);
  const extraStationPrice = Number(rule.extra_station_price ?? rule.extraStationPrice ?? 0);
  const extraPlayerAmount = Number((extraPlayers * extraPlayerPrice).toFixed(2));
  const extraStationAmount = Number((extraStations * extraStationPrice).toFixed(2));
  const total = Number((Number(rule.price || 0) + extraPlayerAmount + extraStationAmount).toFixed(2));
  const percent = Number(rule.deposit_percent ?? rule.depositPercent ?? 50);
  const minDeposit = Number(rule.min_deposit_amount ?? rule.minDepositAmount ?? 0);
  const required = Number(Math.max(total * (percent / 100), minDeposit).toFixed(2));
  return { total, required, pending: Math.max(0, Number((total - required).toFixed(2))), extraPlayers, extraStations, extraPlayerAmount, extraStationAmount };
}

function renderGroupReservationSummary() {
  const box = $('#groupReservationSummaryBox');
  if (!box) return;
  const rule = getGroupReservationSelectedRule();
  if (!rule) {
    box.classList.remove('has-priority');
    box.innerHTML = '<strong>Selecciona paquete</strong><small>Usa los precios grupales configurados, no los tiempos normales.</small>';
    return;
  }
  const { total, required, pending, extraPlayers, extraStations, extraPlayerAmount, extraStationAmount } = getGroupReservationAmounts(rule);
  const players = normalizeReservationPlayerCount($('#groupReservationPlayerCountInput')?.value || 5);
  const date = buildGroupReservationLocalDate();
  const minutes = Number(rule.duration_minutes ?? rule.durationMinutes ?? 0);
  const stationCount = getGroupReservationSelectedStationCount(rule);
  const basePlayers = getGroupReservationRuleMinPlayers(rule);
  const baseStations = getGroupReservationRuleStationCount(rule);
  const stationText = isGroupReservationRuleFullClub(rule) ? 'Todo el club' : `${stationCount || 1} estación${stationCount === 1 ? '' : 'es'}`;
  const dateText = date ? ` · ${formatReservationLocalDate(date)}` : '';
  const extrasText = [
    extraPlayers ? `Personas extra: ${extraPlayers} · RD$${extraPlayerAmount.toFixed(2)}` : '',
    extraStations ? `Estaciones extra: ${extraStations} · RD$${extraStationAmount.toFixed(2)}` : ''
  ].filter(Boolean).join(' · ');
  box.classList.toggle('has-priority', total > 0 && required > 0);
  box.innerHTML = `<strong>${escapeHtml(rule.name || getReservationTypeLabel(rule.price_type))}</strong><small>Incluye ${basePlayers} personas${isGroupReservationRuleFullClub(rule) ? ' · todo el club' : ` · ${baseStations || 1} estación${(baseStations || 1) === 1 ? '' : 'es'}`}<br>${players} personas · ${formatReservationMinutesLabel(minutes)} · ${stationText}${dateText}${extrasText ? `<br>${escapeHtml(extrasText)}` : ''}<br>Total RD$${total.toFixed(2)} · Depósito RD$${required.toFixed(2)} · Pendiente RD$${pending.toFixed(2)}</small>`;
}

function resetGroupReservationForm() {
  ['#groupReservationDateInput', '#groupReservationTimeInput', '#groupReservationCustomerInput', '#groupReservationPhoneInput', '#groupReservationNotesInput'].forEach((selector) => {
    const el = $(selector);
    if (el) el.value = '';
  });
  const typeInput = $('#groupReservationTypeInput');
  if (typeInput) typeInput.value = 'GROUP';
  const playerInput = $('#groupReservationPlayerCountInput');
  if (playerInput) playerInput.value = '5';
  const stationCountInput = $('#groupReservationStationCountInput');
  if (stationCountInput) stationCountInput.value = '2';
  const minuteInput = $('#groupReservationMinuteInput');
  if (minuteInput) minuteInput.value = '00';
  const ampmInput = $('#groupReservationAmPmInput');
  if (ampmInput) ampmInput.value = 'AM';
  const methodInput = $('#groupReservationPaymentMethodInput');
  if (methodInput) methodInput.value = 'CASH';
  fillGroupReservationGameSelect();
  renderGroupReservationPackageOptions({ preserve: false });
}

function buildGroupReservationPayload(paymentOverride = {}) {
  const rule = getGroupReservationSelectedRule();
  const gameId = $('#groupReservationGameInput')?.value || '';
  const game = gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
  const stationCount = getGroupReservationSelectedStationCount(rule);
  const isFullClub = isGroupReservationRuleFullClub(rule);
  const notes = [
    `Grupo / Cumpleaños / Evento: ${rule?.name || 'paquete grupal'}`,
    isFullClub ? 'Todo el club' : `${stationCount || 1} estación(es)`,
    ($('#groupReservationNotesInput')?.value || '').trim()
  ].filter(Boolean).join(' · ');
  return {
    reservationType: 'RESERVATION',
    reservationScope: 'GROUP_EVENT',
    groupEventPriceId: rule?.id || null,
    gameId: gameId || null,
    stationId: $('#groupReservationStationInput')?.value || null,
    memberId: null,
    customerName: ($('#groupReservationCustomerInput')?.value || '').trim(),
    customerPhone: ($('#groupReservationPhoneInput')?.value || '').trim(),
    platform: game?.platform || '',
    desiredStartAt: $('#groupReservationTimeInput')?.value || null,
    minMinutes: Number(rule?.duration_minutes ?? rule?.durationMinutes ?? 0),
    reservedMinutes: Number(rule?.duration_minutes ?? rule?.durationMinutes ?? 0),
    playerCount: normalizeReservationPlayerCount($('#groupReservationPlayerCountInput')?.value || 5),
    stationCount: isFullClub ? 0 : Math.max(1, stationCount || 1),
    isFullClub,
    paidAmount: Number(paymentOverride.paidAmount ?? 0),
    paymentMethod: paymentOverride.paymentMethod || 'CASH',
    paymentReference: paymentOverride.paymentReference || '',
    transferAuthorizationCode: paymentOverride.transferAuthorizationCode || '',
    priorityLevel: 0,
    notes
  };
}

async function saveGroupReservation() {
  const rule = getGroupReservationSelectedRule();
  if (!rule) {
    showToast('Selecciona un paquete grupal configurado');
    $('#groupReservationPackageInput')?.focus();
    return;
  }
  const { total, required } = getGroupReservationAmounts(rule);
  if (total <= 0 || required <= 0) {
    showToast('Configura precio y depósito para ese paquete');
    return;
  }
  const payload = buildGroupReservationPayload();
  if (!payload.customerName && !payload.gameId) {
    showToast('Escribe el nombre del cliente/evento o selecciona un juego');
    $('#groupReservationCustomerInput')?.focus();
    return;
  }
  if (!payload.desiredStartAt) {
    showToast('Selecciona fecha y hora del grupo/evento');
    $('#groupReservationDateInput')?.focus();
    return;
  }
  state.customPaymentFlow = {
    active: true,
    total: required,
    label: 'Grupo / Evento',
    onConfirm: async ({ paymentMethod, reference = '', transferAuthorizationCode = '' } = {}) => {
      try {
        await persistGameReservation(buildGroupReservationPayload({
          paidAmount: required,
          paymentMethod,
          paymentReference: reference,
          transferAuthorizationCode
        }));
        resetGroupReservationForm();
        const groupDetails = $('#groupEventReservationDetails');
        if (groupDetails) groupDetails.open = false;
        return true;
      } catch (error) {
        if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message || 'No se pudo registrar la transferencia');
        else showToast(error.message || 'No se pudo guardar el grupo/evento');
        return false;
      }
    }
  };
  const method = $('#groupReservationPaymentMethodInput')?.value || 'CASH';
  if (method === 'TRANSFER') openTransferPaymentModal();
  else openCashPaymentModal();
}

function getReservationAvailableMinuteOptions() {
  const playerCount = normalizeReservationPlayerCount($('#gameReservationPlayerCountInput')?.value || 1);
  const station = getReservationCandidateStationForPrice();
  let rows = [];
  if (station) rows = getGeneralStationTimePrices(station, playerCount);
  if (!rows.length && station && playerCount > 2) rows = getGeneralStationTimePrices(station, 2);
  if (!rows.length && station && playerCount > 1) rows = getGeneralStationTimePrices(station, 1);
  if (!rows.length) {
    const consoles = getReservationGameAvailableConsoles(getReservationSelectedGame());
    rows = (state.timePrices || [])
      .filter((price) => price.is_active && (!consoles.length || consoles.includes(price.console_type)) && !price.station_id)
      .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));
  }
  const byMinutes = new Map();
  rows.forEach((row) => {
    const minutes = Number(row.minutes || 0);
    if (minutes > 0 && !byMinutes.has(minutes)) byMinutes.set(minutes, row);
  });
  return Array.from(byMinutes.values()).sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));
}

function renderReservationMinuteOptions({ preserve = true } = {}) {
  const select = $('#gameReservationMinutesInput');
  if (!select) return;
  const currentValue = preserve ? select.value : '';
  const rows = getReservationAvailableMinuteOptions();
  select.innerHTML = '<option value="">Selecciona tiempo</option>' + rows.map((row) => {
    const minutes = Number(row.minutes || 0);
    const label = row.label || (minutes >= 60 ? `${minutes / 60} hora${minutes === 60 ? '' : 's'}` : `${minutes} min`);
    const price = Number(row.price || 0);
    return `<option value="${minutes}">${escapeHtml(label)} · RD$${price.toFixed(0)}</option>`;
  }).join('');
  select.value = rows.some((row) => String(row.minutes) === String(currentValue)) ? currentValue : '';
}

function isReservationFeaturedGame(game = getReservationSelectedGame()) {
  if (!game) return false;
  const type = String(game.highlight_type || '').toUpperCase();
  return Boolean(game.is_featured || game.priority_enabled || ['GAME_OF_MONTH', 'IMPORTANT_RELEASE', 'PREMIUM', 'HIGH_DEMAND'].includes(type));
}

function getReservationMemberPlan(member = state.gameReservationMember) {
  const tier = normalizeSavedGameTier(member?.membership_tier || '');
  return (state.membershipPlans || []).find((plan) => normalizeSavedGameTier(plan.code) === tier) || null;
}

function calculateReservationPriority(member = state.gameReservationMember, game = getReservationSelectedGame()) {
  if (!member?.id || !member.membership_active) {
    return { level: 0, label: 'Normal', note: 'Cliente sin membresía asignada.' };
  }
  const plan = getReservationMemberPlan(member);
  const planName = plan?.name || getMembershipLabel(member.membership_tier) || 'Miembro';
  const featured = isReservationFeaturedGame(game);
  if (featured && plan?.featured_game_priority) {
    return { level: 10, label: `Prioridad ${planName}`, note: 'Aplicada por membresía en juego destacado.' };
  }
  return { level: 5, label: planName, note: 'Miembro asignado automáticamente.' };
}


function getReservationCandidateStationForPrice() {
  const stationId = $('#gameReservationStationInput')?.value || '';
  const stations = getReservationCompatibleStations();
  if (stationId) return stations.find((station) => String(station.id) === String(stationId)) || null;
  return stations[0] || null;
}

function getReservationConfiguredAmount() {
  const type = $('#gameReservationTypeInput')?.value || 'WAITLIST';
  const minutes = Number($('#gameReservationMinutesInput')?.value || 0);
  const playerCount = normalizeReservationPlayerCount($('#gameReservationPlayerCountInput')?.value || 1);
  const station = getReservationCandidateStationForPrice();
  const pricePlayerCount = playerCount >= 2 ? 2 : 1;
  const price = station && minutes > 0 ? findConfiguredStationTimePrice(station, minutes, pricePlayerCount) : null;
  const total = Number(price?.price || 0);
  const required = type === 'RESERVATION'
    ? Number((playerCount <= 1 ? total : total * 0.5).toFixed(2))
    : Number(total.toFixed(2));
  return { total, required, station };
}

function renderGameReservationPaymentBox() {
  const box = $('#gameReservationPaymentBox');
  const type = $('#gameReservationTypeInput')?.value || 'WAITLIST';
  const isWaitlist = type !== 'RESERVATION';
  const paidFields = document.querySelectorAll('.reservation-paid-fields');
  paidFields.forEach((el) => el.classList.remove('is-disabled'));

  document.querySelectorAll('.reservation-date-time-grid').forEach((el) => {
    el.classList.toggle('waitlist-hidden', isWaitlist);
  });

  const saveBtn = $('#saveGameReservationBtn');
  if (saveBtn) saveBtn.textContent = isWaitlist ? 'Registrar y cobrar' : 'Registrar reserva y cobrar';

  const timeSummary = $('#gameReservationTimeSummary');
  if (timeSummary && isWaitlist) {
    const minutes = Number($('#gameReservationMinutesInput')?.value || 0);
    timeSummary.innerHTML = `<strong>Lista de espera</strong><small>${minutes ? `${minutes} min cuando se libere` : 'Selecciona el tiempo que desea pagar'}</small>`;
  }

  if (!box) return;
  const playerCount = normalizeReservationPlayerCount($('#gameReservationPlayerCountInput')?.value || 1);
  const { total, required, station } = getReservationConfiguredAmount();
  const paidInput = $('#gameReservationPaidInput');
  if (paidInput) paidInput.value = required > 0 ? required.toFixed(2) : '';

  const ready = required > 0;
  box.classList.toggle('has-priority', ready);
  const stationText = station?.name ? ` · ${station.name}` : '';
  if (isWaitlist) {
    const amountText = total > 0
      ? `Cobrar RD$${required.toFixed(2)} ahora · se asigna cuando se libere${stationText}`
      : 'Selecciona tiempo con precio configurado para cobrar la espera';
    box.innerHTML = `<strong>${ready ? 'Lista de espera pagada' : 'Pago requerido'}</strong><small>${escapeHtml(amountText)}</small>`;
    return;
  }

  const rule = playerCount <= 1 ? 'pago completo' : `grupo de ${playerCount} · depósito 50%`;
  const amountText = total > 0 ? `Total RD$${total.toFixed(2)} · ${rule} RD$${required.toFixed(2)}` : 'Selecciona estación/tiempo con precio configurado';
  box.innerHTML = `<strong>${ready ? 'Pago listo para bloquear' : 'Pago obligatorio'}</strong><small>${escapeHtml(amountText)}${escapeHtml(stationText)}</small>`;
}

function renderGameReservationMemberBox() {
  const box = $('#gameReservationMemberBox');
  const priorityBox = $('#gameReservationPriorityBox');
  const member = state.gameReservationMember || null;
  const priority = calculateReservationPriority(member, getReservationSelectedGame());
  state.gameReservationPriority = priority;
  if (box) {
    if (member?.id) {
      const tier = member.membership_active ? getMembershipLabel(member.membership_tier) : 'Sin membresía activa';
      box.classList.add('has-member');
      box.innerHTML = `<strong>${escapeHtml(member.full_name || 'Miembro')}</strong><small>${escapeHtml(tier)} · QR escaneado</small>`;
    } else {
      box.classList.remove('has-member');
      box.innerHTML = '<strong>Sin miembro</strong><small>Escanea el QR del miembro para asignarlo automáticamente</small>';
    }
  }
  if (priorityBox) {
    priorityBox.classList.toggle('has-priority', Number(priority.level || 0) > 0);
    priorityBox.innerHTML = `<span>Prioridad automática</span><strong>${escapeHtml(priority.label || 'Normal')}</strong><small>${escapeHtml(priority.note || '')}</small>`;
  }
  renderGameReservationPaymentBox();
}

function resetGameReservationForm() {
  state.gameReservationMember = null;
  state.gameReservationPriority = { level: 0, label: 'Normal', note: 'Se actualiza si escaneas un miembro con beneficios.' };
  ['#gameReservationCustomerInput', '#gameReservationPhoneInput', '#gameReservationTimeInput', '#gameReservationDateInput', '#gameReservationHourInput', '#gameReservationMinutesInput', '#gameReservationPaidInput', '#gameReservationNotesInput'].forEach((selector) => {
    const el = $(selector);
    if (el) el.value = '';
  });
  const minuteClockInput = $('#gameReservationMinuteInput');
  if (minuteClockInput) minuteClockInput.value = '00';
  const ampmInput = $('#gameReservationAmPmInput');
  if (ampmInput) ampmInput.value = 'AM';
  const typeInput = $('#gameReservationTypeInput');
  if (typeInput) typeInput.value = 'WAITLIST';
  const platformInput = $('#gameReservationPlatformInput');
  if (platformInput) platformInput.value = '';
  const stationInput = $('#gameReservationStationInput');
  if (stationInput) stationInput.value = '';
  const playerInput = $('#gameReservationPlayerCountInput');
  if (playerInput) playerInput.value = '1';
  const paymentMethodInput = $('#gameReservationPaymentMethodInput');
  if (paymentMethodInput) paymentMethodInput.value = 'CASH';
  syncReservationPlatformAndStations({ preservePlatform: false });
  syncReservationDesiredStart();
  renderGameReservationMemberBox();
}

function setGameReservationMember(member) {
  state.gameReservationMember = member || null;
  const customerInput = $('#gameReservationCustomerInput');
  const phoneInput = $('#gameReservationPhoneInput');
  if (member?.id) {
    if (customerInput) customerInput.value = member.full_name || '';
    if (phoneInput && !phoneInput.value) phoneInput.value = member.phone || '';
  }
  renderGameReservationMemberBox();
  showToast(member?.id ? `${member.full_name || 'Miembro'} asignado a la espera` : 'Miembro removido');
}

function getReservationWhatsappPhone(item = {}) {
  return String(item.customer_phone || item.member_phone || '').replace(/[^0-9]/g, '');
}

const WAITLIST_RESPONSE_WINDOW_MINUTES = 5;
const MEMBERSHIP_WAITLIST_RESPONSE_WINDOWS = {
  GAMER: 7,
  GAMER_PRO: 10,
  CHAMPION: 15
};

function normalizeReservationMembershipTier(tier = '') {
  const value = String(tier || '').trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_');
  if (!value) return '';
  if (value.includes('CHAMPION')) return 'CHAMPION';
  if (value.includes('PRO')) return 'GAMER_PRO';
  if (value.includes('GAMER')) return 'GAMER';
  return value;
}

function getReservationResponseWindowMinutes(item = {}) {
  const active = Boolean(item.member_membership_active || item.membership_active);
  if (!active) return WAITLIST_RESPONSE_WINDOW_MINUTES;
  const tier = normalizeReservationMembershipTier(item.member_membership_tier || item.membership_tier || '');
  return MEMBERSHIP_WAITLIST_RESPONSE_WINDOWS[tier] || 7;
}

function getReservationMembershipBenefitLabel(item = {}) {
  const minutes = getReservationResponseWindowMinutes(item);
  const active = Boolean(item.member_membership_active || item.membership_active);
  if (!active || minutes <= WAITLIST_RESPONSE_WINDOW_MINUTES) return '';
  const tier = getMembershipLabel(item.member_membership_tier || item.membership_tier || '') || 'Miembro';
  return `${tier} · ${minutes} min para responder`;
}

function buildReservationWhatsappMessage(item = {}) {
  const name = item.member_name || item.customer_name || 'jugador';
  const game = item.game_name || 'el juego que esperabas';
  const station = item.waitlist_available_station_name || item.blocked_station_name || item.station_name || '';
  const stationText = station ? ` en ${station}` : '';
  const responseMinutes = getReservationResponseWindowMinutes(item);
  return `Hola ${name}, ya ${game} está disponible${stationText} en Club Versus. Puedes pasar para jugarlo. Te guardamos el turno por ${responseMinutes} minutos.`;
}

function openReservationWhatsapp(item = {}) {
  const phone = getReservationWhatsappPhone(item);
  const message = encodeURIComponent(buildReservationWhatsappMessage(item));
  const url = phone ? `https://wa.me/${phone}?text=${message}` : `https://wa.me/?text=${message}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

async function copyReservationWhatsappMessage(item = {}) {
  const message = buildReservationWhatsappMessage(item);
  try {
    await navigator.clipboard?.writeText(message);
    showToast('Mensaje de WhatsApp copiado');
  } catch (_) {
    showToast(message);
  }
}

async function confirmReservationWhatsappNotified(item = {}) {
  const dialog = getReservationDialog();
  const responseMinutes = getReservationResponseWindowMinutes(item);
  const message = `¿Marcar a ${item.member_name || item.customer_name || 'este cliente'} como avisado? Tendrá ${responseMinutes} minutos para responder o llegar.`;
  if (!dialog) return window.confirm(message);
  const response = await dialog({
    title: 'Marcar como avisado',
    subtitle: item.game_name || 'WhatsApp manual',
    message,
    primaryText: 'Sí, avisado',
    secondaryText: 'Todavía no'
  });
  return response === 'primary';
}

async function handleReservationWhatsapp(item = {}) {
  const dialog = getReservationDialog();
  const phone = getReservationWhatsappPhone(item);
  const phoneText = phone ? `WhatsApp: ${phone}. ` : 'Sin número guardado. ';
  const message = buildReservationWhatsappMessage(item);
  let action = 'primary';
  if (dialog) {
    action = await dialog({
      title: 'WhatsApp manual',
      subtitle: item.game_name || 'Avisar cliente',
      message: `${phoneText}Se abrirá WhatsApp con este mensaje: ${message}`,
      primaryText: phone ? 'Abrir WhatsApp' : 'Abrir sin número',
      secondaryText: 'Copiar mensaje'
    });
  }
  if (action === 'secondary') await copyReservationWhatsappMessage(item);
  else openReservationWhatsapp(item);
  const markNotified = await confirmReservationWhatsappNotified(item);
  if (!markNotified) {
    showToast('WhatsApp preparado. No se marcó como avisado.');
    return;
  }
  await updateGameReservationStatus(item.id, 'NOTIFIED', {
    silent: true,
    responseWindowMinutes: getReservationResponseWindowMinutes(item)
  });
  showToast('Cliente marcado como avisado por WhatsApp');
}

function openGameReservationsModal() {
  fillReservationHourSelect();
  fillGameReservationSelects();
  resetGameReservationForm();
  resetGroupReservationForm();
  const reservationDetails = $('#gameReservationDetails');
  if (reservationDetails) reservationDetails.open = false;
  const groupDetails = $('#groupEventReservationDetails');
  if (groupDetails) groupDetails.open = false;
  renderGameReservationsList();
  openModalElement($('#gameReservationsModal'), { base: 2147483000 });
  loadGameReservations().catch((error) => showToast(error.message || 'No se pudieron cargar reservas'));
}

function closeGameReservationsModal() {
  closeModalElement($('#gameReservationsModal'));
}

function fillGameReservationSelects() {
  const gameSelect = $('#gameReservationGameInput');
  if (gameSelect) {
    const games = (state.stationGames || []).filter((game) => game.is_active !== false)
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    gameSelect.innerHTML = '<option value="">Sin juego específico</option>' + games.map((game) => {
      const badge = getGameHighlightLabel(game);
      return `<option value="${escapeAttr(game.id)}">${escapeHtml(game.name || 'Juego')}${badge ? ` · ${escapeHtml(badge)}` : ''}</option>`;
    }).join('');
  }
  fillGroupReservationGameSelect();
  syncReservationPlatformAndStations({ preservePlatform: false });
}

function getReservationStatusLabel(status = '') {
  const value = String(status || '').toUpperCase();
  if (value === 'RESERVED') return 'Reservado';
  if (value === 'CALLED') return 'Llamado';
  if (value === 'NOTIFIED') return 'Avisado';
  if (value === 'ASSIGNED') return 'Asignado';
  if (value === 'CONVERTED') return 'Asignado';
  if (value === 'CANCELED') return 'Cancelado';
  if (value === 'NO_SHOW') return 'No respondió';
  if (value === 'EXPIRED') return 'Vencido';
  return 'Esperando';
}

function renderGameReservationsList() {
  const list = $('#gameReservationsList');
  const count = $('#gameReservationsCountLabel');
  if (!list) return;
  const rows = Array.isArray(state.gameReservations) ? state.gameReservations : [];
  if (count) count.textContent = `${rows.length} activos`;
  if (!rows.length) {
    list.innerHTML = '<div class="stations-empty">Sin clientes esperando ni reservas activas</div>';
    return;
  }
  let waitlistPosition = 0;
  list.innerHTML = rows.map((item) => {
    const isGroupEvent = String(item.reservation_scope || '').toUpperCase() === 'GROUP_EVENT';
    const title = isGroupEvent ? (item.customer_name || item.game_name || 'Grupo / Evento') : (item.game_name || item.customer_name || 'Cliente');
    const customer = item.member_name || item.customer_name || 'Cliente sin nombre';
    const benefitLabel = getReservationMembershipBenefitLabel(item);
    const priority = Number(item.priority_level || 0) > 0 ? `<span class="reservation-priority">${escapeHtml(benefitLabel || 'Prioridad automática')}</span>` : '';
    const responseWindowLabel = getReservationResponseWindowMinutes(item);
    const highlight = item.game_highlight_type ? `<span class="reservation-highlight">${escapeHtml(getGameHighlightLabel({ highlight_type: item.game_highlight_type, priority_enabled: item.game_priority_enabled }))}</span>` : '';
    const desiredTime = item.desired_start_at ? formatTime(item.desired_start_at) : '';
    const desired = desiredTime ? ` · ${desiredTime}` : '';
    const paidAmount = Number(item.paid_amount || 0);
    const totalAmount = Number(item.estimated_total_amount || item.total_amount || item.price_amount || item.amount || 0);
    const pendingAmount = Math.max(0, totalAmount - paidAmount);
    const isWaitlist = String(item.reservation_type || '').toUpperCase() === 'WAITLIST';
    const positionNumber = isWaitlist ? ++waitlistPosition : null;
    const positionBadge = isWaitlist ? `<span class="waitlist-position-badge">#${positionNumber}</span>` : '';
    const positionInline = isWaitlist ? `<span class="waitlist-position-inline">#${positionNumber} en espera</span>` : '';
    const positionDetail = isWaitlist ? `<div><b>Turno</b><span>#${positionNumber} en espera</span></div>` : '';
    const isAvailableWaitlist = isWaitlist && item.waitlist_available === true;
    const availabilityBadge = isAvailableWaitlist ? `<span class="reservation-available">Disponible ahora</span>` : '';
    const paidInfo = item.reservation_type === 'RESERVATION' ? ` · pago ${escapeHtml(item.payment_status || 'PENDIENTE')} RD$${paidAmount.toFixed(2)}` : '';
    const groupInfoText = isGroupEvent ? (item.is_full_club ? 'todo el club' : `${Number(item.station_count || 1)} estación${Number(item.station_count || 1) === 1 ? '' : 'es'}`) : '';
    const groupInfo = groupInfoText ? ` · ${groupInfoText}` : '';
    const blockInfoText = item.blocked_station_name ? `bloquea ${item.blocked_station_name}${groupInfo}` : groupInfoText;
    const blockInfo = blockInfoText ? ` · ${escapeHtml(blockInfoText)}` : '';
    const phone = getReservationWhatsappPhone(item);
    const notes = item.notes ? String(item.notes) : '';
    const stationText = item.station_name || 'Cualquier estación';
    const minutesText = item.reserved_minutes || item.min_minutes ? `${Number(item.reserved_minutes || item.min_minutes)} min` : 'Tiempo sin definir';
    const paymentDetail = item.reservation_type === 'RESERVATION'
      ? `Estado pago: ${item.payment_status || 'PENDIENTE'} · Pagado RD$${paidAmount.toFixed(2)}${totalAmount ? ` · Total RD$${totalAmount.toFixed(2)} · Pendiente RD$${pendingAmount.toFixed(2)}` : ''}`
      : (paidAmount > 0 ? `Lista pagada · RD$${paidAmount.toFixed(2)}` : 'Lista de espera sin pago');
    const availabilityMessage = item.waitlist_availability_message || (isAvailableWaitlist ? 'Juego disponible para asignar' : 'Esperando disponibilidad');
    const notified = item.status === 'NOTIFIED' && item.response_deadline_at ? `<small class="reservation-deadline">Avisado · vence ${formatTime(item.response_deadline_at)}</small>` : '';
    const availabilityLine = isWaitlist ? `<small class="reservation-availability-line ${isAvailableWaitlist ? 'is-ready' : ''}">${escapeHtml(availabilityMessage)}</small>` : '';
    return `
      <article class="game-reservation-row" data-reservation-row="${escapeAttr(item.id)}">
        <div class="game-reservation-main">
          <div class="waitlist-cover-wrap">
            ${positionBadge}
            ${item.game_cover_url ? `<img src="${escapeAttr(item.game_cover_url)}" alt="${escapeAttr(title)}" />` : '<div class="reservation-cover-placeholder">🎮</div>'}
          </div>
          <div>
            <strong>${positionInline}${escapeHtml(title)}</strong>
            <span>${escapeHtml(customer)} · ${escapeHtml(item.platform || item.game_platform || item.station_console_type || 'Plataforma libre')}${desired}</span>
            <small>${escapeHtml(stationText)} · ${escapeHtml(minutesText)}${blockInfo}${paidInfo}${phone ? ' · WhatsApp listo' : ''}${notes ? ` · ${escapeHtml(notes)}` : ''}</small>
            ${notified}
            ${availabilityLine}
            <div class="reservation-detail-panel" hidden>
              <div><b>Cliente/evento</b><span>${escapeHtml(customer)}</span></div>
              <div><b>Tipo</b><span>${isGroupEvent ? 'Grupo / Cumpleaños / Evento' : escapeHtml(item.reservation_type === 'RESERVATION' ? 'Reserva' : 'Lista de espera')}</span></div>
              ${positionDetail}
              <div><b>Juego/plataforma</b><span>${escapeHtml(title)} · ${escapeHtml(item.platform || item.game_platform || item.station_console_type || 'Plataforma libre')}</span></div>
              <div><b>Horario</b><span>${desiredTime ? escapeHtml(desiredTime) : 'Sin hora'} · ${escapeHtml(minutesText)}</span></div>
              <div><b>Estación</b><span>${escapeHtml(stationText)}${blockInfoText ? ` · ${escapeHtml(blockInfoText)}` : ''}</span></div>
              <div><b>Pago</b><span>${escapeHtml(paymentDetail)}</span></div>
              ${isWaitlist ? `<div><b>Disponibilidad</b><span>${escapeHtml(availabilityMessage)}${item.waitlist_available_station_name ? ` · ${escapeHtml(item.waitlist_available_station_name)}` : ''}</span></div>` : ''}
              ${isWaitlist ? `<div><b>Ventana al avisar</b><span>${escapeHtml(`${responseWindowLabel} min${benefitLabel ? ` · ${benefitLabel}` : ''}`)}</span></div>` : ''}
              ${phone ? `<div><b>WhatsApp</b><span>${escapeHtml(phone)}</span></div>` : ''}
              ${notes ? `<div><b>Nota</b><span>${escapeHtml(notes)}</span></div>` : ''}
            </div>
          </div>
        </div>
        <div class="game-reservation-side">
          <div>${availabilityBadge}${priority}${highlight}</div>
          <em>${getReservationStatusLabel(item.status)}</em>
          <div class="game-reservation-actions">
            <button type="button" class="secondary" data-reservation-details="${escapeAttr(item.id)}">Ver detalles</button>
            <button type="button" class="secondary" data-reservation-whatsapp="${escapeAttr(item.id)}">WhatsApp</button>
            <button type="button" class="secondary ${isAvailableWaitlist ? 'reservation-ready-action' : ''}" data-reservation-status="ASSIGNED" data-reservation-id="${escapeAttr(item.id)}" ${isWaitlist && !isAvailableWaitlist ? 'disabled title="Todavía no hay juego/estación disponible"' : ''}>${isWaitlist ? 'Asignar' : 'Asignar'}</button>
            <button type="button" class="secondary" data-reservation-status="NO_SHOW" data-reservation-id="${escapeAttr(item.id)}">No respondió</button>
            <button type="button" class="danger secondary" data-reservation-status="CANCELED" data-reservation-id="${escapeAttr(item.id)}">Cancelar</button>
          </div>
        </div>
      </article>`;
  }).join('');
  list.querySelectorAll('[data-reservation-details]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const row = list.querySelector(`[data-reservation-row="${CSS.escape(String(btn.dataset.reservationDetails || ''))}"]`);
      const panel = row?.querySelector('.reservation-detail-panel');
      if (!row || !panel) return;
      const isOpen = row.classList.toggle('is-expanded');
      panel.hidden = !isOpen;
      btn.textContent = isOpen ? 'Ocultar detalles' : 'Ver detalles';
    });
  });
  list.querySelectorAll('[data-reservation-status]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const status = String(btn.dataset.reservationStatus || '').toUpperCase();
      if (status === 'ASSIGNED') {
        const reservation = rows.find((row) => String(row.id) === String(btn.dataset.reservationId));
        assignGameReservation(btn.dataset.reservationId, reservation);
        return;
      }
      updateGameReservationStatus(btn.dataset.reservationId, btn.dataset.reservationStatus);
    });
  });
  list.querySelectorAll('[data-reservation-whatsapp]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const item = rows.find((row) => String(row.id) === String(btn.dataset.reservationWhatsapp));
      if (!item) return;
      try {
        await handleReservationWhatsapp(item);
      } catch (error) {
        showToast(error.message || 'No se pudo preparar WhatsApp');
      }
    });
  });
}

function buildGameReservationPayload(paymentOverride = {}) {
  const gameId = $('#gameReservationGameInput')?.value || '';
  const game = gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
  return {
    reservationType: $('#gameReservationTypeInput')?.value || 'WAITLIST',
    gameId: gameId || null,
    stationId: $('#gameReservationStationInput')?.value || null,
    memberId: state.gameReservationMember?.id || null,
    customerName: ($('#gameReservationCustomerInput')?.value || '').trim(),
    customerPhone: ($('#gameReservationPhoneInput')?.value || '').trim(),
    platform: $('#gameReservationPlatformInput')?.value || game?.platform || '',
    desiredStartAt: $('#gameReservationTimeInput')?.value || null,
    minMinutes: Number($('#gameReservationMinutesInput')?.value || 0),
    reservedMinutes: Number($('#gameReservationMinutesInput')?.value || 0),
    playerCount: normalizeReservationPlayerCount($('#gameReservationPlayerCountInput')?.value || 1),
    paidAmount: Number(paymentOverride.paidAmount ?? 0),
    paymentMethod: paymentOverride.paymentMethod || 'CASH',
    paymentReference: paymentOverride.paymentReference || '',
    transferAuthorizationCode: paymentOverride.transferAuthorizationCode || '',
    priorityLevel: Number(state.gameReservationPriority?.level || 0),
    notes: ($('#gameReservationNotesInput')?.value || '').trim()
  };
}

async function persistGameReservation(payload) {
  await api('/stations/game-reservations', { method: 'POST', body: JSON.stringify(payload) });
  showToast(payload.reservationType === 'RESERVATION' ? 'Reserva pagada y registrada' : 'Lista de espera pagada registrada');
  resetGameReservationForm();
  const reservationDetails = $('#gameReservationDetails');
  if (reservationDetails) reservationDetails.open = false;
  await loadGameReservations();
}

async function saveGameReservation() {
  const basePayload = buildGameReservationPayload();
  const isWaitlist = basePayload.reservationType !== 'RESERVATION';
  const { total, required, station } = getReservationConfiguredAmount();

  if (!basePayload.customerName && !basePayload.memberId) {
    showToast('Escribe el nombre del cliente');
    $('#gameReservationCustomerInput')?.focus();
    return;
  }
  if (!basePayload.reservedMinutes) {
    showToast('Indica el tiempo que desea');
    $('#gameReservationMinutesInput')?.focus();
    return;
  }
  if (!station) {
    showToast('No hay estación compatible para ese juego/plataforma');
    return;
  }
  if (required <= 0) {
    showToast('Configura precio para ese tiempo y cantidad de jugadores');
    return;
  }

  if (!isWaitlist && !basePayload.desiredStartAt) {
    showToast('Selecciona fecha y hora de la reserva');
    openReservationDatePicker();
    return;
  }

  state.customPaymentFlow = {
    active: true,
    total: required,
    label: isWaitlist ? 'Lista de espera' : 'Reserva',
    onConfirm: async ({ paymentMethod, reference = '', transferAuthorizationCode = '' } = {}) => {
      try {
        await persistGameReservation(buildGameReservationPayload({
          paidAmount: required,
          paymentMethod,
          paymentReference: reference,
          transferAuthorizationCode
        }));
        return true;
      } catch (error) {
        if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message || 'No se pudo registrar la transferencia');
        else showToast(error.message || (isWaitlist ? 'No se pudo guardar la lista de espera' : 'No se pudo guardar la reserva'));
        return false;
      }
    }
  };
  const method = $('#gameReservationPaymentMethodInput')?.value || 'CASH';
  if (method === 'TRANSFER') openTransferPaymentModal();
  else openCashPaymentModal();
}

function getReservationDialog() {
  const dialog = window.ClubVersusCore?.modalManager?.showAppDialog;
  return typeof dialog === 'function' ? dialog : null;
}

function buildReservationAssignMessage(item = {}) {
  const isGroupEvent = String(item.reservation_scope || '').toUpperCase() === 'GROUP_EVENT';
  const totalAmount = Number(item.total_amount || item.estimated_total_amount || item.price_amount || item.amount || 0);
  const paidAmount = Number(item.paid_amount || 0);
  const pendingAmount = Math.max(0, Number((totalAmount - paidAmount).toFixed(2)));
  const minutesText = item.reserved_minutes || item.min_minutes ? `${Number(item.reserved_minutes || item.min_minutes)} minutos` : 'tiempo configurado';
  const stationText = isGroupEvent
    ? (item.is_full_club ? 'Todo el club' : `${Number(item.station_count || 1)} estación${Number(item.station_count || 1) === 1 ? '' : 'es'}`)
    : (item.station_name || item.blocked_station_name || 'una estación disponible');
  const gameText = item.game_name ? `Juego: ${item.game_name}. ` : '';
  const pendingText = pendingAmount > 0 ? ` Pendiente a cobrar: RD$${pendingAmount.toFixed(2)}.` : ' Sin balance pendiente.';
  return `${gameText}Se activará ${stationText} por ${minutesText}.${pendingText}`;
}

async function confirmReservationAssignment(item = {}) {
  const dialog = getReservationDialog();
  const message = buildReservationAssignMessage(item);
  if (!dialog) return window.confirm(`¿Asignar esta reserva?

${message}`);
  const response = await dialog({
    title: 'Asignar reserva',
    subtitle: item.customer_name || item.member_name || 'Confirmar antes de activar',
    message,
    primaryText: 'Asignar ahora',
    secondaryText: 'Cancelar'
  });
  return response === 'primary';
}

async function chooseGroupPendingPaymentMethod(amount) {
  const dialog = getReservationDialog();
  if (!dialog) return 'CASH';
  const response = await dialog({
    title: 'Cobrar pendiente',
    subtitle: 'Grupo / Cumpleaños / Evento',
    amount: `RD$${Number(amount || 0).toFixed(2)}`,
    message: 'Selecciona cómo pagará el balance pendiente del evento.',
    primaryText: 'Efectivo',
    secondaryText: 'Transferencia'
  });
  if (response === 'secondary') return 'TRANSFER';
  return 'CASH';
}

async function payGroupReservationPending(reservationId, amount, preferredMethod = 'CASH') {
  if (!reservationId || Number(amount || 0) <= 0) return false;
  state.customPaymentFlow = {
    active: true,
    total: Number(amount || 0),
    label: 'Pendiente grupo / evento',
    onConfirm: async ({ paymentMethod, reference = '', transferAuthorizationCode = '' } = {}) => {
      try {
        await api(`/stations/game-reservations/${reservationId}/pay-pending`, {
          method: 'POST',
          body: JSON.stringify({ paymentMethod, paymentReference: reference, transferAuthorizationCode })
        });
        showToast('Pendiente de grupo/evento pagado');
        await loadGameReservations();
        await loadStations();
        return true;
      } catch (error) {
        if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message || 'No se pudo cobrar la transferencia');
        else showToast(error.message || 'No se pudo cobrar el pendiente');
        return false;
      }
    }
  };
  if (String(preferredMethod || '').toUpperCase() === 'TRANSFER') openTransferPaymentModal();
  else openCashPaymentModal();
  return true;
}

function getWaitlistTargetStationId(reservation = {}) {
  const stationId = reservation.waitlist_available_station_id || reservation.blocked_station_id || reservation.station_id || null;
  if (stationId) return stationId;
  const platform = reservation.platform || reservation.game_platform || reservation.station_console_type || '';
  const game = reservation.game_id ? (state.stationGames || []).find((item) => String(item.id) === String(reservation.game_id)) : null;
  const candidates = (state.stations || []).filter((station) => String(station.status || '').toUpperCase() === 'AVAILABLE');
  const compatible = candidates.find((station) => {
    if (platform && station.console_type !== platform) return false;
    if (game && !isGameCompatibleWithStation(game, station)) return false;
    return true;
  });
  return compatible?.id || null;
}

async function prepareWaitlistAssignment(reservationId, reservation = {}) {
  const stationId = getWaitlistTargetStationId(reservation);
  if (!stationId) return showToast('No hay estación libre compatible para esta espera');
  closeGameReservationsModal();
  openStationModal(stationId);
  if (reservation.game_id) {
    state.order.gameId = reservation.game_id;
    state.pendingWaitlistAssignmentId = reservationId;
    renderGameQuickSelection();
    renderOrder();
    closeGamePickerModal();
  }
  state.activeMenuCategory = 'TIME';
  renderModalProducts();
  showToast(`${reservation.game_name || 'Juego'} listo. Selecciona el tiempo y cobra.`);
}

async function assignGameReservation(reservationId, reservation = null) {
  if (!reservationId) return;
  const isWaitlist = String(reservation?.reservation_type || '').toUpperCase() === 'WAITLIST';
  if (isWaitlist) {
    const isPaidWaitlist = Number(reservation?.paid_amount || 0) > 0 && Number(reservation?.reserved_minutes || reservation?.min_minutes || 0) > 0;
    if (!isPaidWaitlist) {
      await prepareWaitlistAssignment(reservationId, reservation || {});
      return;
    }
  }
  const confirmed = await confirmReservationAssignment(reservation || {});
  if (!confirmed) return;
  try {
    const result = await api(`/stations/game-reservations/${reservationId}/assign`, { method: 'POST' });
    const assigned = Array.isArray(result.assignedStations) ? result.assignedStations : [];
    const stationNames = assigned.map((station) => station.name).filter(Boolean).join(', ');
    const pending = Number(result.pendingAmount || 0);
    const isGroupEvent = String(result.reservation?.reservation_scope || '').toUpperCase() === 'GROUP_EVENT';
    const pendingText = pending > 0 ? ` · pendiente RD$${pending.toFixed(2)}` : '';
    showToast(`Reserva asignada${stationNames ? `: ${stationNames}` : ''}${pendingText}`);
    await loadGameReservations();
    await loadStations();
    closeGameReservationsModal();
    if (isGroupEvent && pending > 0) {
      setTimeout(async () => {
        const method = await chooseGroupPendingPaymentMethod(pending);
        await payGroupReservationPending(reservationId, pending, method);
      }, 120);
    }
  } catch (error) {
    showToast(error.message || 'No se pudo asignar la reserva');
  }
}

async function updateGameReservationStatus(reservationId, status, options = {}) {
  if (!reservationId || !status) return;
  try {
    const body = { status };
    if (options.responseWindowMinutes) body.responseWindowMinutes = Number(options.responseWindowMinutes);
    await api(`/stations/game-reservations/${reservationId}`, { method: 'PATCH', body: JSON.stringify(body) });
    if (!options.silent) showToast(status === 'ASSIGNED' || status === 'CONVERTED' ? 'Cliente asignado' : 'Reserva actualizada');
    await loadGameReservations();
  } catch (error) {
    showToast(error.message || 'No se pudo actualizar la reserva');
  }
}

function bindGameReservationEvents() {
  $('#openGameReservationsBtn')?.addEventListener('click', openGameReservationsModal);
  $('#openPendingNoticesBtn')?.addEventListener('click', openPendingNoticesModal);
  $('#closeGameReservationsBtn')?.addEventListener('click', closeGameReservationsModal);
  $('#gameReservationsBackdrop')?.addEventListener('click', closeGameReservationsModal);
  $('#saveGameReservationBtn')?.addEventListener('click', saveGameReservation);
  $('#saveGroupReservationBtn')?.addEventListener('click', saveGroupReservation);
  $('#gameReservationGameInput')?.addEventListener('change', () => { syncReservationPlatformAndStations({ preservePlatform: false }); renderGameReservationMemberBox(); });
  $('#gameReservationPlatformInput')?.addEventListener('change', () => syncReservationPlatformAndStations());
  $('#gameReservationDateInput')?.addEventListener('click', openReservationDatePicker);
  $('#gameReservationDateInput')?.addEventListener('focus', openReservationDatePicker);
  $('#groupReservationDateInput')?.addEventListener('click', () => {
    const input = $('#groupReservationDateInput');
    try { if (typeof input?.showPicker === 'function') input.showPicker(); } catch (_) {}
    input?.focus();
  });
  ['#gameReservationDateInput', '#gameReservationHourInput', '#gameReservationMinuteInput', '#gameReservationAmPmInput'].forEach((selector) => {
    $(selector)?.addEventListener('input', syncReservationDesiredStart);
    $(selector)?.addEventListener('change', syncReservationDesiredStart);
  });
  ['#groupReservationDateInput', '#groupReservationHourInput', '#groupReservationMinuteInput', '#groupReservationAmPmInput'].forEach((selector) => {
    $(selector)?.addEventListener('input', syncGroupReservationDesiredStart);
    $(selector)?.addEventListener('change', syncGroupReservationDesiredStart);
  });
  ['#gameReservationTypeInput', '#gameReservationStationInput', '#gameReservationPlayerCountInput'].forEach((selector) => {
    $(selector)?.addEventListener('input', () => { renderReservationMinuteOptions(); syncReservationDesiredStart(); });
    $(selector)?.addEventListener('change', () => { renderReservationMinuteOptions(); syncReservationDesiredStart(); });
  });
  $('#groupReservationTypeInput')?.addEventListener('change', () => {
    syncGroupReservationPlayerMinimum($('#groupReservationTypeInput')?.value || 'GROUP');
    renderGroupReservationPackageOptions({ preserve: false });
  });
  $('#groupReservationPlayerCountInput')?.addEventListener('change', () => renderGroupReservationPackageOptions({ preserve: true }));
  $('#groupReservationPackageInput')?.addEventListener('change', () => { syncGroupReservationStationCountOptions(); renderGroupReservationStations(); renderGroupReservationSummary(); });
  $('#groupReservationStationCountInput')?.addEventListener('change', () => { renderGroupReservationStations(); renderGroupReservationSummary(); });
  $('#groupReservationGameInput')?.addEventListener('change', () => { renderGroupReservationStations(); renderGroupReservationSummary(); });
  $('#groupReservationStationInput')?.addEventListener('change', renderGroupReservationSummary);
  $('#gameReservationMinutesInput')?.addEventListener('change', syncReservationDesiredStart);
  $('#gameReservationMinutesInput')?.addEventListener('input', syncReservationDesiredStart);
}

function bindGamePickerEvents() {
  $('#openGamePickerBtn')?.addEventListener('click', openGamePickerModal);
  $('#closeGamePickerBtn')?.addEventListener('click', closeGamePickerModal);
  $('#gamePickerBackdrop')?.addEventListener('click', closeGamePickerModal);
  $('#gamePickerUnspecifiedBtn')?.addEventListener('click', () => selectStationOrderGame(null));
  $('#gamePickerSearchInput')?.addEventListener('input', renderGamePickerGrid);
  $('#gamePickerNewRequestBtn')?.addEventListener('click', () => openGameRequestModal({ requestType: 'NEW_GAME' }));
  $('#closeGameRequestBtn')?.addEventListener('click', () => { state.returnToGamePickerAfterRequestClose = false; closeGameRequestModal(); });
  $('#gameRequestBackdrop')?.addEventListener('click', () => { state.returnToGamePickerAfterRequestClose = false; closeGameRequestModal(); });
  document.querySelectorAll('[data-game-request-scope]').forEach((btn) => {
    btn.addEventListener('click', () => setGameRequestScope(btn.dataset.gameRequestScope || 'SUGGESTION'));
  });
  document.querySelectorAll('[data-game-request-decision]').forEach((btn) => {
    btn.addEventListener('click', () => submitGameRequest(btn.dataset.gameRequestDecision || 'SOLO_REGISTRAR'));
  });
  $('#closeSavedGameAlertBtn')?.addEventListener('click', closeSavedGameAlertModal);
  $('#savedGameAlertOkBtn')?.addEventListener('click', closeSavedGameAlertModal);
  $('#savedGameAlertBackdrop')?.addEventListener('click', closeSavedGameAlertModal);
}


function openStationModal(stationId) {
  const station = state.stations.find((item) => item.id === stationId);
  if (!station) return;

  state.posMode = 'station';
  state.selectedStation = station;
  resetOrder();
  state.activeMenuCategory = 'TIME';
  state.order.gameId = station.session_game_id || null;

  state.selectedMember = station.member_id
    ? {
        id: station.member_id,
        full_name: station.member_name || 'Miembro',
        phone: station.member_phone || '',
        visit_count: station.member_visit_count || 0,
        reward_points: station.member_reward_points || 0,
        date_of_birth: station.member_date_of_birth || null,
        membership_tier: station.member_membership_tier || null,
        membership_active: station.member_membership_active || false,
        membership_started_at: station.member_membership_started_at || null,
        visit_reward_id: station.member_visit_reward_id || null,
        visit_reward_type: station.member_visit_reward_type || null,
        visit_reward_minutes: station.member_visit_reward_minutes || null,
        visit_reward_minutes_used: station.member_visit_reward_minutes_used || 0,
        visit_reward_snack_qty: station.member_visit_reward_snack_qty || 0,
        visit_reward_snack_used: station.member_visit_reward_snack_used || 0,
        visit_reward_drink_qty: station.member_visit_reward_drink_qty || 0,
        visit_reward_drink_used: station.member_visit_reward_drink_used || 0,
        visit_reward_product_id: station.member_visit_reward_product_id || null,
        visit_reward_product_name: station.member_visit_reward_product_name || '',
        visit_reward_product_category: station.member_visit_reward_product_category || '',
        visit_reward_product_qty: station.member_visit_reward_product_qty || 0,
        visit_reward_product_used: station.member_visit_reward_product_used || 0,
        visit_reward_expires_at: station.member_visit_reward_expires_at || null
      }
    : null;

  const modal = $('#stationModal');
  const consoleClass = getConsoleClass(station.console_type);
  const isBusy = station.status === 'BUSY';

  modal.className = `modal ${consoleClass}`;
  openModalElement(modal, { base: 5000 });
  $('#modalStatus').textContent = getStatusLabel(station.status);
  $('#modalStatus').className = `modal-status ${station.status.toLowerCase()}`;
  $('#modalStationName').textContent = station.name;
  $('#modalStationMeta').textContent = station.console_type;
  $('#orderStationLabel').textContent = station.name;
  $('#posWorkspaceTitle').textContent = station.status === 'BUSY' ? 'Agregar a sesión' : 'Nueva orden';
  $('#posWorkspaceSubtitle').textContent = station.status === 'BUSY' ? `${station.name} · ${isStationOpenMode(station) ? 'modo libre corriendo' : 'sesión activa'}` : 'Selecciona las horas primero';
  $('#openGamePickerBtn')?.classList.remove('hidden');
  $('#endSessionBtn').classList.toggle('hidden', !isBusy);
  $('#endSessionBtn').textContent = isStationOpenMode(station) ? 'Detener y cobrar' : 'Cerrar sesión';
  $('#memberSearchInput').value = '';
  $('#createMemberName').value = '';
  $('#createMemberPhone').value = '';
  $('#createMemberBirthDate').value = '';
  $('#createMemberBox').classList.add('hidden');

  renderMemberSelection();
  renderGameQuickSelection();
  renderTimeOptions();
  renderModalProducts();
  renderOrder();

  if (!isBusy && getActiveStationGames().length) {
    setTimeout(() => {
      if (state.selectedStation?.id === station.id && !state.order.gameId) openGamePickerModal();
    }, 120);
  }
}

function closeStationModal() {
  closeModalElement($('#stationModal'));
  state.selectedStation = null;
  state.selectedMember = null;
  if (state.order) state.order.gameId = null;
  state.pendingEndSession = false;
  state.pendingAccountPayment = false;
  state.closeAfterPendingPayment = false;
  state.posMode = 'station';
  resetOrder();
}


function getStationTransferRemainingMinutes(station = state.selectedStation) {
  if (!station || station.status !== 'BUSY') return 0;
  if (isStationOpenMode(station)) return 0;
  const remainingMs = getSessionRemainingMs(station);
  if (remainingMs === null) return 0;
  return Math.max(0, Math.ceil(remainingMs / 60000));
}

function getTransferDestinationStations(sourceStation = state.selectedStation) {
  return (state.stations || [])
    .filter((station) => String(station.id) !== String(sourceStation?.id || ''))
    .filter((station) => String(station.status || '').toUpperCase() === 'AVAILABLE')
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
}

function getTransferCompatibleGames(destinationStation) {
  if (!destinationStation) return [];
  return getActiveStationGames()
    .filter((game) => isGameCompatibleWithStation(game, destinationStation))
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
}

function ensureStationTransferModal() {
  let modal = $('#stationTransferModal');
  if (modal) return modal;

  modal = document.createElement('section');
  modal.id = 'stationTransferModal';
  modal.className = 'module-modal station-transfer-modal hidden';
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="module-backdrop" id="stationTransferBackdrop"></div>
    <div class="module-shell station-transfer-shell">
      <header class="module-header station-transfer-header">
        <div>
          <span class="module-kicker">Cambio de estación</span>
          <h2>Mover sesión</h2>
          <p id="stationTransferSubtitle">Conserva el tiempo restante sin cobrar de nuevo.</p>
        </div>
        <button id="closeStationTransferBtn" class="module-close" type="button">×</button>
      </header>
      <div class="station-transfer-summary" id="stationTransferSummary"></div>
      <div class="station-transfer-grid">
        <label>
          Estación destino
          <select id="stationTransferDestinationInput"></select>
        </label>
        <label>
          Juego nuevo
          <select id="stationTransferGameInput"></select>
        </label>
      </div>
      <div class="station-transfer-preview" id="stationTransferPreview"></div>
      <div class="station-transfer-actions">
        <button id="confirmStationTransferBtn" type="button">Confirmar cambio</button>
        <button id="cancelStationTransferBtn" class="secondary" type="button">Cancelar</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  $('#stationTransferBackdrop')?.addEventListener('click', closeStationTransferModal);
  $('#closeStationTransferBtn')?.addEventListener('click', closeStationTransferModal);
  $('#cancelStationTransferBtn')?.addEventListener('click', closeStationTransferModal);
  $('#stationTransferDestinationInput')?.addEventListener('change', renderStationTransferGameOptions);
  $('#stationTransferGameInput')?.addEventListener('change', renderStationTransferPreview);
  $('#confirmStationTransferBtn')?.addEventListener('click', confirmStationTransfer);
  return modal;
}

function closeStationTransferModal() {
  closeModalElement($('#stationTransferModal'));
}

function renderStationTransferGameOptions() {
  const destinationId = $('#stationTransferDestinationInput')?.value || '';
  const destination = (state.stations || []).find((station) => String(station.id) === String(destinationId));
  const gameSelect = $('#stationTransferGameInput');
  if (!gameSelect) return;

  const currentGameId = state.selectedStation?.session_game_id || state.order?.gameId || '';
  const games = getTransferCompatibleGames(destination);
  const currentGameIsCompatible = games.some((game) => String(game.id) === String(currentGameId));
  const preferredGameId = currentGameIsCompatible ? String(currentGameId) : '';

  gameSelect.innerHTML = `<option value="">Sin juego específico</option>` + games.map((game) => {
    const selected = String(game.id) === preferredGameId ? 'selected' : '';
    const location = getGameLocationMessage(game, destination);
    return `<option value="${escapeAttr(game.id)}" ${selected}>${escapeHtml(game.name || 'Juego')}${location ? ` · ${escapeHtml(location)}` : ''}</option>`;
  }).join('');

  if (preferredGameId) gameSelect.value = preferredGameId;
  renderStationTransferPreview();
}

function renderStationTransferPreview() {
  const source = state.selectedStation;
  const destinationId = $('#stationTransferDestinationInput')?.value || '';
  const destination = (state.stations || []).find((station) => String(station.id) === String(destinationId));
  const gameId = $('#stationTransferGameInput')?.value || '';
  const game = gameId ? (state.stationGames || []).find((item) => String(item.id) === String(gameId)) : null;
  const remainingMinutes = getStationTransferRemainingMinutes(source);
  const preview = $('#stationTransferPreview');
  if (!preview) return;

  if (!destination) {
    preview.innerHTML = '<span>Selecciona una estación destino disponible.</span>';
    return;
  }

  preview.innerHTML = `
    <div><b>Destino</b><span>${escapeHtml(destination.name)} · ${escapeHtml(destination.console_type || '')}</span></div>
    <div><b>Juego nuevo</b><span>${escapeHtml(game?.name || 'Sin juego específico')}</span></div>
    <div><b>Tiempo que se mueve</b><span>${remainingMinutes} min restantes</span></div>
    <small>No se cobra otra vez. La estación actual queda libre y la nueva inicia con ese tiempo.</small>
  `;
}

function openStationTransferModal() {
  const station = state.selectedStation;
  if (!station || station.status !== 'BUSY') {
    showToast('Selecciona una estación ocupada');
    return;
  }
  if (isStationOpenMode(station)) {
    showToast('Modo libre no se cambia. Detén y cobra primero.');
    return;
  }
  if (getActiveSessionPendingTotal(station) > 0 || hasNewOrderContent()) {
    showToast('Cobra/guarda lo pendiente antes de cambiar de estación');
    return;
  }

  const remainingMinutes = getStationTransferRemainingMinutes(station);
  if (remainingMinutes <= 0) {
    showToast('Esta sesión ya no tiene tiempo restante');
    return;
  }

  const destinations = getTransferDestinationStations(station);
  if (!destinations.length) {
    showToast('No hay estaciones disponibles para cambiar');
    return;
  }

  const modal = ensureStationTransferModal();
  const summary = $('#stationTransferSummary');
  if (summary) {
    summary.innerHTML = `
      <div>
        <small>Actual</small>
        <strong>${escapeHtml(station.name)} · ${escapeHtml(station.console_type || '')}</strong>
        <span>${escapeHtml(station.session_game_name || 'Sin juego')} · ${remainingMinutes} min restantes</span>
      </div>
      <div>
        <small>Operación</small>
        <strong>Sin cobro adicional</strong>
        <span>Solo se transfiere el tiempo restante.</span>
      </div>
    `;
  }

  const destinationSelect = $('#stationTransferDestinationInput');
  if (destinationSelect) {
    destinationSelect.innerHTML = destinations.map((item) => `<option value="${escapeAttr(item.id)}">${escapeHtml(item.name)} · ${escapeHtml(item.console_type || '')}</option>`).join('');
  }
  renderStationTransferGameOptions();
  openModalElement(modal, { base: 2147483600 });
  modal.classList.remove('hidden');
  modal.removeAttribute('hidden');
  modal.setAttribute('aria-hidden', 'false');
  document.body.appendChild(modal);
  setTimeout(() => $('#stationTransferDestinationInput')?.focus(), 80);
}

async function confirmStationTransfer() {
  const source = state.selectedStation;
  const destinationId = $('#stationTransferDestinationInput')?.value || '';
  const gameId = $('#stationTransferGameInput')?.value || null;
  if (!source || !destinationId) return;

  const btn = $('#confirmStationTransferBtn');
  if (btn) btn.disabled = true;
  try {
    const result = await api(`/stations/${source.id}/transfer`, {
      method: 'POST',
      body: JSON.stringify({ destinationStationId: destinationId, gameId })
    });
    showToast(`Cambio realizado: ${result.fromStation?.name || 'Estación'} → ${result.toStation?.name || 'destino'} · ${result.remainingMinutes || 0} min`);
    closeStationTransferModal();
    await loadAll();
    closeStationModal();
  } catch (error) {
    const rawMessage = String(error?.message || '');
    const cleanMessage = rawMessage.length > 180 || /SELECT|WITH report_window|audit_totals|syntax/i.test(rawMessage)
      ? 'No se pudo cambiar de estación. Revisa que la estación destino esté disponible y el juego sea compatible.'
      : rawMessage;
    showToast(cleanMessage || 'No se pudo cambiar de estación');
  } finally {
    if (btn) btn.disabled = false;
  }
}

function getGeneralStationTimePrices(station, playerCount = state.order.playerCount) {
  if (!station) return [];
  const normalizedPlayerCount = normalizePlayerCount(playerCount);

  const stationRows = state.timePrices
    .filter((price) => price.station_id === station.id && Number(price.player_count || 1) === normalizedPlayerCount && price.is_active)
    .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));

  if (stationRows.length) return stationRows;

  return state.timePrices
    .filter((price) => !price.station_id && price.console_type === station.console_type && Number(price.player_count || 1) === normalizedPlayerCount && price.is_active)
    .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));
}

function getStationTimePrices(station, playerCount = state.order.playerCount) {
  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  const generalRows = getGeneralStationTimePrices(station, normalizedPlayerCount);
  const member = state.selectedMember;
  const tier = member?.membership_active ? member.membership_tier : null;

  if (!tier) return generalRows;

  const memberRows = state.memberTimePrices
    .filter((price) => price.membership_tier === tier && Number(price.player_count || 1) === normalizedPlayerCount && price.is_active)
    .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));

  if (!memberRows.length) return generalRows;

  const byMinutes = new Map(generalRows.map((row) => [Number(row.minutes), row]));
  memberRows.forEach((row) => {
    const fallback = byMinutes.get(Number(row.minutes));
    byMinutes.set(Number(row.minutes), {
      ...row,
      id: row.id || fallback?.id || `${tier}-${normalizedPlayerCount}-${row.minutes}`,
      console_type: station?.console_type,
      membership_tier: tier,
      player_count: normalizedPlayerCount,
      member_price: true
    });
  });

  return Array.from(byMinutes.values())
    .filter((row) => row.is_active)
    .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes));
}

function findConfiguredStationTimePrice(station, minutes, playerCount = state.order.playerCount, { includeInactive = false } = {}) {
  if (!station) return null;
  const normalizedMinutes = Number(minutes || 0);
  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  const matches = (price) => Number(price.minutes || 0) === normalizedMinutes
    && Number(price.player_count || 1) === normalizedPlayerCount
    && (includeInactive || price.is_active);

  return state.timePrices.find((price) => price.station_id === station.id && matches(price))
    || state.timePrices.find((price) => !price.station_id && price.console_type === station.console_type && matches(price))
    || null;
}

function isStationOpenMode(station = state.selectedStation) {
  return station?.status === 'BUSY' && String(station.rate_type || '').toUpperCase() === 'HOURLY';
}

function getOpenModePlayerCount(station = state.selectedStation) {
  return normalizePlayerCount(station?.session_player_count || station?.player_count || state.order.playerCount || 1);
}

function getOpenModeHourlyRate(station = state.selectedStation) {
  const playerCount = getOpenModePlayerCount(station);
  const hourPrice = station ? getStationTimePrices(station, playerCount).find((price) => Number(price.minutes) === 60) : null;
  return Number(hourPrice?.price || station?.hourly_rate || 0);
}

function getOpenModeElapsedMs(station = state.selectedStation) {
  if (!station?.started_at) return 0;
  const started = new Date(station.started_at).getTime();
  if (Number.isNaN(started)) return 0;
  return Math.max(0, Date.now() - started);
}

function getOpenModeElapsedMinutes(station = state.selectedStation) {
  const elapsedMs = getOpenModeElapsedMs(station);
  if (elapsedMs <= 0) return 0;
  return elapsedMs / 60000;
}

function getOpenModeElapsedDisplayMinutes(station = state.selectedStation) {
  const elapsedMs = getOpenModeElapsedMs(station);
  if (elapsedMs <= 0) return 0;
  return Math.max(1, Math.ceil(elapsedMs / 60000));
}

function getOpenModePricingPackages(station = state.selectedStation) {
  if (!station) return [];
  const playerCount = getOpenModePlayerCount(station);
  const wanted = [30, 60, 120, 180];
  const byMinutes = new Map();

  getStationTimePrices(station, playerCount)
    .filter((price) => wanted.includes(Number(price.minutes)))
    .forEach((price) => {
      const minutes = Number(price.minutes);
      const promoted = getTimePriceWithPromotion(station, price);
      const amount = Number(promoted?.finalPrice ?? price.price ?? 0);
      if (Number.isFinite(amount) && amount >= 0 && !byMinutes.has(minutes)) {
        byMinutes.set(minutes, { minutes, amount });
      }
    });

  return wanted
    .filter((minutes) => byMinutes.has(minutes))
    .map((minutes) => byMinutes.get(minutes));
}

function calculateOpenModePackageAmount(chargeableMinutes, packages = [], hourlyRate = 0) {
  const minutes = Math.max(0, Number(chargeableMinutes || 0));
  if (minutes <= 0) return 0;

  const anchors = buildOpenModePricingAnchors(packages, hourlyRate);
  if (anchors.length <= 1) return 0;

  const largest = anchors[anchors.length - 1];
  if (!largest?.minutes || largest.minutes <= 0) return 0;

  const fullBlocks = Math.floor(minutes / largest.minutes);
  const remainder = minutes - (fullBlocks * largest.minutes);
  const baseAmount = fullBlocks * largest.amount;

  if (remainder <= 0.0001) return Number(baseAmount.toFixed(2));
  return Number((baseAmount + interpolateOpenModeAmount(remainder, anchors)).toFixed(2));
}

function buildOpenModePricingAnchors(packages = [], hourlyRate = 0) {
  const byMinutes = new Map([[0, 0]]);

  [...packages]
    .map((pkg) => ({ minutes: Number(pkg.minutes || 0), amount: Number(pkg.amount || 0) }))
    .filter((pkg) => pkg.minutes > 0 && Number.isFinite(pkg.amount) && pkg.amount >= 0)
    .sort((a, b) => a.minutes - b.minutes)
    .forEach((pkg) => {
      if (!byMinutes.has(pkg.minutes) || pkg.amount < byMinutes.get(pkg.minutes)) {
        byMinutes.set(pkg.minutes, pkg.amount);
      }
    });

  const safeHourlyRate = Number(hourlyRate || 0);
  if (safeHourlyRate > 0 && !byMinutes.has(60)) {
    byMinutes.set(60, safeHourlyRate);
  }

  return Array.from(byMinutes.entries())
    .map(([minutes, amount]) => ({ minutes: Number(minutes), amount: Number(amount) }))
    .filter((row) => Number.isFinite(row.minutes) && Number.isFinite(row.amount))
    .sort((a, b) => a.minutes - b.minutes);
}

function interpolateOpenModeAmount(minutes, anchors = []) {
  const target = Math.max(0, Number(minutes || 0));
  if (target <= 0) return 0;

  const sorted = [...anchors].sort((a, b) => a.minutes - b.minutes);
  let previous = sorted[0] || { minutes: 0, amount: 0 };

  for (const next of sorted.slice(1)) {
    if (target <= next.minutes) {
      const spanMinutes = Math.max(1, next.minutes - previous.minutes);
      const spanAmount = next.amount - previous.amount;
      const progress = (target - previous.minutes) / spanMinutes;
      return previous.amount + (spanAmount * Math.max(0, Math.min(1, progress)));
    }
    previous = next;
  }

  const safeRatePerMinute = previous.minutes > 0 ? previous.amount / previous.minutes : 0;
  return previous.amount + ((target - previous.minutes) * safeRatePerMinute);
}

function getOpenModeChargePreview(station = state.selectedStation) {
  const elapsed = getOpenModeElapsedMinutes(station);
  const prepaid = Math.max(0, Number(station?.prepaid_minutes || 0));
  const chargeable = Math.max(0, elapsed - prepaid);
  const hourlyRate = getOpenModeHourlyRate(station);
  const packages = getOpenModePricingPackages(station);
  return {
    elapsed,
    prepaid,
    chargeable,
    hourlyRate,
    packages,
    amount: calculateOpenModePackageAmount(chargeable, packages, hourlyRate)
  };
}


function getUpcomingReservationForStation(station, minutes = 0) {
  if (!station?.id) return null;
  const now = new Date();
  const proposedEnd = new Date(now.getTime() + Math.max(0, Number(minutes || 0)) * 60000);
  return (state.gameReservations || [])
    .filter((reservation) => String(reservation.reservation_type || '').toUpperCase() === 'RESERVATION')
    .filter((reservation) => ['RESERVED', 'CALLED', 'NOTIFIED'].includes(String(reservation.status || '').toUpperCase()))
    .filter((reservation) => String(reservation.blocked_station_id || reservation.station_id || '') === String(station.id))
    .map((reservation) => ({ reservation, start: new Date(reservation.desired_start_at || reservation.desiredStartAt || '') }))
    .filter((entry) => !Number.isNaN(entry.start.getTime()) && entry.start > now)
    .sort((a, b) => a.start - b.start)
    .find((entry) => Number(minutes || 0) <= 0 || entry.start < proposedEnd)
    || null;
}

function getMinutesUntilReservation(entry) {
  if (!entry?.start) return null;
  return Math.max(0, Math.floor((entry.start.getTime() - Date.now()) / 60000));
}

function getReservationConflictMessage(entry, maxMinutes = null) {
  const reservation = entry?.reservation || {};
  const time = entry?.start ? formatTime(entry.start) : 'pronto';
  const game = reservation.game_name ? ` para ${reservation.game_name}` : '';
  const maxText = Number(maxMinutes || 0) > 0 ? ` Puedes vender máximo ${maxMinutes} min.` : ' No queda tiempo antes de esa reserva.';
  return `${state.selectedStation?.name || 'Esta estación'} tiene reserva${game} a las ${time}.${maxText}`;
}


function getSelectedOrderGame(station = state.selectedStation) {
  const gameId = state.order?.gameId || station?.session_game_id || null;
  if (!gameId) return null;
  return (state.stationGames || []).find((game) => String(game.id) === String(gameId)) || null;
}

function getExtraControllerConfig(station = state.selectedStation) {
  const game = getSelectedOrderGame(station);
  if (!station || !game) return null;
  if (String(station.console_type || '').trim() !== 'Nintendo Switch') return null;
  if (game.allows_extra_controllers !== true) return null;
  const max = Math.max(0, Math.min(4, Number(game.max_extra_controllers || 2)));
  if (max <= 0) return null;
  const unitPrice = Math.max(0, Number(game.extra_controller_price || 0));
  return { game, max, unitPrice };
}

function normalizeExtraControllerCount(value = state.order.extraControllerCount, station = state.selectedStation) {
  const config = getExtraControllerConfig(station);
  if (!config || normalizePlayerCount(state.order.playerCount) !== 2) return 0;
  const count = Math.max(0, Math.floor(Number(value || 0)));
  return Math.min(config.max, count);
}

function syncExtraControllerCount() {
  state.order.extraControllerCount = normalizeExtraControllerCount(state.order.extraControllerCount);
  return state.order.extraControllerCount;
}

function getExtraControllerTotal() {
  const config = getExtraControllerConfig();
  const count = syncExtraControllerCount();
  if (!config || !count) return 0;
  return Number((count * config.unitPrice).toFixed(2));
}

function getExtraControllerOrderLine() {
  const config = getExtraControllerConfig();
  const count = syncExtraControllerCount();
  if (!config || !count) return null;
  return {
    count,
    unitPrice: config.unitPrice,
    total: getExtraControllerTotal(),
    totalPlayers: 2 + count,
    gameName: config.game?.name || ''
  };
}


function getKidsCourtesySettings() {
  return state.kidsCourtesySettings || { enabled: false, consoleType: 'Nintendo Switch', baseMinutes: 15, extensionMinutes: 5, label: 'Extensión niños' };
}

function getKidsCourtesyBaseMinutes() {
  const settings = getKidsCourtesySettings();
  return Math.max(0, Number(settings.baseMinutes ?? settings.base_minutes ?? 15));
}

function getKidsCourtesyExtensionMinutes() {
  const settings = getKidsCourtesySettings();
  return Math.max(0, Number(settings.extensionMinutes ?? settings.extension_minutes ?? 5));
}

function isKidsCourtesyExtensionEligible(station = state.selectedStation) {
  const settings = getKidsCourtesySettings();
  if (!settings?.enabled) return false;
  if (!station) return false;
  if (String(station.console_type || '').trim() !== String(settings.consoleType || settings.console_type || 'Nintendo Switch').trim()) return false;
  if (station.status === 'BUSY') return false;
  if (state.order.freeMode) return false;
  return Number(state.order.gameMinutes || 0) === getKidsCourtesyBaseMinutes();
}

function syncKidsCourtesyExtension() {
  state.order.kidsCourtesyExtension = Boolean(state.order.kidsCourtesyExtension && isKidsCourtesyExtensionEligible());
  return state.order.kidsCourtesyExtension;
}

function renderKidsCourtesyExtensionSelector(container) {
  if (!container) return;
  if (!isKidsCourtesyExtensionEligible()) {
    state.order.kidsCourtesyExtension = false;
    return;
  }
  const settings = getKidsCourtesySettings();
  const extensionMinutes = getKidsCourtesyExtensionMinutes();
  const panel = document.createElement('div');
  panel.className = `kids-courtesy-extension-selector ${state.order.kidsCourtesyExtension ? 'active' : ''}`;
  panel.innerHTML = `
    <div class="kids-courtesy-copy">
      <strong>${escapeHtml(settings.label || 'Extensión niños')}</strong>
      <small>+${extensionMinutes} min cortesía · solo para ${getKidsCourtesyBaseMinutes()} min</small>
    </div>
    <button type="button" class="kids-courtesy-toggle ${state.order.kidsCourtesyExtension ? 'active' : ''}" data-kids-courtesy-toggle>
      ${state.order.kidsCourtesyExtension ? 'Activa' : 'Activar'}
    </button>
  `;
  container.appendChild(panel);
  panel.querySelector('[data-kids-courtesy-toggle]')?.addEventListener('click', () => {
    state.order.kidsCourtesyExtension = !state.order.kidsCourtesyExtension;
    syncKidsCourtesyExtension();
    renderTimeOptions();
    renderOrder();
  });
}


function renderExtraControllerSelector(container) {
  if (!container) return;
  const config = getExtraControllerConfig();
  const shouldShow = Boolean(config && normalizePlayerCount(state.order.playerCount) === 2);
  if (!shouldShow) {
    state.order.extraControllerCount = 0;
    return;
  }
  const count = syncExtraControllerCount();
  const total = getExtraControllerTotal();
  const totalPlayers = 2 + count;
  const disabledMinus = count <= 0 ? 'disabled' : '';
  const disabledPlus = count >= config.max ? 'disabled' : '';
  const priceText = config.unitPrice > 0 ? `${money(config.unitPrice)} c/u` : 'Sin precio configurado';
  const totalText = count > 0 ? ` · +${money(total)} · ${totalPlayers} jugadores` : '';
  const panel = document.createElement('div');
  panel.className = 'extra-controller-selector';
  panel.innerHTML = `
    <div class="extra-controller-copy">
      <strong>Controles extra</strong>
      <small>${priceText}${totalText}</small>
    </div>
    <div class="extra-controller-actions">
      <button type="button" class="extra-controller-btn extra-controller-btn-minus" data-extra-controller-minus ${disabledMinus}><span aria-hidden="true">−</span></button>
      <span>${count}</span>
      <button type="button" class="extra-controller-btn extra-controller-btn-plus" data-extra-controller-plus ${disabledPlus}><span aria-hidden="true">+</span></button>
    </div>
  `;
  container.appendChild(panel);
  panel.querySelector('[data-extra-controller-minus]')?.addEventListener('click', () => {
    state.order.extraControllerCount = normalizeExtraControllerCount(count - 1);
    renderTimeOptions();
    renderOrder();
  });
  panel.querySelector('[data-extra-controller-plus]')?.addEventListener('click', () => {
    state.order.extraControllerCount = normalizeExtraControllerCount(count + 1);
    renderTimeOptions();
    renderOrder();
  });
}

function getPlayerCountLabelWithExtras() {
  const line = getExtraControllerOrderLine();
  if (!line) return getPlayerCountLabel(state.order.playerCount);
  return `2 jugadores + ${line.count} control${line.count === 1 ? '' : 'es'} extra${line.count === 1 ? '' : 's'} · ${line.totalPlayers} jugadores`;
}

function renderTimeOptions() {
  const box = $('#timeOptions');
  const station = state.selectedStation;
  if (!box) return;

  if (state.posMode !== 'station' || !station || state.activeMenuCategory !== 'TIME') {
    box.innerHTML = '';
    box.classList.add('hidden');
    return;
  }

  box.classList.remove('hidden');
  box.innerHTML = '';

  state.order.playerCount = normalizePlayerCount(state.order.playerCount);
  const isBusy = station.status === 'BUSY';
  let rawPrices = getStationTimePrices(station, state.order.playerCount);
  if (isBusy && !rawPrices.some((price) => Number(price.minutes) === 15)) {
    const normalizedPlayerCount = normalizePlayerCount(state.order.playerCount);
    const stationExtension = state.timePrices
      .filter((price) => price.station_id === station.id && Number(price.player_count || 1) === normalizedPlayerCount && Number(price.minutes) === 15)
      .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes))[0];
    const consoleExtension = state.timePrices
      .filter((price) => !price.station_id && price.console_type === station.console_type && Number(price.player_count || 1) === normalizedPlayerCount && Number(price.minutes) === 15)
      .sort((a, b) => Number(a.sort_order || a.minutes) - Number(b.sort_order || b.minutes))[0];
    const extensionPrice = stationExtension || consoleExtension;

    if (extensionPrice) {
      rawPrices = [{ ...extensionPrice, label: extensionPrice.label || 'Extensión 15 min', is_active: true }, ...rawPrices];
    } else {
      const fallback = rawPrices.find((price) => Number(price.minutes) === 30) || rawPrices.find((price) => Number(price.minutes) === 60);
      if (fallback) {
        const factor = 15 / Number(fallback.minutes || 60);
        rawPrices = [
          {
            ...fallback,
            id: `extension-15-${fallback.id || station.id}`,
            label: 'Extensión 15 min',
            minutes: 15,
            price: Number((Number(fallback.price || 0) * factor).toFixed(2)),
            sort_order: 15
          },
          ...rawPrices
        ];
      }
    }
  }
  const stationPrices = rawPrices;
  const upcomingReservation = getUpcomingReservationForStation(station, 0);
  const maxMinutesBeforeReservation = getMinutesUntilReservation(upcomingReservation);
  if (upcomingReservation) {
    const warning = document.createElement('div');
    warning.className = 'station-reservation-window-warning';
    warning.innerHTML = `<strong>Reserva próxima</strong><span>${escapeHtml(getReservationConflictMessage(upcomingReservation, maxMinutesBeforeReservation))}</span>`;
    box.appendChild(warning);
    if (Number(state.order.gameMinutes || 0) > 0 && getUpcomingReservationForStation(station, state.order.gameMinutes)) {
      state.order.gameMinutes = 0;
      state.order.gamePriceId = null;
      state.order.freeMode = false;
    }
  }

  const selector = document.createElement('div');
  selector.className = 'time-player-selector';
  selector.innerHTML = timePlayerOptions.map((option) => `
    <button type="button" class="time-player-btn ${state.order.playerCount === option.value ? 'active' : ''}" data-player-count="${option.value}">
      ${option.label}
    </button>
  `).join('');
  box.appendChild(selector);
  renderExtraControllerSelector(box);

  selector.querySelectorAll('[data-player-count]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.order.playerCount = normalizePlayerCount(btn.dataset.playerCount);
      state.order.extraControllerCount = normalizeExtraControllerCount(state.order.extraControllerCount);
      syncKidsCourtesyExtension();
      if (state.order.gameMinutes > 0) {
        const stillAvailable = getStationTimePrices(station, state.order.playerCount)
          .some((price) => Number(price.minutes) === Number(state.order.gameMinutes));
        if (!stillAvailable) {
          state.order.gameMinutes = 0;
          state.order.gamePriceId = null;
        }
      }
      renderTimeOptions();
      renderOrder();
    });
  });

  const actionGrid = document.createElement('div');
  actionGrid.className = 'time-price-options-grid free-mode-grid';
  box.appendChild(actionGrid);

  const freeBtn = document.createElement('button');
  freeBtn.type = 'button';
  const freeBlockedByReservation = Boolean(upcomingReservation && !isStationOpenMode(station));
  freeBtn.className = `time-option pos-menu-button free-mode-option ${freeBlockedByReservation ? 'reservation-blocked' : ''} ${state.order.freeMode || isStationOpenMode(station) ? 'selected' : ''}`;
  if (freeBlockedByReservation) freeBtn.disabled = true;
  const preview = getOpenModeChargePreview(station);
  const previewChargeableMinutes = Math.max(0, Math.ceil(Number(preview?.chargeable || 0)));
  const previewChargeableLabel = previewChargeableMinutes > 0
    ? `${previewChargeableMinutes} min aprox.`
    : 'menos de 1 min';
  const busyText = isBusy
    ? (isStationOpenMode(station)
      ? `Activo · ${previewChargeableLabel}`
      : 'Continuar libre al detener')
    : 'Sin tiempo fijo · cobrar al detener';
  freeBtn.innerHTML = `<strong>Modo libre</strong><span>${busyText}<small>${getPlayerCountLabelWithExtras()}</small></span>`;
  freeBtn.addEventListener('click', () => {
    if (freeBlockedByReservation) {
      showToast(getReservationConflictMessage(upcomingReservation, maxMinutesBeforeReservation));
      return;
    }
    activateFreeMode();
  });
  actionGrid.appendChild(freeBtn);

  const priceGrid = document.createElement('div');
  priceGrid.className = 'time-price-options-grid';
  box.appendChild(priceGrid);

  if (!stationPrices.length) {
    priceGrid.innerHTML = isBusy
      ? '<div class="empty-state">Sin precios configurados para extender</div>'
      : '<div class="empty-state">Sin precios configurados</div>';
    return;
  }

  stationPrices.forEach((timePrice) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    const minutes = Number(timePrice.minutes || 0);
    const blockedEntry = getUpcomingReservationForStation(station, minutes);
    const blockedMaxMinutes = getMinutesUntilReservation(blockedEntry);
    const isBlockedByReservation = Boolean(blockedEntry);
    const promoPrice = getTimePriceWithPromotion(station, timePrice);
    const extraControllerTotal = getExtraControllerTotal();
    const displayPrice = Number((Number(promoPrice.finalPrice || 0) + extraControllerTotal).toFixed(2));
    const displayBasePrice = Number((Number(promoPrice.basePrice || 0) + extraControllerTotal).toFixed(2));
    btn.className = `time-option pos-menu-button ${isBlockedByReservation ? 'reservation-blocked' : ''} ${promoPrice.promotion ? 'promo-time-option' : ''} ${state.order.gameMinutes === Number(timePrice.minutes) ? 'selected' : ''}`;
    if (isBlockedByReservation) btn.disabled = true;
    const memberTag = timePrice.member_price ? `<small>${getMembershipLabel(timePrice.membership_tier)}</small>` : '';
    const playerTag = `<small>${getPlayerCountLabelWithExtras()}</small>`;
    const extraControllerTag = extraControllerTotal > 0 ? `<small>Controles extra +${money(extraControllerTotal)}</small>` : '';
    const extensionTag = isBusy && Number(timePrice.minutes) === 15 ? '<small>Solo extensión</small>' : '';
    const blockedTag = isBlockedByReservation ? '<small>Choca con reserva</small>' : '';
    const timeLabel = isBusy && Number(timePrice.minutes) === 15 ? 'Extensión 15 min' : timePrice.label;
    btn.innerHTML = promoPrice.promotion
      ? `<strong>${timeLabel}</strong><span><b>${money(displayPrice)}</b><small>${promoPrice.promotion.name}</small>${extensionTag}${blockedTag}${memberTag}${playerTag}${extraControllerTag}</span>`
      : `<strong>${timeLabel}</strong><span>${money(displayPrice)}${extensionTag}${blockedTag}${memberTag}${playerTag}${extraControllerTag}</span>`;
    btn.addEventListener('click', () => {
      if (isBlockedByReservation) {
        showToast(getReservationConflictMessage(blockedEntry, blockedMaxMinutes));
        return;
      }
      state.order.freeMode = false;
      state.order.gameMinutes = state.order.gameMinutes === Number(timePrice.minutes) ? 0 : Number(timePrice.minutes);
      state.order.gamePriceId = state.order.gameMinutes > 0 ? timePrice.id : null;
      syncKidsCourtesyExtension();
      renderTimeOptions();
      renderOrder();
    });
    priceGrid.appendChild(btn);
  });
  renderKidsCourtesyExtensionSelector(box);
}

function getActiveSessionItems(station = state.selectedStation) {
  return Array.isArray(station?.active_session_items) ? station.active_session_items : [];
}

function getActiveSessionPendingTotal(station = state.selectedStation) {
  return getActiveSessionItems(station).reduce((sum, item) => item.payment_status === 'PENDING' ? sum + Number(item.total || 0) : sum, 0);
}

function getActiveSessionPaidTotal(station = state.selectedStation) {
  return getActiveSessionItems(station).reduce((sum, item) => item.payment_status === 'PAID' ? sum + Number(item.total || 0) : sum, 0);
}

function getActiveSessionAccountTotal(station = state.selectedStation) {
  return getActiveSessionItems(station).reduce((sum, item) => sum + Number(item.total || 0), 0);
}

function getOrderComboIncludedMinutes() {
  return (state.order?.items || []).reduce((sum, item) => {
    const product = (state.products || []).find((entry) => String(entry.id) === String(item.productId));
    const isCombo = Boolean(product?.is_combo) || String(product?.category || item.category || '').toUpperCase() === 'COMBO';
    if (!isCombo) return sum;
    const minutes = Number(product?.combo_included_minutes || product?.comboIncludedMinutes || item.combo_included_minutes || 0);
    return sum + Math.max(0, minutes) * Math.max(1, Number(item.quantity || 1));
  }, 0);
}

function getOrderHasTimeSource() {
  return Number(state.order?.gameMinutes || 0) > 0
    || Number(getOrderComboIncludedMinutes() || 0) > 0
    || Boolean(state.order?.welcomeBonus || state.order?.visitReward);
}

async function checkoutStation(paymentMethod, paymentReference = '', transferAuthorizationCode = '') {
  const station = state.selectedStation;

  if (!requireOpenDrawerForSales(true)) return;

  if (state.posMode === 'station' && station && !hasNewOrderContent() && getActiveSessionPendingTotal(station) > 0) {
    try {
      const result = await api(`/stations/${station.id}/pay-account`, {
        method: 'POST',
        body: JSON.stringify({ paymentMethod, paymentReference, transferAuthorizationCode })
      });
      showToast(`Cuenta cobrada: ${money(result.sale.total)}`);
      await loadAll();
      if (!state.paymentFlowContext) closeStationModal();
      return true;
    } catch (error) {
      if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message);
      else showToast(error.message);
      return false;
    }
  }

  if (state.posMode === 'quick') {
    return window.ClubVersusQuickSale?.checkoutQuickOrder?.(paymentMethod, paymentReference, transferAuthorizationCode);
  }

  if (!station) return;

  const isNewStationSession = station.status !== 'BUSY';
  const hasTimeSource = getOrderHasTimeSource();

  if (isNewStationSession && !hasTimeSource) {
    showToast('Selecciona horas antes de cobrar');
    state.activeMenuCategory = 'TIME';
    renderModalProducts();
    return false;
  }

  if (getOrderTotal() <= 0 && !state.order.welcomeBonus && !state.order.visitReward && !state.order.productBonus && !state.order.familyDiscount) {
    showToast('Agrega tiempo, productos o una recompensa');
    return;
  }

  try {
    const result = await api(`/stations/${station.id}/checkout`, {
      method: 'POST',
      body: JSON.stringify({
        paymentMethod,
        paymentReference,
        transferAuthorizationCode,
        memberId: state.selectedMember?.id || null,
        gameMinutes: state.order.gameMinutes,
        playerCount: state.order.playerCount,
        gameId: state.order.gameId || null,
        gamePriceId: state.order.gamePriceId || null,
        welcomeBonusId: state.order.welcomeBonus?.id || null,
        visitRewardId: state.order.visitReward?.id || state.order.productBonus?.id || null,
        rewardMinutesRequested: state.order.visitReward?.minutes || 0,
        rewardSnackQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'SNACK' ? Number(state.order.productBonus.quantity || 0) : 0,
        rewardDrinkQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'DRINK' ? Number(state.order.productBonus.quantity || 0) : 0,
        rewardProductId: state.order.productBonus?.productId || null,
        rewardProductQty: state.order.productBonus?.productId ? Number(state.order.productBonus.quantity || 0) : 0,
        items: state.order.items.map((item) => ({ productId: item.productId, quantity: item.quantity, modifierOptionIds: (item.modifiers || []).map((modifier) => modifier.optionId) })),
        extras: (state.order.extras || []).map((extra) => ({ extraId: extra.id, quantity: extra.quantity })),
        extraControllerCount: syncExtraControllerCount(),
        kidsCourtesyExtensionMinutes: state.order.kidsCourtesyExtension ? getKidsCourtesyExtensionMinutes() : 0,
        tournamentEntries: (state.order.tournamentEntries || []).map((entry) => ({
          tournamentId: entry.tournamentId,
          participantId: entry.participantId || null,
          playerName: entry.playerName || '',
          phone: entry.phone || '',
          nickname: entry.nickname || '',
          memberId: entry.memberId || null
        }))
      })
    });

    showToast(`Venta cobrada: ${money(result.sale.total)}`);
    const assignedWaitlistId = state.pendingWaitlistAssignmentId;
    state.pendingWaitlistAssignmentId = null;
    if (assignedWaitlistId) {
      await api(`/stations/game-reservations/${assignedWaitlistId}`, { method: 'PATCH', body: JSON.stringify({ status: 'ASSIGNED' }) }).catch(() => {});
    }
    await loadAll();
    if (!state.paymentFlowContext) closeStationModal();
    return true;
  } catch (error) {
    if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message);
    else showToast(error.message);
    return false;
  }
}

async function saveStationAccount() {
  const station = state.selectedStation;
  if (!station || state.posMode !== 'station') return;
  if (!requireOpenDrawerForSales(true)) return;
  if (!hasNewOrderContent()) {
    showToast('Agrega algo antes de guardar');
    return;
  }

  try {
    await api(`/stations/${station.id}/save-account`, {
      method: 'POST',
      body: JSON.stringify(getCurrentOrderPayload())
    });
    showToast('Cuenta guardada');
    const assignedWaitlistId = state.pendingWaitlistAssignmentId;
    state.pendingWaitlistAssignmentId = null;
    if (assignedWaitlistId) {
      await api(`/stations/game-reservations/${assignedWaitlistId}`, { method: 'PATCH', body: JSON.stringify({ status: 'ASSIGNED' }) }).catch(() => {});
    }
    await loadAll();
    closeStationModal();
    setTimeout(() => closeStationModal(), 30);
  } catch (error) {
    showToast(error.message || 'No se pudo guardar la cuenta');
  }
}

async function awaitEndSession(paymentMethod = 'CASH', paymentReference = '', transferAuthorizationCode = '', options = {}) {
  const station = state.selectedStation;
  if (!station || station.status !== 'BUSY') return false;

  try {
    const result = await api(`/stations/${station.id}/end`, {
      method: 'POST',
      body: JSON.stringify({ paymentMethod, paymentReference, transferAuthorizationCode })
    });

    const saleText = result.sale ? ` · ${money(result.sale.total)}` : '';
    const rewardText = result.rewardCreated ? ' · recompensa creada' : '';
    showToast(`Sesión cerrada${saleText}${rewardText}`);
    state.pendingEndSession = false;
    await loadAll();
    if (!options.deferClose) closeStationModal();
    return true;
  } catch (error) {
    if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message);
    else showToast(error.message);
    return false;
  }
}

async function endSelectedSession() {
  const station = state.selectedStation;
  if (!station || station.status !== 'BUSY') return;

  const pendingBalance = getActiveSessionPendingTotal(station);
  if (pendingBalance > 0) {
    showToast('Esta estación tiene balance pendiente');
    state.pendingAccountPayment = true;
    state.closeAfterPendingPayment = true;
    openCashPaymentModal();
    return;
  }

  const openModePreview = isStationOpenMode(station) ? getOpenModeChargePreview(station) : { amount: 0 };
  const roundedOpenModeTotal = Math.max(0, Math.round(Number(openModePreview.amount || 0)));
  const needsPayment = roundedOpenModeTotal > 0;
  if (needsPayment) {
    state.customPaymentFlow = {
      active: true,
      total: roundedOpenModeTotal,
      label: 'Modo libre',
      onConfirm: async ({ paymentMethod = 'CASH', reference = '', transferAuthorizationCode = '' } = {}) => {
        const completed = await awaitEndSession(paymentMethod, reference, transferAuthorizationCode);
        if (completed) state.customPaymentFlow = null;
        return completed;
      }
    };
    openCashPaymentModal();
    return;
  }

  await awaitEndSession('CASH');
}

  bindStationConfigUiEvents();
  bindStationGamesConfigEvents();
  bindStationExtrasConfigEvents();
  bindGamePickerEvents();
  bindGameReservationEvents();

  window.ClubVersusStations = {
    getStationMenuCategories: getStationMenuCategories,
    getStationMembershipLogo: getStationMembershipLogo,
    getStationMembershipMarkup: getStationMembershipMarkup,
    canManageStations: canManageStations,
    getSessionRemainingMs: getSessionRemainingMs,
    getStationTimeState: getStationTimeState,
    loadStations: loadStations,
    loadGameReservations: loadGameReservations,
    loadPendingNotices: loadPendingNotices,
    openPendingNoticesModal: openPendingNoticesModal,
    renderVersusBoard: renderVersusBoard,
    startVersusMode: startVersusMode,
    setVersusStationWinner: setVersusStationWinner,
    renderStations: renderStations,
    checkStationTimeAlerts: checkStationTimeAlerts,
    updateStationLiveTimers: updateStationLiveTimers,
    openStationsConfigModule: openStationsConfigModule,
    closeStationsConfigModule: closeStationsConfigModule,
    resetStationConfigForm: resetStationConfigForm,
    renderStationModelOptions: renderStationModelOptions,
    selectStationConfig: selectStationConfig,
    renderStationsConfigModule: renderStationsConfigModule,
    renderStationGamesConfigModule: renderStationGamesConfigModule,
    resetStationGameForm: resetStationGameForm,
    renderStationExtrasConfigModule: renderStationExtrasConfigModule,
    resetStationExtraForm: resetStationExtraForm,
    saveStationExtraConfig: saveStationExtraConfig,
    bindStationConfigUiEvents: bindStationConfigUiEvents,
    bindStationGamesConfigEvents: bindStationGamesConfigEvents,
    bindStationExtrasConfigEvents: bindStationExtrasConfigEvents,
    saveStationConfig: saveStationConfig,
    deleteStationConfig: deleteStationConfig,
    openStationModal: openStationModal,
    closeStationModal: closeStationModal,
    getGeneralStationTimePrices: getGeneralStationTimePrices,
    getStationTimePrices: getStationTimePrices,
    findConfiguredStationTimePrice: findConfiguredStationTimePrice,
    isStationOpenMode: isStationOpenMode,
    getOpenModeHourlyRate: getOpenModeHourlyRate,
    getOpenModeElapsedMs: getOpenModeElapsedMs,
    getOpenModeElapsedMinutes: getOpenModeElapsedMinutes,
    getOpenModeChargePreview: getOpenModeChargePreview,
    getExtraControllerTotal: getExtraControllerTotal,
    getExtraControllerOrderLine: getExtraControllerOrderLine,
    syncExtraControllerCount: syncExtraControllerCount,
    renderTimeOptions: renderTimeOptions,
    getActiveSessionItems: getActiveSessionItems,
    getActiveSessionPendingTotal: getActiveSessionPendingTotal,
    getActiveSessionPaidTotal: getActiveSessionPaidTotal,
    getActiveSessionAccountTotal: getActiveSessionAccountTotal,
    checkoutStation: checkoutStation,
    saveStationAccount: saveStationAccount,
    awaitEndSession: awaitEndSession,
    endSelectedSession: endSelectedSession,
    openStationTransferModal: openStationTransferModal,
    getStationTransferRemainingMinutes: getStationTransferRemainingMinutes,
    maybeShowSavedGameAlert: maybeShowSavedGameAlert,
    handleStationSavedGameAlert: handleStationSavedGameAlert,
    openGameReservationsModal: openGameReservationsModal,
    openGameRequestsListModal: openGameRequestsListModal,
    openGameRequestsAdminModule: openGameRequestsAdminModule,
    setGameReservationMember: setGameReservationMember
  };

  window.ClubVersusModules['stations'] = window.ClubVersusStations;
})();
