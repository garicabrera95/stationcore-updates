(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

// Orden POS, miembros rápidos, productos del modal e integración POS/Torneos movidos desde app.js en v2.0.6.7.
function resetOrder() {
  state.order = {
    gameMinutes: 0,
    gamePriceId: null,
    freeMode: false,
    playerCount: 1,
    extraControllerCount: 0,
    kidsCourtesyExtension: false,
    familyDiscount: null,
    welcomeBonus: null,
    visitReward: null,
    productBonus: null,
    items: [],
    extras: [],
    tournamentEntries: []
  };
}

function setSelectedMember(member) {
  state.selectedMember = member || null;
  state.order.welcomeBonus = null;
  state.order.visitReward = null;
  state.order.productBonus = null;
  renderMemberSelection();
  renderOrder();
  if (state.posMode === 'station') {
    setTimeout(() => window.ClubVersusModules?.stations?.handleStationSavedGameAlert?.(), 80);
  }
}

function getMemberRewardList(member) {
  const list = Array.isArray(member?.available_rewards) ? member.available_rewards : [];
  if (list.length) return list;
  if (!hasVisitReward(member)) return [];
  return [{
    id: member.visit_reward_id,
    reward_type: member.visit_reward_type,
    reward_minutes: member.visit_reward_minutes,
    used_reward_minutes: member.visit_reward_minutes_used,
    prize_snack_qty: member.visit_reward_snack_qty,
    used_prize_snack_qty: member.visit_reward_snack_used,
    prize_drink_qty: member.visit_reward_drink_qty,
    used_prize_drink_qty: member.visit_reward_drink_used,
    prize_product_id: member.visit_reward_product_id,
    prize_product_qty: member.visit_reward_product_qty,
    used_prize_product_qty: member.visit_reward_product_used,
    prize_product_name: member.visit_reward_product_name,
    prize_product_category: member.visit_reward_product_category,
    expires_at: member.visit_reward_expires_at,
    status: member.visit_reward_status
  }];
}

function getRewardRemainingValue(reward, totalKey, usedKey) {
  return Math.max(0, Number(reward?.[totalKey] || 0) - Number(reward?.[usedKey] || 0));
}

function getRewardProductFromReward(reward) {
  if (!reward?.prize_product_id) return null;
  const product = state.products.find((item) => String(item.id) === String(reward.prize_product_id));
  return product || {
    id: reward.prize_product_id,
    name: reward.prize_product_name || 'Producto / servicio',
    category: reward.prize_product_category || '',
    price: 0
  };
}

function describeRewardSummary(reward) {
  const parts = [];
  const minutes = getRewardRemainingValue(reward, 'reward_minutes', 'used_reward_minutes');
  const snacks = getRewardRemainingValue(reward, 'prize_snack_qty', 'used_prize_snack_qty');
  const drinks = getRewardRemainingValue(reward, 'prize_drink_qty', 'used_prize_drink_qty');
  const productQty = getRewardRemainingValue(reward, 'prize_product_qty', 'used_prize_product_qty');
  const product = getRewardProductFromReward(reward);
  if (minutes > 0) parts.push(`${minutes} min`);
  if (snacks > 0) parts.push(`${snacks} snack(s)`);
  if (drinks > 0) parts.push(`${drinks} bebida(s)`);
  if (productQty > 0) parts.push(`${productQty} ${product?.name || 'producto'}`);
  return parts.join(' + ');
}

function rewardButtonHtml(reward, kind) {
  const id = escapeHtml(reward.id);
  if (kind === 'time') return `<button type="button" class="reward-apply-btn mini" data-order-apply-reward-time="${id}">Tiempo guardado</button>`;
  if (kind === 'snack') return `<button type="button" class="reward-apply-btn mini" data-order-apply-reward-snack="${id}">Bono snack</button>`;
  if (kind === 'drink') return `<button type="button" class="reward-apply-btn mini" data-order-apply-reward-drink="${id}">Bono bebida</button>`;
  if (kind === 'product') {
    const product = getRewardProductFromReward(reward);
    return `<button type="button" class="reward-apply-btn mini" data-order-apply-reward-product="${id}">Bono ${escapeHtml(product?.name || 'producto')}</button>`;
  }
  return '';
}

function renderMemberSelection() {
  const result = $('#memberResult');
  const orderBox = $('#orderMemberBox');
  const quickLabel = $('#memberQuickLabel');
  const member = state.selectedMember;

  if (!result || !orderBox) return;

  if (!member) {
    if (quickLabel) quickLabel.textContent = 'General';
    result.className = 'member-result empty';
    result.textContent = 'General';
    orderBox.className = 'order-member empty';
    orderBox.innerHTML = '<strong>General</strong><span>PRECIO</span>';
    return;
  }

  const phone = member.phone ? ` · ${member.phone}` : '';
  const birthday = member.date_of_birth ? ` · Cumple ${formatBirthDate(member.date_of_birth)}` : '';
  const visits = Number(member.visit_count || 0);
  const points = Number(member.reward_points || 0);
  const membership = member.membership_active ? getMembershipLabel(member.membership_tier) : 'General';
  const membershipKey = getMembershipKey(member.membership_tier);
  if (quickLabel) quickLabel.textContent = `${member.full_name} · ${membership}`;
  const bonusAvailable = hasWelcomeBonus(member);
  const rewardAvailable = hasVisitReward(member);
  const bonusText = bonusAvailable
    ? `Bono ${Number(member.welcome_bonus_minutes)} min · vence ${formatDateTime(member.welcome_bonus_expires_at)}`
    : '';
  const rewardList = getMemberRewardList(member);
  const rewardSummaries = rewardList.map(describeRewardSummary).filter(Boolean);
  const rewardText = rewardSummaries.length
    ? `${rewardSummaries.slice(0, 2).join(' · ')}${rewardSummaries.length > 2 ? ` · +${rewardSummaries.length - 2} más` : ''}`
    : `${getVisitsUntilReward(member)} visitas para recompensa`;

  result.className = 'member-result';
  result.innerHTML = `
    <div class="member-result-card member-result-card-stacked member-tier-${membershipKey}">
      <span>
        <strong>${member.full_name}</strong>
        <small><b class="member-tier-pill">${membership}</b> ${visits} visitas · ${points} pts${phone}${birthday}</small>
        ${bonusText ? `<small class="member-bonus-line">${bonusText}</small>` : ''}
        <small class="member-reward-line">${rewardText}</small>
      </span>
      <div class="member-benefit-actions">
        ${bonusAvailable ? '<button type="button" class="bonus-apply-btn" data-apply-welcome-bonus>Aplicar bono</button>' : ''}
        ${rewardAvailable ? `<button type="button" class="reward-apply-btn" data-apply-visit-reward>Aplicar ${getRewardLabel(member.visit_reward_type).toLowerCase()}</button>` : ''}
      </div>
    </div>
  `;

  const bonusBtn = result.querySelector('[data-apply-welcome-bonus]');
  if (bonusBtn) {
    bonusBtn.addEventListener('click', applyWelcomeBonus);
  }

  const rewardBtn = result.querySelector('[data-apply-visit-reward]');
  if (rewardBtn) {
    rewardBtn.addEventListener('click', applyVisitReward);
  }

  const orderActions = [];
  if (bonusAvailable) orderActions.push('<button type="button" class="bonus-apply-btn mini" data-order-apply-welcome-bonus>Aplicar bono tiempo</button>');
  rewardList.forEach((reward) => {
    if (getRewardRemainingValue(reward, 'reward_minutes', 'used_reward_minutes') > 0) orderActions.push(rewardButtonHtml(reward, 'time'));
    if (getRewardRemainingValue(reward, 'prize_snack_qty', 'used_prize_snack_qty') > 0) orderActions.push(rewardButtonHtml(reward, 'snack'));
    if (getRewardRemainingValue(reward, 'prize_drink_qty', 'used_prize_drink_qty') > 0) orderActions.push(rewardButtonHtml(reward, 'drink'));
    if (getRewardRemainingValue(reward, 'prize_product_qty', 'used_prize_product_qty') > 0) orderActions.push(rewardButtonHtml(reward, 'product'));
  });

  orderBox.className = 'order-member';
  orderBox.innerHTML = `
    <strong>${member.full_name}</strong>
    <span>${membership}</span>
    ${orderActions.length ? `<div class="order-member-actions">${orderActions.join('')}</div>` : ''}
  `;

  orderBox.querySelector('[data-order-apply-welcome-bonus]')?.addEventListener('click', applyWelcomeBonus);
  orderBox.querySelector('[data-order-apply-time-reward]')?.addEventListener('click', applyVisitReward);
  orderBox.querySelector('[data-order-apply-snack-reward]')?.addEventListener('click', () => applyProductReward('SNACK'));
  orderBox.querySelector('[data-order-apply-drink-reward]')?.addEventListener('click', () => applyProductReward('DRINK'));
  orderBox.querySelector('[data-order-apply-product-reward]')?.addEventListener('click', applyExactProductReward);
  orderBox.querySelectorAll('[data-order-apply-reward-time]').forEach((btn) => btn.addEventListener('click', () => applyRewardTimeById(btn.dataset.orderApplyRewardTime)));
  orderBox.querySelectorAll('[data-order-apply-reward-snack]').forEach((btn) => btn.addEventListener('click', () => applyRewardCategoryById(btn.dataset.orderApplyRewardSnack, 'SNACK')));
  orderBox.querySelectorAll('[data-order-apply-reward-drink]').forEach((btn) => btn.addEventListener('click', () => applyRewardCategoryById(btn.dataset.orderApplyRewardDrink, 'DRINK')));
  orderBox.querySelectorAll('[data-order-apply-reward-product]').forEach((btn) => btn.addEventListener('click', () => applyRewardProductById(btn.dataset.orderApplyRewardProduct)));
}


function ensureRewardQuantityModal() {
  let modal = document.querySelector('#rewardQuantityModal');
  if (modal) return modal;
  modal = document.createElement('section');
  modal.id = 'rewardQuantityModal';
  modal.className = 'module-modal hidden reward-quantity-modal';
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="module-backdrop" data-close-reward-quantity></div>
    <div class="module-shell reward-quantity-shell">
      <header class="reward-quantity-header">
        <div>
          <h2 id="rewardQuantityTitle">Aplicar bono</h2>
          <p id="rewardQuantitySubtitle">Selecciona la cantidad a usar</p>
        </div>
        <button type="button" class="icon-btn" data-close-reward-quantity>×</button>
      </header>
      <div class="reward-quantity-body">
        <label for="rewardQuantityInput">Cantidad</label>
        <input id="rewardQuantityInput" type="number" min="1" step="1" inputmode="numeric" />
        <div id="rewardQuantityHint" class="reward-quantity-hint"></div>
      </div>
      <footer class="reward-quantity-actions">
        <button type="button" class="secondary" data-close-reward-quantity>Cancelar</button>
        <button type="button" id="confirmRewardQuantityBtn">Aplicar bono</button>
      </footer>
    </div>
  `;
  document.body.appendChild(modal);
  return modal;
}

function askRewardQuantity({ title = 'Aplicar bono', subtitle = '', available = 1, itemName = 'bono' } = {}) {
  const max = Math.max(1, Number.parseInt(String(available || 1), 10) || 1);
  if (max <= 1) return Promise.resolve(1);

  const modal = ensureRewardQuantityModal();
  const titleEl = modal.querySelector('#rewardQuantityTitle');
  const subtitleEl = modal.querySelector('#rewardQuantitySubtitle');
  const input = modal.querySelector('#rewardQuantityInput');
  const hint = modal.querySelector('#rewardQuantityHint');
  const confirmBtn = modal.querySelector('#confirmRewardQuantityBtn');

  if (titleEl) titleEl.textContent = title;
  if (subtitleEl) subtitleEl.textContent = subtitle || `Tienes ${max} ${itemName} disponibles.`;
  if (input) {
    input.min = '1';
    input.max = String(max);
    input.value = '1';
  }
  if (hint) hint.textContent = `Disponible: ${max}. Puedes aplicar de 1 a ${max}.`;

  return new Promise((resolve) => {
    let settled = false;
    const cleanup = () => {
      modal.querySelectorAll('[data-close-reward-quantity]').forEach((btn) => btn.removeEventListener('click', onCancel));
      confirmBtn?.removeEventListener('click', onConfirm);
      input?.removeEventListener('keydown', onKeyDown);
    };
    const close = (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      modal.classList.add('hidden');
      modal.setAttribute('aria-hidden', 'true');
      closeModalElement?.(modal);
      resolve(value);
    };
    const onCancel = () => close(null);
    const onConfirm = () => {
      const quantity = Math.max(1, Math.min(max, Number.parseInt(String(input?.value || '1'), 10) || 1));
      close(quantity);
    };
    const onKeyDown = (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        onConfirm();
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        onCancel();
      }
    };

    modal.querySelectorAll('[data-close-reward-quantity]').forEach((btn) => btn.addEventListener('click', onCancel));
    confirmBtn?.addEventListener('click', onConfirm);
    input?.addEventListener('keydown', onKeyDown);

    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
    openModalElement?.(modal, { base: 2147482600 });
    requestAnimationFrame(() => {
      bringModalToFront?.(modal, { base: 2147482600 });
      input?.focus();
      input?.select();
    });
  });
}

function applyWelcomeBonus() {
  const member = state.selectedMember;
  if (!hasWelcomeBonus(member)) return;

  state.order.welcomeBonus = {
    id: member.welcome_bonus_id,
    minutes: Number(member.welcome_bonus_minutes || 30),
    expiresAt: member.welcome_bonus_expires_at
  };

  renderOrder();
  showToast('Bono aplicado');
}

async function applyVisitReward() {
  const member = state.selectedMember;
  const available = getRewardMinutes(member);
  if (!hasVisitReward(member) || available <= 0) return showToast('No hay minutos disponibles');
  const minutes = await askRewardQuantity({
    title: 'Usar tiempo guardado',
    subtitle: `Tienes ${available} minutos disponibles. Puedes usar solo una parte.`,
    available,
    itemName: 'minutos'
  });
  if (!minutes) return;

  state.order.visitReward = {
    id: member.visit_reward_id,
    type: member.visit_reward_type || 'VISIT_REWARD',
    minutes,
    expiresAt: member.visit_reward_expires_at
  };

  renderOrder();
  showToast(`Tiempo guardado aplicado: ${minutes} min`);
}

async function applyProductReward(category) {
  const member = state.selectedMember;
  if (!hasVisitReward(member)) return showToast('No hay bono disponible');
  const available = category === 'DRINK' ? getRewardDrinkQty(member) : getRewardSnackQty(member);
  if (available <= 0) return showToast(category === 'DRINK' ? 'No hay bonos de bebida' : 'No hay bonos de snack');

  const quantity = await askRewardQuantity({
    title: category === 'DRINK' ? 'Aplicar bono de bebida' : 'Aplicar bono de snack',
    subtitle: `Tienes ${available} bono(s) disponibles.`,
    available,
    itemName: category === 'DRINK' ? 'bebida(s)' : 'snack(s)'
  });
  if (!quantity) return;

  state.order.productBonus = {
    id: member.visit_reward_id,
    type: member.visit_reward_type || 'TOURNAMENT_PRIZE',
    category,
    quantity
  };

  renderOrder();
  showToast(category === 'DRINK' ? 'Bono de bebida activo' : 'Bono de snack activo');
}

async function applyExactProductReward() {
  const member = state.selectedMember;
  const product = getRewardProduct(member);
  const available = getRewardProductQty(member);
  if (!member?.visit_reward_id || !product || available <= 0) return showToast('No hay bono de producto disponible');

  const quantity = await askRewardQuantity({
    title: `Aplicar bono de ${product.name}`,
    subtitle: `Tienes ${available} bono(s) de ${product.name}.`,
    available,
    itemName: product.name
  });
  if (!quantity) return;

  state.order.productBonus = {
    id: member.visit_reward_id,
    type: member.visit_reward_type || 'MANUAL_BONUS',
    category: product.category,
    productId: product.id,
    productName: product.name,
    quantity
  };

  renderOrder();
  showToast(`Bono de ${product.name} activo`);
}

function findAvailableRewardById(rewardId) {
  return getMemberRewardList(state.selectedMember).find((reward) => String(reward.id) === String(rewardId));
}

async function applyRewardTimeById(rewardId) {
  const reward = findAvailableRewardById(rewardId);
  const available = getRewardRemainingValue(reward, 'reward_minutes', 'used_reward_minutes');
  if (!reward || available <= 0) return showToast('No hay minutos disponibles');
  const minutes = await askRewardQuantity({
    title: 'Usar tiempo guardado',
    subtitle: `Tienes ${available} minutos disponibles. Puedes usar solo una parte.`,
    available,
    itemName: 'minutos'
  });
  if (!minutes) return;
  state.order.visitReward = {
    id: reward.id,
    type: reward.reward_type || 'VISIT_REWARD',
    minutes,
    expiresAt: reward.expires_at
  };
  renderOrder();
  showToast(`Tiempo guardado aplicado: ${minutes} min`);
}

async function applyRewardCategoryById(rewardId, category) {
  const reward = findAvailableRewardById(rewardId);
  const available = category === 'DRINK'
    ? getRewardRemainingValue(reward, 'prize_drink_qty', 'used_prize_drink_qty')
    : getRewardRemainingValue(reward, 'prize_snack_qty', 'used_prize_snack_qty');
  if (!reward || available <= 0) return showToast(category === 'DRINK' ? 'No hay bonos de bebida' : 'No hay bonos de snack');
  const quantity = await askRewardQuantity({
    title: category === 'DRINK' ? 'Aplicar bono de bebida' : 'Aplicar bono de snack',
    subtitle: `Tienes ${available} bono(s) disponibles.`,
    available,
    itemName: category === 'DRINK' ? 'bebida(s)' : 'snack(s)'
  });
  if (!quantity) return;
  state.order.productBonus = {
    id: reward.id,
    type: reward.reward_type || 'TOURNAMENT_PRIZE',
    category,
    quantity
  };
  renderOrder();
  showToast(category === 'DRINK' ? 'Bono de bebida activo' : 'Bono de snack activo');
}

async function applyRewardProductById(rewardId) {
  const reward = findAvailableRewardById(rewardId);
  const product = getRewardProductFromReward(reward);
  const available = getRewardRemainingValue(reward, 'prize_product_qty', 'used_prize_product_qty');
  if (!reward || !product || available <= 0) return showToast('No hay bono de producto disponible');
  const quantity = await askRewardQuantity({
    title: `Aplicar bono de ${product.name}`,
    subtitle: `Tienes ${available} bono(s) de ${product.name}.`,
    available,
    itemName: product.name
  });
  if (!quantity) return;
  state.order.productBonus = {
    id: reward.id,
    type: reward.reward_type || 'POINT_REDEMPTION',
    category: product.category,
    productId: product.id,
    productName: product.name,
    quantity
  };
  renderOrder();
  showToast(`Bono de ${product.name} activo`);
}

function openMemberPicker() {
  const panel = $('#memberPickerPanel');
  if (!panel) return;
  panel.classList.remove('hidden');
  panel.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('#memberSearchInput')?.focus(), 30);
}

function closeMemberPicker() {
  const panel = $('#memberPickerPanel');
  if (!panel) return;
  panel.classList.add('hidden');
  panel.setAttribute('aria-hidden', 'true');
}
function openStationModal(...args) {
  return window.ClubVersusStations?.openStationModal?.(...args);
}

function openQuickOrderModal() {
  return window.ClubVersusQuickSale?.openQuickOrderModal?.();
}
function closeStationModal(...args) {
  return window.ClubVersusStations?.closeStationModal?.(...args);
}
function getGeneralStationTimePrices(...args) {
  return window.ClubVersusStations?.getGeneralStationTimePrices?.(...args);
}
function getStationTimePrices(...args) {
  return window.ClubVersusStations?.getStationTimePrices?.(...args);
}
function findConfiguredStationTimePrice(...args) {
  return window.ClubVersusStations?.findConfiguredStationTimePrice?.(...args);
}

function buildFallbackTimePrice(station, minutes, playerCount = state.order.playerCount) {
  const normalizedMinutes = Number(minutes || 0);
  const fallback = getStationTimePrices(station, playerCount).find((price) => Number(price.minutes || 0) === 30)
    || getStationTimePrices(station, playerCount).find((price) => Number(price.minutes || 0) === 60);
  if (!fallback || !normalizedMinutes) return null;
  const factor = normalizedMinutes / Number(fallback.minutes || 60);
  return {
    ...fallback,
    id: `extension-${normalizedMinutes}-${fallback.id || station?.id || 'time'}`,
    label: normalizedMinutes === 15 ? 'Extensión 15 min' : `${normalizedMinutes} min`,
    minutes: normalizedMinutes,
    player_count: normalizePlayerCount(playerCount),
    price: Number((Number(fallback.price || 0) * factor).toFixed(2)),
    sort_order: normalizedMinutes
  };
}

function getOrderTimePriceForMinutes(station, minutes, playerCount = state.order.playerCount) {
  const normalizedMinutes = Number(minutes || 0);
  if (!station || normalizedMinutes <= 0) return null;
  const activePrice = getStationTimePrices(station, playerCount).find((price) => Number(price.minutes) === normalizedMinutes);
  if (activePrice) return activePrice;
  if (station.status === 'BUSY' && normalizedMinutes === 15) {
    return findConfiguredStationTimePrice(station, 15, playerCount, { includeInactive: true })
      || buildFallbackTimePrice(station, 15, playerCount);
  }
  return null;
}

function normalizeDateOnly(value) {
  if (!value) return null;
  const date = parseAppDate(value);
  if (!date) return null;
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function promotionAppliesNow(promotion, station) {
  if (!promotion?.is_active || !station) return false;

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const starts = normalizeDateOnly(promotion.starts_on);
  const ends = normalizeDateOnly(promotion.ends_on);

  if (starts && today < starts) return false;
  if (ends && today > ends) return false;

  const days = Array.isArray(promotion.days_of_week) ? promotion.days_of_week.map(Number) : [0, 1, 2, 3, 4, 5, 6];
  if (!days.includes(now.getDay())) return false;

  if (!promotion.all_day) {
    const current = now.getHours() * 60 + now.getMinutes();
    const [startHour, startMinute] = String(promotion.start_time || '00:00').split(':').map(Number);
    const [endHour, endMinute] = String(promotion.end_time || '23:59').split(':').map(Number);
    const start = (startHour * 60) + startMinute;
    const end = (endHour * 60) + endMinute;

    if (start <= end && (current < start || current > end)) return false;
    if (start > end && current < start && current > end) return false;
  }

  if (promotion.scope_type === 'ALL') return true;
  if (promotion.scope_type === 'CONSOLE') return promotion.console_type === station.console_type;
  if (promotion.scope_type === 'STATION') return promotion.station_id === station.id;
  return false;
}

function applyPromotionToTimePrice(price, promotion) {
  const base = Number(price || 0);
  if (!promotion || base <= 0) {
    return {
      basePrice: base,
      finalPrice: base,
      discount: 0,
      promotion: null
    };
  }

  let finalPrice = base;
  if (promotion.discount_type === 'PERCENT') {
    finalPrice = base - (base * Number(promotion.discount_value || 0) / 100);
  } else if (promotion.discount_type === 'FIXED_PRICE') {
    finalPrice = Number(promotion.discount_value || 0);
  }

  finalPrice = Math.max(0, Number(finalPrice.toFixed(2)));
  return {
    basePrice: base,
    finalPrice,
    discount: Math.max(0, Number((base - finalPrice).toFixed(2))),
    promotion
  };
}

function getBestActivePromotion(station, basePrice) {
  const candidates = state.promotions.filter((promotion) => promotionAppliesNow(promotion, station));
  if (!candidates.length) return null;

  return candidates
    .map((promotion) => ({
      promotion,
      price: applyPromotionToTimePrice(basePrice, promotion).finalPrice
    }))
    .sort((a, b) => a.price - b.price)[0].promotion;
}

function getTimePriceWithPromotion(station, timePrice) {
  const promotion = getBestActivePromotion(station, Number(timePrice?.price || 0));
  return applyPromotionToTimePrice(Number(timePrice?.price || 0), promotion);
}

function getOrderTimePrice() {
  const station = state.selectedStation;
  if (!station || state.order.gameMinutes <= 0) return null;
  return getOrderTimePriceForMinutes(station, state.order.gameMinutes, state.order.playerCount);
}
function isStationOpenMode(...args) {
  return window.ClubVersusStations?.isStationOpenMode?.(...args);
}
function getOpenModeHourlyRate(...args) {
  return window.ClubVersusStations?.getOpenModeHourlyRate?.(...args);
}
function getOpenModeElapsedMs(...args) {
  return window.ClubVersusStations?.getOpenModeElapsedMs?.(...args);
}
function getOpenModeElapsedMinutes(...args) {
  return window.ClubVersusStations?.getOpenModeElapsedMinutes?.(...args);
}
function getOpenModeChargePreview(...args) {
  return window.ClubVersusStations?.getOpenModeChargePreview?.(...args);
}
function renderTimeOptions(...args) {
  return window.ClubVersusStations?.renderTimeOptions?.(...args);
}

function activateFreeMode() {
  const station = state.selectedStation;
  if (!station) return;
  state.order.freeMode = !state.order.freeMode;
  if (state.order.freeMode) {
    state.order.gameMinutes = 0;
    state.order.gamePriceId = null;
    state.order.kidsCourtesyExtension = false;
  }
  renderTimeOptions();
  renderOrder();
}

function renderMenuCategoryTabs() {
  const tabs = $('#menuCategoryTabs');
  if (!tabs) return;

  const availableCategories = new Set(state.products.map((product) => product.category));
  const sourceCategories = state.posMode === 'quick' ? getQuickOrderCategories() : getStationMenuCategories();
  const visibleCategories = sourceCategories.filter((category) => {
    return category.id === 'TIME' || category.id === 'TOURNAMENT' || category.id === 'EXTRAS' || availableCategories.has(category.id);
  });

  if (!visibleCategories.some((category) => category.id === state.activeMenuCategory)) {
    state.activeMenuCategory = visibleCategories[0]?.id || (state.posMode === 'quick' ? 'DRINK' : 'TIME');
  }

  tabs.innerHTML = visibleCategories.map((category) => `
    <button type="button" class="menu-category-tab ${state.activeMenuCategory === category.id ? 'active' : ''}" data-menu-category="${category.id}" style="--category-color:${category.color || '#2563eb'}">
      ${category.label}
    </button>
  `).join('');

  tabs.querySelectorAll('[data-menu-category]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.activeMenuCategory = btn.dataset.menuCategory;
      renderTimeOptions();
      renderModalProducts();
    });
  });
}


function getProductDisplayPrice(product) {
  const base = Number(product?.price || 0);
  const groups = getProductModifierGroups(product);
  if (!groups.length) return { label: money(base), hasModifiers: false };
  const optionValues = groups.flatMap((group) => (group.options || []).map((option) => Number(option.price_delta || 0)).filter((value) => Number.isFinite(value)));
  if (!optionValues.length) return { label: `Desde ${money(base)}`, hasModifiers: true };
  const positiveOptionValues = optionValues.filter((value) => value > 0);
  const candidatePrices = [base, ...optionValues.map((delta) => base + delta)];
  if (/tamañ|tamano|size/i.test(groups.map((group) => group.name || '').join(' ')) && positiveOptionValues.length >= 2) {
    candidatePrices.push(...positiveOptionValues);
  }
  const minPrice = Math.max(0, Math.min(...candidatePrices.filter((value) => Number.isFinite(value) && value >= 0)));
  return { label: `Desde ${money(minPrice)}`, hasModifiers: true };
}


async function loadPosTournaments(...args) {
  return window.ClubVersusTournaments?.loadPosTournaments?.(...args);
}

function isTodayTournament(...args) {
  return window.ClubVersusTournaments?.isTodayTournament?.(...args) || false;
}

function isClosedFinishedTournament(...args) {
  return window.ClubVersusTournaments?.isClosedFinishedTournament?.(...args) || false;
}

function getVisiblePosTournaments(...args) {
  return window.ClubVersusTournaments?.getVisiblePosTournaments?.(...args) || [];
}

function getPrimaryPosTournament(...args) {
  return window.ClubVersusTournaments?.getPrimaryPosTournament?.(...args) || null;
}

function getTournamentEntryFee(...args) {
  return window.ClubVersusTournaments?.getTournamentEntryFee?.(...args) || 0;
}

function getPendingTournamentParticipants(...args) {
  return window.ClubVersusTournaments?.getPendingTournamentParticipants?.(...args) || [];
}

function getTournamentEntryLineId(...args) {
  return window.ClubVersusTournamentEntryModal?.getTournamentEntryLineId?.(...args) || '';
}

function addTournamentEntryToOrder(...args) {
  return window.ClubVersusTournamentEntryModal?.addTournamentEntryToOrder?.(...args);
}

function removeTournamentEntryFromOrder(...args) {
  return window.ClubVersusTournamentEntryModal?.removeTournamentEntryFromOrder?.(...args);
}

function getTournamentEntryDiscountPreview(...args) {
  return window.ClubVersusTournamentEntryModal?.getTournamentEntryDiscountPreview?.(...args) || { baseAmount: 0, total: 0, discountAmount: 0, label: 'Sin descuento' };
}

function updateTournamentEntryModalTotals(...args) {
  return window.ClubVersusTournamentEntryModal?.updateTournamentEntryModalTotals?.(...args);
}

function forceTournamentEntryModalLayout(...args) {
  return window.ClubVersusTournamentEntryModal?.forceTournamentEntryModalLayout?.(...args);
}

function openTournamentEntryModal(...args) {
  return window.ClubVersusTournamentEntryModal?.openTournamentEntryModal?.(...args);
}

function closeTournamentEntryModal(...args) {
  return window.ClubVersusTournamentEntryModal?.closeTournamentEntryModal?.(...args);
}

async function searchTournamentEntryMembers(...args) {
  return window.ClubVersusTournamentEntryModal?.searchTournamentEntryMembers?.(...args);
}

function buildTournamentEntryFromModal(...args) {
  return window.ClubVersusTournamentEntryModal?.buildTournamentEntryFromModal?.(...args);
}

async function submitTournamentEntry(...args) {
  return window.ClubVersusTournamentEntryModal?.submitTournamentEntry?.(...args);
}

function promptNewTournamentEntry(...args) {
  return window.ClubVersusTournamentEntryModal?.promptNewTournamentEntry?.(...args);
}

function isTournamentAwardPending(...args) {
  return window.ClubVersusTournaments?.isTournamentAwardPending?.(...args) || false;
}

function getTournamentAwardPrizeParts(...args) {
  return window.ClubVersusTournaments?.getTournamentAwardPrizeParts?.(...args) || [];
}

function closeTournamentAwardsDeliveryModal(...args) {
  return window.ClubVersusTournaments?.closeTournamentAwardsDeliveryModal?.(...args);
}

function renderTournamentAwardsDeliveryModal(...args) {
  return window.ClubVersusTournaments?.renderTournamentAwardsDeliveryModal?.(...args);
}

async function refreshTournamentAwardsDelivery(...args) {
  return window.ClubVersusTournaments?.refreshTournamentAwardsDelivery?.(...args);
}

async function openTournamentAwardsDelivery(...args) {
  return window.ClubVersusTournaments?.openTournamentAwardsDelivery?.(...args);
}

window.openTournamentAwardsDelivery = openTournamentAwardsDelivery;

function setTournamentAwardsDeliveryBusy(...args) {
  return window.ClubVersusTournaments?.setTournamentAwardsDeliveryBusy?.(...args);
}

function setTournamentAwardsDeliveryStatus(...args) {
  return window.ClubVersusTournaments?.setTournamentAwardsDeliveryStatus?.(...args);
}

async function finishTournamentAwardDelivery(...args) {
  return window.ClubVersusTournaments?.finishTournamentAwardDelivery?.(...args);
}

async function deliverTournamentAwardFromPos(...args) {
  return window.ClubVersusTournaments?.deliverTournamentAwardFromPos?.(...args);
}

async function deliverAllTournamentAwardsFromPos(...args) {
  return window.ClubVersusTournaments?.deliverAllTournamentAwardsFromPos?.(...args);
}

window.deliverTournamentAwardFromPos = deliverTournamentAwardFromPos;
window.deliverAllTournamentAwardsFromPos = deliverAllTournamentAwardsFromPos;

function bindTournamentAwardsDeliveryDelegatedClicks(...args) {
  return window.ClubVersusTournaments?.bindTournamentAwardsDeliveryDelegatedClicks?.(...args);
}

async function startPosVersus(...args) {
  return window.ClubVersusVersusMode?.startPosVersus?.(...args);
}

async function closePosVersus(...args) {
  return window.ClubVersusVersusMode?.closePosVersus?.(...args);
}

function isTournamentFullForSale(...args) {
  return window.ClubVersusTournaments?.isTournamentFullForSale?.(...args) || false;
}

function getTournamentCapacityLabel(...args) {
  return window.ClubVersusTournaments?.getTournamentCapacityLabel?.(...args) || '';
}

function renderTournamentDayPanel(...args) {
  return window.ClubVersusTournaments?.renderTournamentDayPanel?.(...args);
}

function renderTournamentPosProducts(...args) {
  return window.ClubVersusTournaments?.renderTournamentPosProducts?.(...args);
}

function renderModalProducts() {
  const list = $('#modalProductsList');
  if (!list) return;

  if (state.posMode === 'quick' && state.activeMenuCategory === 'TIME') {
    state.activeMenuCategory = getFirstQuickOrderCategory();
  }

  renderMenuCategoryTabs();

  if (state.activeMenuCategory === 'TIME') {
    list.innerHTML = '';
    list.className = 'modal-products-list hidden';
    renderTimeOptions();
    return;
  }

  if (state.activeMenuCategory === 'EXTRAS') {
    renderTimeOptions();
    renderStationExtrasOptions(list);
    return;
  }

  if (state.activeMenuCategory === 'TOURNAMENT') {
    renderTimeOptions();
    renderTournamentPosProducts(list);
    return;
  }

  renderTimeOptions();
  list.innerHTML = '';

  const rawFilteredProducts = state.products.filter((product) => product.category === state.activeMenuCategory);
  const membershipSort = new Map(getMembershipTierOptions(true).map((plan, index) => [String(plan.id || '').toUpperCase(), index]));
  const normalizeMembershipProductKey = (product) => {
    const planCode = String(product?.membership_plan_code || '').trim().toUpperCase();
    if (planCode) return planCode.replace(/[^A-Z0-9]+/g, '_');

    const sku = String(product?.sku || '').toUpperCase();
    const name = String(product?.name || '').toUpperCase();
    const source = `${sku} ${name}`;
    if (source.includes('CHAMPION')) return 'CHAMPION';
    if (source.includes('GAMER_PRO') || source.includes('GAMER-PRO') || source.includes('GAMER PRO') || /\bPRO\b/.test(source)) return 'GAMER_PRO';
    if (source.includes('GAMER')) return 'GAMER';
    return name.replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '') || String(product?.id || '');
  };

  const rawProductsForCategory = state.activeMenuCategory === 'MEMBERSHIP'
    ? [...rawFilteredProducts].sort((a, b) => {
        const aKey = normalizeMembershipProductKey(a);
        const bKey = normalizeMembershipProductKey(b);
        const aRank = membershipSort.has(aKey) ? membershipSort.get(aKey) : 999;
        const bRank = membershipSort.has(bKey) ? membershipSort.get(bKey) : 999;
        if (aRank !== bRank) return aRank - bRank;
        const aHasPlan = a.membership_plan_code ? 0 : 1;
        const bHasPlan = b.membership_plan_code ? 0 : 1;
        if (aHasPlan !== bHasPlan) return aHasPlan - bHasPlan;
        return String(a.name || '').localeCompare(String(b.name || ''));
      })
    : rawFilteredProducts;

  const seenProductKeys = new Set();
  const filteredProducts = rawProductsForCategory.filter((product) => {
    const dedupeKey = product.category === 'MEMBERSHIP'
      ? `MEMBERSHIP:${normalizeMembershipProductKey(product)}`
      : String(product.id);
    if (!dedupeKey || seenProductKeys.has(dedupeKey)) return false;
    seenProductKeys.add(dedupeKey);
    return true;
  });

  if (filteredProducts.length === 0) {
    list.className = 'modal-products-list empty';
    list.textContent = 'Sin productos';
    return;
  }

  list.className = 'modal-products-list';

  filteredProducts.forEach((product) => {
    const categoryLabel = getCategoryLabel(product.category);
    const stockText = product.category === 'MEMBERSHIP'
      ? 'Activa membresía'
      : product.track_stock ? `Stock ${product.stock_qty}` : 'Servicio';
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `modal-product-card product-category-${String(product.category || '').toLowerCase()}`;
    card.innerHTML = `
      <span>
        <small class="product-category-label">${categoryLabel}</small>
        <strong>${product.name}</strong>
        <small>${stockText}</small>
      </span>
      <b>${getProductDisplayPrice(product).label}</b>
    `;
    card.addEventListener('click', () => addProductToOrder(product.id));
    list.appendChild(card);
  });
}


function getAssignedStationExtras(station = state.selectedStation) {
  if (!station) return [];
  return (state.stationExtras || [])
    .filter((extra) => extra.is_active !== false)
    .filter((extra) => (Array.isArray(extra.station_ids) ? extra.station_ids : []).map(String).includes(String(station.id)))
    .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
}

function getStationExtraIcon(extra = {}) {
  const name = String(extra.name || '').toLowerCase();
  if (name.includes('racing') || name.includes('wheel') || name.includes('volante') || name.includes('carrera')) return '🏎️';
  if (name.includes('vr') || name.includes('realidad')) return '🥽';
  if (name.includes('stream') || name.includes('live')) return '📡';
  if (name.includes('control') || name.includes('mando')) return '🎮';
  return '⭐';
}

function renderStationExtrasOptions(list) {
  const extras = getAssignedStationExtras();
  if (!extras.length) {
    list.className = 'modal-products-list empty';
    list.textContent = 'Sin extras asignados a esta estación';
    return;
  }
  list.className = 'modal-products-list station-extras-grid';
  list.innerHTML = '';
  extras.forEach((extra) => {
    const selected = (state.order.extras || []).find((line) => String(line.id) === String(extra.id));
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `modal-product-card station-extra-card ${selected ? 'selected' : ''}`;
    const typeLabel = extra.pricing_type === 'HOURLY' ? 'por hora' : (extra.pricing_type === 'FIXED' ? 'fijo' : 'por sesión');
    card.innerHTML = `
      <span class="station-extra-option-copy">
        <i class="station-extra-option-icon" aria-hidden="true">${getStationExtraIcon(extra)}</i>
        <span>
          <small class="product-category-label">EXTRA</small>
          <strong>${escapeHtml(extra.name)}</strong>
          <small>${escapeHtml(typeLabel)}${selected ? ` · ${selected.quantity} agregado(s)` : ''}</small>
        </span>
      </span>
      <b>${money(extra.price)}</b>
    `;
    card.addEventListener('click', () => addStationExtraToOrder(extra.id));
    list.appendChild(card);
  });
}

function addStationExtraToOrder(extraId) {
  const extra = getAssignedStationExtras().find((item) => String(item.id) === String(extraId));
  if (!extra) return showToast('Extra no disponible para esta estación');
  state.order.extras = Array.isArray(state.order.extras) ? state.order.extras : [];
  const existing = state.order.extras.find((line) => String(line.id) === String(extra.id));
  if (existing) existing.quantity += 1;
  else state.order.extras.push({ id: extra.id, name: extra.name, price: Number(extra.price || 0), pricingType: extra.pricing_type || 'SESSION', quantity: 1 });
  renderModalProducts();
  renderOrder();
}

function removeStationExtraFromOrder(extraId) {
  const existing = (state.order.extras || []).find((line) => String(line.id) === String(extraId));
  if (!existing) return;
  existing.quantity -= 1;
  if (existing.quantity <= 0) state.order.extras = (state.order.extras || []).filter((line) => line !== existing);
  renderModalProducts();
  renderOrder();
}

function getProductModifierGroups(product) {
  const assignedIds = Array.isArray(product?.modifier_group_ids) ? product.modifier_group_ids.map(String) : [];
  if (!assignedIds.length) return [];
  return (state.modifierGroups || [])
    .filter((group) => assignedIds.includes(String(group.id)) && group.is_active !== false)
    .map((group) => ({
      ...group,
      options: (group.options || []).filter((option) => option.is_active !== false)
    }))
    .filter((group) => group.options.length > 0)
    .sort((a, b) => Number(a.sort_order || 100) - Number(b.sort_order || 100) || String(a.name || '').localeCompare(String(b.name || '')));
}

function getModifierLineKey(productId, modifiers = []) {
  const optionIds = modifiers.map((modifier) => String(modifier.optionId || modifier.id || '')).filter(Boolean).sort();
  return `${productId}::${optionIds.join('|')}`;
}

function getModifierDescription(modifiers = []) {
  const names = modifiers.map((modifier) => modifier.optionName || modifier.name).filter(Boolean);
  return names.length ? names.join(', ') : '';
}

function getModifierPriceDelta(modifiers = []) {
  return modifiers.reduce((sum, modifier) => sum + Number(modifier.priceDelta ?? modifier.price_delta ?? 0), 0);
}

function ensureProductModifierModal() {
  let modal = document.querySelector('#productModifierChoiceModal');
  if (modal) return modal;
  modal = document.createElement('section');
  modal.id = 'productModifierChoiceModal';
  modal.className = 'modal hidden product-modifier-choice-modal';
  modal.setAttribute('aria-hidden', 'true');
  modal.innerHTML = `
    <div class="modal-backdrop" id="productModifierChoiceBackdrop"></div>
    <div class="modal-card product-modifier-choice-card">
      <header class="modal-header">
        <div>
          <h2 id="productModifierChoiceTitle">Opciones</h2>
          <p id="productModifierChoiceMeta">Selecciona modificadores</p>
        </div>
        <button id="closeProductModifierChoiceBtn" class="icon-btn" type="button">×</button>
      </header>
      <div id="productModifierChoiceBody" class="product-modifier-choice-body"></div>
      <div class="drawer-actions-grid product-modifier-choice-actions">
        <button id="confirmProductModifierChoiceBtn" type="button">Agregar</button>
        <button id="cancelProductModifierChoiceBtn" type="button" class="secondary">Cancelar</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#productModifierChoiceBackdrop')?.addEventListener('click', closeProductModifierModal);
  modal.querySelector('#closeProductModifierChoiceBtn')?.addEventListener('click', closeProductModifierModal);
  modal.querySelector('#cancelProductModifierChoiceBtn')?.addEventListener('click', closeProductModifierModal);
  modal.querySelector('#confirmProductModifierChoiceBtn')?.addEventListener('click', confirmProductModifierSelection);
  return modal;
}

function closeProductModifierModal() {
  const modal = document.querySelector('#productModifierChoiceModal');
  if (!modal) return;
  closeModalElement(modal);
  state.modifierChoice = { productId: null, selections: {} };
}

function openProductModifierModal(productId) {
  const product = state.products.find((item) => item.id === productId);
  const groups = getProductModifierGroups(product);
  if (!product || groups.length === 0) return false;

  state.modifierChoice = { productId, selections: {} };
  const modal = ensureProductModifierModal();
  const title = modal.querySelector('#productModifierChoiceTitle');
  const meta = modal.querySelector('#productModifierChoiceMeta');
  const body = modal.querySelector('#productModifierChoiceBody');
  if (title) title.textContent = product.name;
  if (meta) meta.textContent = `${money(product.price)} base`;
  if (body) {
    body.innerHTML = groups.map((group) => `
      <section class="product-modifier-choice-group" data-choice-group-id="${group.id}">
        <div class="product-modifier-choice-group-head">
          <strong>${escapeHtml(group.name)}</strong>
          <span>${group.is_required ? 'Obligatorio' : 'Opcional'} · ${group.allow_multiple ? 'varias' : 'una'}</span>
        </div>
        <div class="product-modifier-choice-options">
          ${group.options.map((option) => `
            <button type="button" class="product-modifier-choice-option" data-choice-group-id="${group.id}" data-choice-option-id="${option.id}">
              <span>${escapeHtml(option.name)}</span>
              <b>${Number(option.price_delta || 0) > 0 ? `+${money(option.price_delta)}` : money(0)}</b>
            </button>
          `).join('')}
        </div>
      </section>
    `).join('');

    body.querySelectorAll('[data-choice-option-id]').forEach((btn) => {
      btn.addEventListener('click', () => toggleModifierChoice(btn.dataset.choiceGroupId, btn.dataset.choiceOptionId));
    });
  }

  openModalElement(modal, { base: 2147481200 });
  requestAnimationFrame(() => bringModalToFront(modal, { base: 2147481200 }));
  return true;
}

function toggleModifierChoice(groupId, optionId) {
  const product = state.products.find((item) => item.id === state.modifierChoice.productId);
  const group = getProductModifierGroups(product).find((item) => String(item.id) === String(groupId));
  if (!group) return;

  const current = Array.isArray(state.modifierChoice.selections[groupId]) ? state.modifierChoice.selections[groupId] : [];
  if (group.allow_multiple) {
    state.modifierChoice.selections[groupId] = current.includes(optionId)
      ? current.filter((id) => id !== optionId)
      : [...current, optionId];
  } else {
    state.modifierChoice.selections[groupId] = current.includes(optionId) ? [] : [optionId];
  }

  const modal = document.querySelector('#productModifierChoiceModal');
  modal?.querySelectorAll(`[data-choice-group-id="${CSS.escape(groupId)}"][data-choice-option-id]`).forEach((btn) => {
    const selected = (state.modifierChoice.selections[groupId] || []).includes(btn.dataset.choiceOptionId);
    btn.classList.toggle('selected', selected);
  });
}

function getSelectedModifierObjects(product, selections) {
  const groups = getProductModifierGroups(product);
  const modifiers = [];
  for (const group of groups) {
    const selectedIds = Array.isArray(selections[group.id]) ? selections[group.id] : [];
    if (group.is_required && selectedIds.length === 0) {
      const error = new Error(`Selecciona ${group.name}`);
      error.userMessage = true;
      throw error;
    }
    if (!group.allow_multiple && selectedIds.length > 1) {
      const error = new Error(`Solo una opción en ${group.name}`);
      error.userMessage = true;
      throw error;
    }
    selectedIds.forEach((optionId) => {
      const option = group.options.find((item) => String(item.id) === String(optionId));
      if (!option) return;
      modifiers.push({
        groupId: group.id,
        groupName: group.name,
        optionId: option.id,
        optionName: option.name,
        priceDelta: Number(option.price_delta || 0)
      });
    });
  }
  return modifiers;
}

function confirmProductModifierSelection() {
  const product = state.products.find((item) => item.id === state.modifierChoice.productId);
  if (!product) return closeProductModifierModal();
  try {
    const modifiers = getSelectedModifierObjects(product, state.modifierChoice.selections || {});
    commitProductToOrder(product, modifiers);
    closeProductModifierModal();
  } catch (error) {
    showToast(error.message || 'Selecciona las opciones');
  }
}

function addProductToOrder(productId) {
  const product = state.products.find((item) => item.id === productId);
  if (!product) return;

  if (getProductModifierGroups(product).length > 0) {
    openProductModifierModal(productId);
    return;
  }

  commitProductToOrder(product, []);
}

function commitProductToOrder(product, modifiers = []) {
  const productId = product.id;
  if (product.category === 'MEMBERSHIP' && !state.selectedMember) {
    showToast('Selecciona o crea un miembro');
    return;
  }

  if (product.category === 'MEMBERSHIP') {
    const existingMembership = state.order.items.find((item) => item.category === 'MEMBERSHIP');
    if (existingMembership) {
      showToast('Solo puedes seleccionar una membresía');
      return;
    }

    state.order.items.push({
      lineId: getModifierLineKey(productId, []),
      productId,
      name: product.name,
      category: product.category,
      price: Number(product.price),
      quantity: 1,
      modifiers: []
    });
    renderOrder();
    return;
  }

  const unitPrice = Number((Number(product.price || 0) + getModifierPriceDelta(modifiers)).toFixed(2));
  const lineId = getModifierLineKey(productId, modifiers);
  const existing = state.order.items.find((item) => item.lineId === lineId);
  if (existing) existing.quantity += 1;
  else state.order.items.push({ lineId, productId, name: product.name, category: product.category, price: unitPrice, quantity: 1, modifiers });

  renderOrder();
}

function removeProductFromOrder(lineId) {
  const existing = state.order.items.find((item) => item.lineId === lineId || item.productId === lineId);
  if (!existing) return;

  existing.quantity -= 1;
  if (existing.quantity <= 0) {
    state.order.items = state.order.items.filter((item) => item !== existing);
  }

  if (state.order.productBonus && !state.order.items.some((item) => item.category === state.order.productBonus.category || item.productId === state.order.productBonus.productId)) {
    state.order.productBonus = null;
  }

  renderOrder();
}


function getOrderDiscountableTimeTotal() {
  const station = state.selectedStation;
  const selectedTimePrice = getOrderTimePrice();
  const promoPrice = station && selectedTimePrice ? getTimePriceWithPromotion(station, selectedTimePrice) : null;
  return promoPrice ? Number(promoPrice.finalPrice || 0) : 0;
}

function getFamilyDiscountAmount() {
  const discount = state.order.familyDiscount;
  if (!discount) return 0;
  const percent = Math.max(0, Math.min(100, Number(discount.discount_percent || discount.discountPercent || 0)));
  const base = getOrderDiscountableTimeTotal();
  return Number((base * percent / 100).toFixed(2));
}

function getFamilyDiscountCode() {
  return String(state.order.familyDiscount?.code || '').trim().toUpperCase();
}

function clearFamilyDiscount() {
  state.order.familyDiscount = null;
  const input = $('#familyDiscountCodeInput');
  if (input) input.value = '';
  renderOrder();
}

async function applyFamilyDiscountFromInput() {
  const input = $('#familyDiscountCodeInput');
  const status = $('#familyDiscountStatus');
  const code = String(input?.value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!code) {
    if (status) status.textContent = 'Escribe el código familiar.';
    input?.focus();
    return;
  }
  const discountableAmount = getOrderDiscountableTimeTotal();
  if (discountableAmount <= 0) {
    if (status) status.textContent = 'Selecciona tiempo de juego antes de aplicar el código.';
    return;
  }
  const button = $('#applyFamilyDiscountBtn');
  if (button) button.disabled = true;
  try {
    const data = await api('/stations/discount-codes/preview', {
      method: 'POST',
      body: JSON.stringify({ code, discountableAmount })
    });
    state.order.familyDiscount = data.discountCode || null;
    if (input) input.value = getFamilyDiscountCode();
    renderOrder();
  } catch (error) {
    state.order.familyDiscount = null;
    if (status) status.textContent = error.message || 'Código inválido.';
  } finally {
    if (button) button.disabled = false;
  }
}

function renderFamilyDiscountBox() {
  const box = $('#familyDiscountBox');
  const status = $('#familyDiscountStatus');
  const clearBtn = $('#clearFamilyDiscountBtn');
  const input = $('#familyDiscountCodeInput');
  if (!box) return;
  const show = state.posMode === 'station' && Boolean(state.selectedStation) && getOrderDiscountableTimeTotal() > 0;
  box.classList.toggle('hidden', !show && !state.order.familyDiscount);
  const amount = getFamilyDiscountAmount();
  if (state.order.familyDiscount && amount <= 0) state.order.familyDiscount = null;
  if (state.order.familyDiscount) {
    if (input) input.value = getFamilyDiscountCode();
    if (status) status.textContent = `${Number(state.order.familyDiscount.discount_percent || 0)}% aplicado · -${money(amount)}`;
    clearBtn?.classList.remove('hidden');
  } else {
    if (status) status.textContent = 'Aplica a tiempo de juego.';
    clearBtn?.classList.add('hidden');
  }
}

function getOrderTotal() {
  const station = state.selectedStation;
  const selectedTimePrice = getOrderTimePrice();
  const promoPrice = station && selectedTimePrice ? getTimePriceWithPromotion(station, selectedTimePrice) : null;
  const timeTotal = promoPrice ? Number(promoPrice.finalPrice || 0) : 0;
  const productTotal = state.order.items.reduce((sum, item) => sum + getOrderItemPaidQty(item) * item.price, 0);
  const tournamentTotal = (state.order.tournamentEntries || []).reduce((sum, entry) => sum + Number(entry.entryFee || 0), 0);
  const extraTotal = (state.order.extras || []).reduce((sum, extra) => sum + Number(extra.price || 0) * Number(extra.quantity || 1), 0);
  const extraControllerTotal = getExtraControllerTotal();
  const familyDiscountAmount = getFamilyDiscountAmount();
  return Number(Math.max(0, timeTotal + productTotal + tournamentTotal + extraTotal + extraControllerTotal - familyDiscountAmount).toFixed(2));
}

function getOrderItemFreeQty(item) {
  const bonus = state.order.productBonus;
  if (!bonus) return 0;
  if (bonus.productId) {
    return bonus.productId === item.productId ? Math.min(Number(item.quantity || 0), Number(bonus.quantity || 0)) : 0;
  }
  if (bonus.category !== item.category) return 0;
  const sameCategoryItems = state.order.items.filter((entry) => entry.category === bonus.category);
  let remaining = Number(bonus.quantity || 0);
  for (const entry of sameCategoryItems) {
    if (entry.productId === item.productId) return Math.min(Number(entry.quantity || 0), Math.max(0, remaining));
    remaining -= Number(entry.quantity || 0);
  }
  return 0;
}

function getOrderItemPaidQty(item) {
  return Math.max(0, Number(item.quantity || 0) - getOrderItemFreeQty(item));
}
function getActiveSessionItems(...args) {
  return window.ClubVersusStations?.getActiveSessionItems?.(...args);
}
function getActiveSessionPendingTotal(...args) {
  return window.ClubVersusStations?.getActiveSessionPendingTotal?.(...args);
}
function getActiveSessionPaidTotal(...args) {
  return window.ClubVersusStations?.getActiveSessionPaidTotal?.(...args);
}
function getActiveSessionAccountTotal(...args) {
  return window.ClubVersusStations?.getActiveSessionAccountTotal?.(...args);
}


function getExtraControllerTotal() {
  return window.ClubVersusStations?.getExtraControllerTotal?.() || 0;
}

function getExtraControllerOrderLine() {
  return window.ClubVersusStations?.getExtraControllerOrderLine?.() || null;
}

function syncExtraControllerCount() {
  return window.ClubVersusStations?.syncExtraControllerCount?.() || 0;
}

function hasNewOrderContent() {
  return state.order.gameMinutes > 0 || state.order.freeMode || state.order.items.length > 0 || (state.order.extras || []).length > 0 || (state.order.tournamentEntries || []).length > 0 || Boolean(state.order.welcomeBonus || state.order.visitReward || state.order.productBonus);
}

function updateOrderActionButtons() {
  const pending = getActiveSessionPendingTotal();
  const newTotal = getOrderTotal();
  const hasNew = hasNewOrderContent();
  const station = state.selectedStation;
  const isStation = state.posMode === 'station';
  const payBtn = $('#checkoutCashBtn');
  const saveBtn = $('#saveAccountBtn');
  const transferBtn = $('#checkoutTransferBtn');
  const changeBtn = $('#transferSessionBtn');
  const endBtn = $('#endSessionBtn');

  const hasRewardOnlyCheckout = state.order.items.length > 0 && newTotal <= 0 && Boolean(state.order.productBonus);
  if (payBtn) {
    payBtn.textContent = hasRewardOnlyCheckout ? 'Completar canje' : (!hasNew && pending > 0 ? 'Pagar cuenta' : 'Pagar ahora');
    payBtn.disabled = isStation ? (!hasNew && pending <= 0) : (newTotal <= 0 && !hasRewardOnlyCheckout);
  }
  if (saveBtn) {
    saveBtn.classList.toggle('hidden', !isStation);
    saveBtn.disabled = !hasNew || Boolean(state.order.familyDiscount);
    saveBtn.title = state.order.familyDiscount ? 'El código familiar debe pagarse ahora para quedar registrado.' : '';
  }
  if (transferBtn) transferBtn.classList.add('hidden');
  if (changeBtn) {
    const canShowChange = isStation && station?.status === 'BUSY';
    changeBtn.classList.toggle('hidden', !canShowChange);
    changeBtn.disabled = !canShowChange || hasNew || pending > 0 || window.ClubVersusStations?.isStationOpenMode?.(station);
    changeBtn.title = hasNew
      ? 'Termina o elimina lo nuevo antes de cambiar de estación.'
      : (pending > 0 ? 'Cobra o guarda el balance pendiente antes de cambiar.' : (window.ClubVersusStations?.isStationOpenMode?.(station) ? 'Modo libre: detén y cobra antes de cambiar.' : 'Mover esta sesión a otra estación disponible.'));
  }
  if (endBtn) endBtn.classList.toggle('hidden', !(isStation && station?.status === 'BUSY'));
}

function getCurrentOrderPayload() {
  return {
    memberId: state.selectedMember?.id || null,
    gameMinutes: state.order.freeMode ? 0 : state.order.gameMinutes,
    playerCount: state.order.playerCount,
    gameId: state.order.gameId || null,
    freeMode: Boolean(state.order.freeMode),
    gamePriceId: state.order.gamePriceId || null,
    welcomeBonusId: state.order.welcomeBonus?.id || null,
    visitRewardId: state.order.visitReward?.id || state.order.productBonus?.id || null,
    rewardMinutesRequested: state.order.visitReward?.minutes || 0,
    rewardSnackQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'SNACK' ? Number(state.order.productBonus.quantity || 0) : 0,
    rewardDrinkQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'DRINK' ? Number(state.order.productBonus.quantity || 0) : 0,
    rewardProductId: state.order.productBonus?.productId || null,
    rewardProductQty: state.order.productBonus?.productId ? Number(state.order.productBonus.quantity || 0) : 0,
    items: state.order.items.map((item) => ({ productId: item.productId, quantity: item.quantity, modifierOptionIds: (item.modifiers || []).map((modifier) => modifier.optionId) })),
    extras: (state.order.extras || []).map((extra) => ({ extraId: extra.id, quantity: extra.quantity })),
    extraControllerCount: syncExtraControllerCount(),
    kidsCourtesyExtensionMinutes: state.order.kidsCourtesyExtension ? getKidsCourtesyExtensionMinutes() : 0,
    familyDiscountCode: getFamilyDiscountCode(),
    tournamentEntries: (state.order.tournamentEntries || []).map((entry) => ({
      tournamentId: entry.tournamentId,
      participantId: entry.participantId || null,
      playerName: entry.playerName || '',
      phone: entry.phone || '',
      nickname: entry.nickname || '',
      memberId: entry.memberId || null
    }))
  };
}


function getKidsCourtesySettings() {
  return state.kidsCourtesySettings || { enabled: false, consoleType: 'Nintendo Switch', baseMinutes: 15, extensionMinutes: 5, label: 'Extensión niños' };
}

function getKidsCourtesyExtensionMinutes() {
  const settings = getKidsCourtesySettings();
  return Math.max(0, Number(settings.extensionMinutes ?? settings.extension_minutes ?? 5));
}

function renderOrder() {
  const box = $('#orderItems');
  const station = state.selectedStation;
  const rows = [];
  const persistedItems = state.posMode === 'station' ? getActiveSessionItems(station) : [];

  persistedItems.forEach((item) => {
    const status = item.payment_status === 'PAID' ? 'Pagado' : 'Pendiente';
    const statusClass = item.payment_status === 'PAID' ? 'paid' : 'pending';
    rows.push(`
      <div class="order-row saved-order-row ${statusClass}">
        <span>${item.description}<small>${Number(item.quantity || 1)} x ${money(item.unit_price || 0)}</small></span>
        <strong>${money(item.total || 0)}<small class="line-status-pill ${statusClass}">${status}</small></strong>
      </div>
    `);
  });

  if (station && state.order.freeMode) {
    rows.push(`
      <div class="order-row new-order-row">
        <span>Modo libre<small>${getPlayerCountLabel(state.order.playerCount)} · cobrar al final</small></span>
        <strong>${money(0)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  if (station && state.order.gameMinutes > 0) {
    const selectedTimePrice = getOrderTimePrice();
    const promoPrice = selectedTimePrice ? getTimePriceWithPromotion(station, selectedTimePrice) : null;
    const price = promoPrice ? Number(promoPrice.finalPrice || 0) : 0;
    rows.push(`
      <div class="order-row new-order-row ${promoPrice?.promotion ? 'promo-order-row' : ''}">
        <span>Tiempo · ${selectedTimePrice?.label || `${state.order.gameMinutes} min`}<small>${getPlayerCountLabel(state.order.playerCount)}</small>${selectedTimePrice?.member_price ? `<small>${getMembershipLabel(selectedTimePrice.membership_tier)}</small>` : ''}${promoPrice?.promotion ? `<small>${promoPrice.promotion.name}</small>` : ''}</span>
        <strong>${promoPrice?.promotion ? `<em>${money(promoPrice.basePrice)}</em>` : ''}${money(price)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  const extraControllerLine = getExtraControllerOrderLine();
  if (extraControllerLine) {
    rows.push(`
      <div class="order-row new-order-row extra-order-row">
        <span>Control extra Nintendo<small>${extraControllerLine.count} x ${money(extraControllerLine.unitPrice)} · ${extraControllerLine.totalPlayers} jugadores</small></span>
        <strong>${money(extraControllerLine.total)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  const familyDiscountAmount = getFamilyDiscountAmount();
  if (state.order.familyDiscount && familyDiscountAmount > 0) {
    rows.push(`
      <div class="order-row new-order-row family-discount-order-row">
        <span>Descuento familiar<small>${escapeHtml(getFamilyDiscountCode())} · ${Number(state.order.familyDiscount.discount_percent || 0)}%</small></span>
        <strong>-${money(familyDiscountAmount)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  if (state.order.welcomeBonus) {
    rows.push(`
      <div class="order-row product-order-row bonus-order-row">
        <button type="button" data-remove-bonus>−</button>
        <span>Bono bienvenida · ${state.order.welcomeBonus.minutes} min</span>
        <strong>${money(0)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  if (state.order.visitReward) {
    rows.push(`
      <div class="order-row product-order-row reward-order-row">
        <button type="button" data-remove-reward>−</button>
        <span>Bono minutos · ${state.order.visitReward.minutes} min</span>
        <strong>${money(0)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  }

  (state.order.tournamentEntries || []).forEach((entry) => {
    rows.push(`
      <div class="order-row product-order-row tournament-order-row new-order-row">
        <button type="button" data-remove-tournament-entry="${entry.lineId}">−</button>
        <span>Inscripción torneo · ${escapeHtml(entry.playerName || 'Participante')}<small>${escapeHtml(entry.tournamentName || 'Torneo')}</small></span>
        <strong>${money(entry.entryFee || 0)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  });

  (state.order.extras || []).forEach((extra) => {
    const total = Number(extra.price || 0) * Number(extra.quantity || 1);
    rows.push(`
      <div class="order-row product-order-row extra-order-row new-order-row">
        <button type="button" data-remove-extra="${escapeAttr(extra.id)}">−</button>
        <span>Extra · ${escapeHtml(extra.name)}<small>${Number(extra.quantity || 1)} x ${money(extra.price || 0)}</small></span>
        <strong>${money(total)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  });


  if (state.order.kidsCourtesyExtension && Number(state.order.gameMinutes || 0) > 0) {
    rows.push(`
      <div class="order-row courtesy-extension-row">
        <span>${escapeHtml(getKidsCourtesySettings().label || 'Extensión niños')}<small>+${getKidsCourtesyExtensionMinutes()} min cortesía</small></span>
        <strong>RD$0</strong>
      </div>
    `);
  }

  state.order.items.forEach((item) => {
    const freeQty = getOrderItemFreeQty(item);
    const paidQty = getOrderItemPaidQty(item);
    const modifierText = getModifierDescription(item.modifiers || []);
    const modifierSmall = modifierText ? `<small>${escapeHtml(modifierText)}</small>` : '';
    const freeText = freeQty > 0 ? `<small>${freeQty} por bono · ${paidQty} pagado(s)</small>` : '';
    rows.push(`
      <div class="order-row product-order-row new-order-row ${freeQty > 0 ? 'reward-order-row' : ''}">
        <button type="button" data-remove-product="${item.lineId || item.productId}">−</button>
        <span>${item.quantity} x ${escapeHtml(item.name)}${modifierSmall}${freeText}</span>
        <strong>${freeQty > 0 ? `<em>${money(item.price * item.quantity)}</em>` : ''}${money(item.price * paidQty)}<small class="line-status-pill new">Nuevo</small></strong>
      </div>
    `);
  });

  if (rows.length === 0) {
    box.className = 'order-items empty';
    box.textContent = 'Sin artículos';
  } else {
    box.className = 'order-items';
    box.innerHTML = rows.join('');
    box.querySelectorAll('[data-remove-product]').forEach((btn) => {
      btn.addEventListener('click', () => removeProductFromOrder(btn.dataset.removeProduct));
    });
    box.querySelectorAll('[data-remove-extra]').forEach((btn) => {
      btn.addEventListener('click', () => removeStationExtraFromOrder(btn.dataset.removeExtra));
    });
    box.querySelectorAll('[data-remove-tournament-entry]').forEach((btn) => {
      btn.addEventListener('click', () => removeTournamentEntryFromOrder(btn.dataset.removeTournamentEntry));
    });

    const bonusBtn = box.querySelector('[data-remove-bonus]');
    if (bonusBtn) {
      bonusBtn.addEventListener('click', () => {
        state.order.welcomeBonus = null;
        renderOrder();
      });
    }

    const rewardBtn = box.querySelector('[data-remove-reward]');
    if (rewardBtn) {
      rewardBtn.addEventListener('click', () => {
        state.order.visitReward = null;
        renderOrder();
      });
    }
  }

  renderFamilyDiscountBox();

  const paid = getActiveSessionPaidTotal();
  const pending = getActiveSessionPendingTotal();
  const newTotal = getOrderTotal();
  const total = paid + pending + newTotal;
  setText('#orderPaidTotal', money(paid));
  setText('#orderPendingTotal', money(pending));
  setText('#orderNewTotal', money(newTotal));
  $('#orderTotal').textContent = money(total);
  updateOrderActionButtons();
}
async function checkoutStation(...args) {
  return window.ClubVersusStations?.checkoutStation?.(...args);
}
async function saveStationAccount(...args) {
  return window.ClubVersusStations?.saveStationAccount?.(...args);
}
async function awaitEndSession(...args) {
  return window.ClubVersusStations?.awaitEndSession?.(...args);
}
async function endSelectedSession(...args) {
  return window.ClubVersusStations?.endSelectedSession?.(...args);
}





let paymentFlowModule = null;

  window.ClubVersusModules.order = {
    resetOrder,
    setSelectedMember,
    renderMemberSelection,
    applyWelcomeBonus,
    applyVisitReward,
    applyProductReward,
    applyExactProductReward,
    openMemberPicker,
    closeMemberPicker,
    openStationModal,
    openQuickOrderModal,
    closeStationModal,
    getGeneralStationTimePrices,
    getStationTimePrices,
    findConfiguredStationTimePrice,
    buildFallbackTimePrice,
    getOrderTimePriceForMinutes,
    normalizeDateOnly,
    promotionAppliesNow,
    applyPromotionToTimePrice,
    getBestActivePromotion,
    getTimePriceWithPromotion,
    getOrderTimePrice,
    isStationOpenMode,
    getOpenModeHourlyRate,
    getOpenModeElapsedMs,
    getOpenModeElapsedMinutes,
    getOpenModeChargePreview,
    renderTimeOptions,
    activateFreeMode,
    renderMenuCategoryTabs,
    getProductDisplayPrice,
    loadPosTournaments,
    isTodayTournament,
    isClosedFinishedTournament,
    getVisiblePosTournaments,
    getPrimaryPosTournament,
    getTournamentEntryFee,
    getPendingTournamentParticipants,
    getTournamentEntryLineId,
    addTournamentEntryToOrder,
    removeTournamentEntryFromOrder,
    getTournamentEntryDiscountPreview,
    updateTournamentEntryModalTotals,
    forceTournamentEntryModalLayout,
    openTournamentEntryModal,
    closeTournamentEntryModal,
    searchTournamentEntryMembers,
    buildTournamentEntryFromModal,
    submitTournamentEntry,
    promptNewTournamentEntry,
    isTournamentAwardPending,
    getTournamentAwardPrizeParts,
    closeTournamentAwardsDeliveryModal,
    renderTournamentAwardsDeliveryModal,
    refreshTournamentAwardsDelivery,
    openTournamentAwardsDelivery,
    setTournamentAwardsDeliveryBusy,
    setTournamentAwardsDeliveryStatus,
    finishTournamentAwardDelivery,
    deliverTournamentAwardFromPos,
    deliverAllTournamentAwardsFromPos,
    bindTournamentAwardsDeliveryDelegatedClicks,
    startPosVersus,
    closePosVersus,
    isTournamentFullForSale,
    getTournamentCapacityLabel,
    renderTournamentDayPanel,
    renderTournamentPosProducts,
    renderModalProducts,
    renderStationExtrasOptions,
    addStationExtraToOrder,
    removeStationExtraFromOrder,
    getProductModifierGroups,
    getModifierLineKey,
    getModifierDescription,
    getModifierPriceDelta,
    ensureProductModifierModal,
    closeProductModifierModal,
    openProductModifierModal,
    toggleModifierChoice,
    getSelectedModifierObjects,
    confirmProductModifierSelection,
    addProductToOrder,
    commitProductToOrder,
    removeProductFromOrder,
    getOrderTotal,
    getFamilyDiscountAmount,
    getFamilyDiscountCode,
    clearFamilyDiscount,
    applyFamilyDiscountFromInput,
    getOrderItemFreeQty,
    getOrderItemPaidQty,
    getActiveSessionItems,
    getActiveSessionPendingTotal,
    getActiveSessionPaidTotal,
    getActiveSessionAccountTotal,
    hasNewOrderContent,
    updateOrderActionButtons,
    getCurrentOrderPayload,
    renderOrder,
    checkoutStation,
    saveStationAccount,
    awaitEndSession,
    endSelectedSession
  };
})();
