const state = {
  token: localStorage.getItem('cv_token'),
  user: JSON.parse(localStorage.getItem('cv_user') || 'null'),
  pinBuffer: '',
  posAccess: { checked: false, enabled: true, authorized: false, reason: '' },
  stations: [],
  products: [],
  posCategories: [],
  inventoryProducts: [],
  inventorySummary: {},
  modifierGroups: [],
  selectedModifierGroupId: null,
  selectedModifierOptionId: null,
  selectedInventoryProductId: null,
  selectedPosCategoryCode: null,
  members: [],
  employees: [],
  permissionOptions: [],
  selectedPermissionUserId: null,
  timePrices: [],
  groupEventPrices: [],
  stationExtras: [],
  stationGames: [],
  gameStorageDevices: [],
  gameReservations: [],
  gameReservationMember: null,
  gameReservationPriority: { level: 0, label: 'Normal', note: 'Se actualiza si escaneas un miembro con beneficios.' },
  selectedStationGameId: null,
  selectedGameDeviceId: null,
  selectedStationExtraId: null,
  promotions: [],
  bonusRules: [],
  memberTimePrices: [],
  membershipPlans: [],
  selectedMembershipPlanCode: null,
  tournaments: [],
  selectedTournamentId: null,
  selectedTournament: null,
  tournamentParticipants: [],
  tournamentMatches: [],
  tournamentPrizeConfigs: [],
  tournamentAwards: [],
  tournamentManualPairings: [],
  tournamentRanking: [],
  tournamentRankingLabel: 'Este mes',
  tournamentMemberResults: [],
  selectedTournamentMember: null,
  posTournaments: [],
  posTournamentParticipants: [],
  tournamentEntryDiscounts: [],
  tournamentEntryModal: { tournamentId: null, selectedMember: null },
  tournamentAwardsDelivery: { tournamentId: null, awards: [], tournament: null },
  activeVersus: null,
  manualBonusMember: null,
  selectedTimePriceScope: { type: 'console', id: 'PlayStation 4' },
  selectedPromotionId: null,
  selectedStationConfigId: null,
  timeAlertedSessions: new Set(),
  timeWarningStationId: null,
  drawer: null,
  appSettings: { drawerWorkflowEnabled: true },
  dailySummary: { sales: {}, sessions: {}, range: {}, drawer: null, dailySales: [], stationSales: [], categorySales: [], topProducts: [], cashierSales: [], transfers: [], bonuses: {}, memberships: [], openAccounts: [], pendingAccounts: {}, closedSessions: [], employeeSummary: { totals: {}, employees: [] } },
  reportRange: { preset: 'today', startDate: '', endDate: '' },
  auditFilters: { userId: '', eventType: '', stationId: '', limit: '100' },
  auditEvents: [],
  financeRange: { preset: 'month', startDate: '', endDate: '' },
  payroll: { totals: {}, employees: [], templates: [], shifts: [], rules: [], payments: [], range: {} },
  payrollShowOwners: false,
  denominationMode: null,
  logoutAfterDrawerClose: false,
  activeMenuCategory: 'TIME',
  activeMainSection: 'stations',
  posMode: 'station',
  selectedStation: null,
  selectedMember: null,
  pendingEndSession: false,
  pendingAccountPayment: false,
  closeAfterPendingPayment: false,
  cashOtherAmountMode: false,
  cashSelectedAmount: null,
  paymentFlowContext: null,
  customPaymentFlow: null,
  modifierChoice: { productId: null, selections: {} },
  scannerBuffer: '',
  scannerTimer: null,
  scannerStartedAt: null,
  scannerLastKeyAt: null,
  scannerTarget: null,
  lastScannedCode: '',
  order: {
    gameMinutes: 0,
    gamePriceId: null,
    freeMode: false,
    playerCount: 1,
    extraControllerCount: 0,
    familyDiscount: null,
    welcomeBonus: null,
    visitReward: null,
    items: []
  }
};

const $ = (selector) => document.querySelector(selector);
const money = (value) => `RD$${Number(value || 0).toFixed(2)}`;
const escapeAttr = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escapeHtml = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const formatTime = (value) => {
  if (!value) return '';
  return new Date(value).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
};

const parseAppDate = (value) => {
  if (!value) return null;
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;

  const raw = String(value).trim();
  if (!raw) return null;

  const dateTimeLocal = raw.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (dateTimeLocal) {
    const date = new Date(
      Number(dateTimeLocal[1]),
      Number(dateTimeLocal[2]) - 1,
      Number(dateTimeLocal[3]),
      Number(dateTimeLocal[4]),
      Number(dateTimeLocal[5]),
      Number(dateTimeLocal[6] || 0)
    );
    return Number.isNaN(date.getTime()) ? null : date;
  }

  const dateOnly = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateOnly) {
    const date = new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]));
    return Number.isNaN(date.getTime()) ? null : date;
  }

  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
};

const formatBirthDate = (value) => {
  const date = parseAppDate(value);
  if (!date) return 'Sin fecha';

  return date.toLocaleDateString('es-DO', {
    day: '2-digit',
    month: 'short'
  });
};









const timePackages = [
  { label: '15 min', minutes: 15 },
  { label: '30 min', minutes: 30 },
  { label: '1 hora', minutes: 60 },
  { label: '2 horas', minutes: 120 },
  { label: '3 horas', minutes: 180 }
];

const timePlayerOptions = [
  { value: 1, label: '1 jugador' },
  { value: 2, label: '2 jugadores' }
];

const priceConsoleTypes = ['PlayStation 4', 'PlayStation 5', 'Xbox One', 'Xbox Series', 'Nintendo Switch'];
const defaultMembershipTierOptions = [
  { id: 'GAMER', label: 'Gamer', color: '#2563eb', is_active: true, show_in_pos: true, sort_order: 10 },
  { id: 'GAMER_PRO', label: 'Gamer Pro', color: '#ef4444', is_active: true, show_in_pos: true, sort_order: 20 },
  { id: 'CHAMPION', label: 'Champion', color: '#facc15', is_active: true, show_in_pos: true, sort_order: 30 }
];

function getMembershipTierOptions(includeInactive = false) {
  const source = state.membershipPlans?.length
    ? state.membershipPlans.map((plan) => ({
        id: plan.code,
        label: plan.name,
        color: plan.color,
        is_active: plan.is_active,
        show_in_pos: plan.show_in_pos,
        archived_at: plan.archived_at,
        sort_order: plan.sort_order
      }))
    : defaultMembershipTierOptions;
  return source
    .filter((plan) => includeInactive || (plan.is_active !== false && !plan.archived_at))
    .sort((a, b) => Number(a.sort_order || 100) - Number(b.sort_order || 100) || String(a.label || '').localeCompare(String(b.label || '')));
}
const defaultProductCategories = [
  { code: 'DRINK', name: 'Bebidas', color: '#2563eb', sort_order: 10, button_size: 'normal', is_active: true, show_in_station: true, show_in_quick: true, show_in_bonuses: true, is_membership: false },
  { code: 'SNACK', name: 'Snacks', color: '#f97316', sort_order: 20, button_size: 'normal', is_active: true, show_in_station: true, show_in_quick: true, show_in_bonuses: true, is_membership: false },
  { code: 'COMBO', name: 'Combos', color: '#16a34a', sort_order: 30, button_size: 'normal', is_active: true, show_in_station: true, show_in_quick: true, show_in_bonuses: true, is_membership: false },
  { code: 'MEMBERSHIP', name: 'Membresías', color: '#facc15', sort_order: 40, button_size: 'normal', is_active: true, show_in_station: true, show_in_quick: true, show_in_bonuses: false, is_membership: true }
];

function getProductCategories() {
  const source = state.posCategories?.length ? state.posCategories : defaultProductCategories;
  return [...source].sort((a, b) => Number(a.sort_order || 100) - Number(b.sort_order || 100) || String(a.name || '').localeCompare(String(b.name || '')));
}

function isProtectedPosCategory(categoryOrCode) {
  if (!categoryOrCode) return false;
  if (typeof categoryOrCode === 'string') return categoryOrCode === 'MEMBERSHIP';
  return categoryOrCode.code === 'MEMBERSHIP' || categoryOrCode.is_membership === true;
}
function getStationMenuCategories(...args) {
  return window.ClubVersusStations?.getStationMenuCategories?.(...args);
}

function getQuickOrderCategories() {
  return window.ClubVersusQuickSale?.getQuickOrderCategories?.() || [];
}

function getFirstQuickOrderCategory() {
  return window.ClubVersusQuickSale?.getFirstQuickOrderCategory?.() || 'DRINK';
}

const menuCategories = [
  { id: 'ALL', label: 'Todo' },
  { id: 'TIME', label: 'Horas' },
  ...defaultProductCategories.map((category) => ({ id: category.code, label: category.name }))
];

const drawerDenominations = {
  bills: [2000, 1000, 500, 200, 100, 50],
  coins: [25, 10, 5, 1]
};

function getCategoryLabel(category = '') {
  const foundDynamic = getProductCategories().find((item) => item.code === category);
  if (foundDynamic) return foundDynamic.name;
  const found = menuCategories.find((item) => item.id === category);
  if (found) return found.label;
  if (category === 'PRODUCT') return 'Producto';
  return category || 'Producto';
}

function getRoleLabel(role = '') {
  if (role === 'OWNER') return 'Owner';
  if (role === 'MANAGER') return 'Manager';
  if (role === 'CASHIER') return 'Cajero';
  return role || 'Usuario';
}

function getMembershipLabel(tier = '') {
  const plan = getMembershipTierOptions(true).find((item) => item.id === tier);
  if (plan) return plan.label;
  if (tier === 'GAMER') return 'Gamer';
  if (tier === 'GAMER_PRO') return 'Gamer Pro';
  if (tier === 'CHAMPION') return 'Champion';
  return tier ? String(tier).replace(/_/g, ' ') : 'General';
}

function getTournamentStatusLabel(status = '') {
  if (status === 'SCHEDULED') return 'Programado';
  if (status === 'ACTIVE') return 'En curso';
  if (status === 'FINISHED') return 'Finalizado';
  if (status === 'CANCELLED') return 'Cancelado';
  return status || 'Programado';
}

function formatDateTimeLocal(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const pad = (part) => String(part).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function formatTournamentDate(value) {
  const date = parseAppDate(value);
  if (!date) return 'Sin fecha';
  return date.toLocaleString('es-DO', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit' });
}


function getPlayerCountLabel(playerCount = 1) {
  return Number(playerCount) === 2 ? '2 jugadores' : '1 jugador';
}

function normalizePlayerCount(value) {
  return Number(value) === 2 ? 2 : 1;
}

function hasWelcomeBonus(member) {
  return Boolean(member?.welcome_bonus_id && Number(member?.welcome_bonus_minutes || 0) > 0);
}

function getRewardMinutes(member) {
  return Math.max(0, Number(member?.visit_reward_minutes || 0) - Number(member?.visit_reward_minutes_used || 0));
}

function getRewardSnackQty(member) {
  return Math.max(0, Number(member?.visit_reward_snack_qty || 0) - Number(member?.visit_reward_snack_used || 0));
}

function getRewardDrinkQty(member) {
  return Math.max(0, Number(member?.visit_reward_drink_qty || 0) - Number(member?.visit_reward_drink_used || 0));
}

function getRewardProductQty(member) {
  return Math.max(0, Number(member?.visit_reward_product_qty || 0) - Number(member?.visit_reward_product_used || 0));
}

function getRewardProduct(member) {
  if (!member?.visit_reward_product_id) return null;
  const product = state.products.find((item) => item.id === member.visit_reward_product_id);
  return product || {
    id: member.visit_reward_product_id,
    name: member.visit_reward_product_name || 'Producto / servicio',
    category: member.visit_reward_product_category || '',
    price: 0
  };
}

function hasVisitReward(member) {
  return Boolean(member?.visit_reward_id && (
    getRewardMinutes(member) > 0
    || getRewardSnackQty(member) > 0
    || getRewardDrinkQty(member) > 0
    || getRewardProductQty(member) > 0
  ));
}

function getRewardLabel(type = '') {
  if (type === 'VISIT_REWARD') return 'Recompensa';
  return 'Bono';
}

function getVisitsUntilReward(member) {
  return Number(member?.visits_until_reward ?? 0);
}

function formatDateTime(value) {
  const date = parseAppDate(value);
  if (!date) return '';
  return date.toLocaleDateString('es-DO', {
    day: '2-digit',
    month: 'short'
  });
}

function getMembershipKey(tier = '') {
  if (tier === 'GAMER_PRO') return 'gamer-pro';
  if (tier === 'CHAMPION') return 'champion';
  if (tier === 'GAMER') return 'gamer';
  return tier ? 'custom' : 'general';
}

function getMembershipShortCode(tier = '') {
  if (tier === 'GAMER_PRO') return 'P';
  if (tier === 'CHAMPION') return 'C';
  if (tier === 'GAMER') return 'G';
  return tier ? String(tier).replace(/[^A-Z0-9]/g, '').slice(0, 2) || 'M' : 'GE';
}

function getMemberDisplayCode(member) {
  if (!member?.id) return 'CV-GE';
  const shortId = String(member.id).replace(/-/g, '').slice(0, 6).toUpperCase();
  return `CV-${getMembershipShortCode(member.membership_tier)}-${shortId}`;
}

function getMembershipArt(tier = '') {
  const key = getMembershipKey(tier);
  return `/assets/memberships/${key}.svg`;
}
function getStationMembershipLogo(...args) {
  return window.ClubVersusStations?.getStationMembershipLogo?.(...args);
}
function getStationMembershipMarkup(...args) {
  return window.ClubVersusStations?.getStationMembershipMarkup?.(...args);
}

function hasPermission(permission) {
  if (!permission) return true;
  if (state.user?.role === 'OWNER') return true;
  return Array.isArray(state.user?.permissions) && state.user.permissions.includes(permission);
}

function requirePermission(permission) {
  if (hasPermission(permission)) return true;
  showToast('No tienes permiso');
  return false;
}

function applyPermissionUI() {
  document.querySelectorAll('[data-permission]').forEach((el) => {
    const allowed = hasPermission(el.dataset.permission);
    el.classList.toggle('locked', !allowed);
    el.disabled = !allowed;
  });

  document.querySelectorAll('[data-admin-only]').forEach((el) => {
    const allowed = state.user?.role === 'OWNER' || state.user?.role === 'MANAGER';
    el.classList.toggle('hidden', !allowed);
    el.disabled = !allowed;
  });

  if ($('#openDrawerBtn')) $('#openDrawerBtn').disabled = !hasPermission('drawer');
  if ($('#topDrawerBtn')) $('#topDrawerBtn').disabled = !hasPermission('drawer');
}


async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
      ...(localStorage.getItem('cv_pos_access_token') ? { 'X-POS-Access-Token': localStorage.getItem('cv_pos_access_token') } : {}),
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || data.message || 'Request failed');
    if (data && typeof data === 'object') Object.assign(error, data);
    throw error;
  }
  return data;
}

function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.add('hidden'), 3200);
}

function registerCoreGlobals() {
  window.state = state;
  window.api = api;
  window.showToast = showToast;
  window.money = money;
  window.escapeHtml = escapeHtml;
  window.escapeAttr = escapeAttr;
  window.parseAppDate = parseAppDate;
  window.formatTime = formatTime;
  window.formatDateTime = formatDateTime;
  window.getRoleLabel = getRoleLabel;
  window.getCategoryLabel = getCategoryLabel;
  window.hasPermission = hasPermission;
  window.requirePermission = requirePermission;
  window.applyPermissionUI = applyPermissionUI;
  window.requireOpenDrawerForSales = requireOpenDrawerForSales;

  window.ClubVersusCore = window.ClubVersusCore || {};
  window.ClubVersusCore.state = window.ClubVersusCore.state || {};
  if (typeof window.ClubVersusCore.state.setRef === 'function') window.ClubVersusCore.state.setRef(state);
  else window.ClubVersusCore.state.ref = state;
  window.ClubVersusCore.api = window.ClubVersusCore.api || {};
  window.ClubVersusCore.api.request = api;
}

registerCoreGlobals();

function showTransferPaymentError(message) {
  const box = $('#transferPaymentError');
  if (!box) {
    showToast(message);
    return;
  }
  box.textContent = message;
  box.classList.remove('hidden');
}

function clearTransferPaymentError() {
  const box = $('#transferPaymentError');
  if (!box) return;
  box.textContent = '';
  box.classList.add('hidden');
}

function bringModalToFront(modal, options = {}) {
  return window.ClubVersusCore?.modalManager?.bringToFront?.(modal, options);
}

function openModalElement(modal, options = {}) {
  return window.ClubVersusCore?.modalManager?.open?.(modal, options);
}

function closeModalElement(modal) {
  return window.ClubVersusCore?.modalManager?.close?.(modal);
}

function isDrawerWorkflowEnabled() {
  return state.appSettings?.drawerWorkflowEnabled !== false;
}

async function promptOpenDrawerIfRequired() {
  if (!state.token || !isDrawerWorkflowEnabled() || state.drawer) return false;

  showToast('Debes abrir la caja antes de iniciar ventas.');

  if (hasPermission('drawer') && typeof openDenominationCounter === 'function') {
    // Abrir directo el conteo inicial después de cargar el estado real de la caja.
    setTimeout(() => openDenominationCounter('open'), 80);
  }

  return true;
}

function requireOpenDrawerForSales(openDrawer = true) {
  if (!isDrawerWorkflowEnabled()) return true;
  if (state.drawer) return true;
  showToast('Debes abrir la caja antes de iniciar ventas.');
  if (openDrawer && hasPermission('drawer') && typeof openDenominationCounter === 'function') openDenominationCounter('open');
  return false;
}


window.isDrawerWorkflowEnabled = isDrawerWorkflowEnabled;
window.promptOpenDrawerIfRequired = promptOpenDrawerIfRequired;

// Sesión, login/logout y PIN movidos a public/js/modules/auth-session.js en v2.0.6.7.
function setView(...args) { return window.ClubVersusModules.authSession.setView(...args); }
function updatePinUI(...args) { return window.ClubVersusModules.authSession.updatePinUI(...args); }
function addDigit(...args) { return window.ClubVersusModules.authSession.addDigit(...args); }
function clearPin(...args) { return window.ClubVersusModules.authSession.clearPin(...args); }
function backspacePin(...args) { return window.ClubVersusModules.authSession.backspacePin(...args); }
async function login(...args) { return window.ClubVersusModules.authSession.login(...args); }
function forceCloseAllOverlaysForLogout(...args) { return window.ClubVersusModules.authSession.forceCloseAllOverlaysForLogout(...args); }
async function closeCurrentEmployeeSection(...args) { return window.ClubVersusModules.authSession.closeCurrentEmployeeSection(...args); }
function performLogout(...args) { return window.ClubVersusModules.authSession.performLogout(...args); }
async function lockEmployeeSection(...args) { return window.ClubVersusModules.authSession.lockEmployeeSection(...args); }
function checkPosAccess(...args) { return window.ClubVersusModules.authSession.checkPosAccess(...args); }
function verifyPosAccess(...args) { return window.ClubVersusModules.authSession.verifyPosAccess(...args); }
async function logout(...args) { return window.ClubVersusModules.authSession.logout(...args); }

async function loadAll() {
  const tasks = [
    ['categorías', loadProductCategories],
    ['precios', loadTimePrices],
    ['extensión infantil', () => window.ClubVersusModules?.prices?.loadKidsCourtesySettings?.() || Promise.resolve()],
    ['precios grupos/eventos', loadGroupEventPrices],
    ['extras estaciones', loadStationExtras],
    ['juegos estaciones', loadStationGames],
    ['dispositivos juegos', loadGameStorageDevices],
    ['reservas juegos', () => window.ClubVersusStations?.loadGameReservations?.() || Promise.resolve()],
    ['avisos pendientes', () => window.ClubVersusStations?.loadPendingNotices?.({ silent: true }) || Promise.resolve()],
    ['descuentos', loadPromotions],
    ['bonos', loadBonusRules],
    ['planes membresía', loadMembershipPlans],
    ['precios miembros', loadMemberTimePrices],
    ['torneos POS', loadPosTournaments],
    ['estaciones', loadStations],
    ['productos', loadProducts],
    ['modificadores', loadModifierGroups],
    ['reportes', loadReports],
    ['configuración', loadAppSettings],
    ['rifas operativas', () => window.ClubVersusModules?.raffles?.loadOperationalRaffles?.() || Promise.resolve()],
    ['caja', loadDrawer]
  ];

  for (const [label, task] of tasks) {
    try {
      await task();
    } catch (error) {
      console.error(`Error cargando ${label}:`, error);
      const message = error?.message || `No se pudo cargar ${label}`;
      const permissionDenied = /no tienes permiso/i.test(message);
      if (!permissionDenied) {
        showToast(message);
      }
    }
  }
}

function getConsoleClass(consoleType = '') {
  const value = consoleType.toLowerCase();
  if (value.includes('nintendo') || value.includes('switch')) return 'console-switch';
  if (value.includes('xbox')) return 'console-xbox';
  if (value.includes('ps5') || value.includes('playstation 5')) return 'console-ps5';
  if (value.includes('ps4') || value.includes('playstation')) return 'console-ps4';
  return 'console-default';
}

function getConsoleShortName(consoleType = '') {
  const value = consoleType.toLowerCase();
  if (value.includes('nintendo') || value.includes('switch')) return 'NS';
  if (value.includes('xbox')) return 'XB';
  if (value.includes('ps5') || value.includes('playstation 5')) return 'PS5';
  if (value.includes('ps4') || value.includes('playstation')) return 'PS4';
  return 'VS';
}

function getPlatform(consoleType = '') {
  const value = consoleType.toLowerCase();
  if (value.includes('nintendo') || value.includes('switch')) return 'Nintendo';
  if (value.includes('xbox')) return 'Xbox';
  return 'PlayStation';
}

function getPlatformModels(platform = 'PlayStation') {
  if (platform === 'Xbox') return ['Xbox One', 'Xbox Series'];
  if (platform === 'Nintendo') return ['Nintendo Switch'];
  return ['PlayStation 4', 'PlayStation 5'];
}

function getConsoleLogo(consoleType = '') {
  const platform = getPlatform(consoleType);
  if (platform === 'Xbox') return '<span class="console-mark xbox-mark">X</span>';
  if (platform === 'Nintendo') return '<span class="console-mark nintendo-mark"><span></span><span></span></span>';
  return '<span class="console-mark playstation-mark"><span>△</span><span>○</span><span>×</span><span>□</span></span>';
}
function canManageStations(...args) {
  return window.ClubVersusStations?.canManageStations?.(...args);
}
function getSessionRemainingMs(...args) {
  return window.ClubVersusStations?.getSessionRemainingMs?.(...args);
}

function formatDuration(ms) {
  const totalSeconds = Math.max(0, Math.floor(Number(ms || 0) / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((part) => String(part).padStart(2, '0')).join(':');
}
function getStationTimeState(...args) {
  return window.ClubVersusStations?.getStationTimeState?.(...args);
}

function getStatusLabel(status) {
  if (status === 'AVAILABLE') return 'DISPONIBLE';
  if (status === 'BUSY') return 'OCUPADA';
  if (status === 'MAINTENANCE') return 'MANTENIMIENTO';
  if (status === 'OFFLINE') return 'INACTIVA';
  return status;
}

function getElapsedMinutes(startedAt) {
  if (!startedAt) return null;
  const start = new Date(startedAt).getTime();
  return Math.max(0, Math.round((Date.now() - start) / 60000));
}

function getEndTime(station) {
  if (!station.started_at || !station.prepaid_minutes) return null;
  const end = new Date(new Date(station.started_at).getTime() + Number(station.prepaid_minutes) * 60000);
  return formatTime(end);
}
async function loadStations(...args) {
  return window.ClubVersusStations?.loadStations?.(...args);
}


async function loadTimePrices() {
  const { prices } = await api('/stations/time-prices');
  state.timePrices = prices || [];
}



async function loadGroupEventPrices() {
  try {
    const { prices } = await api('/stations/group-event-prices');
    state.groupEventPrices = prices || [];
  } catch (error) {
    state.groupEventPrices = [];
    throw error;
  }
}

async function loadStationGames() {
  try {
    const { games } = await api('/stations/games');
    state.stationGames = games || [];
  } catch (error) {
    state.stationGames = [];
    throw error;
  }
}

async function loadGameStorageDevices() {
  try {
    const { devices } = await api('/stations/game-devices');
    state.gameStorageDevices = devices || [];
  } catch (error) {
    state.gameStorageDevices = [];
    throw error;
  }
}

async function loadStationExtras() {
  try {
    const { extras } = await api('/stations/extras');
    state.stationExtras = extras || [];
  } catch (error) {
    state.stationExtras = [];
    throw error;
  }
}

async function loadPromotions() {
  const { promotions } = await api('/promotions');
  state.promotions = promotions || [];
  try {
    const result = await api('/promotions/tournament-entry-discounts');
    state.tournamentEntryDiscounts = result.discounts || [];
  } catch (error) {
    state.tournamentEntryDiscounts = [];
  }
}

async function loadBonusRules() {
  const { rules } = await api('/promotions/bonus-rules');
  state.bonusRules = rules || [];
}

function getBonusRule(ruleKey) {
  return (state.bonusRules || []).find((rule) => String(rule.rule_key || '').toUpperCase() === String(ruleKey || '').toUpperCase()) || null;
}

async function loadMembershipPlans() {
  const { plans } = await api('/promotions/membership-plans');
  state.membershipPlans = plans || [];
  renderManualBonusMembershipOptions();
}

async function loadMemberTimePrices() {
  const { prices } = await api('/promotions/member-time-prices');
  state.memberTimePrices = prices || [];
}


function getRoundLabelFromMatches(roundNumber, matches = []) {
  const maxRound = Math.max(1, ...matches.map((match) => Number(match.round_number || 1)));
  return getTournamentRoundLabel(Number(roundNumber || 1), maxRound);
}
function renderVersusBoard(...args) {
  return window.ClubVersusStations?.renderVersusBoard?.(...args);
}
async function startVersusMode(...args) {
  return window.ClubVersusStations?.startVersusMode?.(...args);
}
async function setVersusStationWinner(...args) {
  return window.ClubVersusStations?.setVersusStationWinner?.(...args);
}
function renderStations(...args) {
  return window.ClubVersusStations?.renderStations?.(...args);
}
function checkStationTimeAlerts(...args) {
  return window.ClubVersusStations?.checkStationTimeAlerts?.(...args);
}

function openTimeWarning(station, ended = false) {
  const modal = $('#timeWarningModal');
  if (!modal) return;
  state.timeWarningStationId = station.id;
  $('#timeWarningTitle').textContent = ended ? 'Tiempo terminado' : 'Aviso de tiempo';
  $('#timeWarningText').textContent = ended
    ? `El tiempo de ${station.name} terminó.`
    : `A ${station.name} le quedan 5 minutos.`;
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
}

function closeTimeWarning() {
  const modal = $('#timeWarningModal');
  if (!modal) return;
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
}

function addTimeFromWarning() {
  const stationId = state.timeWarningStationId;
  closeTimeWarning();
  if (stationId) openStationModal(stationId);
}
function openStationsConfigModule(...args) {
  return window.ClubVersusStations?.openStationsConfigModule?.(...args);
}
function closeStationsConfigModule(...args) {
  return window.ClubVersusStations?.closeStationsConfigModule?.(...args);
}
function resetStationConfigForm(...args) {
  return window.ClubVersusStations?.resetStationConfigForm?.(...args);
}
function renderStationModelOptions(...args) {
  return window.ClubVersusStations?.renderStationModelOptions?.(...args);
}
function selectStationConfig(...args) {
  return window.ClubVersusStations?.selectStationConfig?.(...args);
}
function renderStationsConfigModule(...args) {
  return window.ClubVersusStations?.renderStationsConfigModule?.(...args);
}
async function saveStationConfig(...args) {
  return window.ClubVersusStations?.saveStationConfig?.(...args);
}
async function deleteStationConfig(...args) {
  return window.ClubVersusStations?.deleteStationConfig?.(...args);
}

async function loadProductCategories() {
  const { categories } = await api('/products/categories');
  state.posCategories = categories || [];
  renderCategorySelects();
  renderModalProducts();
}

async function loadProducts() {
  if (!state.posCategories?.length) {
    await loadProductCategories().catch(() => {});
  }
  const { products } = await api('/products');
  state.products = products;
  renderCategorySelects();
  renderModalProducts();
}

// Orden POS, miembros rápidos, productos del modal e integración POS/Torneos movidos a public/js/modules/order.js en v2.0.6.7.
function resetOrder(...args) { return window.ClubVersusModules.order.resetOrder(...args); }
function setSelectedMember(...args) { return window.ClubVersusModules.order.setSelectedMember(...args); }
function renderMemberSelection(...args) { return window.ClubVersusModules.order.renderMemberSelection(...args); }
function applyWelcomeBonus(...args) { return window.ClubVersusModules.order.applyWelcomeBonus(...args); }
function applyVisitReward(...args) { return window.ClubVersusModules.order.applyVisitReward(...args); }
function applyProductReward(...args) { return window.ClubVersusModules.order.applyProductReward(...args); }
function applyExactProductReward(...args) { return window.ClubVersusModules.order.applyExactProductReward(...args); }
function openMemberPicker(...args) { return window.ClubVersusModules.order.openMemberPicker(...args); }
function closeMemberPicker(...args) { return window.ClubVersusModules.order.closeMemberPicker(...args); }
function openStationModal(...args) { return window.ClubVersusModules.order.openStationModal(...args); }
function openQuickOrderModal(...args) { return window.ClubVersusModules.order.openQuickOrderModal(...args); }
function closeStationModal(...args) { return window.ClubVersusModules.order.closeStationModal(...args); }
function getGeneralStationTimePrices(...args) { return window.ClubVersusModules.order.getGeneralStationTimePrices(...args); }
function getStationTimePrices(...args) { return window.ClubVersusModules.order.getStationTimePrices(...args); }
function findConfiguredStationTimePrice(...args) { return window.ClubVersusModules.order.findConfiguredStationTimePrice(...args); }
function buildFallbackTimePrice(...args) { return window.ClubVersusModules.order.buildFallbackTimePrice(...args); }
function getOrderTimePriceForMinutes(...args) { return window.ClubVersusModules.order.getOrderTimePriceForMinutes(...args); }
function normalizeDateOnly(...args) { return window.ClubVersusModules.order.normalizeDateOnly(...args); }
function promotionAppliesNow(...args) { return window.ClubVersusModules.order.promotionAppliesNow(...args); }
function applyPromotionToTimePrice(...args) { return window.ClubVersusModules.order.applyPromotionToTimePrice(...args); }
function getBestActivePromotion(...args) { return window.ClubVersusModules.order.getBestActivePromotion(...args); }
function getTimePriceWithPromotion(...args) { return window.ClubVersusModules.order.getTimePriceWithPromotion(...args); }
function getOrderTimePrice(...args) { return window.ClubVersusModules.order.getOrderTimePrice(...args); }
function isStationOpenMode(...args) { return window.ClubVersusModules.order.isStationOpenMode(...args); }
function getOpenModeHourlyRate(...args) { return window.ClubVersusModules.order.getOpenModeHourlyRate(...args); }
function getOpenModeElapsedMs(...args) { return window.ClubVersusModules.order.getOpenModeElapsedMs(...args); }
function getOpenModeElapsedMinutes(...args) { return window.ClubVersusModules.order.getOpenModeElapsedMinutes(...args); }
function getOpenModeChargePreview(...args) { return window.ClubVersusModules.order.getOpenModeChargePreview(...args); }
function renderTimeOptions(...args) { return window.ClubVersusModules.order.renderTimeOptions(...args); }
function activateFreeMode(...args) { return window.ClubVersusModules.order.activateFreeMode(...args); }
function renderMenuCategoryTabs(...args) { return window.ClubVersusModules.order.renderMenuCategoryTabs(...args); }
function getProductDisplayPrice(...args) { return window.ClubVersusModules.order.getProductDisplayPrice(...args); }
async function loadPosTournaments(...args) { return window.ClubVersusModules.order.loadPosTournaments(...args); }
function isTodayTournament(...args) { return window.ClubVersusModules.order.isTodayTournament(...args); }
function isClosedFinishedTournament(...args) { return window.ClubVersusModules.order.isClosedFinishedTournament(...args); }
function getVisiblePosTournaments(...args) { return window.ClubVersusModules.order.getVisiblePosTournaments(...args); }
function getPrimaryPosTournament(...args) { return window.ClubVersusModules.order.getPrimaryPosTournament(...args); }
function getTournamentEntryFee(...args) { return window.ClubVersusModules.order.getTournamentEntryFee(...args); }
function getPendingTournamentParticipants(...args) { return window.ClubVersusModules.order.getPendingTournamentParticipants(...args); }
function getTournamentEntryLineId(...args) { return window.ClubVersusModules.order.getTournamentEntryLineId(...args); }
function addTournamentEntryToOrder(...args) { return window.ClubVersusModules.order.addTournamentEntryToOrder(...args); }
function removeTournamentEntryFromOrder(...args) { return window.ClubVersusModules.order.removeTournamentEntryFromOrder(...args); }
function getTournamentEntryDiscountPreview(...args) { return window.ClubVersusModules.order.getTournamentEntryDiscountPreview(...args); }
function updateTournamentEntryModalTotals(...args) { return window.ClubVersusModules.order.updateTournamentEntryModalTotals(...args); }
function forceTournamentEntryModalLayout(...args) { return window.ClubVersusModules.order.forceTournamentEntryModalLayout(...args); }
function openTournamentEntryModal(...args) { return window.ClubVersusModules.order.openTournamentEntryModal(...args); }
function closeTournamentEntryModal(...args) { return window.ClubVersusModules.order.closeTournamentEntryModal(...args); }
async function searchTournamentEntryMembers(...args) { return window.ClubVersusModules.order.searchTournamentEntryMembers(...args); }
function buildTournamentEntryFromModal(...args) { return window.ClubVersusModules.order.buildTournamentEntryFromModal(...args); }
async function submitTournamentEntry(...args) { return window.ClubVersusModules.order.submitTournamentEntry(...args); }
function promptNewTournamentEntry(...args) { return window.ClubVersusModules.order.promptNewTournamentEntry(...args); }
function isTournamentAwardPending(...args) { return window.ClubVersusModules.order.isTournamentAwardPending(...args); }
function getTournamentAwardPrizeParts(...args) { return window.ClubVersusModules.order.getTournamentAwardPrizeParts(...args); }
function closeTournamentAwardsDeliveryModal(...args) { return window.ClubVersusModules.order.closeTournamentAwardsDeliveryModal(...args); }
function renderTournamentAwardsDeliveryModal(...args) { return window.ClubVersusModules.order.renderTournamentAwardsDeliveryModal(...args); }
async function refreshTournamentAwardsDelivery(...args) { return window.ClubVersusModules.order.refreshTournamentAwardsDelivery(...args); }
async function openTournamentAwardsDelivery(...args) { return window.ClubVersusModules.order.openTournamentAwardsDelivery(...args); }
function setTournamentAwardsDeliveryBusy(...args) { return window.ClubVersusModules.order.setTournamentAwardsDeliveryBusy(...args); }
function setTournamentAwardsDeliveryStatus(...args) { return window.ClubVersusModules.order.setTournamentAwardsDeliveryStatus(...args); }
async function finishTournamentAwardDelivery(...args) { return window.ClubVersusModules.order.finishTournamentAwardDelivery(...args); }
async function deliverTournamentAwardFromPos(...args) { return window.ClubVersusModules.order.deliverTournamentAwardFromPos(...args); }
async function deliverAllTournamentAwardsFromPos(...args) { return window.ClubVersusModules.order.deliverAllTournamentAwardsFromPos(...args); }
function bindTournamentAwardsDeliveryDelegatedClicks(...args) { return window.ClubVersusModules.order.bindTournamentAwardsDeliveryDelegatedClicks(...args); }
async function startPosVersus(...args) { return window.ClubVersusModules.order.startPosVersus(...args); }
async function closePosVersus(...args) { return window.ClubVersusModules.order.closePosVersus(...args); }
function isTournamentFullForSale(...args) { return window.ClubVersusModules.order.isTournamentFullForSale(...args); }
function getTournamentCapacityLabel(...args) { return window.ClubVersusModules.order.getTournamentCapacityLabel(...args); }
function renderTournamentDayPanel(...args) { return window.ClubVersusModules.order.renderTournamentDayPanel(...args); }
function renderTournamentPosProducts(...args) { return window.ClubVersusModules.order.renderTournamentPosProducts(...args); }
function renderModalProducts(...args) { return window.ClubVersusModules.order.renderModalProducts(...args); }
function getProductModifierGroups(...args) { return window.ClubVersusModules.order.getProductModifierGroups(...args); }
function getModifierLineKey(...args) { return window.ClubVersusModules.order.getModifierLineKey(...args); }
function getModifierDescription(...args) { return window.ClubVersusModules.order.getModifierDescription(...args); }
function getModifierPriceDelta(...args) { return window.ClubVersusModules.order.getModifierPriceDelta(...args); }
function ensureProductModifierModal(...args) { return window.ClubVersusModules.order.ensureProductModifierModal(...args); }
function closeProductModifierModal(...args) { return window.ClubVersusModules.order.closeProductModifierModal(...args); }
function openProductModifierModal(...args) { return window.ClubVersusModules.order.openProductModifierModal(...args); }
function toggleModifierChoice(...args) { return window.ClubVersusModules.order.toggleModifierChoice(...args); }
function getSelectedModifierObjects(...args) { return window.ClubVersusModules.order.getSelectedModifierObjects(...args); }
function confirmProductModifierSelection(...args) { return window.ClubVersusModules.order.confirmProductModifierSelection(...args); }
function addProductToOrder(...args) { return window.ClubVersusModules.order.addProductToOrder(...args); }
function commitProductToOrder(...args) { return window.ClubVersusModules.order.commitProductToOrder(...args); }
// Wrappers restantes de Orden y Escáner movidos en v2.0.6.7.
function removeProductFromOrder(...args) { return window.ClubVersusModules.order.removeProductFromOrder(...args); }
function getOrderTotal(...args) { return window.ClubVersusModules.order.getOrderTotal(...args); }
function getOrderItemFreeQty(...args) { return window.ClubVersusModules.order.getOrderItemFreeQty(...args); }
function getOrderItemPaidQty(...args) { return window.ClubVersusModules.order.getOrderItemPaidQty(...args); }
function getActiveSessionItems(...args) { return window.ClubVersusModules.order.getActiveSessionItems(...args); }
function getActiveSessionPendingTotal(...args) { return window.ClubVersusModules.order.getActiveSessionPendingTotal(...args); }
function getActiveSessionPaidTotal(...args) { return window.ClubVersusModules.order.getActiveSessionPaidTotal(...args); }
function getActiveSessionAccountTotal(...args) { return window.ClubVersusModules.order.getActiveSessionAccountTotal(...args); }
function hasNewOrderContent(...args) { return window.ClubVersusModules.order.hasNewOrderContent(...args); }
function updateOrderActionButtons(...args) { return window.ClubVersusModules.order.updateOrderActionButtons(...args); }
function getCurrentOrderPayload(...args) { return window.ClubVersusModules.order.getCurrentOrderPayload(...args); }
function renderOrder(...args) { return window.ClubVersusModules.order.renderOrder(...args); }
async function checkoutStation(...args) { return window.ClubVersusModules.order.checkoutStation(...args); }
async function saveStationAccount(...args) { return window.ClubVersusModules.order.saveStationAccount(...args); }
async function awaitEndSession(...args) { return window.ClubVersusModules.order.awaitEndSession(...args); }
async function endSelectedSession(...args) { return window.ClubVersusModules.order.endSelectedSession(...args); }
function normalizeScanCode(...args) { return window.ClubVersusModules.scanner.normalizeScanCode(...args); }
function isPosModalOpen(...args) { return window.ClubVersusModules.scanner.isPosModalOpen(...args); }
function isScanProductModalOpen(...args) { return window.ClubVersusModules.scanner.isScanProductModalOpen(...args); }
function isTypingTarget(...args) { return window.ClubVersusModules.scanner.isTypingTarget(...args); }
function isMemberSearchTarget(...args) { return window.ClubVersusModules.scanner.isMemberSearchTarget(...args); }
function isLikelyScanCode(...args) { return window.ClubVersusModules.scanner.isLikelyScanCode(...args); }
function resetScannerBuffer(...args) { return window.ClubVersusModules.scanner.resetScannerBuffer(...args); }
function clearScannerTargetValueIfNeeded(...args) { return window.ClubVersusModules.scanner.clearScannerTargetValueIfNeeded(...args); }
function findProductByScanCode(...args) { return window.ClubVersusModules.scanner.findProductByScanCode(...args); }
function isPlaceholderScanProduct(...args) { return window.ClubVersusModules.scanner.isPlaceholderScanProduct(...args); }
async function processScannedCode(...args) { return window.ClubVersusModules.scanner.processScannedCode(...args); }
function finishScannerBuffer(...args) { return window.ClubVersusModules.scanner.finishScannerBuffer(...args); }
function handleGlobalScanner(...args) { return window.ClubVersusModules.scanner.handleGlobalScanner(...args); }
function openScanProductModal(...args) { return window.ClubVersusModules.scanner.openScanProductModal(...args); }
function closeScanProductModal(...args) { return window.ClubVersusModules.scanner.closeScanProductModal(...args); }
async function saveScannedProduct(...args) { return window.ClubVersusModules.scanner.saveScannedProduct(...args); }

let paymentFlowModule = null;

function getPaymentFlowModule() {
  if (!paymentFlowModule) {
    if (!window.ClubVersusPaymentFlow?.create) {
      throw new Error('Payment flow module is not loaded');
    }
    paymentFlowModule = window.ClubVersusPaymentFlow.create({
      state,
      $,
      setText,
      money,
      showToast,
      requireOpenDrawerForSales,
      closeStationModal,
      checkoutStation,
      awaitEndSession,
      getOrderTotal,
      getActiveSessionPendingTotal,
      getOpenModeChargePreview,
      hasNewOrderContent,
      showTransferPaymentError,
      clearTransferPaymentError,
      showAppDialog
    });
  }
  return paymentFlowModule;
}

function getActivePaymentTotal() { return getPaymentFlowModule().getActivePaymentTotal(); }
function getPaymentRequiresCheckout() { return getPaymentFlowModule().getPaymentRequiresCheckout(); }
function clearCashPaymentError() { return getPaymentFlowModule().clearCashPaymentError(); }
function showCashPaymentError(message) { return getPaymentFlowModule().showCashPaymentError(message); }
function updateCashChange() { return getPaymentFlowModule().updateCashChange(); }
function openCashPaymentModal() { return getPaymentFlowModule().openCashPaymentModal(); }
function renderCashFastButtons() { return getPaymentFlowModule().renderCashFastButtons(); }
function setCashReceivedAmount(amount) { return getPaymentFlowModule().setCashReceivedAmount(amount); }
function closeCashPaymentModal() { return getPaymentFlowModule().closeCashPaymentModal(); }
function addCashFastAmount(amount) { return getPaymentFlowModule().addCashFastAmount(amount); }
function setCashExactAmount() { return getPaymentFlowModule().setCashExactAmount(); }
function clearCashAmount() { return getPaymentFlowModule().clearCashAmount(); }
function confirmCashPayment() { return getPaymentFlowModule().confirmCashPayment(); }
function showChangeAndReceiptPrompts(change) { return getPaymentFlowModule().showChangeAndReceiptPrompts(change); }
function openTransferPaymentModal() { return getPaymentFlowModule().openTransferPaymentModal(); }
function closeTransferPaymentModal() { return getPaymentFlowModule().closeTransferPaymentModal(); }
function confirmTransferPayment() { return getPaymentFlowModule().confirmTransferPayment(); }

function showAppDialog(options = {}) {
  return window.ClubVersusCore?.modalManager?.showAppDialog?.(options);
}




async function searchMembers() {
  const input = $('#memberSearchInput');
  const q = input.value.trim();

  if (!q) {
    showToast('Ingresa nombre, teléfono o QR');
    return;
  }

  try {
    const { members } = await api(`/members/search?q=${encodeURIComponent(q)}`);
    renderMemberResults(members);
  } catch (error) {
    showToast(error.message);
  }
}

function renderMemberResults(members) {
  const result = $('#memberResult');

  if (!members.length) {
    result.className = 'member-result empty';
    result.textContent = 'No encontrado';
    return;
  }

  if (members.length === 1) {
    setSelectedMember(members[0]);
    closeMemberPicker();
    return;
  }

  result.className = 'member-result';
  result.innerHTML = members.map((member) => {
    const phone = member.phone ? ` · ${member.phone}` : '';
    const birthday = member.date_of_birth ? ` · Cumple ${formatBirthDate(member.date_of_birth)}` : '';
    const membership = member.membership_active ? getMembershipLabel(member.membership_tier) : 'General';
    const bonus = hasWelcomeBonus(member) ? ` · Bono ${Number(member.welcome_bonus_minutes)} min` : '';
    const reward = hasVisitReward(member) ? ` · Recompensa ${Number(member.visit_reward_minutes)} min` : '';
    return `
      <button type="button" class="member-result-card" data-member-id="${member.id}">
        <span>
          <strong>${member.full_name}</strong>
          <small>${membership} · ${Number(member.visit_count || 0)} visitas · ${Number(member.reward_points || 0)} pts${phone}${birthday}${bonus}${reward}</small>
        </span>
        <b>Usar</b>
      </button>
    `;
  }).join('');

  result.querySelectorAll('[data-member-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const member = members.find((item) => item.id === btn.dataset.memberId);
      setSelectedMember(member);
      closeMemberPicker();
    });
  });
}

function clearSelectedMember() {
  setSelectedMember(null);
  $('#memberSearchInput').value = '';
  closeMemberPicker();
  showToast('Precio general seleccionado');
}

function openCreateMember() {
  $('#createMemberBox').classList.remove('hidden');
  $('#createMemberName').focus();
}

function closeCreateMember() {
  $('#createMemberBox').classList.add('hidden');
  $('#createMemberName').value = '';
  $('#createMemberPhone').value = '';
  $('#createMemberPortalUsername').value = '';
  $('#createMemberPortalPin').value = '';
  $('#createMemberPortalPinConfirm').value = '';
  $('#createMemberBirthDate').value = '';
}

async function createMemberFromModal() {
  const fullName = $('#createMemberName').value.trim();
  const phone = $('#createMemberPhone').value.trim();
  const portalUsername = $('#createMemberPortalUsername').value.trim();
  const portalPin = $('#createMemberPortalPin').value.trim();
  const portalPinConfirm = $('#createMemberPortalPinConfirm').value.trim();
  const dateOfBirth = $('#createMemberBirthDate').value || null;

  if (!fullName) {
    showToast('Ingresa el nombre');
    return;
  }

  try {
    const { member } = await api('/members', {
      method: 'POST',
      body: JSON.stringify({ fullName, phone, dateOfBirth, portalUsername, portalPin, portalPinConfirm, portalEnabled: Boolean(portalUsername || portalPin) })
    });

    setSelectedMember(member);
    closeCreateMember();
    closeMemberPicker();
    showToast('Miembro creado');
  } catch (error) {
    showToast(error.message);
  }
}




async function loadDrawer() {
  const { drawer } = await api('/drawer/status');
  state.drawer = drawer || null;

  const topDrawerBtn = $('#topDrawerBtn');

  if (drawer) {
    const expected = drawer.summary?.expected_cash ?? drawer.opening_amount;
    $('#drawerStatus').textContent = `Abierta · ${money(expected)}`;
    if (topDrawerBtn) {
      topDrawerBtn.textContent = `Caja abierta · ${money(expected)}`;
      topDrawerBtn.classList.remove('drawer-closed');
      topDrawerBtn.classList.add('drawer-open');
    }
  } else {
    $('#drawerStatus').textContent = 'Cerrada';
    if (topDrawerBtn) {
      topDrawerBtn.textContent = 'Abrir caja';
      topDrawerBtn.classList.remove('drawer-open');
      topDrawerBtn.classList.add('drawer-closed');
    }
  }

  renderDrawerModule();
}



// Inventario, categorías POS y modificadores fueron movidos a public/js/modules/inventory.js.


// Permisos movido a public/js/modules/permissions.js en v2.0.6.5.
async function openPermissionsModule(...args) { return window.ClubVersusModules.permissions.openPermissionsModule(...args); }
function closePermissionsModule(...args) { return window.ClubVersusModules.permissions.closePermissionsModule(...args); }
async function loadEmployeesForPermissions(...args) { return window.ClubVersusModules.permissions.loadEmployeesForPermissions(...args); }
async function loadPermissionOptions(...args) { return window.ClubVersusModules.permissions.loadPermissionOptions(...args); }
function renderPermissionsModule(...args) { return window.ClubVersusModules.permissions.renderPermissionsModule(...args); }
async function savePermissions(...args) { return window.ClubVersusModules.permissions.savePermissions(...args); }

// Precios, promociones, planes de membresía y bonos movidos a public/js/modules/prices.js en v2.0.6.5.
function openTimePricesModule(...args) { return window.ClubVersusModules.prices.openTimePricesModule(...args); }
function closeTimePricesModule(...args) { return window.ClubVersusModules.prices.closeTimePricesModule(...args); }
function getTimePriceScopeRows(...args) { return window.ClubVersusModules.prices.getTimePriceScopeRows(...args); }
function getTimePriceScopeName(...args) { return window.ClubVersusModules.prices.getTimePriceScopeName(...args); }
function renderTimePriceEditorRows(...args) { return window.ClubVersusModules.prices.renderTimePriceEditorRows(...args); }
function renderTimePricesModule(...args) { return window.ClubVersusModules.prices.renderTimePricesModule(...args); }
function collectTimePriceRows(...args) { return window.ClubVersusModules.prices.collectTimePriceRows(...args); }
async function saveTimePrices(...args) { return window.ClubVersusModules.prices.saveTimePrices(...args); }
async function saveGroupEventPrices(...args) { return window.ClubVersusModules.prices.saveGroupEventPrices(...args); }
function addGroupEventPriceRow(...args) { return window.ClubVersusModules.prices.addGroupEventPriceRow(...args); }
async function applyTimePricesToAll(...args) { return window.ClubVersusModules.prices.applyTimePricesToAll(...args); }
function canManagePromotions(...args) { return window.ClubVersusModules.prices.canManagePromotions(...args); }
function inputDate(...args) { return window.ClubVersusModules.prices.inputDate(...args); }
function todayInputDate(...args) { return window.ClubVersusModules.prices.todayInputDate(...args); }
function getPromotionScopeLabel(...args) { return window.ClubVersusModules.prices.getPromotionScopeLabel(...args); }
function getPromotionTypeLabel(...args) { return window.ClubVersusModules.prices.getPromotionTypeLabel(...args); }
async function openPromotionsModule(...args) { return window.ClubVersusModules.prices.openPromotionsModule(...args); }
function closePromotionsModule(...args) { return window.ClubVersusModules.prices.closePromotionsModule(...args); }
function resetPromotionForm(...args) { return window.ClubVersusModules.prices.resetPromotionForm(...args); }
function renderPromotionStationOptions(...args) { return window.ClubVersusModules.prices.renderPromotionStationOptions(...args); }
function renderPromotionDays(...args) { return window.ClubVersusModules.prices.renderPromotionDays(...args); }
function updatePromotionFormVisibility(...args) { return window.ClubVersusModules.prices.updatePromotionFormVisibility(...args); }
function selectPromotion(...args) { return window.ClubVersusModules.prices.selectPromotion(...args); }
function renderTournamentEntryDiscountRules(...args) { return window.ClubVersusModules.prices.renderTournamentEntryDiscountRules(...args); }
async function saveTournamentEntryDiscountRules(...args) { return window.ClubVersusModules.prices.saveTournamentEntryDiscountRules(...args); }
function renderPromotionsModule(...args) { return window.ClubVersusModules.prices.renderPromotionsModule(...args); }
async function savePromotion(...args) { return window.ClubVersusModules.prices.savePromotion(...args); }
async function deletePromotion(...args) { return window.ClubVersusModules.prices.deletePromotion(...args); }
function renderMembershipPlansModule(...args) { return window.ClubVersusModules.prices.renderMembershipPlansModule(...args); }
function getMembershipPlanFormPayload(...args) { return window.ClubVersusModules.prices.getMembershipPlanFormPayload(...args); }
function openMembershipPlanModal(...args) { return window.ClubVersusModules.prices.openMembershipPlanModal(...args); }
function closeMembershipPlanModal(...args) { return window.ClubVersusModules.prices.closeMembershipPlanModal(...args); }
async function saveMembershipPlan(...args) { return window.ClubVersusModules.prices.saveMembershipPlan(...args); }
async function archiveMembershipPlan(...args) { return window.ClubVersusModules.prices.archiveMembershipPlan(...args); }
async function restoreMembershipPlan(...args) { return window.ClubVersusModules.prices.restoreMembershipPlan(...args); }
function getMemberPriceRows(...args) { return window.ClubVersusModules.prices.getMemberPriceRows(...args); }
function renderMemberPricesModule(...args) { return window.ClubVersusModules.prices.renderMemberPricesModule(...args); }
async function saveMemberTimePrices(...args) { return window.ClubVersusModules.prices.saveMemberTimePrices(...args); }
function renderManualBonusMembershipOptions(...args) { return window.ClubVersusModules.prices.renderManualBonusMembershipOptions(...args); }
function getManualBonusProductCategoryOptions(...args) { return window.ClubVersusModules.prices.getManualBonusProductCategoryOptions(...args); }
function renderManualBonusProductOptions(...args) { return window.ClubVersusModules.prices.renderManualBonusProductOptions(...args); }
function renderManualBonusProductItemOptions(...args) { return window.ClubVersusModules.prices.renderManualBonusProductItemOptions(...args); }
function getBonusTierOptions(...args) { return window.ClubVersusModules.prices.getBonusTierOptions(...args); }
function renderBonusRulesModule(...args) { return window.ClubVersusModules.prices.renderBonusRulesModule(...args); }
async function saveBonusRule(...args) { return window.ClubVersusModules.prices.saveBonusRule(...args); }
function renderManualBonusMember(...args) { return window.ClubVersusModules.prices.renderManualBonusMember(...args); }
function updateManualBonusFields(...args) { return window.ClubVersusModules.prices.updateManualBonusFields(...args); }
async function searchManualBonusMember(...args) { return window.ClubVersusModules.prices.searchManualBonusMember(...args); }
async function grantManualBonus(...args) { return window.ClubVersusModules.prices.grantManualBonus(...args); }

function setMainSection(section) {
  state.activeMainSection = section;
  if ($('#topStationsBtn')) $('#topStationsBtn').classList.toggle('active', section === 'stations');
  if ($('#topQuickOrderBtn')) $('#topQuickOrderBtn').classList.toggle('active', section === 'quick');

  if (section === 'stations') {
    closeStationModal();
    if ($('#appView')) $('#appView').classList.remove('hidden');
  }

  if (section === 'quick') {
    if (!requireOpenDrawerForSales(true)) {
      state.activeMainSection = 'stations';
      if ($('#topStationsBtn')) $('#topStationsBtn').classList.add('active');
      if ($('#topQuickOrderBtn')) $('#topQuickOrderBtn').classList.remove('active');
      return;
    }
    openQuickOrderModal();
  }
}


function openTransferCodesModule() {
  if (!(state.user?.role === 'OWNER' || state.user?.role === 'MANAGER')) return showToast('Solo administrador puede generar códigos');
  closeModuleHub();
  setText('#generatedTransferCode', '------');
  setText('#generatedTransferCodeExpires', 'Vence en 15 minutos');
  $('#transferCodesModal')?.classList.remove('hidden');
  $('#transferCodesModal')?.setAttribute('aria-hidden', 'false');
}

function closeTransferCodesModule() {
  closeConfigModule('#transferCodesModal');
}

async function generateTransferCode() {
  try {
    const result = await api('/authorization-codes/transfer', {
      method: 'POST',
      body: JSON.stringify({ expiresMinutes: 15 })
    });
    const code = result.authorizationCode?.code || '------';
    setText('#generatedTransferCode', code);
    setText('#generatedTransferCodeExpires', 'Código válido por 15 minutos y de un solo uso');
  } catch (error) {
    showToast(error.message);
  }
}


// Administración completa de torneos movida a public/js/modules/tournaments.js en v2.0.6.5.
function loadTournaments(...args) { return window.ClubVersusModules.tournaments.loadTournaments(...args); }
function loadTournamentRanking(...args) { return window.ClubVersusModules.tournaments.loadTournamentRanking(...args); }
function renderTournamentRanking(...args) { return window.ClubVersusModules.tournaments.renderTournamentRanking(...args); }
function loadTournamentDetail(...args) { return window.ClubVersusModules.tournaments.loadTournamentDetail(...args); }
function openTournamentsModule(...args) { return window.ClubVersusModules.tournaments.openTournamentsModule(...args); }
function closeTournamentsModule(...args) { return window.ClubVersusModules.tournaments.closeTournamentsModule(...args); }
function resetTournamentForm(...args) { return window.ClubVersusModules.tournaments.resetTournamentForm(...args); }
function fillTournamentForm(...args) { return window.ClubVersusModules.tournaments.fillTournamentForm(...args); }
function getTournamentPayload(...args) { return window.ClubVersusModules.tournaments.getTournamentPayload(...args); }
function getPositionLabel(...args) { return window.ClubVersusModules.tournaments.getPositionLabel(...args); }
function getMembershipTierLabel(...args) { return window.ClubVersusModules.tournaments.getMembershipTierLabel(...args); }
function renderMembershipPlanPrizeOptions(...args) { return window.ClubVersusModules.tournaments.renderMembershipPlanPrizeOptions(...args); }
function getPrizeConfigByPosition(...args) { return window.ClubVersusModules.tournaments.getPrizeConfigByPosition(...args); }
function renderTournamentPrizeConfigInputs(...args) { return window.ClubVersusModules.tournaments.renderTournamentPrizeConfigInputs(...args); }
function getTournamentPrizeConfigPayload(...args) { return window.ClubVersusModules.tournaments.getTournamentPrizeConfigPayload(...args); }
function getParticipantOptions(...args) { return window.ClubVersusModules.tournaments.getParticipantOptions(...args); }
function getAwardByPosition(...args) { return window.ClubVersusModules.tournaments.getAwardByPosition(...args); }
function buildTournamentAwardsPayload(...args) { return window.ClubVersusModules.tournaments.buildTournamentAwardsPayload(...args); }
function assignTournamentAwards(...args) { return window.ClubVersusModules.tournaments.assignTournamentAwards(...args); }
function deliverTournamentAward(...args) { return window.ClubVersusModules.tournaments.deliverTournamentAward(...args); }
function getAwardPendingLabel(...args) { return window.ClubVersusModules.tournaments.getAwardPendingLabel(...args); }
function renderTournamentAwardsPanel(...args) { return window.ClubVersusModules.tournaments.renderTournamentAwardsPanel(...args); }
function saveTournament(...args) { return window.ClubVersusModules.tournaments.saveTournament(...args); }
function selectTournament(...args) { return window.ClubVersusModules.tournaments.selectTournament(...args); }
function setTournamentStatus(...args) { return window.ClubVersusModules.tournaments.setTournamentStatus(...args); }
function cancelTournament(...args) { return window.ClubVersusModules.tournaments.cancelTournament(...args); }
function deleteTournament(...args) { return window.ClubVersusModules.tournaments.deleteTournament(...args); }
function renderTournamentMemberPicker(...args) { return window.ClubVersusModules.tournaments.renderTournamentMemberPicker(...args); }
function searchTournamentParticipantMember(...args) { return window.ClubVersusModules.tournaments.searchTournamentParticipantMember(...args); }
function selectTournamentParticipantMember(...args) { return window.ClubVersusModules.tournaments.selectTournamentParticipantMember(...args); }
function clearTournamentParticipantMember(...args) { return window.ClubVersusModules.tournaments.clearTournamentParticipantMember(...args); }
function addTournamentParticipant(...args) { return window.ClubVersusModules.tournaments.addTournamentParticipant(...args); }
function markParticipantPaid(...args) { return window.ClubVersusModules.tournaments.markParticipantPaid(...args); }
function deleteTournamentParticipant(...args) { return window.ClubVersusModules.tournaments.deleteTournamentParticipant(...args); }
function getPaidTournamentParticipantOptions(...args) { return window.ClubVersusModules.tournaments.getPaidTournamentParticipantOptions(...args); }
function renderManualPairingsPanel(...args) { return window.ClubVersusModules.tournaments.renderManualPairingsPanel(...args); }
function addManualPairing(...args) { return window.ClubVersusModules.tournaments.addManualPairing(...args); }
function deleteManualPairing(...args) { return window.ClubVersusModules.tournaments.deleteManualPairing(...args); }
function generateTournamentBracket(...args) { return window.ClubVersusModules.tournaments.generateTournamentBracket(...args); }
function setTournamentMatchWinner(...args) { return window.ClubVersusModules.tournaments.setTournamentMatchWinner(...args); }
function assignTournamentMatchStation(...args) { return window.ClubVersusModules.tournaments.assignTournamentMatchStation(...args); }
function startTournamentMatchStation(...args) { return window.ClubVersusModules.tournaments.startTournamentMatchStation(...args); }
function releaseTournamentMatchStation(...args) { return window.ClubVersusModules.tournaments.releaseTournamentMatchStation(...args); }
function getTournamentStationOptions(...args) { return window.ClubVersusModules.tournaments.getTournamentStationOptions(...args); }
function renderTournamentBracket(...args) { return window.ClubVersusModules.tournaments.renderTournamentBracket(...args); }
function getNextPowerOfTwo(...args) { return window.ClubVersusModules.tournaments.getNextPowerOfTwo(...args); }
function getTournamentRoundLabel(...args) { return window.ClubVersusModules.tournaments.getTournamentRoundLabel(...args); }
function renderTournamentMatch(...args) { return window.ClubVersusModules.tournaments.renderTournamentMatch(...args); }
function renderTournamentsModule(...args) { return window.ClubVersusModules.tournaments.renderTournamentsModule(...args); }

// Reportes fue movido a un módulo separado en v2.0.5.6.
function localDateOnly(...args) { return window.ClubVersusModules.reports.localDateOnly(...args); }
function getWeekStartDate(...args) { return window.ClubVersusModules.reports.getWeekStartDate(...args); }
function getReportPresetRange(...args) { return window.ClubVersusModules.reports.getReportPresetRange(...args); }
function normalizeReportRange(...args) { return window.ClubVersusModules.reports.normalizeReportRange(...args); }
function formatReportDate(...args) { return window.ClubVersusModules.reports.formatReportDate(...args); }
function getReportRangeLabel(...args) { return window.ClubVersusModules.reports.getReportRangeLabel(...args); }
function syncReportControls(...args) { return window.ClubVersusModules.reports.syncReportControls(...args); }
function loadReports(...args) { return window.ClubVersusModules.reports.loadReports(...args); }
function setReportPreset(...args) { return window.ClubVersusModules.reports.setReportPreset(...args); }
function applyCustomReportRange(...args) { return window.ClubVersusModules.reports.applyCustomReportRange(...args); }
function openReportsModule(...args) { return window.ClubVersusModules.reports.openReportsModule(...args); }
function closeReportsModule(...args) { return window.ClubVersusModules.reports.closeReportsModule(...args); }
function renderReportList(...args) { return window.ClubVersusModules.reports.renderReportList(...args); }
function syncAuditFilterOptions(...args) { return window.ClubVersusModules.reports.syncAuditFilterOptions(...args); }
function loadAuditEvents(...args) { return window.ClubVersusModules.reports.loadAuditEvents(...args); }
function applyAuditFilters(...args) { return window.ClubVersusModules.reports.applyAuditFilters(...args); }
function renderReportsModule(...args) { return window.ClubVersusModules.reports.renderReportsModule(...args); }

// Finanzas y Sueldos fueron movidos a módulos separados en v2.0.5.5.
function getFinancePresetRange(...args) { return window.ClubVersusModules.finance.getFinancePresetRange(...args); }
function setFinancePreset(...args) { return window.ClubVersusModules.finance.setFinancePreset(...args); }
function openFinancesModule(...args) { return window.ClubVersusModules.finance.openFinancesModule(...args); }
function closeFinancesModule(...args) { return window.ClubVersusModules.finance.closeFinancesModule(...args); }
function financeDate(...args) { return window.ClubVersusModules.finance.financeDate(...args); }
function loadFinanceSummary(...args) { return window.ClubVersusModules.finance.loadFinanceSummary(...args); }
function renderFinanceSummary(...args) { return window.ClubVersusModules.finance.renderFinanceSummary(...args); }
function renderFinanceList(...args) { return window.ClubVersusModules.finance.renderFinanceList(...args); }
function deleteFinanceItem(...args) { return window.ClubVersusModules.finance.deleteFinanceItem(...args); }
function saveFinanceInvestment(...args) { return window.ClubVersusModules.finance.saveFinanceInvestment(...args); }
function saveFinanceExpense(...args) { return window.ClubVersusModules.finance.saveFinanceExpense(...args); }
function saveFinanceRecurring(...args) { return window.ClubVersusModules.finance.saveFinanceRecurring(...args); }
function setFinanceTab(...args) { return window.ClubVersusModules.finance.setFinanceTab(...args); }
function syncFinanceControls(...args) { return window.ClubVersusModules.finance.syncFinanceControls(...args); }
function getPayrollEmployeeName(...args) { return window.ClubVersusModules.payroll.getPayrollEmployeeName(...args); }
function ensureEmployeesForPayroll(...args) { return window.ClubVersusModules.payroll.ensureEmployeesForPayroll(...args); }
function normalizePayrollEmployee(...args) { return window.ClubVersusModules.payroll.normalizePayrollEmployee(...args); }
function mergePayrollEmployeeSources(...args) { return window.ClubVersusModules.payroll.mergePayrollEmployeeSources(...args); }
function getPayrollSelectableEmployees(...args) { return window.ClubVersusModules.payroll.getPayrollSelectableEmployees(...args); }
function payrollSelectOptions(...args) { return window.ClubVersusModules.payroll.payrollSelectOptions(...args); }
function fillPayrollEmployeeForm(...args) { return window.ClubVersusModules.payroll.fillPayrollEmployeeForm(...args); }
function getPayrollCalendarMonth(...args) { return window.ClubVersusModules.payroll.getPayrollCalendarMonth(...args); }
function getPayrollCalendarRange(...args) { return window.ClubVersusModules.payroll.getPayrollCalendarRange(...args); }
function setPayrollCalendarMonth(...args) { return window.ClubVersusModules.payroll.setPayrollCalendarMonth(...args); }
function changePayrollCalendarMonth(...args) { return window.ClubVersusModules.payroll.changePayrollCalendarMonth(...args); }
function showPayrollNotice(...args) { return window.ClubVersusModules.payroll.showPayrollNotice(...args); }
function payrollRotationDraftIsReady(...args) { return window.ClubVersusModules.payroll.payrollRotationDraftIsReady(...args); }
function syncPayrollRotationStartToMonth(...args) { return window.ClubVersusModules.payroll.syncPayrollRotationStartToMonth(...args); }
function getPayrollMonthLabel(...args) { return window.ClubVersusModules.payroll.getPayrollMonthLabel(...args); }
function shiftsByDateMap(...args) { return window.ClubVersusModules.payroll.shiftsByDateMap(...args); }
function renderPayrollMonthlyCalendar(...args) { return window.ClubVersusModules.payroll.renderPayrollMonthlyCalendar(...args); }
function buildPayrollPrintableScheduleHtml(...args) { return window.ClubVersusModules.payroll.buildPayrollPrintableScheduleHtml(...args); }
function printPayrollSchedule(...args) { return window.ClubVersusModules.payroll.printPayrollSchedule(...args); }
function renderPayrollModule(...args) { return window.ClubVersusModules.payroll.renderPayrollModule(...args); }
function loadPayroll(...args) { return window.ClubVersusModules.payroll.loadPayroll(...args); }
function savePayrollEmployee(...args) { return window.ClubVersusModules.payroll.savePayrollEmployee(...args); }
function savePayrollShift(...args) { return window.ClubVersusModules.payroll.savePayrollShift(...args); }
function getSelectedPayrollRotationShifts(...args) { return window.ClubVersusModules.payroll.getSelectedPayrollRotationShifts(...args); }
function savePayrollRotationRule(...args) { return window.ClubVersusModules.payroll.savePayrollRotationRule(...args); }
function generatePayrollRotation(...args) { return window.ClubVersusModules.payroll.generatePayrollRotation(...args); }
function savePayrollPayment(...args) { return window.ClubVersusModules.payroll.savePayrollPayment(...args); }
function deletePayrollRecord(...args) { return window.ClubVersusModules.payroll.deletePayrollRecord(...args); }

// Mantenimiento movido a public/js/modules/maintenance.js en v2.0.6.5.
function openMaintenanceModule(...args) { return window.ClubVersusModules.maintenance.openMaintenanceModule(...args); }
function closeMaintenanceModule(...args) { return window.ClubVersusModules.maintenance.closeMaintenanceModule(...args); }
function updateCleanupButton(...args) { return window.ClubVersusModules.maintenance.updateCleanupButton(...args); }
async function runMaintenanceCleanup(...args) { return window.ClubVersusModules.maintenance.runMaintenanceCleanup(...args); }

function isPinLoginKeyboardActive() {
  const loginView = $('#loginView');
  const pinCard = $('#pinLoginCard');
  const desktopExitModal = $('#desktopExitModal');
  const exitModalOpen = desktopExitModal
    && !desktopExitModal.classList.contains('hidden')
    && desktopExitModal.getAttribute('aria-hidden') !== 'true';

  return !state.token
    && loginView
    && !loginView.classList.contains('hidden')
    && pinCard
    && !pinCard.classList.contains('hidden')
    && !exitModalOpen;
}

function handlePinLoginKeyboard(event) {
  if (!isPinLoginKeyboardActive()) return;

  const target = event.target;
  const isEditableTarget = target
    && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable);
  if (isEditableTarget && target.id !== 'pinInput') return;

  const key = String(event.key || '');
  let handled = false;

  if (/^\d$/.test(key)) {
    addDigit(key);
    handled = true;
  } else if (key === 'Backspace' || key === 'Delete') {
    backspacePin();
    handled = true;
  } else if (key === 'Enter') {
    const form = $('#loginForm');
    if (typeof form?.requestSubmit === 'function') form.requestSubmit();
    else form?.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    handled = true;
  } else if (key === 'Escape' || key.toLowerCase() === 'c') {
    clearPin();
    handled = true;
  }

  if (handled) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }
}

function setupKeypad() {
  document.querySelectorAll('[data-key]').forEach((btn) => {
    btn.addEventListener('click', () => addDigit(btn.dataset.key));
  });

  $('#clearPinBtn')?.addEventListener('click', clearPin);
  $('#backspaceBtn')?.addEventListener('click', backspacePin);
  document.addEventListener('keydown', handlePinLoginKeyboard);
}


function bindClick(selector, handler) {
  const element = $(selector);
  if (element) element.addEventListener('click', handler);
}

function bindInput(selector, handler) {
  const element = $(selector);
  if (element) element.addEventListener('input', handler);
}

function bindChange(selector, handler) {
  const element = $(selector);
  if (element) element.addEventListener('change', handler);
}

function bindKeydown(selector, handler) {
  const element = $(selector);
  if (element) element.addEventListener('keydown', handler);
}

function setupAppEvents() {
  setupKeypad();

  const posAccessForm = $('#posAccessForm');
  if (posAccessForm) posAccessForm.addEventListener('submit', verifyPosAccess);

  const loginForm = $('#loginForm');
  if (loginForm) loginForm.addEventListener('submit', login);

  window.ClubVersusModules.authSession.bindDesktopExitControls?.();

  bindClick('#logoutBtn', logout);
  bindClick('#lockSessionBtn', lockEmployeeSection);
  bindClick('#refreshBtn', loadAll);
  bindClick('#topStationsBtn', () => setMainSection('stations'));
  bindClick('#topQuickOrderBtn', () => setMainSection('quick'));
  bindClick('#moduleHubBtn', openModuleHub);
  bindClick('#topDrawerBtn', () => openDenominationCounter(state.drawer ? 'close' : 'open'));
  bindClick('#quickDrawerPaymentActionBtn', openDrawerPaymentModal);

  bindClick('#openDrawerBtn', () => openDenominationCounter(state.drawer ? 'close' : 'open'));
  bindClick('#closeModalBtn', closeStationModal);
  bindClick('#modalBackdrop', closeStationModal);
  bindClick('#checkoutCashBtn', openCashPaymentModal);
  bindClick('#checkoutTransferBtn', openTransferPaymentModal);
  bindClick('#saveAccountBtn', saveStationAccount);
  bindClick('#transferSessionBtn', () => window.ClubVersusStations?.openStationTransferModal?.());
  bindClick('#applyFamilyDiscountBtn', () => window.ClubVersusModules?.order?.applyFamilyDiscountFromInput?.());
  bindClick('#clearFamilyDiscountBtn', () => window.ClubVersusModules?.order?.clearFamilyDiscount?.());
  bindInput('#familyDiscountCodeInput', (event) => { event.target.value = String(event.target.value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  bindClick('#paymentBackdrop', closeCashPaymentModal);
  bindClick('#closePaymentBtn', closeCashPaymentModal);
  bindInput('#cashReceivedInput', updateCashChange);
  bindClick('#confirmCashPaymentBtn', confirmCashPayment);
  bindClick('#paymentMethodCashBtn', () => {});
  bindClick('#paymentMethodTransferBtn', () => {
    closeCashPaymentModal();
    openTransferPaymentModal();
  });
  bindClick('#transferPaymentBackdrop', closeTransferPaymentModal);
  bindClick('#closeTransferPaymentBtn', closeTransferPaymentModal);
  bindClick('#cancelTransferPaymentBtn', closeTransferPaymentModal);
  bindClick('#confirmTransferPaymentBtn', confirmTransferPayment);
  bindClick('#closeTransferCodesBtn', closeTransferCodesModule);
  bindClick('#transferCodesBackdrop', closeTransferCodesModule);
  bindClick('#generateTransferCodeBtn', generateTransferCode);
  bindClick('#posMoreBtn', () => {});
  bindClick('#endSessionBtn', endSelectedSession);
  bindClick('#closeScanProductBtn', closeScanProductModal);
  bindClick('#scanProductBackdrop', closeScanProductModal);
  bindClick('#closeStationsConfigBtn', closeStationsConfigModule);
  bindClick('#stationsConfigBackdrop', closeStationsConfigModule);
  bindClick('#newStationConfigBtn', resetStationConfigForm);
  bindClick('#saveStationConfigBtn', saveStationConfig);
  bindClick('#deleteStationConfigBtn', deleteStationConfig);
  bindChange('#stationConfigPlatformSelect', () => renderStationModelOptions($('#stationConfigPlatformSelect').value));
  bindClick('#closeTimePricesModuleBtn', closeTimePricesModule);
  bindClick('#timePricesModuleBackdrop', closeTimePricesModule);
  bindClick('#saveTimePricesBtn', saveTimePrices);
  bindClick('#applyAllTimePricesBtn', applyTimePricesToAll);
  bindClick('#addGroupEventPriceBtn', addGroupEventPriceRow);
  bindClick('#saveGroupEventPricesBtn', saveGroupEventPrices);
  bindClick('#closePromotionsModuleBtn', closePromotionsModule);
  bindClick('#promotionsModuleBackdrop', closePromotionsModule);
  bindClick('#newPromotionBtn', resetPromotionForm);
  bindClick('#savePromotionBtn', savePromotion);
  bindClick('#deletePromotionBtn', deletePromotion);
  bindClick('#saveTournamentEntryDiscountsBtn', saveTournamentEntryDiscountRules);
  bindClick('#saveWelcomeBonusRuleBtn', () => saveBonusRule('WELCOME_MEMBERSHIP'));
  bindClick('#saveVisitBonusRuleBtn', () => saveBonusRule('VISIT_REWARD'));
  bindClick('#manualBonusMemberSearchBtn', searchManualBonusMember);
  bindClick('#grantManualBonusBtn', grantManualBonus);
  bindClick('#newMembershipPlanBtn', () => openMembershipPlanModal());
  bindClick('#closeMembershipPlanModalBtn', closeMembershipPlanModal);
  bindClick('#closeMembershipPlanFooterBtn', closeMembershipPlanModal);
  bindClick('#membershipPlanBackdrop', closeMembershipPlanModal);
  bindClick('#saveMembershipPlanBtn', saveMembershipPlan);
  bindClick('#archiveMembershipPlanBtn', archiveMembershipPlan);
  bindClick('#restoreMembershipPlanBtn', restoreMembershipPlan);
  bindChange('#manualBonusTypeSelect', updateManualBonusFields);
  bindChange('#manualBonusProductCategorySelect', renderManualBonusProductItemOptions);
  bindKeydown('#manualBonusMemberSearchInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      searchManualBonusMember();
    }
  });
  bindChange('#promotionScopeSelect', () => { renderPromotionStationOptions(); updatePromotionFormVisibility(); });
  bindChange('#promotionAllDayInput', updatePromotionFormVisibility);
  bindChange('#promotionNoEndInput', updatePromotionFormVisibility);
  bindClick('#closeTimeWarningBtn', closeTimeWarning);
  bindClick('#timeWarningBackdrop', closeTimeWarning);
  bindClick('#dismissTimeWarningBtn', closeTimeWarning);
  bindClick('#addTimeWarningBtn', addTimeFromWarning);
  bindClick('#closeTournamentEntryModalBtn', closeTournamentEntryModal);
  bindClick('#tournamentEntryBackdrop', closeTournamentEntryModal);
  bindClick('#searchTournamentEntryMemberBtn', searchTournamentEntryMembers);
  bindClick('#clearTournamentEntryMemberBtn', () => { state.tournamentEntryModal.selectedMember = null; updateTournamentEntryModalTotals(); });
  bindClick('#payTournamentEntryNowBtn', () => submitTournamentEntry('PAY'));
  bindClick('#saveTournamentEntryPendingBtn', () => submitTournamentEntry('PENDING'));
  bindClick('#closeTournamentAwardsDeliveryBtn', closeTournamentAwardsDeliveryModal);
  bindClick('#closeTournamentAwardsDeliveryFooterBtn', closeTournamentAwardsDeliveryModal);
  bindClick('#tournamentAwardsDeliveryBackdrop', closeTournamentAwardsDeliveryModal);
  bindClick('#deliverAllTournamentAwardsBtn', deliverAllTournamentAwardsFromPos);
  bindTournamentAwardsDeliveryDelegatedClicks();
  bindKeydown('#tournamentEntryMemberSearchInput', (event) => { if (event.key === 'Enter') { event.preventDefault(); searchTournamentEntryMembers(); } });
  bindKeydown('#tournamentEntryNameInput', (event) => { if (event.key === 'Enter') { event.preventDefault(); submitTournamentEntry('PAY'); } });

  bindClick('#cancelScanProductBtn', closeScanProductModal);
  bindClick('#saveScanProductBtn', saveScannedProduct);
  bindKeydown('#scanProductNameInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      saveScannedProduct();
    }
  });

  bindClick('#openMemberPickerBtn', openMemberPicker);
  bindClick('#closeMemberPickerBtn', closeMemberPicker);
  bindClick('#searchMemberBtn', searchMembers);
  bindClick('#clearMemberBtn', clearSelectedMember);
  bindClick('#openCreateMemberBtn', openCreateMember);
  bindClick('#saveNewMemberBtn', createMemberFromModal);
  bindClick('#cancelNewMemberBtn', closeCreateMember);
  bindKeydown('#memberSearchInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      searchMembers();
    }
  });

  bindClick('#closeModuleHubBtn', closeModuleHub);
  bindClick('#moduleHubBackdrop', closeModuleHub);
  bindClick('#saveAppSettingsBtn', saveAppSettings);
  bindChange('#drawerWorkflowToggle', () => {
    if (typeof previewAppSettings === 'function') previewAppSettings();
    else renderAppSettingsPanel({ keepDraft: true });
  });
  document.querySelectorAll('[data-module]').forEach((btn) => {
    btn.addEventListener('click', () => handleModuleClick(btn.dataset.module, btn.dataset.permission));
  });

  bindClick('#closeDrawerModuleBtn', closeDrawerModule);
  bindClick('#drawerModuleBackdrop', closeDrawerModule);
  bindClick('#drawerOpenActionBtn', () => openDenominationCounter('open'));
  bindClick('#drawerPaymentActionBtn', openDrawerPaymentModal);
  bindClick('#drawerCloseActionBtn', () => openDenominationCounter('close'));
  bindClick('#closeDrawerPaymentBtn', closeDrawerPaymentModal);
  bindClick('#drawerPaymentBackdrop', closeDrawerPaymentModal);
  bindClick('#cancelDrawerPaymentBtn', closeDrawerPaymentModal);
  bindClick('#confirmDrawerPaymentBtn', confirmDrawerPayment);
  bindClick('#closeDenominationBtn', closeDenominationCounter);
  bindClick('#denominationBackdrop', closeDenominationCounter);
  bindClick('#confirmDenominationBtn', confirmDenominationCounter);
  bindInput('#denominationOtherInput', updateDenominationTotal);

  bindClick('#closeMembersModuleBtn', closeMembersModule);
  bindClick('#membersModuleBackdrop', closeMembersModule);
  bindClick('#membersModuleSearchBtn', searchMembersModule);
  bindKeydown('#membersModuleSearchInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      searchMembersModule();
    }
  });

  bindClick('#closeInventoryModuleBtn', closeInventoryModule);
  bindClick('#inventoryModuleBackdrop', closeInventoryModule);
  bindInput('#inventorySearchInput', renderInventoryModule);
  bindChange('#inventoryCategoryFilter', renderInventoryModule);
  bindClick('#newInventoryProductBtn', () => { resetInventoryForm(); openInventoryProductEditor(); });
  bindClick('#closeInventoryProductEditorBtn', closeInventoryProductEditor);
  bindClick('#inventoryProductEditorBackdrop', closeInventoryProductEditor);
  bindClick('#saveInventoryProductBtn', saveInventoryProduct);
  bindClick('#deleteInventoryProductBtn', deleteInventoryProduct);
  bindClick('#addInventoryComboComponentBtn', addInventoryComboComponent);
  bindChange('#inventoryCategoryInput', renderInventoryComboBuilder);
  bindInput('#inventoryComboMinutesInput', renderInventoryComboBuilder);
  bindChange('#inventoryComboPlayerCountInput', renderInventoryComboBuilder);
  bindClick('#applyInventoryAdjustBtn', applyInventoryAdjustment);
  bindInput('#posCategorySearchInput', renderPosCategoryList);
  bindInput('#posCategoryItemsSearchInput', renderPosCategoryItems);
  bindClick('#newPosCategoryBtn', () => { resetPosCategoryForm(); openPosCategoryEditor(); });
  bindClick('#closePosCategoryEditorBtn', closePosCategoryEditor);
  bindClick('#posCategoryEditorBackdrop', closePosCategoryEditor);
  bindClick('#savePosCategoryBtn', savePosCategory);
  bindClick('#deletePosCategoryBtn', deletePosCategory);
  bindClick('#assignProductToCategoryBtn', assignProductToCurrentCategory);
  bindInput('#modifierSearchInput', renderModifierGroupsList);
  bindClick('#newModifierGroupBtn', resetModifierGroupEditor);
  document.querySelectorAll('[data-inventory-view]').forEach((btn) => {
    btn.addEventListener('click', () => showInventoryView(btn.dataset.inventoryView));
  });

  bindClick('#closeTournamentsModuleBtn', closeTournamentsModule);
  bindClick('#tournamentsModuleBackdrop', closeTournamentsModule);
  bindClick('#newTournamentBtn', resetTournamentForm);
  bindInput('#tournamentWinnersCountInput', renderTournamentPrizeConfigInputs);
  bindClick('#saveTournamentBtn', saveTournament);
  bindClick('#startTournamentBtn', startVersusMode);
  bindClick('#cancelTournamentBtn', cancelTournament);
  bindClick('#deleteTournamentBtn', deleteTournament);
  bindClick('#addParticipantBtn', addTournamentParticipant);
  bindClick('#participantMemberSearchBtn', searchTournamentParticipantMember);
  bindClick('#clearParticipantMemberBtn', () => clearTournamentParticipantMember(true));
  bindKeydown('#participantMemberSearchInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      searchTournamentParticipantMember();
    }
  });
  bindClick('#generateBracketBtn', generateTournamentBracket);
  bindClick('#assignTournamentAwardsBtn', assignTournamentAwards);
  window.ClubVersusTournaments?.bindTournamentAwardsDeliveryDelegatedClicks?.();
  bindKeydown('#participantNameInput', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      addTournamentParticipant();
    }
  });

  bindClick('#closeReportsModuleBtn', closeReportsModule);
  bindClick('#reportsModuleBackdrop', closeReportsModule);
  document.querySelectorAll('[data-report-preset]').forEach((btn) => {
    btn.addEventListener('click', () => setReportPreset(btn.dataset.reportPreset));
  });
  bindClick('#applyReportRangeBtn', applyCustomReportRange);
  bindClick('#applyAuditFiltersBtn', applyAuditFilters);
  bindChange('#auditEmployeeFilter', applyAuditFilters);
  bindChange('#auditEventTypeFilter', applyAuditFilters);
  bindChange('#auditStationFilter', applyAuditFilters);
  bindChange('#auditLimitFilter', applyAuditFilters);
  bindKeydown('#reportStartDate', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      applyCustomReportRange();
    }
  });
  bindKeydown('#reportEndDate', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      applyCustomReportRange();
    }
  });

  bindClick('#closeEmployeesModuleBtn', closeEmployeesModule);
  bindClick('#employeesModuleBackdrop', closeEmployeesModule);
  bindClick('#closeFinancesModuleBtn', closeFinancesModule);
  bindClick('#financesModuleBackdrop', closeFinancesModule);
  bindClick('#applyFinanceRangeBtn', () => { state.financeRange = { preset: 'custom', startDate: $('#financeStartDate')?.value || '', endDate: $('#financeEndDate')?.value || '' }; loadFinanceSummary().then(() => { if (!document.querySelector('[data-finance-panel="payroll"]')?.classList.contains('hidden')) return loadPayroll(); }).catch((error) => showToast(error.message)); });
  bindChange('#financeStartDate', () => { state.financeRange = { preset: 'custom', startDate: $('#financeStartDate')?.value || '', endDate: $('#financeEndDate')?.value || '' }; loadFinanceSummary().then(() => { if (!document.querySelector('[data-finance-panel="payroll"]')?.classList.contains('hidden')) return loadPayroll(); }).catch((error) => showToast(error.message)); });
  bindChange('#financeEndDate', () => { state.financeRange = { preset: 'custom', startDate: $('#financeStartDate')?.value || '', endDate: $('#financeEndDate')?.value || '' }; loadFinanceSummary().then(() => { if (!document.querySelector('[data-finance-panel="payroll"]')?.classList.contains('hidden')) return loadPayroll(); }).catch((error) => showToast(error.message)); });
  document.querySelectorAll('[data-finance-preset]').forEach((btn) => btn.addEventListener('click', () => setFinancePreset(btn.dataset.financePreset).then(() => { if (!document.querySelector('[data-finance-panel="payroll"]')?.classList.contains('hidden')) return loadPayroll(); }).catch((error) => showToast(error.message))));
  document.querySelectorAll('[data-finance-tab]').forEach((btn) => btn.addEventListener('click', () => setFinanceTab(btn.dataset.financeTab)));
  $('#financeInvestmentForm')?.addEventListener('submit', saveFinanceInvestment);
  $('#financeExpenseForm')?.addEventListener('submit', saveFinanceExpense);
  $('#financeRecurringForm')?.addEventListener('submit', saveFinanceRecurring);
  bindChange('#payrollShowOwnersInput', () => { state.payrollShowOwners = Boolean($('#payrollShowOwnersInput')?.checked); renderPayrollModule(); });
  bindChange('#payrollEmployeeSelect', () => fillPayrollEmployeeForm($('#payrollEmployeeSelect')?.value));
  bindClick('#savePayrollEmployeeBtn', savePayrollEmployee);
  bindClick('#savePayrollShiftBtn', savePayrollShift);
  bindClick('#savePayrollRotationBtn', savePayrollRotationRule);
  bindClick('#payrollPrevMonthBtn', () => changePayrollCalendarMonth(-1).catch((error) => showToast(error.message || 'No se pudo cargar el mes anterior')));
  bindClick('#payrollNextMonthBtn', () => changePayrollCalendarMonth(1).catch((error) => showToast(error.message || 'No se pudo cargar el próximo mes')));
  bindClick('#generatePayrollRotationBtn', generatePayrollRotation);
  bindClick('#printPayrollScheduleBtn', printPayrollSchedule);
  bindClick('#savePayrollPaymentBtn', savePayrollPayment);
  bindClick('#closeMaintenanceModuleBtn', closeMaintenanceModule);
  bindClick('#maintenanceModuleBackdrop', closeMaintenanceModule);
  bindClick('#cancelCleanupBtn', closeMaintenanceModule);
  bindInput('#cleanupConfirmInput', updateCleanupButton);
  bindClick('#runCleanupBtn', runMaintenanceCleanup);
  bindClick('#saveEmployeeBtn', saveEmployee);
  bindClick('#newEmployeeBtn', () => resetEmployeeForm(true));
  bindClick('#resetEmployeeFormBtn', resetEmployeeForm);
  bindClick('#deleteEmployeeBtn', deleteEmployee);
  bindClick('#closeEmployeeEditorBtn', closeEmployeeEditor);
  bindClick('#employeeEditorOverlay', closeEmployeeEditor);
  bindClick('#toggleEmployeePermissionsBtn', toggleEmployeePermissions);
  $('#employeeRoleInput')?.addEventListener('change', () => {
    const id = $('#employeeIdInput')?.value;
    const employee = state.employees.find((item) => item.id === id) || null;
    renderEmployeePermissions(employee);
  });

  bindClick('#closePermissionsModuleBtn', closePermissionsModule);
  bindClick('#permissionsModuleBackdrop', closePermissionsModule);
  bindClick('#savePermissionsBtn', savePermissions);
  document.addEventListener('keydown', handleGlobalScanner);
}

setupAppEvents();
updatePinUI();
checkPosAccess().catch(() => setView());
if ($('#topStationsBtn')) $('#topStationsBtn').classList.add('active');

setInterval(() => {
  if (state.token && state.activeMainSection === 'stations') renderStations(state.stations);
}, 1000);

if (state.token) {
  loadAll()
    .then(() => promptOpenDrawerIfRequired())
    .catch((error) => showToast(error.message));
}
