(function () {
  window.ClubVersusModals = window.ClubVersusModals || {};

  function createPaymentFlow(deps) {
    const {
      state,
      $,
      setText,
      money,
      showToast,
      requireOpenDrawerForSales,
      closeStationModal,
      checkoutStation,
      awaitEndSession,
      getOrderTotal,
      getActiveSessionPendingTotal,
      getOpenModeChargePreview,
      hasNewOrderContent,
      showTransferPaymentError,
      clearTransferPaymentError,
      showAppDialog
    } = deps;

    let cashAutoSubmitting = false;

    function getActivePaymentTotal() {
      if (state.customPaymentFlow?.active) return Number(state.customPaymentFlow.total || 0);
      if (state.pendingEndSession) return getOpenModeChargePreview().amount;
      if (state.pendingAccountPayment) return getActiveSessionPendingTotal();
      return getOrderTotal();
    }

    function getPaymentRequiresCheckout() {
      if (state.customPaymentFlow?.active) return Number(state.customPaymentFlow.total || 0) > 0;
      if (state.pendingEndSession) return true;
      if (state.pendingAccountPayment) return getActiveSessionPendingTotal() > 0;
      const total = getOrderTotal();
      const hasFreeTime = Boolean(state.order.welcomeBonus || state.order.visitReward);
      const hasProductBonus = Boolean(state.order.productBonus);
      const hasFamilyDiscountCheckout = Boolean(state.order.familyDiscount) && hasNewOrderContent();
      return total > 0 || hasFreeTime || hasProductBonus || hasFamilyDiscountCheckout;
    }

    function getReceiptCashierName() {
      return state.user?.full_name || state.user?.fullName || state.user?.name || state.user?.username || '';
    }

    function getReceiptMemberName() {
      return state.selectedMember?.full_name || state.selectedMember?.name || state.selectedStation?.member_name || '';
    }

    function getReceiptStationName() {
      if (state.posMode !== 'station' && !state.selectedStation) return '';
      return state.selectedStation?.name || state.selectedStation?.station_name || '';
    }

    function getReceiptOrderLines(total = 0) {
      const lines = [];
      const station = state.selectedStation;

      if (state.pendingEndSession) {
        lines.push({ name: station ? `Tiempo ${station.name || 'estación'}` : 'Tiempo de juego', quantity: 1, total });
        return lines;
      }

      if (state.pendingAccountPayment) {
        lines.push({ name: station ? `Cuenta ${station.name || 'estación'}` : 'Cuenta pendiente', quantity: 1, total });
        return lines;
      }

      if (station && state.order?.gameMinutes > 0) {
        const orderTotal = typeof getOrderTotal === 'function' ? Number(getOrderTotal() || 0) : total;
        const productTotal = (state.order.items || []).reduce((sum, item) => {
          const freeQty = typeof getOrderItemFreeQty === 'function' ? getOrderItemFreeQty(item) : 0;
          const paidQty = Math.max(0, Number(item.quantity || 0) - Number(freeQty || 0));
          return sum + paidQty * Number(item.price || 0);
        }, 0);
        const extraTotal = (state.order.extras || []).reduce((sum, extra) => sum + Number(extra.price || 0) * Number(extra.quantity || 1), 0);
        const tournamentTotal = (state.order.tournamentEntries || []).reduce((sum, entry) => sum + Number(entry.entryFee || 0), 0);
        const timeTotal = Math.max(0, orderTotal - productTotal - extraTotal - tournamentTotal);
        lines.push({ name: `Tiempo ${state.order.gameMinutes} min`, quantity: 1, total: timeTotal, note: station.name || '' });
      }

      if (station && state.order?.freeMode) {
        lines.push({ name: 'Modo libre', quantity: 1, total: 0, note: station.name || 'Cobrar al final' });
      }

      if (state.order?.welcomeBonus) {
        lines.push({ name: `Bono bienvenida ${state.order.welcomeBonus.minutes || 0} min`, quantity: 1, total: 0 });
      }

      if (state.order?.visitReward) {
        lines.push({ name: `Bono minutos ${state.order.visitReward.minutes || 0} min`, quantity: 1, total: 0 });
      }

      (state.order?.extras || []).forEach((extra) => {
        lines.push({ name: `Extra ${extra.name || 'servicio'}`, quantity: Number(extra.quantity || 1), total: Number(extra.price || 0) * Number(extra.quantity || 1) });
      });

      (state.order?.tournamentEntries || []).forEach((entry) => {
        lines.push({ name: `Torneo ${entry.playerName || 'participante'}`, quantity: 1, total: Number(entry.entryFee || 0), note: entry.tournamentName || '' });
      });

      (state.order?.items || []).forEach((item) => {
        const freeQty = typeof getOrderItemFreeQty === 'function' ? getOrderItemFreeQty(item) : 0;
        const paidQty = Math.max(0, Number(item.quantity || 0) - Number(freeQty || 0));
        lines.push({
          name: item.name || 'Producto',
          quantity: Number(item.quantity || 1),
          total: Number(item.price || 0) * paidQty,
          note: freeQty > 0 ? `${freeQty} por bono` : ''
        });
      });

      if (!lines.length && total > 0) lines.push({ name: 'Venta', quantity: 1, total });
      return lines;
    }

    function buildReceiptSnapshot({ paymentMethod = 'CASH', received = 0, change = 0, total = 0 } = {}) {
      return {
        businessName: 'Club Versus',
        date: new Date().toISOString(),
        cashier: getReceiptCashierName(),
        station: getReceiptStationName(),
        member: getReceiptMemberName(),
        saleLabel: state.posMode === 'quick' ? 'Venta rápida' : '',
        paymentMethod,
        received,
        change,
        total,
        lines: getReceiptOrderLines(total)
      };
    }

    async function printReceiptSnapshot(receipt) {
      const desktopApi = window.clubVersusDesktop;
      if (!desktopApi?.printReceipt) {
        showToast('Impresión de recibo no disponible en esta ventana');
        return false;
      }
      try {
        await desktopApi.printReceipt({ receipt });
        showToast('Recibo enviado a impresora');
        return true;
      } catch (error) {
        showToast(error.message || 'No se pudo imprimir recibo');
        return false;
      }
    }

    function clearCashPaymentError() {
      const error = $('#cashPaymentError');
      if (!error) return;
      error.classList.add('hidden');
      error.textContent = '';
    }

    function showCashPaymentError(message) {
      const error = $('#cashPaymentError');
      if (!error) {
        showToast(message);
        return;
      }
      error.textContent = message;
      error.classList.remove('hidden');
    }

    function updateCashChange() {
      clearCashPaymentError();
      if (state.cashOtherAmountMode) state.cashSelectedAmount = null;
    }

    async function openCashPaymentModal() {
      if (!requireOpenDrawerForSales(true)) return;
      document.querySelectorAll('.app-dialog-modal').forEach((dialog) => dialog.remove());

      state.pendingAccountPayment = state.posMode === 'station' && !hasNewOrderContent() && getActiveSessionPendingTotal() > 0;
      const total = getActivePaymentTotal();

      if (!getPaymentRequiresCheckout()) {
        showToast('No hay nada para cobrar');
        return;
      }

      // If the sale is completely covered by a bonus, no change is needed.
      // Close it directly so the cashier does not have to confirm RD$0.00 in cash.
      if (total <= 0) {
        if (state.pendingEndSession) {
          const success = await awaitEndSession('CASH');
          if (success) closeCashPaymentModal();
          return;
        }
        checkoutStation('CASH');
        return;
      }

      setText('#paymentTotalAmount', money(total));
      clearCashPaymentError();
      state.cashOtherAmountMode = false;
      state.cashSelectedAmount = null;

      const input = $('#cashReceivedInput');
      if (input) input.value = '';
      renderCashFastButtons();
      bindCashOtherAmountInput();

      const modal = $('#paymentModal');
      if (modal) window.ClubVersusCore?.modalManager?.open?.(modal, { base: 11000 });

      setTimeout(() => input?.focus(), 50);
    }

    function renderCashFastButtons() {
      const grid = document.querySelector('.cash-fast-grid');
      const inputWrap = document.querySelector('.cash-payment-panel label');
      if (!grid) return;
      const total = getActivePaymentTotal();
      const bills = [50, 100, 200, 500, 1000, 2000].filter((amount) => amount >= total);
      const selected = Number(state.cashSelectedAmount || 0);
      const exactSelected = selected > 0 && Math.abs(selected - total) < 0.01 && !state.cashOtherAmountMode;
      const buttons = [
        `<button type="button" id="cashExactBtn" class="${exactSelected ? 'selected' : ''}">Exacto</button>`,
        ...bills.map((amount) => `<button type="button" data-cash-set-amount="${amount}" class="${selected === amount && !state.cashOtherAmountMode ? 'selected' : ''}">${money(amount)}</button>`),
        `<button type="button" id="cashOtherAmountBtn" class="secondary ${state.cashOtherAmountMode ? 'selected' : ''}">Otro monto</button>`
      ];
      grid.innerHTML = buttons.join('');
      if (inputWrap) inputWrap.classList.toggle('hidden', !state.cashOtherAmountMode);
      grid.querySelector('#cashExactBtn')?.addEventListener('click', setCashExactAmount);
      grid.querySelector('#cashOtherAmountBtn')?.addEventListener('click', () => {
        state.cashOtherAmountMode = true;
        state.cashSelectedAmount = null;
        renderCashFastButtons();
        bindCashOtherAmountInput();
        const input = $('#cashReceivedInput');
        if (input) {
          input.value = '';
          setTimeout(() => input.focus(), 30);
        }
      });
      grid.querySelectorAll('[data-cash-set-amount]').forEach((btn) => {
        btn.addEventListener('click', () => setCashReceivedAmount(btn.dataset.cashSetAmount));
      });
    }

    async function setCashReceivedAmount(amount) {
      const input = $('#cashReceivedInput');
      if (!input) return;
      const received = Number(amount || 0);
      input.value = String(received);
      state.cashOtherAmountMode = false;
      state.cashSelectedAmount = received;
      clearCashPaymentError();
      renderCashFastButtons();
      await confirmCashPayment({ auto: true });
    }

    function closeCashPaymentModal() {
      const modal = $('#paymentModal');
      if (modal) {
        window.ClubVersusCore?.modalManager?.close?.(modal);
        modal.style.pointerEvents = 'none';
      }
      clearCashPaymentError();
      state.pendingAccountPayment = false;
      state.cashOtherAmountMode = false;
      state.cashSelectedAmount = null;
    }

    function addCashFastAmount(amount) {
      const input = $('#cashReceivedInput');
      if (!input) return;
      const current = Number(input.value || 0);
      input.value = String(current + Number(amount || 0));
      clearCashPaymentError();
    }

    async function setCashExactAmount() {
      const input = $('#cashReceivedInput');
      if (!input) return;
      const total = getActivePaymentTotal();
      input.value = String(total);
      state.cashOtherAmountMode = false;
      state.cashSelectedAmount = total;
      clearCashPaymentError();
      renderCashFastButtons();
      await confirmCashPayment({ auto: true });
    }

    function clearCashAmount() {
      const input = $('#cashReceivedInput');
      if (input) input.value = '';
      state.cashSelectedAmount = null;
      clearCashPaymentError();
      renderCashFastButtons();
    }

    function bindCashOtherAmountInput() {
      const input = $('#cashReceivedInput');
      if (!input || input.dataset.cvAutoCashBound === 'true') return;
      input.dataset.cvAutoCashBound = 'true';

      input.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        confirmCashPayment({ auto: true });
      });

      input.addEventListener('change', () => {
        if (!state.cashOtherAmountMode) return;
        const received = Number(input.value || 0);
        const total = getActivePaymentTotal();
        if (received >= total && total > 0) confirmCashPayment({ auto: true });
      });
    }

    async function confirmCashPayment(options = {}) {
      if (cashAutoSubmitting) return;
      cashAutoSubmitting = true;
      try {
      const total = getActivePaymentTotal();
      const input = $('#cashReceivedInput');
      const received = Number(input?.value || 0);

      clearCashPaymentError();

      if (total > 0 && received < total) {
        showCashPaymentError('El monto recibido es menor que el total');
        input?.focus();
        return;
      }

      const change = Math.max(0, received - total);
      const receiptSnapshot = buildReceiptSnapshot({ paymentMethod: 'CASH', received, change, total });
      if (window.ClubVersusHardware?.kickCashDrawerForEvent) {
        window.ClubVersusHardware.kickCashDrawerForEvent('cash-payment', { toast: true });
      }
      const paymentContext = {
        mode: state.posMode,
        stationId: state.selectedStation?.id || null,
        pendingEndSession: Boolean(state.pendingEndSession),
        closeAfterPendingPayment: Boolean(state.closeAfterPendingPayment),
        custom: state.customPaymentFlow?.active ? { ...state.customPaymentFlow } : null
      };
      state.paymentFlowContext = paymentContext;

      let success = false;
      if (paymentContext.custom?.active && typeof paymentContext.custom.onConfirm === 'function') {
        success = await paymentContext.custom.onConfirm({ paymentMethod: 'CASH', received, change, total });
      } else {
        success = paymentContext.pendingEndSession
          ? await awaitEndSession('CASH', '', '', { deferClose: true })
          : await checkoutStation('CASH');
      }
      if (!success) {
        state.paymentFlowContext = null;
        return;
      }

      closeCashPaymentModal();
      await new Promise((resolve) => setTimeout(resolve, 25));
      await showChangeAndReceiptPrompts(change, receiptSnapshot);

      if (!paymentContext.custom?.active && (paymentContext.mode === 'station' || paymentContext.mode === 'quick' || paymentContext.pendingEndSession)) {
        closeStationModal();
      }

      if (paymentContext.closeAfterPendingPayment) {
        state.closeAfterPendingPayment = false;
        const refreshed = paymentContext.stationId ? state.stations.find((item) => item.id === paymentContext.stationId) : null;
        if (refreshed?.status === 'BUSY') await awaitEndSession('CASH');
      }

      if (success && paymentContext.custom?.active) state.customPaymentFlow = null;
      state.paymentFlowContext = null;
      } finally {
        cashAutoSubmitting = false;
      }
    }

    async function showChangeAndReceiptPrompts(change, receiptSnapshot = null) {
      await showAppDialog({
        title: 'Cambio a entregar',
        subtitle: 'Abre la caja y entrega el cambio.',
        amount: money(change),
        primaryText: 'Listo'
      });

      const receiptAnswer = await showAppDialog({
        title: '¿Quieres recibo?',
        subtitle: 'Imprime solo si el cliente lo pidió.',
        primaryText: 'Imprimir recibo',
        secondaryText: 'No imprimir'
      });

      if (receiptAnswer === 'primary') await printReceiptSnapshot(receiptSnapshot || buildReceiptSnapshot({ paymentMethod: 'CASH', received: getActivePaymentTotal(), change, total: getActivePaymentTotal() }));
    }

    function openTransferPaymentModal() {
      if (!requireOpenDrawerForSales(true)) return;

      const total = getActivePaymentTotal();
      const hasFreeTime = Boolean(state.order.welcomeBonus || state.order.visitReward);
      const hasFamilyDiscountCheckout = Boolean(state.order.familyDiscount) && hasNewOrderContent();

      if (total <= 0 && !hasFreeTime && !hasFamilyDiscountCheckout) {
        showToast('No hay nada para cobrar');
        return;
      }

      if (total <= 0 && hasFamilyDiscountCheckout) {
        checkoutStation('CASH');
        return;
      }

      setText('#transferPaymentTotal', money(total));
      const input = $('#transferReferenceInput');
      const codeInput = $('#transferAuthorizationCodeInput');
      if (input) input.value = '';
      if (codeInput) codeInput.value = '';
      clearTransferPaymentError();

      const modal = $('#transferPaymentModal');
      if (modal) window.ClubVersusCore?.modalManager?.open?.(modal, { base: 11000 });

      setTimeout(() => input?.focus(), 50);
    }

    function closeTransferPaymentModal() {
      const modal = $('#transferPaymentModal');
      if (modal) window.ClubVersusCore?.modalManager?.close?.(modal);
      clearTransferPaymentError();
    }

    async function confirmTransferPayment() {
      const reference = $('#transferReferenceInput')?.value?.trim() || '';
      const transferAuthorizationCode = $('#transferAuthorizationCodeInput')?.value?.trim() || '';
      const total = getActivePaymentTotal();

      clearTransferPaymentError();

      if (!/^\d{6}$/.test(transferAuthorizationCode)) {
        showTransferPaymentError('Ingresa el código administrativo de 6 dígitos');
        $('#transferAuthorizationCodeInput')?.focus();
        return;
      }

      const paymentContext = {
        mode: state.posMode,
        stationId: state.selectedStation?.id || null,
        pendingEndSession: Boolean(state.pendingEndSession),
        closeAfterPendingPayment: Boolean(state.closeAfterPendingPayment),
        custom: state.customPaymentFlow?.active ? { ...state.customPaymentFlow } : null
      };
      state.paymentFlowContext = paymentContext;

      const shouldCloseSessionAfterPayment = state.closeAfterPendingPayment;
      const success = paymentContext.custom?.active && typeof paymentContext.custom.onConfirm === 'function'
        ? await paymentContext.custom.onConfirm({ paymentMethod: 'TRANSFER', reference, transferAuthorizationCode, total })
        : (state.pendingEndSession
          ? await awaitEndSession('TRANSFER', reference, transferAuthorizationCode)
          : await checkoutStation('TRANSFER', reference, transferAuthorizationCode));
      if (success) {
        closeTransferPaymentModal();
        if (!paymentContext.custom?.active && (paymentContext.mode === 'station' || paymentContext.pendingEndSession)) closeStationModal();
        if (!paymentContext.custom?.active && shouldCloseSessionAfterPayment) {
          state.closeAfterPendingPayment = false;
          const refreshed = paymentContext.stationId ? state.stations.find((item) => item.id === paymentContext.stationId) : null;
          if (refreshed?.status === 'BUSY') await awaitEndSession('TRANSFER', reference, transferAuthorizationCode);
        }
      }
      if (success && paymentContext.custom?.active) state.customPaymentFlow = null;
      state.paymentFlowContext = null;
    }

    return {
      getActivePaymentTotal,
      getPaymentRequiresCheckout,
      clearCashPaymentError,
      showCashPaymentError,
      updateCashChange,
      openCashPaymentModal,
      renderCashFastButtons,
      setCashReceivedAmount,
      closeCashPaymentModal,
      addCashFastAmount,
      setCashExactAmount,
      clearCashAmount,
      confirmCashPayment,
      showChangeAndReceiptPrompts,
      openTransferPaymentModal,
      closeTransferPaymentModal,
      confirmTransferPayment
    };
  }

  window.ClubVersusPaymentFlow = window.ClubVersusPaymentFlow || {};
  window.ClubVersusPaymentFlow.create = createPaymentFlow;
  window.ClubVersusModals['payment-flow'] = window.ClubVersusPaymentFlow;
})();
