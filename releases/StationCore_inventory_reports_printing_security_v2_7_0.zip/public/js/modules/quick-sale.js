(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

  function getQuickOrderCategories() {
    const categories = getProductCategories()
      .filter((category) => category.is_active !== false && category.show_in_quick !== false)
      .map((category) => ({
        id: category.code,
        label: category.name,
        color: category.color,
        buttonSize: category.button_size
      }));
    if ((state.posTournaments || []).length) {
      categories.push({ id: 'TOURNAMENT', label: 'Torneos', color: '#8b5cf6', buttonSize: 'wide' });
    }
    return categories;
  }

  function getFirstQuickOrderCategory() {
    const availableCategories = new Set(state.products.map((product) => product.category));
    const first = getQuickOrderCategories().find((category) => category.id === 'TOURNAMENT' || availableCategories.has(category.id));
    return first?.id || 'DRINK';
  }

  function openQuickOrderModal() {
    state.posMode = 'quick';
    state.selectedStation = null;
    state.selectedMember = null;
    resetOrder();
    state.activeMenuCategory = getFirstQuickOrderCategory();

    const modal = $('#stationModal');
    if (!modal) return;
    modal.className = 'modal quick-order-mode';
    openModalElement(modal, { base: 5000 });
    $('#modalStatus').textContent = 'VENTA RÁPIDA';
    $('#modalStatus').className = 'modal-status available';
    $('#modalStationName').textContent = 'Venta rápida';
    $('#modalStationMeta').textContent = '';
    $('#orderStationLabel').textContent = 'Venta rápida';
    $('#posWorkspaceTitle').textContent = 'Venta rápida';
    $('#posWorkspaceSubtitle').textContent = 'Sin estación asignada';
    $('#endSessionBtn').classList.add('hidden');
    $('#openGamePickerBtn')?.classList.add('hidden');
    $('#openGamePickerBtn')?.classList.remove('selected');
    if ($('#gameQuickLabel')) $('#gameQuickLabel').textContent = 'Juego no especificado';
    $('#memberSearchInput').value = '';
    $('#createMemberName').value = '';
    $('#createMemberPhone').value = '';
    $('#createMemberPortalUsername').value = '';
    $('#createMemberPortalPin').value = '';
    $('#createMemberPortalPinConfirm').value = '';
    $('#createMemberBirthDate').value = '';
    $('#createMemberBox').classList.add('hidden');

    renderMemberSelection();
    renderTimeOptions();
    renderModalProducts();
    renderOrder();
  }

  async function checkoutQuickOrder(paymentMethod, paymentReference = '', transferAuthorizationCode = '') {
    if (state.order.gameMinutes > 0) {
      showToast('La venta rápida no permite horas');
      return false;
    }

    if (state.order.items.length === 0 && !(state.order.tournamentEntries || []).length) {
      showToast('Agrega productos o inscripción');
      return false;
    }

    if (getOrderTotal() <= 0 && !state.order.productBonus && !(state.order.tournamentEntries || []).length) {
      showToast('Hay artículos en RD$0 sin bono aplicado. Revisa la orden.');
      return false;
    }

    try {
      const result = await api('/sales', {
        method: 'POST',
        body: JSON.stringify({
          paymentMethod,
          paymentReference,
          transferAuthorizationCode,
          memberId: state.selectedMember?.id || null,
          visitRewardId: state.order.productBonus?.id || null,
          rewardSnackQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'SNACK' ? Number(state.order.productBonus.quantity || 0) : 0,
          rewardDrinkQty: !state.order.productBonus?.productId && state.order.productBonus?.category === 'DRINK' ? Number(state.order.productBonus.quantity || 0) : 0,
          rewardProductId: state.order.productBonus?.productId || null,
          rewardProductQty: state.order.productBonus?.productId ? Number(state.order.productBonus.quantity || 0) : 0,
          items: state.order.items.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            printDetails: item.printDetails || null,
            modifierOptionIds: (item.modifiers || []).map((modifier) => modifier.optionId)
          })),
          tournamentEntries: (state.order.tournamentEntries || []).map((entry) => ({
            tournamentId: entry.tournamentId,
            participantId: entry.participantId || null,
            playerName: entry.playerName || '',
            phone: entry.phone || '',
            nickname: entry.nickname || '',
            memberId: entry.memberId || null
          }))
        })
      });

      showToast(Number(result.sale.total || 0) > 0 ? `Venta cobrada: ${money(result.sale.total)}` : 'Canje completado');
      resetOrder();
      state.selectedMember = null;

      const refreshQuickSaleUi = async () => {
        try {
          await loadAll();
          if (state.posMode === 'quick') {
            renderMemberSelection();
            renderModalProducts();
            renderOrder();
          }
        } catch (refreshError) {
          console.warn('No se pudo refrescar Venta rápida después del cobro', refreshError);
          showToast('Venta cobrada. Refresca la pantalla si no ves el inventario actualizado.');
        }
      };

      if (paymentMethod !== 'CASH') {
        await refreshQuickSaleUi();
        closeStationModal();
      } else {
        // No bloquear el flujo de efectivo/cambio esperando que carguen todos los datos.
        // Si loadAll falla o tarda, la venta ya quedó cobrada y el modal de cambio debe continuar.
        refreshQuickSaleUi();
      }
      return true;
    } catch (error) {
      if (paymentMethod === 'TRANSFER') showTransferPaymentError(error.message);
      else showToast(error.message);
      return false;
    }
  }

  window.ClubVersusQuickSale = {
    getQuickOrderCategories,
    getFirstQuickOrderCategory,
    openQuickOrderModal,
    checkoutQuickOrder
  };

  window.ClubVersusModules['quick-sale'] = window.ClubVersusQuickSale;
})();
