(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};
  window.ClubVersusModules.inventory = window.ClubVersusModules.inventory || {};
})();

// Módulo de Inventario, categorías POS y modificadores.
// Mantiene las mismas funciones globales usadas por app.js y los botones existentes.

function showInventoryView(view = 'items') {
  const normalized = ['items', 'categories', 'modifiers'].includes(view) ? view : 'items';
  if (normalized === 'modifiers') renderModifiersModule();
  document.querySelectorAll('[data-inventory-view]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.inventoryView === normalized);
  });
  document.querySelectorAll('[data-inventory-panel]').forEach((panel) => {
    panel.classList.toggle('hidden', panel.dataset.inventoryPanel !== normalized);
  });
}

function openInventoryProductEditor() {
  const modal = $('#inventoryProductEditorModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
  $('#inventoryNameInput')?.focus();
}

function closeInventoryProductEditor() {
  const modal = $('#inventoryProductEditorModal');
  if (!modal) return;
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
}

function openPosCategoryEditor() {
  const modal = $('#posCategoryEditorModal');
  if (!modal) return;
  const isEdit = Boolean($('#posCategoryCodeInput')?.value);
  const title = $('#posCategoryEditorTitle');
  if (title) title.textContent = isEdit ? 'Editar categoría' : 'Nueva categoría';
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
  $('#posCategoryNameInput')?.focus();
}

function closePosCategoryEditor() {
  const modal = $('#posCategoryEditorModal');
  if (!modal) return;
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
}

// Miembros y detalle de miembro fueron movidos a public/js/modules/members.js y public/js/modals/member-detail-modal.js.



function renderCategorySelects() {
  const categories = getProductCategories();
  const activeCategories = categories.filter((category) => category.is_active !== false);

  const filter = $('#inventoryCategoryFilter');
  if (filter) {
    const current = filter.value || 'ALL';
    filter.innerHTML = '<option value="ALL">Todo activo</option>' + categories.map((category) => `<option value="${category.code}">${category.name}</option>`).join('') + '<option value="__INACTIVE__">Archivados / inactivos</option>';
    filter.value = Array.from(filter.options).some((option) => option.value === current) ? current : 'ALL';
  }

  const input = $('#inventoryCategoryInput');
  if (input) {
    const current = input.value || activeCategories[0]?.code || 'DRINK';
    input.innerHTML = activeCategories.map((category) => `<option value="${category.code}">${category.name}</option>`).join('');
    input.value = Array.from(input.options).some((option) => option.value === current) ? current : (activeCategories[0]?.code || 'DRINK');
  }

  renderPosCategoryList();
  renderManualBonusProductOptions();
}

function resetPosCategoryForm() {
  const nextOrder = Math.max(0, ...getProductCategories().map((category) => Number(category.sort_order || 0))) + 10;
  $('#posCategoryCodeInput').value = '';
  $('#posCategoryNameInput').value = '';
  $('#posCategoryColorInput').value = '#2563eb';
  $('#posCategoryOrderInput').value = nextOrder;
  $('#posCategorySizeInput').value = 'normal';
  $('#posCategoryActiveInput').checked = true;
  $('#posCategoryStationInput').checked = true;
  $('#posCategoryQuickInput').checked = true;
  $('#posCategoryBonusInput').checked = true;
  state.selectedPosCategoryCode = null;
  const deleteBtn = $('#deletePosCategoryBtn');
  if (deleteBtn) {
    deleteBtn.disabled = true;
    deleteBtn.textContent = 'Quitar categoría';
    deleteBtn.classList.remove('protected');
  }
  renderPosCategoryItems();
}

function fillPosCategoryForm(category) {
  if (!category) return resetPosCategoryForm();
  state.selectedPosCategoryCode = category.code || null;
  $('#posCategoryCodeInput').value = category.code || '';
  $('#posCategoryNameInput').value = category.name || '';
  $('#posCategoryColorInput').value = category.color || '#2563eb';
  $('#posCategoryOrderInput').value = Number(category.sort_order || 100);
  $('#posCategorySizeInput').value = category.button_size || 'normal';
  $('#posCategoryActiveInput').checked = category.is_active !== false;
  $('#posCategoryStationInput').checked = category.show_in_station !== false;
  $('#posCategoryQuickInput').checked = category.show_in_quick !== false;
  $('#posCategoryBonusInput').checked = category.show_in_bonuses !== false;
  const isProtected = isProtectedPosCategory(category);
  const deleteBtn = $('#deletePosCategoryBtn');
  if (deleteBtn) {
    deleteBtn.disabled = isProtected;
    deleteBtn.textContent = isProtected ? 'Categoría protegida' : 'Quitar categoría';
    deleteBtn.classList.toggle('protected', isProtected);
  }
  renderPosCategoryItems();
}

function renderPosCategoryList() {
  const list = $('#posCategoryList');
  if (!list) return;
  const search = String($('#posCategorySearchInput')?.value || '').trim().toLowerCase();
  const categories = getProductCategories().filter((category) => {
    const haystack = `${category.name || ''} ${category.code || ''}`.toLowerCase();
    return !search || haystack.includes(search);
  });
  if (!categories.length) {
    list.innerHTML = '<div class="inventory-empty">Sin categorías</div>';
    return;
  }

  list.innerHTML = categories.map((category) => `
    <button type="button" class="pos-category-row ${category.is_active === false ? 'inactive' : ''}" data-pos-category-code="${category.code}" style="--category-color:${category.color || '#2563eb'}">
      <span class="category-dot"></span>
      <span><strong>${category.name}</strong><small>${category.code} · ${isProtectedPosCategory(category) ? 'Protegida · ' : ''}${category.show_in_station === false ? 'Oculta estaciones' : 'Estaciones'} · ${category.show_in_quick === false ? 'Oculta venta' : 'Venta rápida'}</small></span>
      <b>${Number(category.sort_order || 0)}</b>
    </button>
  `).join('');

  list.querySelectorAll('[data-pos-category-code]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const category = getProductCategories().find((item) => item.code === btn.dataset.posCategoryCode);
      fillPosCategoryForm(category);
      openPosCategoryEditor();
    });
  });
}

function getInventoryProductPayloadFromProduct(product, overrides = {}) {
  return {
    name: overrides.name ?? product.name ?? '',
    category: overrides.category ?? product.category ?? 'SNACK',
    sku: overrides.sku ?? product.sku ?? '',
    price: Number(overrides.price ?? product.price ?? 0),
    cost: Number(overrides.cost ?? product.cost ?? 0),
    stockQty: Number(overrides.stockQty ?? product.stock_qty ?? 0),
    lowStockThreshold: Number(overrides.lowStockThreshold ?? product.low_stock_threshold ?? 5),
    supplierLeadDays: Number(overrides.supplierLeadDays ?? product.supplier_lead_days ?? 3),
    reorderCoverDays: Number(overrides.reorderCoverDays ?? product.reorder_cover_days ?? 14),
    trackStock: overrides.trackStock ?? Boolean(product.track_stock),
    isActive: overrides.isActive ?? Boolean(product.is_active),
    comboIncludedMinutes: Number(overrides.comboIncludedMinutes ?? product.combo_included_minutes ?? 0),
    comboPlayerCount: Number(overrides.comboPlayerCount ?? product.combo_player_count ?? 1),
    comboComponents: overrides.comboComponents ?? product.combo_components ?? []
  };
}

function renderPosCategoryItems() {
  const panel = $('#posCategoryItemsPanel');
  const list = $('#posCategoryItemsList');
  const count = $('#posCategoryItemsCount');
  const assignSelect = $('#posCategoryAssignProductSelect');
  if (!panel || !list || !assignSelect) return;

  const code = $('#posCategoryCodeInput')?.value || state.selectedPosCategoryCode || '';
  const isExistingCategory = Boolean(code);
  panel.classList.toggle('hidden', !isExistingCategory);

  if (!isExistingCategory) {
    list.innerHTML = '';
    assignSelect.innerHTML = '<option value="">Guarda la categoría primero</option>';
    if (count) count.textContent = '0 artículos';
    return;
  }

  const search = String($('#posCategoryItemsSearchInput')?.value || '').trim().toLowerCase();
  const assigned = state.inventoryProducts.filter((product) => product.category === code);
  const filteredAssigned = assigned.filter((product) => {
    const haystack = `${product.name || ''} ${product.sku || ''}`.toLowerCase();
    return !search || haystack.includes(search);
  });
  const available = state.inventoryProducts.filter((product) => product.category !== code && product.is_active !== false);

  if (count) count.textContent = `${assigned.length} artículo${assigned.length === 1 ? '' : 's'}`;
  assignSelect.innerHTML = available.length
    ? '<option value="">Seleccionar artículo</option>' + available.map((product) => `<option value="${product.id}">${product.name} · ${getCategoryLabel(product.category)}</option>`).join('')
    : '<option value="">Sin artículos disponibles</option>';

  if (!filteredAssigned.length) {
    list.innerHTML = '<div class="inventory-empty compact-empty">Sin artículos en esta categoría</div>';
    return;
  }

  list.innerHTML = filteredAssigned.map((product) => `
    <div class="category-item-row" data-category-product-id="${product.id}">
      <span>
        <strong>${product.name}</strong>
        <small>${product.sku || 'Sin código'} · ${money(product.price || 0)}</small>
      </span>
      <div>
        <button type="button" class="secondary" data-edit-category-product="${product.id}">Editar</button>
        <button type="button" class="danger soft-danger" data-remove-category-product="${product.id}">Quitar</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('[data-edit-category-product]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const product = state.inventoryProducts.find((item) => item.id === btn.dataset.editCategoryProduct);
      if (!product) return;
      closePosCategoryEditor();
      fillInventoryForm(product);
      setTimeout(openInventoryProductEditor, 30);
    });
  });

  list.querySelectorAll('[data-remove-category-product]').forEach((btn) => {
    btn.addEventListener('click', () => moveProductOutOfCategory(btn.dataset.removeCategoryProduct));
  });
}

async function assignProductToCurrentCategory() {
  const code = $('#posCategoryCodeInput')?.value || state.selectedPosCategoryCode;
  const productId = $('#posCategoryAssignProductSelect')?.value;
  if (!code) return showToast('Selecciona una categoría');
  if (!productId) return showToast('Selecciona un artículo');
  const product = state.inventoryProducts.find((item) => item.id === productId);
  if (!product) return showToast('Artículo no encontrado');

  try {
    await api(`/products/${product.id}`, {
      method: 'PATCH',
      body: JSON.stringify(getInventoryProductPayloadFromProduct(product, { category: code }))
    });
    showToast('Artículo asignado');
    await loadProducts();
    await loadInventoryModule();
    renderPosCategoryItems();
  } catch (error) {
    showToast(error.message);
  }
}

async function moveProductOutOfCategory(productId) {
  const currentCode = $('#posCategoryCodeInput')?.value || state.selectedPosCategoryCode;
  const product = state.inventoryProducts.find((item) => item.id === productId);
  if (!product || !currentCode) return showToast('Artículo no encontrado');
  const targetCategory = getProductCategories().find((category) => category.code !== currentCode && category.is_active !== false)?.code;
  if (!targetCategory) return showToast('No hay otra categoría activa');

  const ok = confirm(`¿Quitar ${product.name} de esta categoría? Se moverá a ${getCategoryLabel(targetCategory)}.`);
  if (!ok) return;

  try {
    await api(`/products/${product.id}`, {
      method: 'PATCH',
      body: JSON.stringify(getInventoryProductPayloadFromProduct(product, { category: targetCategory }))
    });
    showToast('Artículo movido');
    await loadProducts();
    await loadInventoryModule();
    renderPosCategoryItems();
  } catch (error) {
    showToast(error.message);
  }
}

function getPosCategoryPayload() {
  return {
    code: $('#posCategoryCodeInput').value || undefined,
    name: $('#posCategoryNameInput').value.trim(),
    color: $('#posCategoryColorInput').value || '#2563eb',
    sortOrder: Number($('#posCategoryOrderInput').value || 100),
    buttonSize: $('#posCategorySizeInput').value || 'normal',
    isActive: $('#posCategoryActiveInput').checked,
    showInStation: $('#posCategoryStationInput').checked,
    showInQuick: $('#posCategoryQuickInput').checked,
    showInBonuses: $('#posCategoryBonusInput').checked,
    isMembership: $('#posCategoryCodeInput').value === 'MEMBERSHIP'
  };
}

async function savePosCategory() {
  const code = $('#posCategoryCodeInput').value;
  const payload = getPosCategoryPayload();
  if (!payload.name) return showToast('Nombre requerido');
  if (payload.category === 'COMBO' && payload.comboIncludedMinutes <= 0 && payload.comboComponents.length === 0) {
    return showToast('Agrega tiempo o artículos al combo');
  }

  try {
    await api(code ? `/products/categories/${encodeURIComponent(code)}` : '/products/categories', {
      method: code ? 'PATCH' : 'POST',
      body: JSON.stringify(payload)
    });
    showToast(code ? 'Categoría actualizada' : 'Categoría creada');
    await loadProductCategories();
    await loadProducts();
    resetPosCategoryForm();
    closePosCategoryEditor();
  } catch (error) {
    showToast(error.message);
  }
}

async function deletePosCategory() {
  const code = $('#posCategoryCodeInput').value;
  if (!code) return showToast('Selecciona categoría');
  const category = getProductCategories().find((item) => item.code === code);
  if (isProtectedPosCategory(category || code)) return showToast('Membresías es categoría protegida. Puedes ocultarla, no eliminarla.');
  const ok = confirm('¿Quitar esta categoría? Si tiene productos, se desactivará.');
  if (!ok) return;

  try {
    const result = await api(`/products/categories/${encodeURIComponent(code)}`, { method: 'DELETE' });
    showToast(result.action === 'deleted' ? 'Categoría eliminada' : 'Categoría desactivada');
    await loadProductCategories();
    await loadProducts();
    resetPosCategoryForm();
    closePosCategoryEditor();
  } catch (error) {
    showToast(error.message);
  }
}


function getModifierGroupById(id) {
  return (state.modifierGroups || []).find((group) => group.id === id) || null;
}

function getModifierOptionById(group, optionId) {
  return (group?.options || []).find((option) => option.id === optionId) || null;
}

async function loadModifierGroups() {
  try {
    const { groups } = await api('/products/modifiers');
    state.modifierGroups = groups || [];
    if (state.selectedModifierGroupId && !getModifierGroupById(state.selectedModifierGroupId)) {
      state.selectedModifierGroupId = null;
      state.selectedModifierOptionId = null;
    }
    renderModifiersModule();
  } catch (error) {
    showToast(error.message || 'No se pudieron cargar modificadores');
  }
}

function renderModifiersModule() {
  renderModifierGroupsList();
  renderModifierEditor();
}

function renderModifierGroupsList() {
  const list = $('#modifierGroupsList');
  if (!list) return;

  const search = String($('#modifierSearchInput')?.value || '').trim().toLowerCase();
  const groups = (state.modifierGroups || []).filter((group) => {
    const haystack = `${group.name || ''} ${(group.options || []).map((option) => option.name).join(' ')}`.toLowerCase();
    return !search || haystack.includes(search);
  });

  if (!groups.length) {
    list.innerHTML = '<div class="inventory-empty">Sin modificadores</div>';
    return;
  }

  list.innerHTML = groups.map((group) => {
    const options = group.options || [];
    const activeOptions = options.filter((option) => option.is_active !== false).length;
    const selected = group.id === state.selectedModifierGroupId ? 'active' : '';
    const flags = [
      group.is_required ? 'Obligatorio' : 'Opcional',
      group.allow_multiple ? 'Múltiple' : 'Único'
    ];
    return `
      <button type="button" class="modifier-group-row ${selected} ${group.is_active ? '' : 'inactive'}" data-modifier-group-id="${group.id}">
        <span>
          <strong>${group.name}</strong>
          <small>${flags.join(' · ')} · ${activeOptions} opciones</small>
        </span>
        <b>${Number(group.sort_order || 100)}</b>
      </button>
    `;
  }).join('');

  list.querySelectorAll('[data-modifier-group-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedModifierGroupId = btn.dataset.modifierGroupId;
      state.selectedModifierOptionId = null;
      renderModifiersModule();
    });
  });
}

function renderModifierEditor() {
  const panel = $('#modifierEditorPanel');
  if (!panel) return;
  const group = getModifierGroupById(state.selectedModifierGroupId);

  if (!group) {
    panel.classList.add('empty');
    panel.innerHTML = `
      <h3>Nuevo grupo</h3>
      <div class="modifier-form-card">
        <label>Nombre<input id="modifierGroupNameInput" type="text" autocomplete="off" placeholder="Ej. Tipo de impresión" /></label>
        <div class="inventory-form-grid">
          <label>Orden<input id="modifierGroupOrderInput" type="number" step="1" value="100" /></label>
          <label class="checkbox-line modifier-check"><input id="modifierGroupActiveInput" type="checkbox" checked /><span>Activo</span></label>
        </div>
        <div class="inventory-checks modifier-checks">
          <label class="checkbox-line"><input id="modifierGroupRequiredInput" type="checkbox" /><span>Obligatorio</span></label>
          <label class="checkbox-line"><input id="modifierGroupMultipleInput" type="checkbox" /><span>Permite varias</span></label>
        </div>
        <button id="saveModifierGroupBtn" type="button">Guardar grupo</button>
      </div>
    `;
    bindModifierEditorActions();
    return;
  }

  panel.classList.remove('empty');
  const options = group.options || [];
  const selectedOption = getModifierOptionById(group, state.selectedModifierOptionId);

  panel.innerHTML = `
    <div class="modifier-editor-header">
      <div>
        <h3>${group.name}</h3>
        <span>${options.length} opciones</span>
      </div>
      <button id="newModifierGroupInlineBtn" type="button" class="secondary">Nuevo grupo</button>
    </div>

    <div class="modifier-form-card">
      <label>Nombre<input id="modifierGroupNameInput" type="text" autocomplete="off" value="${escapeAttr(group.name || '')}" /></label>
      <div class="inventory-form-grid">
        <label>Orden<input id="modifierGroupOrderInput" type="number" step="1" value="${Number(group.sort_order || 100)}" /></label>
        <label class="checkbox-line modifier-check"><input id="modifierGroupActiveInput" type="checkbox" ${group.is_active !== false ? 'checked' : ''} /><span>Activo</span></label>
      </div>
      <div class="inventory-checks modifier-checks">
        <label class="checkbox-line"><input id="modifierGroupRequiredInput" type="checkbox" ${group.is_required ? 'checked' : ''} /><span>Obligatorio</span></label>
        <label class="checkbox-line"><input id="modifierGroupMultipleInput" type="checkbox" ${group.allow_multiple ? 'checked' : ''} /><span>Permite varias</span></label>
      </div>
      <div class="drawer-actions-grid compact-actions">
        <button id="saveModifierGroupBtn" type="button">Guardar grupo</button>
        <button id="deleteModifierGroupBtn" type="button" class="danger">Quitar grupo</button>
      </div>
    </div>

    <div class="modifier-options-card">
      <div class="modifier-editor-header compact">
        <h3>Opciones</h3>
        <button id="newModifierOptionBtn" type="button" class="secondary">+ Nueva opción</button>
      </div>
      <div id="modifierOptionsList" class="modifier-options-list">
        ${options.length ? options.map((option) => `
          <button type="button" class="modifier-option-row ${option.id === state.selectedModifierOptionId ? 'active' : ''} ${option.is_active ? '' : 'inactive'}" data-modifier-option-id="${option.id}">
            <span>
              <strong>${option.name}</strong>
              <small>${money(option.price_delta || 0)} · Orden ${Number(option.sort_order || 100)}</small>
            </span>
            <b>${option.is_active ? 'Activo' : 'Oculto'}</b>
          </button>
        `).join('') : '<div class="inventory-empty compact-empty">Sin opciones</div>'}
      </div>
      <div class="modifier-option-editor">
        <h4>${selectedOption ? 'Editar opción' : 'Nueva opción'}</h4>
        <input id="modifierOptionIdInput" type="hidden" value="${selectedOption?.id || ''}" />
        <div class="inventory-form-grid">
          <label>Nombre<input id="modifierOptionNameInput" type="text" autocomplete="off" value="${escapeAttr(selectedOption?.name || '')}" /></label>
          <label>Precio extra (se suma al precio base)<input id="modifierOptionPriceInput" type="number" min="0" step="1" value="${Number(selectedOption?.price_delta || 0)}" /></label>
        </div>
        <div class="inventory-form-grid">
          <label>Orden<input id="modifierOptionOrderInput" type="number" step="1" value="${Number(selectedOption?.sort_order || 100)}" /></label>
          <label class="checkbox-line modifier-check"><input id="modifierOptionActiveInput" type="checkbox" ${selectedOption?.is_active === false ? '' : 'checked'} /><span>Activo</span></label>
        </div>
        <div class="drawer-actions-grid compact-actions">
          <button id="saveModifierOptionBtn" type="button">Guardar opción</button>
          <button id="deleteModifierOptionBtn" type="button" class="danger" ${selectedOption ? '' : 'disabled'}>Quitar opción</button>
        </div>
      </div>
    </div>
  `;

  panel.querySelectorAll('[data-modifier-option-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedModifierOptionId = btn.dataset.modifierOptionId;
      renderModifierEditor();
    });
  });
  bindModifierEditorActions();
}

function bindModifierEditorActions() {
  bindClick('#saveModifierGroupBtn', saveModifierGroup);
  bindClick('#deleteModifierGroupBtn', deleteModifierGroup);
  bindClick('#newModifierGroupInlineBtn', resetModifierGroupEditor);
  bindClick('#newModifierOptionBtn', resetModifierOptionEditor);
  bindClick('#saveModifierOptionBtn', saveModifierOption);
  bindClick('#deleteModifierOptionBtn', deleteModifierOption);
}

function resetModifierGroupEditor() {
  state.selectedModifierGroupId = null;
  state.selectedModifierOptionId = null;
  renderModifiersModule();
  $('#modifierGroupNameInput')?.focus();
}

function resetModifierOptionEditor() {
  state.selectedModifierOptionId = null;
  renderModifierEditor();
  $('#modifierOptionNameInput')?.focus();
}

function getModifierGroupPayload() {
  return {
    name: $('#modifierGroupNameInput')?.value?.trim() || '',
    sortOrder: Number($('#modifierGroupOrderInput')?.value || 100),
    isRequired: Boolean($('#modifierGroupRequiredInput')?.checked),
    allowMultiple: Boolean($('#modifierGroupMultipleInput')?.checked),
    isActive: Boolean($('#modifierGroupActiveInput')?.checked)
  };
}

async function saveModifierGroup() {
  const payload = getModifierGroupPayload();
  if (!payload.name) return showToast('Nombre requerido');

  const id = state.selectedModifierGroupId;
  try {
    const result = await api(id ? `/products/modifiers/groups/${id}` : '/products/modifiers/groups', {
      method: id ? 'PATCH' : 'POST',
      body: JSON.stringify(payload)
    });
    if (!id && result.group?.id) state.selectedModifierGroupId = result.group.id;
    showToast(id ? 'Grupo actualizado' : 'Grupo creado');
    await loadModifierGroups();
  } catch (error) {
    showToast(error.message);
  }
}

async function deleteModifierGroup() {
  const group = getModifierGroupById(state.selectedModifierGroupId);
  if (!group) return showToast('Selecciona un grupo');
  if (!confirm(`¿Quitar ${group.name}? También se quitarán sus opciones.`)) return;

  try {
    await api(`/products/modifiers/groups/${group.id}`, { method: 'DELETE' });
    state.selectedModifierGroupId = null;
    state.selectedModifierOptionId = null;
    showToast('Grupo eliminado');
    await loadModifierGroups();
  } catch (error) {
    showToast(error.message);
  }
}

function getModifierOptionPayload() {
  return {
    name: $('#modifierOptionNameInput')?.value?.trim() || '',
    priceDelta: Number($('#modifierOptionPriceInput')?.value || 0),
    sortOrder: Number($('#modifierOptionOrderInput')?.value || 100),
    isActive: Boolean($('#modifierOptionActiveInput')?.checked)
  };
}

async function saveModifierOption() {
  const group = getModifierGroupById(state.selectedModifierGroupId);
  if (!group) return showToast('Selecciona un grupo');
  const payload = getModifierOptionPayload();
  if (!payload.name) return showToast('Nombre requerido');

  const optionId = $('#modifierOptionIdInput')?.value || '';
  try {
    await api(optionId ? `/products/modifiers/options/${optionId}` : `/products/modifiers/groups/${group.id}/options`, {
      method: optionId ? 'PATCH' : 'POST',
      body: JSON.stringify(payload)
    });
    state.selectedModifierOptionId = null;
    showToast(optionId ? 'Opción actualizada' : 'Opción creada');
    await loadModifierGroups();
  } catch (error) {
    showToast(error.message);
  }
}

async function deleteModifierOption() {
  const optionId = $('#modifierOptionIdInput')?.value || '';
  if (!optionId) return showToast('Selecciona una opción');
  if (!confirm('¿Quitar esta opción?')) return;

  try {
    await api(`/products/modifiers/options/${optionId}`, { method: 'DELETE' });
    state.selectedModifierOptionId = null;
    showToast('Opción eliminada');
    await loadModifierGroups();
  } catch (error) {
    showToast(error.message);
  }
}

async function openInventoryModule() {
  if (!requirePermission('inventory')) return;
  closeModuleHub();
  resetInventoryForm();
  resetPosCategoryForm();
  renderCategorySelects();
  showInventoryView('items');
  $('#inventoryModuleModal').classList.remove('hidden');
  $('#inventoryModuleModal').setAttribute('aria-hidden', 'false');
  await loadModifierGroups();
  await loadInventoryModule();
}

function closeInventoryModule() {
  closeConfigModule('#inventoryModuleModal');
}

async function loadInventoryModule() {
  try {
    const { products, summary } = await api('/products/inventory');
    state.inventoryProducts = products || [];
    state.inventorySummary = summary || {};
    renderInventoryModule();
  } catch (error) {
    showToast(error.message);
  }
}

function renderInventoryModule() {
  const list = $('#inventoryList');
  const label = $('#inventorySummaryLabel');
  if (!list || !label) return;

  const search = String($('#inventorySearchInput')?.value || '').trim().toLowerCase();
  const category = $('#inventoryCategoryFilter')?.value || 'ALL';
  const summary = state.inventorySummary || {};

  label.textContent = `${summary.active_products || 0} activos · ${summary.low_stock || 0} bajo stock`;

  const products = state.inventoryProducts.filter((product) => {
    const isActive = product.is_active !== false;
    const showInactive = category === '__INACTIVE__';
    const matchesCategory = category === 'ALL'
      ? isActive
      : showInactive
        ? !isActive
        : product.category === category && isActive;
    const haystack = `${product.name || ''} ${product.sku || ''}`.toLowerCase();
    const matchesSearch = !search || haystack.includes(search);
    return matchesCategory && matchesSearch;
  });

  if (!products.length) {
    list.innerHTML = '<div class="inventory-empty">Sin productos</div>';
    return;
  }

  list.innerHTML = products.map((product) => {
    const isLow = Boolean(product.is_low_stock);
    const stockText = product.track_stock ? `Stock ${Number(product.stock_qty || 0)}` : 'Sin stock';
    const profit = Number(product.price || 0) - Number(product.cost || 0);
    return `
      <button type="button" class="inventory-row ${product.is_active ? '' : 'inactive'} ${isLow ? 'low-stock' : ''}" data-inventory-product-id="${product.id}">
        <span>
          <strong>${product.name}</strong><br />
          <span>${getCategoryLabel(product.category)} · ${product.sku || 'Sin código'} · Ganancia ${money(profit)}${Number(product.modifier_group_count || 0) ? ` · ${Number(product.modifier_group_count || 0)} mod.` : ''}</span>
        </span>
        <b class="inventory-stock-pill ${isLow ? 'low' : ''}">${stockText}</b>
      </button>
    `;
  }).join('');

  list.querySelectorAll('[data-inventory-product-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const product = state.inventoryProducts.find((item) => item.id === btn.dataset.inventoryProductId);
      fillInventoryForm(product);
      openInventoryProductEditor();
    });
  });
}


function getComboComponentIds(product = {}) {
  const components = product.combo_components || product.comboComponents || [];
  return Array.isArray(components) ? components.map((item) => ({
    productId: item.productId || item.product_id || item.component_product_id,
    quantity: Math.max(1, Number(item.quantity || 1))
  })).filter((item) => item.productId) : [];
}

function isInventoryComboCategory() {
  return $('#inventoryCategoryInput')?.value === 'COMBO';
}

function getInventoryComboComponents() {
  return Array.isArray(state.inventoryComboComponents) ? state.inventoryComboComponents : [];
}

function setInventoryComboComponents(components = []) {
  state.inventoryComboComponents = (components || [])
    .map((item) => ({ productId: item.productId || item.product_id, quantity: Math.max(1, Number(item.quantity || 1)) }))
    .filter((item) => item.productId);
}

function renderInventoryComboBuilder() {
  const card = $('#inventoryComboCard');
  if (!card) return;
  const isCombo = isInventoryComboCategory();
  card.classList.toggle('hidden', !isCombo);
  if (!isCombo) return;

  const currentId = $('#inventoryProductId')?.value || '';
  const select = $('#inventoryComboProductSelect');
  const components = getInventoryComboComponents();
  const available = (state.inventoryProducts || []).filter((product) => product.is_active !== false && product.id !== currentId && product.category !== 'COMBO');

  if (select) {
    const current = select.value;
    select.innerHTML = available.length
      ? '<option value="">Seleccionar artículo</option>' + available.map((product) => `<option value="${product.id}">${escapeHtml(product.name)} · ${getCategoryLabel(product.category)} · ${money(product.price || 0)}</option>`).join('')
      : '<option value="">Sin artículos disponibles</option>';
    if (available.some((product) => product.id === current)) select.value = current;
  }

  const list = $('#inventoryComboComponentsList');
  if (list) {
    list.innerHTML = components.length ? components.map((component, index) => {
      const product = (state.inventoryProducts || []).find((item) => item.id === component.productId) || {};
      return `
        <div class="combo-component-row">
          <span><strong>${escapeHtml(product.name || 'Artículo')}</strong><small>${getCategoryLabel(product.category || '')} · Cantidad ${Number(component.quantity || 1)}</small></span>
          <button type="button" class="danger soft-danger" data-remove-combo-component="${index}">Quitar</button>
        </div>
      `;
    }).join('') : '<div class="inventory-empty compact-empty">Sin artículos incluidos</div>';

    list.querySelectorAll('[data-remove-combo-component]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const index = Number(btn.dataset.removeComboComponent);
        const next = getInventoryComboComponents().filter((_, itemIndex) => itemIndex !== index);
        setInventoryComboComponents(next);
        renderInventoryComboBuilder();
      });
    });
  }

  const minutes = Number($('#inventoryComboMinutesInput')?.value || 0);
  const playerCount = Number($('#inventoryComboPlayerCountInput')?.value || 1);
  const label = $('#inventoryComboSummaryLabel');
  if (label) {
    const parts = [];
    if (minutes > 0) parts.push(`${minutes} min`);
    parts.push(playerCount === 2 ? '2 jugadores' : '1 jugador');
    parts.push(`${components.length} artículo${components.length === 1 ? '' : 's'}`);
    label.textContent = parts.join(' · ');
  }
}

function addInventoryComboComponent() {
  const productId = $('#inventoryComboProductSelect')?.value;
  const quantity = Math.max(1, Number($('#inventoryComboQtyInput')?.value || 1));
  if (!productId) return showToast('Selecciona un artículo para el combo');
  const components = getInventoryComboComponents();
  const existing = components.find((item) => item.productId === productId);
  if (existing) existing.quantity += quantity;
  else components.push({ productId, quantity });
  setInventoryComboComponents(components);
  if ($('#inventoryComboProductSelect')) $('#inventoryComboProductSelect').value = '';
  if ($('#inventoryComboQtyInput')) $('#inventoryComboQtyInput').value = '1';
  renderInventoryComboBuilder();
}


function getProductModifierGroupIds(product = {}) {
  const ids = product.modifier_group_ids || product.modifierGroupIds || [];
  if (Array.isArray(ids)) return ids.map((id) => String(id));
  if (typeof ids === 'string') {
    return ids.replace(/[{}]/g, '').split(',').map((id) => id.trim()).filter(Boolean);
  }
  return [];
}

function getSelectedProductModifierGroupIds() {
  return Array.from(document.querySelectorAll('#inventoryProductModifiersList [data-product-modifier-group-input]:checked'))
    .map((input) => input.value)
    .filter(Boolean);
}

function renderInventoryProductModifiers(selectedIds = []) {
  const list = $('#inventoryProductModifiersList');
  const label = $('#inventoryModifierCountLabel');
  if (!list) return;
  const selected = new Set((selectedIds || []).map((id) => String(id)));
  const groups = (state.modifierGroups || []).filter((group) => group.is_active !== false);
  if (!groups.length) {
    list.innerHTML = '<div class="inventory-empty compact-empty">Sin grupos de modificadores</div>';
    if (label) label.textContent = '0 asignados';
    return;
  }
  list.innerHTML = groups.map((group) => {
    const count = (group.options || []).filter((option) => option.is_active !== false).length;
    return `
      <label class="product-modifier-assign-row ${selected.has(String(group.id)) ? 'selected' : ''}">
        <input type="checkbox" data-product-modifier-group-input value="${escapeAttr(group.id)}" ${selected.has(String(group.id)) ? 'checked' : ''} />
        <span>
          <strong>${group.name}</strong>
          <small>${count} opciones · ${group.is_required ? 'Obligatorio' : 'Opcional'} · ${group.allow_multiple ? 'Varias' : 'Una'}</small>
        </span>
      </label>
    `;
  }).join('');
  if (label) label.textContent = `${selected.size} asignados`;
  list.querySelectorAll('[data-product-modifier-group-input]').forEach((input) => {
    input.addEventListener('change', () => {
      const ids = getSelectedProductModifierGroupIds();
      renderInventoryProductModifiers(ids);
    });
  });
}

function resetInventoryForm() {
  if (!$('#inventoryProductId')) return;
  state.selectedInventoryProductId = null;
  $('#inventoryFormTitle').textContent = 'Nuevo producto';
  $('#inventoryProductId').value = '';
  $('#inventoryNameInput').value = '';
  renderCategorySelects();
  $('#inventoryCategoryInput').value = Array.from($('#inventoryCategoryInput').options)[0]?.value || 'DRINK';
  $('#inventorySkuInput').value = '';
  $('#inventoryPriceInput').value = '0';
  $('#inventoryCostInput').value = '0';
  $('#inventoryStockInput').value = '0';
  $('#inventoryLowStockInput').value = '5';
  $('#inventorySupplierLeadDaysInput').value = '3';
  $('#inventoryReorderCoverDaysInput').value = '14';
  $('#inventoryTrackStockInput').checked = true;
  $('#inventoryActiveInput').checked = true;
  $('#inventoryComboMinutesInput').value = '0';
  $('#inventoryComboPlayerCountInput').value = '1';
  setInventoryComboComponents([]);
  $('#inventoryAdjustQtyInput').value = '';
  $('#inventoryAdjustReasonInput').value = '';
  $('#inventoryAdjustPanel').classList.add('hidden');
  renderInventoryComboBuilder();
  renderInventoryProductModifiers([]);
  const deleteBtn = $('#deleteInventoryProductBtn');
  if (deleteBtn) deleteBtn.disabled = true;
}

function fillInventoryForm(product) {
  if (!product) return;
  state.selectedInventoryProductId = product.id;
  $('#inventoryFormTitle').textContent = 'Editar producto';
  $('#inventoryProductId').value = product.id;
  $('#inventoryNameInput').value = product.name || '';
  renderCategorySelects();
  $('#inventoryCategoryInput').value = product.category || 'SNACK';
  $('#inventorySkuInput').value = product.sku || '';
  $('#inventoryPriceInput').value = Number(product.price || 0);
  $('#inventoryCostInput').value = Number(product.cost || 0);
  $('#inventoryStockInput').value = Number(product.stock_qty || 0);
  $('#inventoryLowStockInput').value = Number(product.low_stock_threshold || 5);
  $('#inventorySupplierLeadDaysInput').value = Number(product.supplier_lead_days ?? 3);
  $('#inventoryReorderCoverDaysInput').value = Number(product.reorder_cover_days ?? 14);
  $('#inventoryTrackStockInput').checked = Boolean(product.track_stock);
  $('#inventoryActiveInput').checked = Boolean(product.is_active);
  $('#inventoryComboMinutesInput').value = Number(product.combo_included_minutes || 0);
  $('#inventoryComboPlayerCountInput').value = Number(product.combo_player_count || 1) === 2 ? '2' : '1';
  setInventoryComboComponents(getComboComponentIds(product));
  $('#inventoryAdjustQtyInput').value = '';
  $('#inventoryAdjustReasonInput').value = '';
  $('#inventoryAdjustPanel').classList.remove('hidden');
  renderInventoryComboBuilder();
  renderInventoryProductModifiers(getProductModifierGroupIds(product));
  const deleteBtn = $('#deleteInventoryProductBtn');
  if (deleteBtn) deleteBtn.disabled = false;
}

function getInventoryPayload() {
  return {
    name: $('#inventoryNameInput').value.trim(),
    category: $('#inventoryCategoryInput').value,
    sku: $('#inventorySkuInput').value.trim(),
    price: Number($('#inventoryPriceInput').value || 0),
    cost: Number($('#inventoryCostInput').value || 0),
    stockQty: Number($('#inventoryStockInput').value || 0),
    lowStockThreshold: Number($('#inventoryLowStockInput').value || 0),
    supplierLeadDays: Number($('#inventorySupplierLeadDaysInput').value || 0),
    reorderCoverDays: Number($('#inventoryReorderCoverDaysInput').value || 14),
    trackStock: $('#inventoryTrackStockInput').checked,
    isActive: $('#inventoryActiveInput').checked,
    comboIncludedMinutes: isInventoryComboCategory() ? Number($('#inventoryComboMinutesInput')?.value || 0) : 0,
    comboPlayerCount: Number($('#inventoryComboPlayerCountInput')?.value || 1) === 2 ? 2 : 1,
    comboComponents: isInventoryComboCategory() ? getInventoryComboComponents() : [],
    modifierGroupIds: getSelectedProductModifierGroupIds()
  };
}

async function saveInventoryProduct() {
  const id = $('#inventoryProductId').value;
  const payload = getInventoryPayload();

  if (!payload.name) return showToast('Nombre requerido');
  if (payload.category === 'COMBO' && payload.comboIncludedMinutes <= 0 && payload.comboComponents.length === 0) {
    return showToast('Agrega tiempo o artículos al combo');
  }

  try {
    await api(id ? `/products/${id}` : '/products', {
      method: id ? 'PATCH' : 'POST',
      body: JSON.stringify(payload)
    });

    showToast(id ? 'Producto actualizado' : 'Producto creado');
    await loadProducts();
    await loadInventoryModule();
    resetInventoryForm();
    closeInventoryProductEditor();
  } catch (error) {
    showToast(error.message);
  }
}

async function applyInventoryAdjustment() {
  const id = $('#inventoryProductId').value;
  if (!id) return showToast('Selecciona un producto');

  const quantity = Number($('#inventoryAdjustQtyInput').value || 0);
  const reason = $('#inventoryAdjustReasonInput').value.trim() || 'Ajuste manual';

  if (!quantity) return showToast('Cantidad requerida');

  try {
    await api(`/products/${id}/adjust`, {
      method: 'POST',
      body: JSON.stringify({ quantity, reason })
    });

    showToast('Stock actualizado');
    await loadProducts();
    await loadInventoryModule();
    const product = state.inventoryProducts.find((item) => item.id === id);
    fillInventoryForm(product);
  } catch (error) {
    showToast(error.message);
  }
}


async function deleteInventoryProduct() {
  const id = $('#inventoryProductId')?.value;
  if (!id) return showToast('Selecciona un producto');

  const product = state.inventoryProducts.find((item) => item.id === id);
  const name = product?.name || 'este producto';
  const ok = confirm(`¿Eliminar ${name}? Si ya tiene ventas, se desactivará para conservar el historial.`);
  if (!ok) return;

  try {
    const result = await api(`/products/${id}`, { method: 'DELETE' });
    showToast(result.action === 'deleted' ? 'Producto eliminado' : 'Producto desactivado');
    await loadProducts();
    await loadInventoryModule();
    resetInventoryForm();
    closeInventoryProductEditor();
  } catch (error) {
    showToast(error.message);
  }
}
