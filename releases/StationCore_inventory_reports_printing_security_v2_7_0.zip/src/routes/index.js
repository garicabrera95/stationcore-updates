import { Router } from 'express';
import authRoutes from './auth.routes.js';
import stationRoutes from './stations.routes.js';
import productRoutes from './products.routes.js';
import saleRoutes from './sales.routes.js';
import memberRoutes from './members.routes.js';
import drawerRoutes from './drawer.routes.js';
import reportRoutes from './reports.routes.js';
import userRoutes from './users.routes.js';
import promotionRoutes from './promotions.routes.js';
import authorizationCodeRoutes from './authorizationCodes.routes.js';
import tournamentRoutes from './tournaments.routes.js';
import financeRoutes from './finances.routes.js';
import payrollRoutes from './payroll.routes.js';
import maintenanceRoutes from './maintenance.routes.js';
import raffleRoutes from './raffles.routes.js';
import tvRoutes from './tv.routes.js';
import memberPortalRoutes from './memberPortal.routes.js';
import ownerDashboardRoutes from './ownerDashboard.routes.js';
import { requireAuth } from '../middleware/auth.js';
import { requirePosRemoteWriteAccess } from '../controllers/auth.controller.js';

export const apiRouter = Router();

apiRouter.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'club-versus-pos' });
});

apiRouter.use('/auth', authRoutes);
apiRouter.use('/stations', requireAuth, requirePosRemoteWriteAccess, stationRoutes);
apiRouter.use('/products', requireAuth, requirePosRemoteWriteAccess, productRoutes);
apiRouter.use('/sales', requireAuth, requirePosRemoteWriteAccess, saleRoutes);
apiRouter.use('/members', requireAuth, requirePosRemoteWriteAccess, memberRoutes);
apiRouter.use('/drawer', requireAuth, requirePosRemoteWriteAccess, drawerRoutes);
apiRouter.use('/reports', requireAuth, reportRoutes);
apiRouter.use('/users', requireAuth, requirePosRemoteWriteAccess, userRoutes);
apiRouter.use('/promotions', requireAuth, requirePosRemoteWriteAccess, promotionRoutes);
apiRouter.use('/authorization-codes', requireAuth, requirePosRemoteWriteAccess, authorizationCodeRoutes);
apiRouter.use('/tournaments', requireAuth, requirePosRemoteWriteAccess, tournamentRoutes);
apiRouter.use('/finances', requireAuth, requirePosRemoteWriteAccess, financeRoutes);
apiRouter.use('/payroll', requireAuth, requirePosRemoteWriteAccess, payrollRoutes);
apiRouter.use('/maintenance', requireAuth, requirePosRemoteWriteAccess, maintenanceRoutes);
apiRouter.use('/raffles', requireAuth, requirePosRemoteWriteAccess, raffleRoutes);
apiRouter.use('/tv', tvRoutes);
apiRouter.use('/member-portal', memberPortalRoutes);
apiRouter.use('/owner-dashboard', ownerDashboardRoutes);
