import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../db/pool.js';
import { env } from '../config/env.js';

const DEFAULT_ROLE_PERMISSIONS = {
  OWNER: ['stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'permissions', 'tournaments', 'finances', 'versus'],
  MANAGER: ['stations', 'drawer', 'members', 'inventory', 'prices', 'promotions', 'reports', 'employees', 'tournaments', 'finances', 'versus'],
  CASHIER: ['stations', 'drawer', 'members', 'versus']
};


async function getPosAccessSettings() {
  const { rows } = await query(`SELECT value FROM app_settings WHERE key = 'pos_access_security' LIMIT 1`);
  const value = rows[0]?.value || {};
  return {
    enabled: value.enabled !== false,
    accessCodeHash: value.accessCodeHash || '',
    rememberDays: Number(value.rememberDays || 7),
    remoteMode: String(value.remoteMode || 'READ_ONLY').toUpperCase()
  };
}

function getClientIp(req) {
  return String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
}

function isLocalPosRequest(req) {
  if (String(req.headers['x-forwarded-for'] || '').trim()) return false;
  const ip = String(req.socket?.remoteAddress || '').toLowerCase();
  return ip === '127.0.0.1' || ip === '::1' || ip.endsWith('::ffff:127.0.0.1');
}

export async function requirePosRemoteWriteAccess(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || isLocalPosRequest(req)) return next();
  try {
    const settings = await getPosAccessSettings();
    if (settings.remoteMode === 'FULL') return next();
    return res.status(403).json({ error: settings.remoteMode === 'DISABLED'
      ? 'El acceso remoto al POS está desactivado.'
      : 'POS Live está en modo solo lectura. Esta operación solo puede realizarse en la computadora del club.' });
  } catch (_error) {
    return res.status(503).json({ error: 'No se pudo validar la política de acceso remoto.' });
  }
}

function normalizeDeviceName(value) {
  const raw = String(value || '').trim();
  return raw.slice(0, 80) || 'Dispositivo POS';
}

async function verifyPosAccessToken(req) {
  const settings = await getPosAccessSettings();
  if (!settings.enabled) return { ok: true, settings, reason: 'disabled' };

  const token = req.headers['x-pos-access-token'];
  if (!token) return { ok: false, settings, reason: 'missing' };

  try {
    const payload = jwt.verify(String(token), env.jwtSecret);
    if (payload?.purpose !== 'pos_access' || !payload?.deviceId) {
      return { ok: false, settings, reason: 'invalid' };
    }

    const { rows } = await query(
      `SELECT id, device_id, device_name, expires_at, is_active
       FROM pos_access_devices
       WHERE device_id = $1
       LIMIT 1`,
      [payload.deviceId]
    );
    const device = rows[0];
    if (!device || device.is_active === false) return { ok: false, settings, reason: 'revoked' };
    if (device.expires_at && new Date(device.expires_at).getTime() < Date.now()) {
      return { ok: false, settings, reason: 'expired' };
    }

    await query(
      `UPDATE pos_access_devices
       SET last_seen_at = NOW(), last_ip = $2, last_user_agent = $3
       WHERE device_id = $1`,
      [payload.deviceId, getClientIp(req), String(req.headers['user-agent'] || '').slice(0, 240)]
    );

    return { ok: true, settings, device, reason: 'authorized' };
  } catch (_error) {
    return { ok: false, settings, reason: 'invalid' };
  }
}

export async function posAccessStatus(req, res) {
  const result = await verifyPosAccessToken(req);
  res.json({
    enabled: result.settings.enabled,
    authorized: Boolean(result.ok),
    deviceName: result.device?.device_name || null,
    reason: result.reason,
    remoteMode: result.settings.remoteMode,
    localAccess: isLocalPosRequest(req)
  });
}

export async function verifyPosAccess(req, res) {
  const settings = await getPosAccessSettings();
  if (!settings.enabled) {
    return res.json({ authorized: true, token: null, expiresInDays: null });
  }

  const { accessKey, deviceId, deviceName, remember } = req.body || {};
  const submitted = String(accessKey || '').trim();
  if (!submitted) return res.status(400).json({ error: 'Ingresa la clave de acceso del POS' });

  const envKey = String(env.posAccessKey || '').trim();
  const validByEnv = Boolean(envKey) && submitted === envKey;
  const validByHash = settings.accessCodeHash ? bcrypt.compareSync(submitted, settings.accessCodeHash) : false;
  if (!validByEnv && !validByHash) {
    return res.status(401).json({ error: 'Clave de acceso incorrecta' });
  }

  const normalizedDeviceId = String(deviceId || '').trim().slice(0, 120) || `pos-${Date.now()}`;
  const normalizedDeviceName = normalizeDeviceName(deviceName);
  const rememberDays = remember === false ? 1 : Math.max(1, Math.min(settings.rememberDays || 30, 90));
  const expiresAtSql = `NOW() + INTERVAL '${rememberDays} days'`;

  await query(
    `INSERT INTO pos_access_devices (device_id, device_name, last_ip, last_user_agent, expires_at, is_active)
     VALUES ($1, $2, $3, $4, ${expiresAtSql}, true)
     ON CONFLICT (device_id) DO UPDATE SET
       device_name = EXCLUDED.device_name,
       last_ip = EXCLUDED.last_ip,
       last_user_agent = EXCLUDED.last_user_agent,
       last_seen_at = NOW(),
       expires_at = ${expiresAtSql},
       is_active = true`,
    [normalizedDeviceId, normalizedDeviceName, getClientIp(req), String(req.headers['user-agent'] || '').slice(0, 240)]
  );

  const token = jwt.sign(
    { purpose: 'pos_access', deviceId: normalizedDeviceId, deviceName: normalizedDeviceName },
    env.jwtSecret,
    { expiresIn: `${rememberDays}d` }
  );

  res.json({ authorized: true, token, deviceId: normalizedDeviceId, deviceName: normalizedDeviceName, expiresInDays: rememberDays });
}

async function requirePosAccessForLogin(req, res) {
  const result = await verifyPosAccessToken(req);
  if (!isLocalPosRequest(req) && result.settings.remoteMode === 'DISABLED') {
    res.status(403).json({ error: 'El acceso remoto al POS está desactivado.' });
    return false;
  }
  if (!result.ok) {
    res.status(403).json({ error: 'Este dispositivo no está autorizado para abrir el POS' });
    return false;
  }
  return true;
}

async function getUserPermissions(user) {
  if (user.role === 'OWNER') return DEFAULT_ROLE_PERMISSIONS.OWNER;

  const { rows } = await query(
    `SELECT permission_key
     FROM user_permissions
     WHERE user_id = $1
     AND is_enabled = true
     ORDER BY permission_key`,
    [user.id]
  );

  if (rows.length) return rows.map((row) => row.permission_key);
  return DEFAULT_ROLE_PERMISSIONS[user.role] || DEFAULT_ROLE_PERMISSIONS.CASHIER;
}

export async function loginWithPin(req, res) {
  if (!(await requirePosAccessForLogin(req, res))) return;
  const { pin } = req.body;
  if (!pin) return res.status(400).json({ error: 'PIN is required' });

  const { rows } = await query(
    `SELECT id, full_name, role, pin_hash, is_active
     FROM users
     WHERE is_active = true
     ORDER BY created_at ASC`
  );

  const user = rows.find((row) => bcrypt.compareSync(String(pin), row.pin_hash));
  if (!user) return res.status(401).json({ error: 'Invalid PIN' });

  const permissions = await getUserPermissions(user);
  const sessionResult = await query(
    `INSERT INTO employee_sessions (user_id, status)
     VALUES ($1, 'ACTIVE')
     RETURNING id`,
    [user.id]
  );
  const employeeSessionId = sessionResult.rows[0]?.id || null;

  const tokenPayload = {
    id: user.id,
    name: user.full_name,
    role: user.role,
    permissions,
    employeeSessionId
  };

  const token = jwt.sign(tokenPayload, env.jwtSecret, { expiresIn: '12h' });

  res.json({
    token,
    user: {
      id: user.id,
      name: user.full_name,
      role: user.role,
      permissions,
      employeeSessionId
    }
  });
}


export async function verifyDesktopExitPin(req, res) {
  if (!(await requirePosAccessForLogin(req, res))) return;
  const { pin } = req.body || {};
  if (!pin) return res.status(400).json({ error: 'Ingresa el PIN administrador' });

  const { rows } = await query(
    `SELECT id, full_name, role, pin_hash, is_active
     FROM users
     WHERE is_active = true
     ORDER BY created_at ASC`
  );

  const user = rows.find((row) => bcrypt.compareSync(String(pin), row.pin_hash));
  if (!user) return res.status(401).json({ error: 'PIN incorrecto' });

  if (!['OWNER', 'MANAGER'].includes(String(user.role || '').toUpperCase())) {
    return res.status(403).json({ error: 'Este PIN no tiene permiso administrador para salir de StationCore' });
  }

  res.json({ ok: true, user: { id: user.id, name: user.full_name, role: user.role } });
}

export async function closeEmployeeSection(req, res) {
  const employeeSessionId = req.user?.employeeSessionId;
  if (!employeeSessionId) return res.json({ ok: true });

  await query(
    `UPDATE employee_sessions
     SET status = 'CLOSED',
         closed_at = COALESCE(closed_at, NOW())
     WHERE id = $1
       AND user_id = $2
       AND status = 'ACTIVE'`,
    [employeeSessionId, req.user.id]
  );

  res.json({ ok: true });
}

export function me(req, res) {
  res.json({ user: req.user });
}
