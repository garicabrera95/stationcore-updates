import { query, withTransaction } from '../db/pool.js';

const CATEGORY_ORDER = `
  COALESCE(pc.sort_order,
    CASE p.category
      WHEN 'DRINK' THEN 10
      WHEN 'SNACK' THEN 20
      WHEN 'COMBO' THEN 30
      WHEN 'MEMBERSHIP' THEN 40
      ELSE 100
    END
  ),
  p.name
`;

const CATEGORY_COLUMNS = `
  pc.name AS category_name,
  pc.color AS category_color,
  pc.sort_order AS category_sort_order,
  pc.button_size AS category_button_size,
  pc.is_membership AS category_is_membership
`;

const DEFAULT_CATEGORY_COLORS = {
  DRINK: '#2563eb',
  SNACK: '#f97316',
  COMBO: '#16a34a',
  MEMBERSHIP: '#facc15'
};

const MEMBERSHIP_CANONICAL_SKUS = {
  'MEMB-GAMER': 'MEMBERSHIP-GAMER',
  'MEMB-GAMER_PRO': 'MEMBERSHIP-GAMER-PRO',
  'MEMB-CHAMPION': 'MEMBERSHIP-CHAMPION'
};

async function archiveLegacyMembershipDuplicates() {
  try {
    await query(
      `UPDATE products legacy
       SET is_active = false,
           name = CASE
             WHEN legacy.name ILIKE '%(Archivado)%' THEN legacy.name
             ELSE legacy.name || ' (Archivado)'
           END,
           sku = legacy.sku || '-ARCHIVED-' || LEFT(legacy.id::text, 8),
           updated_at = NOW()
       WHERE legacy.category = 'MEMBERSHIP'
         AND legacy.is_active = true
         AND legacy.sku = ANY($1::text[])
         AND EXISTS (
           SELECT 1
           FROM products canonical
           WHERE canonical.category = 'MEMBERSHIP'
             AND canonical.is_active = true
             AND canonical.sku = CASE legacy.sku
               WHEN 'MEMB-GAMER' THEN 'MEMBERSHIP-GAMER'
               WHEN 'MEMB-GAMER_PRO' THEN 'MEMBERSHIP-GAMER-PRO'
               WHEN 'MEMB-CHAMPION' THEN 'MEMBERSHIP-CHAMPION'
             END
         )`,
      [Object.keys(MEMBERSHIP_CANONICAL_SKUS)]
    );
  } catch (error) {
    console.warn('No se pudo archivar membresías duplicadas legacy:', error.message);
  }
}

function canManageInventory(req) {
  return req.user?.role === 'OWNER' || req.user?.role === 'MANAGER' || req.user?.permissions?.includes('inventory');
}


function normalizeInt(value, fallback = 0) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeMoney(value, fallback = 0) {
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : fallback;
}

function normalizeCategory(value) {
  const normalized = String(value || 'SNACK').trim().toUpperCase();
  return normalized || 'SNACK';
}

function normalizeCategoryPayload(body = {}) {
  const name = String(body.name || '').trim();
  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }
  const rawCode = String(body.code || name).trim().toUpperCase();
  const code = rawCode
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '') || 'CATEGORY';

  return {
    code,
    name,
    color: String(body.color || DEFAULT_CATEGORY_COLORS[code] || '#2563eb').trim() || '#2563eb',
    sortOrder: normalizeInt(body.sortOrder ?? body.sort_order, 100),
    buttonSize: ['small', 'normal', 'large'].includes(String(body.buttonSize || body.button_size || 'normal'))
      ? String(body.buttonSize || body.button_size || 'normal')
      : 'normal',
    isActive: normalizeBool(body.isActive ?? body.is_active, true),
    showInStation: normalizeBool(body.showInStation ?? body.show_in_station, true),
    showInQuick: normalizeBool(body.showInQuick ?? body.show_in_quick, true),
    showInBonuses: normalizeBool(body.showInBonuses ?? body.show_in_bonuses, true),
    isMembership: normalizeBool(body.isMembership ?? body.is_membership, code === 'MEMBERSHIP') || code === 'MEMBERSHIP'
  };
}

function normalizeModifierGroupIds(value) {
  const source = Array.isArray(value) ? value : [];
  return [...new Set(source.map((item) => String(item || '').trim()).filter(Boolean))];
}

function normalizeComboComponents(value) {
  const source = Array.isArray(value) ? value : [];
  const map = new Map();
  for (const item of source) {
    const productId = String(item.productId || item.product_id || item.componentProductId || item.component_product_id || '').trim();
    if (!productId) continue;
    const quantity = Math.max(1, normalizeInt(item.quantity ?? item.qty, 1));
    map.set(productId, (map.get(productId) || 0) + quantity);
  }
  return Array.from(map.entries()).map(([productId, quantity]) => ({ productId, quantity }));
}

function normalizeComboPlayerCount(value) {
  const count = normalizeInt(value, 1);
  return count === 2 ? 2 : 1;
}

function normalizeProductPayload(body = {}) {
  const name = String(body.name || '').trim();
  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    category: normalizeCategory(body.category),
    sku: String(body.sku || '').trim() || null,
    price: normalizeMoney(body.price),
    cost: normalizeMoney(body.cost),
    stockQty: Math.max(0, normalizeInt(body.stockQty ?? body.stock_qty, 0)),
    lowStockThreshold: Math.max(0, normalizeInt(body.lowStockThreshold ?? body.low_stock_threshold, 5)),
    supplierLeadDays: Math.min(90, Math.max(0, normalizeInt(body.supplierLeadDays ?? body.supplier_lead_days, 3))),
    reorderCoverDays: Math.min(180, Math.max(1, normalizeInt(body.reorderCoverDays ?? body.reorder_cover_days, 14))),
    trackStock: normalizeBool(body.trackStock ?? body.track_stock, true),
    isActive: normalizeBool(body.isActive ?? body.is_active, true),
    comboIncludedMinutes: Math.max(0, normalizeInt(body.comboIncludedMinutes ?? body.combo_included_minutes, 0)),
    comboPlayerCount: normalizeComboPlayerCount(body.comboPlayerCount ?? body.combo_player_count),
    comboComponents: normalizeComboComponents(body.comboComponents || body.combo_components),
    modifierGroupIds: normalizeModifierGroupIds(body.modifierGroupIds || body.modifier_group_ids)
  };
}

async function saveProductModifierAssignments(client, productId, modifierGroupIds = []) {
  await client.query('DELETE FROM product_modifier_assignments WHERE product_id = $1', [productId]);
  for (let index = 0; index < modifierGroupIds.length; index += 1) {
    await client.query(
      `INSERT INTO product_modifier_assignments (product_id, group_id, sort_order)
       VALUES ($1, $2, $3)
       ON CONFLICT (product_id, group_id) DO UPDATE SET sort_order = EXCLUDED.sort_order`,
      [productId, modifierGroupIds[index], (index + 1) * 10]
    );
  }
}

async function getProductModifierGroupIds(client, productId) {
  const { rows } = await client.query(
    `SELECT group_id
     FROM product_modifier_assignments
     WHERE product_id = $1
     ORDER BY sort_order`,
    [productId]
  );
  return rows.map((row) => row.group_id);
}

async function saveComboComponents(client, comboProductId, components = []) {
  await client.query('DELETE FROM product_combo_components WHERE combo_product_id = $1', [comboProductId]);
  for (const component of components || []) {
    if (!component.productId || String(component.productId) === String(comboProductId)) continue;
    await client.query(
      `INSERT INTO product_combo_components (combo_product_id, component_product_id, quantity)
       VALUES ($1, $2, $3)
       ON CONFLICT (combo_product_id, component_product_id)
       DO UPDATE SET quantity = EXCLUDED.quantity`,
      [comboProductId, component.productId, Math.max(1, Number(component.quantity || 1))]
    );
  }
}

async function decorateProductsWithCombos(rows) {
  if (!rows.length) return rows;
  const ids = rows.map((row) => row.id);
  const components = await query(
    `SELECT pcc.combo_product_id,
            pcc.component_product_id,
            pcc.quantity,
            p.name AS component_name,
            p.category AS component_category,
            p.price AS component_price,
            p.stock_qty AS component_stock_qty,
            p.track_stock AS component_track_stock
     FROM product_combo_components pcc
     JOIN products p ON p.id = pcc.component_product_id
     WHERE pcc.combo_product_id = ANY($1::uuid[])
     ORDER BY p.name`,
    [ids]
  ).catch(() => ({ rows: [] }));

  const map = new Map();
  for (const row of components.rows) {
    const key = String(row.combo_product_id);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push({
      product_id: row.component_product_id,
      productId: row.component_product_id,
      quantity: Number(row.quantity || 1),
      name: row.component_name,
      category: row.component_category,
      price: row.component_price,
      stock_qty: row.component_stock_qty,
      track_stock: row.component_track_stock
    });
  }

  return rows.map((row) => ({
    ...row,
    combo_components: map.get(String(row.id)) || []
  }));
}

async function decorateProductsWithModifiers(rows) {
  if (!rows.length) return rows;
  const ids = rows.map((row) => row.id);
  const assigned = await query(
    `SELECT product_id, group_id
     FROM product_modifier_assignments
     WHERE product_id = ANY($1::uuid[])
     ORDER BY sort_order`,
    [ids]
  ).catch(() => ({ rows: [] }));

  const map = new Map();
  for (const row of assigned.rows) {
    const key = String(row.product_id);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(row.group_id);
  }

  const withModifiers = rows.map((row) => ({
    ...row,
    modifier_group_ids: map.get(String(row.id)) || []
  }));
  return decorateProductsWithCombos(withModifiers);
}


export async function listProductCategories(_req, res) {
  const { rows } = await query(`
    SELECT *
    FROM product_categories
    ORDER BY sort_order, name
  `);
  res.json({ categories: rows });
}

export async function updateProductCategory(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  try {
    const category = normalizeCategoryPayload({ ...req.body, code: req.params.code });
    const existing = await query('SELECT * FROM product_categories WHERE code = $1', [req.params.code]);
    if (!existing.rows.length) return res.status(404).json({ error: 'Categoría no encontrada' });

    const isMembership = existing.rows[0].is_membership || req.params.code === 'MEMBERSHIP';
    const { rows } = await query(
      `UPDATE product_categories
       SET name = $2,
           color = $3,
           sort_order = $4,
           button_size = $5,
           is_active = $6,
           show_in_station = $7,
           show_in_quick = $8,
           show_in_bonuses = $9,
           is_membership = $10,
           updated_at = NOW()
       WHERE code = $1
       RETURNING *`,
      [
        req.params.code,
        category.name,
        category.color,
        category.sortOrder,
        category.buttonSize,
        category.isActive,
        category.showInStation,
        category.showInQuick,
        category.showInBonuses,
        isMembership
      ]
    );

    res.json({ category: rows[0] });
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }
}

export async function deleteProductCategory(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const code = String(req.params.code || '').trim().toUpperCase();
  if (!code) return res.status(400).json({ error: 'Categoría requerida' });
  if (['MEMBERSHIP', 'PRINTING', 'SUPPLIES'].includes(code)) return res.status(400).json({ error: 'Esta categoría es protegida. Puedes ocultarla, no eliminarla.' });

  const used = await query('SELECT COUNT(*)::int AS count FROM products WHERE category = $1', [code]);
  if (Number(used.rows[0]?.count || 0) > 0) {
    const { rows } = await query(
      `UPDATE product_categories
       SET is_active = false, show_in_station = false, show_in_quick = false, show_in_bonuses = false, updated_at = NOW()
       WHERE code = $1
       RETURNING *`,
      [code]
    );
    if (!rows.length) return res.status(404).json({ error: 'Categoría no encontrada' });
    return res.json({ action: 'deactivated', category: rows[0] });
  }

  const { rowCount } = await query('DELETE FROM product_categories WHERE code = $1', [code]);
  if (!rowCount) return res.status(404).json({ error: 'Categoría no encontrada' });
  res.json({ action: 'deleted' });
}

export async function listProducts(_req, res) {
  await archiveLegacyMembershipDuplicates();

  const { rows } = await query(
    `SELECT p.*, ${CATEGORY_COLUMNS}
     FROM products p
     LEFT JOIN product_categories pc ON pc.code = p.category
     WHERE p.is_active = true
     ORDER BY ${CATEGORY_ORDER}`
  );

  res.json({ products: await decorateProductsWithModifiers(rows) });
}

export async function listInventory(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  await archiveLegacyMembershipDuplicates();

  const { rows } = await query(
    `SELECT p.*, ${CATEGORY_COLUMNS}
     FROM products p
     LEFT JOIN product_categories pc ON pc.code = p.category
     ORDER BY p.is_active DESC, ${CATEGORY_ORDER}`
  );

  const products = await decorateProductsWithModifiers(rows);
  const activeProducts = products.filter((product) => product.is_active !== false);
  const lowStock = activeProducts.filter((product) => product.track_stock && Number(product.stock_qty || 0) <= Number(product.low_stock_threshold || 0)).length;

  res.json({
    products,
    summary: {
      active_products: activeProducts.length,
      low_stock: lowStock
    }
  });
}

export async function createProduct(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  let payload;
  try {
    payload = normalizeProductPayload(req.body);
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }

  try {
    const product = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `INSERT INTO products (name, category, sku, price, cost, stock_qty, track_stock, is_combo, is_active, low_stock_threshold, combo_included_minutes, combo_player_count, supplier_lead_days, reorder_cover_days)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $2 = 'COMBO', $8, $9, CASE WHEN $2 = 'COMBO' THEN $10 ELSE 0 END, $11, $12, $13)
         RETURNING *`,
        [
          payload.name,
          payload.category,
          payload.sku,
          payload.price,
          payload.cost,
          payload.stockQty,
          payload.trackStock,
          payload.isActive,
          payload.lowStockThreshold,
          payload.comboIncludedMinutes,
          payload.comboPlayerCount,
          payload.supplierLeadDays,
          payload.reorderCoverDays
        ]
      );
      await saveProductModifierAssignments(client, rows[0].id, payload.modifierGroupIds);
      if (payload.category === 'COMBO') await saveComboComponents(client, rows[0].id, payload.comboComponents);
      rows[0].modifier_group_ids = await getProductModifierGroupIds(client, rows[0].id);
      return (await decorateProductsWithCombos([rows[0]]))[0];
    });

    res.status(201).json({ product });
  } catch (error) {
    if (error.code === '23503') return res.status(400).json({ error: 'Modificador inválido' });
    if (error.code === '23505') return res.status(400).json({ error: 'Ya existe un producto con ese código' });
    throw error;
  }
}

export async function saveProductCategory(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const category = normalizeCategoryPayload(req.body);
  const { rows } = await query(
    `INSERT INTO product_categories (
       code, name, color, sort_order, button_size, is_active,
       show_in_station, show_in_quick, show_in_bonuses, is_membership
     )
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     ON CONFLICT (code) DO UPDATE
     SET name = EXCLUDED.name,
         color = EXCLUDED.color,
         sort_order = EXCLUDED.sort_order,
         button_size = EXCLUDED.button_size,
         is_active = EXCLUDED.is_active,
         show_in_station = EXCLUDED.show_in_station,
         show_in_quick = EXCLUDED.show_in_quick,
         show_in_bonuses = EXCLUDED.show_in_bonuses,
         is_membership = EXCLUDED.is_membership,
         updated_at = NOW()
     RETURNING *`,
    [
      category.code,
      category.name,
      category.color,
      category.sortOrder,
      category.buttonSize,
      category.isActive,
      category.showInStation,
      category.showInQuick,
      category.showInBonuses,
      category.isMembership
    ]
  );

  res.json({ category: rows[0] });
}

export async function updateProduct(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { id } = req.params;
  const name = String(req.body.name || '').trim();
  const category = normalizeCategory(req.body.category);
  const sku = String(req.body.sku || '').trim() || null;
  const price = normalizeMoney(req.body.price);
  const cost = normalizeMoney(req.body.cost);
  const stockQty = Math.max(0, normalizeInt(req.body.stockQty, 0));
  const lowStockThreshold = Math.max(0, normalizeInt(req.body.lowStockThreshold, 5));
  const supplierLeadDays = Math.min(90, Math.max(0, normalizeInt(req.body.supplierLeadDays ?? req.body.supplier_lead_days, 3)));
  const reorderCoverDays = Math.min(180, Math.max(1, normalizeInt(req.body.reorderCoverDays ?? req.body.reorder_cover_days, 14)));
  const trackStock = Boolean(req.body.trackStock);
  const isActive = Boolean(req.body.isActive);
  const modifierGroupIds = normalizeModifierGroupIds(req.body.modifierGroupIds || req.body.modifier_group_ids);
  const comboIncludedMinutes = Math.max(0, normalizeInt(req.body.comboIncludedMinutes ?? req.body.combo_included_minutes, 0));
  const comboPlayerCount = normalizeComboPlayerCount(req.body.comboPlayerCount ?? req.body.combo_player_count);
  const comboComponents = normalizeComboComponents(req.body.comboComponents || req.body.combo_components);

  if (!name) return res.status(400).json({ error: 'Nombre requerido' });

  try {
    const product = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `UPDATE products
         SET name = $2,
             category = $3,
             sku = $4,
             price = $5,
             cost = $6,
             stock_qty = $7,
             track_stock = $8,
             is_combo = $3 = 'COMBO',
             is_active = $9,
             low_stock_threshold = $10,
             combo_included_minutes = CASE WHEN $3 = 'COMBO' THEN $11 ELSE 0 END,
             combo_player_count = $12,
             supplier_lead_days = $13,
             reorder_cover_days = $14,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [id, name, category, sku, price, cost, stockQty, trackStock, isActive, lowStockThreshold, comboIncludedMinutes, comboPlayerCount, supplierLeadDays, reorderCoverDays]
      );
      if (!rows.length) return null;
      await saveProductModifierAssignments(client, rows[0].id, modifierGroupIds);
      if (category === 'COMBO') await saveComboComponents(client, rows[0].id, comboComponents);
      else await saveComboComponents(client, rows[0].id, []);
      return (await decorateProductsWithCombos([rows[0]]))[0];
    });

    if (!product) return res.status(404).json({ error: 'Producto no encontrado' });
    res.json({ product });
  } catch (error) {
    if (error.code === '23503') return res.status(400).json({ error: 'Modificador inválido' });
    throw error;
  }
}

export async function adjustProductStock(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { id } = req.params;
  const quantity = normalizeInt(req.body.quantity, 0);
  const reason = String(req.body.reason || '').trim() || 'Ajuste manual';

  if (quantity === 0) return res.status(400).json({ error: 'Cantidad requerida' });

  const result = await withTransaction(async (client) => {
    const productResult = await client.query(
      `SELECT * FROM products WHERE id = $1 FOR UPDATE`,
      [id]
    );

    if (productResult.rowCount === 0) {
      const error = new Error('Producto no encontrado');
      error.status = 404;
      throw error;
    }

    const product = productResult.rows[0];
    const before = Number(product.stock_qty || 0);
    const after = before + quantity;

    if (after < 0) {
      const error = new Error('El inventario no puede quedar negativo');
      error.status = 400;
      throw error;
    }

    const updated = await client.query(
      `UPDATE products SET stock_qty = $2, track_stock = true, updated_at = NOW() WHERE id = $1 RETURNING *`,
      [id, after]
    );

    await client.query(
      `INSERT INTO inventory_movements (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reason)
       VALUES ($1, $2, $3, $4, $5, $6, 'MANUAL', $7)`,
      [id, req.user.id, quantity > 0 ? 'ADJUSTMENT_IN' : 'ADJUSTMENT_OUT', quantity, before, after, reason]
    );

    return updated.rows[0];
  });

  res.json({ product: result });
}


function normalizeBool(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') return ['true', '1', 'yes', 'on'].includes(value.toLowerCase());
  return Boolean(value);
}

function normalizeModifierGroupPayload(body = {}) {
  const name = String(body.name || '').trim();
  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    sortOrder: normalizeInt(body.sortOrder ?? body.sort_order, 100),
    isRequired: normalizeBool(body.isRequired ?? body.is_required, false),
    allowMultiple: normalizeBool(body.allowMultiple ?? body.allow_multiple, false),
    isActive: normalizeBool(body.isActive ?? body.is_active, true)
  };
}

function normalizeModifierOptionPayload(body = {}) {
  const name = String(body.name || '').trim();
  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    priceDelta: normalizeMoney(body.priceDelta ?? body.price_delta),
    sortOrder: normalizeInt(body.sortOrder ?? body.sort_order, 100),
    isActive: normalizeBool(body.isActive ?? body.is_active, true)
  };
}

export async function listModifierGroups(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { rows } = await query(`
    SELECT
      g.*,
      COALESCE(
        json_agg(
          json_build_object(
            'id', o.id,
            'group_id', o.group_id,
            'name', o.name,
            'price_delta', o.price_delta,
            'sort_order', o.sort_order,
            'is_active', o.is_active,
            'created_at', o.created_at,
            'updated_at', o.updated_at
          ) ORDER BY o.sort_order, o.name
        ) FILTER (WHERE o.id IS NOT NULL),
        '[]'::json
      ) AS options
    FROM product_modifier_groups g
    LEFT JOIN product_modifier_options o ON o.group_id = g.id
    GROUP BY g.id
    ORDER BY g.is_active DESC, g.sort_order, g.name
  `);

  res.json({ groups: rows });
}

export async function createModifierGroup(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  let payload;
  try {
    payload = normalizeModifierGroupPayload(req.body);
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }

  const { rows } = await query(
    `INSERT INTO product_modifier_groups (name, sort_order, is_required, allow_multiple, is_active)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [payload.name, payload.sortOrder, payload.isRequired, payload.allowMultiple, payload.isActive]
  );

  res.status(201).json({ group: rows[0] });
}

export async function updateModifierGroup(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  let payload;
  try {
    payload = normalizeModifierGroupPayload(req.body);
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }

  const { rows } = await query(
    `UPDATE product_modifier_groups
     SET name = $2,
         sort_order = $3,
         is_required = $4,
         allow_multiple = $5,
         is_active = $6,
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [req.params.id, payload.name, payload.sortOrder, payload.isRequired, payload.allowMultiple, payload.isActive]
  );

  if (!rows.length) return res.status(404).json({ error: 'Grupo no encontrado' });
  res.json({ group: rows[0] });
}

export async function deleteModifierGroup(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const { rowCount } = await query('DELETE FROM product_modifier_groups WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'Grupo no encontrado' });
  res.json({ action: 'deleted' });
}

export async function createModifierOption(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  let payload;
  try {
    payload = normalizeModifierOptionPayload(req.body);
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }

  const { rows } = await query(
    `INSERT INTO product_modifier_options (group_id, name, price_delta, sort_order, is_active)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [req.params.id, payload.name, payload.priceDelta, payload.sortOrder, payload.isActive]
  );

  res.status(201).json({ option: rows[0] });
}

export async function updateModifierOption(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  let payload;
  try {
    payload = normalizeModifierOptionPayload(req.body);
  } catch (error) {
    return res.status(error.status || 400).json({ error: error.message || 'Datos inválidos' });
  }

  const { rows } = await query(
    `UPDATE product_modifier_options
     SET name = $2,
         price_delta = $3,
         sort_order = $4,
         is_active = $5,
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [req.params.id, payload.name, payload.priceDelta, payload.sortOrder, payload.isActive]
  );

  if (!rows.length) return res.status(404).json({ error: 'Opción no encontrada' });
  res.json({ option: rows[0] });
}

export async function deleteModifierOption(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });
  const { rowCount } = await query('DELETE FROM product_modifier_options WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'Opción no encontrada' });
  res.json({ action: 'deleted' });
}

export async function lookupProductByCode(req, res) {
  const code = String(req.params.code || '').trim();
  if (!code) return res.status(400).json({ error: 'Código requerido' });

  const { rows } = await query(
    `SELECT *
     FROM products
     WHERE is_active = true
     AND LOWER(COALESCE(sku, '')) = LOWER($1)
     LIMIT 1`,
    [code]
  );

  if (!rows.length) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json({ product: rows[0] });
}

export async function createScannedProduct(req, res) {
  const sku = String(req.body.sku || '').trim();
  const name = String(req.body.name || '').trim();
  const category = normalizeCategory(req.body.category);
  const price = normalizeMoney(req.body.price);
  const cost = normalizeMoney(req.body.cost);
  const stockQty = Math.max(0, normalizeInt(req.body.stockQty, 0));
  const lowStockThreshold = Math.max(0, normalizeInt(req.body.lowStockThreshold, 5));
  const trackStock = req.body.trackStock !== false;

  if (!sku) return res.status(400).json({ error: 'Código requerido' });
  if (!name) return res.status(400).json({ error: 'Nombre requerido' });

  const existing = await query(
    `SELECT * FROM products WHERE LOWER(COALESCE(sku, '')) = LOWER($1) LIMIT 1`,
    [sku]
  );

  if (existing.rows.length) {
    const product = existing.rows[0];
    const looksLikePlaceholder =
      String(product.name || '').trim().toLowerCase() === sku.toLowerCase() &&
      Number(product.price || 0) === 0;

    if (!product.is_active || looksLikePlaceholder) {
      const updated = await query(
        `UPDATE products
         SET name = $2,
             category = $3,
             price = $4,
             cost = $5,
             stock_qty = $6,
             track_stock = $7,
             is_combo = $3 = 'COMBO',
             is_active = true,
             low_stock_threshold = $8,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [product.id, name, category, price, cost, stockQty, trackStock, lowStockThreshold]
      );
      return res.json({ product: updated.rows[0], existed: true, updated: true });
    }

    return res.json({ product, existed: true });
  }

  const { rows } = await query(
    `INSERT INTO products (name, category, sku, price, cost, stock_qty, track_stock, is_combo, is_active, low_stock_threshold)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $2 = 'COMBO', true, $8)
     RETURNING *`,
    [name, category, sku, price, cost, stockQty, trackStock, lowStockThreshold]
  );

  res.status(201).json({ product: rows[0], existed: false });
}


export async function deleteProduct(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { id } = req.params;

  const result = await withTransaction(async (client) => {
    const productResult = await client.query('SELECT * FROM products WHERE id = $1 FOR UPDATE', [id]);
    if (!productResult.rowCount) {
      const error = new Error('Producto no encontrado');
      error.status = 404;
      throw error;
    }

    const usedResult = await client.query('SELECT COUNT(*)::int AS count FROM sale_items WHERE product_id = $1', [id]);
    const usedInSales = Number(usedResult.rows[0]?.count || 0) > 0;

    if (usedInSales) {
      const updated = await client.query(
        `UPDATE products
         SET is_active = false, updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [id]
      );
      return { action: 'deactivated', product: updated.rows[0] };
    }

    await client.query('DELETE FROM product_combo_components WHERE combo_product_id = $1 OR component_product_id = $1', [id]);
    await client.query('DELETE FROM inventory_movements WHERE product_id = $1', [id]);
    await client.query('DELETE FROM products WHERE id = $1', [id]);

    return { action: 'deleted' };
  });

  res.json(result);
}

export async function listInventoryMovements(req, res) {
  if (!canManageInventory(req)) return res.status(403).json({ error: 'No tienes permiso' });

  const { rows } = await query(
    `SELECT im.*, p.name AS product_name, u.full_name AS user_name
     FROM inventory_movements im
     JOIN products p ON p.id = im.product_id
     LEFT JOIN users u ON u.id = im.user_id
     ORDER BY im.created_at DESC
     LIMIT 50`
  );

  res.json({ movements: rows });
}
