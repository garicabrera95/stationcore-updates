ALTER TABLE products ADD COLUMN IF NOT EXISTS product_kind TEXT NOT NULL DEFAULT 'PRODUCT';
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_product_kind_check;
ALTER TABLE products ADD CONSTRAINT products_product_kind_check CHECK (product_kind IN ('PRODUCT','PRINT_SERVICE','SUPPLY','PREPARED_PRODUCT'));

CREATE TABLE IF NOT EXISTS print_supply_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supply_type TEXT NOT NULL UNIQUE CHECK (supply_type IN ('PAPER','BLACK_INK','COLOR_INK')),
  purchase_quantity NUMERIC(12,2) NOT NULL DEFAULT 1,
  purchase_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  yield_units NUMERIC(12,2) NOT NULL DEFAULT 1,
  remaining_units NUMERIC(12,2) NOT NULL DEFAULT 0,
  low_level_units NUMERIC(12,2) NOT NULL DEFAULT 10,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS print_service_recipes (
  product_id UUID PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  paper_sheets NUMERIC(8,3) NOT NULL DEFAULT 1,
  black_ink_units NUMERIC(8,3) NOT NULL DEFAULT 0,
  color_ink_units NUMERIC(8,3) NOT NULL DEFAULT 0,
  waste_percent NUMERIC(6,2) NOT NULL DEFAULT 15,
  service_code TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS print_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(), sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  sale_item_id UUID NOT NULL REFERENCES sale_items(id) ON DELETE CASCADE, product_id UUID NOT NULL REFERENCES products(id),
  service_code TEXT NOT NULL, printed_pages NUMERIC(12,2) NOT NULL, paper_sheets NUMERIC(12,2) NOT NULL,
  paper_cost NUMERIC(12,4) NOT NULL DEFAULT 0, ink_cost NUMERIC(12,4) NOT NULL DEFAULT 0,
  estimated_cost NUMERIC(12,4) NOT NULL DEFAULT 0, revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO product_categories (code,name,color,sort_order,button_size,is_active,show_in_station,show_in_quick,show_in_bonuses,is_membership)
VALUES ('PRINTING','Impresiones y copias','#7c3aed',35,'normal',true,true,true,false,false),
       ('SUPPLIES','Insumos internos','#64748b',999,'small',true,false,false,false,false)
ON CONFLICT (code) DO UPDATE SET name=EXCLUDED.name, is_active=true;

INSERT INTO print_supply_settings (supply_type,purchase_quantity,purchase_cost,yield_units,remaining_units,low_level_units)
VALUES ('PAPER',500,0,500,0,50),('BLACK_INK',1,0,4500,0,300),('COLOR_INK',1,0,7500,0,500)
ON CONFLICT (supply_type) DO NOTHING;

INSERT INTO products (name,category,sku,price,cost,stock_qty,track_stock,is_active,product_kind)
VALUES ('Blanco y negro','PRINTING','PRINT-BW',15,0,0,false,true,'PRINT_SERVICE'),
('Color liviano','PRINTING','PRINT-COLOR-LIGHT',15,0,0,false,true,'PRINT_SERVICE'),
('Color página completa','PRINTING','PRINT-COLOR-FULL',20,0,0,false,true,'PRINT_SERVICE'),
('Copia de cédula','PRINTING','PRINT-ID',10,0,0,false,true,'PRINT_SERVICE')
ON CONFLICT DO NOTHING;

INSERT INTO print_service_recipes(product_id,service_code,paper_sheets,black_ink_units,color_ink_units,waste_percent)
SELECT id, sku, 1,
 CASE WHEN sku='PRINT-BW' THEN 1 WHEN sku='PRINT-ID' THEN .15 ELSE .1 END,
 CASE WHEN sku='PRINT-COLOR-LIGHT' THEN 1 WHEN sku='PRINT-COLOR-FULL' THEN 3 WHEN sku='PRINT-ID' THEN .35 ELSE 0 END, 15
FROM products WHERE sku IN ('PRINT-BW','PRINT-COLOR-LIGHT','PRINT-COLOR-FULL','PRINT-ID')
ON CONFLICT (product_id) DO NOTHING;

CREATE OR REPLACE FUNCTION stationcore_record_print_job() RETURNS TRIGGER AS $$
DECLARE r print_service_recipes%ROWTYPE; paper print_supply_settings%ROWTYPE; black print_supply_settings%ROWTYPE; color print_supply_settings%ROWTYPE;
DECLARE pc NUMERIC:=0; ic NUMERIC:=0; factor NUMERIC:=1;
BEGIN
 SELECT * INTO r FROM print_service_recipes WHERE product_id=NEW.product_id; IF NOT FOUND THEN RETURN NEW; END IF;
 SELECT * INTO paper FROM print_supply_settings WHERE supply_type='PAPER'; SELECT * INTO black FROM print_supply_settings WHERE supply_type='BLACK_INK'; SELECT * INTO color FROM print_supply_settings WHERE supply_type='COLOR_INK';
 factor:=1+(r.waste_percent/100.0); pc:=NEW.quantity*r.paper_sheets*factor*(paper.purchase_cost/NULLIF(paper.yield_units,0));
 ic:=NEW.quantity*factor*((r.black_ink_units*black.purchase_cost/NULLIF(black.yield_units,0))+(r.color_ink_units*color.purchase_cost/NULLIF(color.yield_units,0)));
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(NEW.quantity*r.paper_sheets*factor)),updated_at=NOW() WHERE supply_type='PAPER';
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(NEW.quantity*r.black_ink_units*factor)),updated_at=NOW() WHERE supply_type='BLACK_INK';
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(NEW.quantity*r.color_ink_units*factor)),updated_at=NOW() WHERE supply_type='COLOR_INK';
 UPDATE sale_items SET unit_cost=(pc+ic)/NULLIF(NEW.quantity,0),cost_total=pc+ic WHERE id=NEW.id;
 INSERT INTO print_jobs(sale_id,sale_item_id,product_id,service_code,printed_pages,paper_sheets,paper_cost,ink_cost,estimated_cost,revenue)
 VALUES(NEW.sale_id,NEW.id,NEW.product_id,r.service_code,NEW.quantity,NEW.quantity*r.paper_sheets,pc,ic,pc+ic,NEW.total);
 RETURN NEW;
END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_record_print_job ON sale_items;
CREATE TRIGGER trg_record_print_job AFTER INSERT ON sale_items FOR EACH ROW EXECUTE FUNCTION stationcore_record_print_job();
