ALTER TABLE pos_access_devices
  ADD COLUMN IF NOT EXISTS revoked_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS revoked_by_user_id UUID REFERENCES users(id);

UPDATE app_settings
SET value = COALESCE(value, '{}'::jsonb) || '{"remoteMode":"READ_ONLY","rememberDays":7}'::jsonb,
    updated_at = NOW()
WHERE key = 'pos_access_security';
