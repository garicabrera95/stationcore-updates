ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS printing_details JSONB;
UPDATE product_categories SET show_in_station=false,show_in_quick=true,updated_at=NOW() WHERE code='PRINTING';

CREATE OR REPLACE FUNCTION stationcore_record_print_job() RETURNS TRIGGER AS $$
DECLARE r print_service_recipes%ROWTYPE; paper print_supply_settings%ROWTYPE; black print_supply_settings%ROWTYPE; color print_supply_settings%ROWTYPE;
DECLARE pc NUMERIC:=0; ic NUMERIC:=0; factor NUMERIC:=1; sheets NUMERIC:=0;
BEGIN
 SELECT * INTO r FROM print_service_recipes WHERE product_id=NEW.product_id; IF NOT FOUND THEN RETURN NEW; END IF;
 SELECT * INTO paper FROM print_supply_settings WHERE supply_type='PAPER'; SELECT * INTO black FROM print_supply_settings WHERE supply_type='BLACK_INK'; SELECT * INTO color FROM print_supply_settings WHERE supply_type='COLOR_INK';
 factor:=1+(r.waste_percent/100.0);
 sheets:=COALESCE(NULLIF(NEW.printing_details->>'paperSheets','')::numeric,NEW.quantity*r.paper_sheets);
 pc:=sheets*factor*(paper.purchase_cost/NULLIF(paper.yield_units,0));
 ic:=NEW.quantity*factor*((r.black_ink_units*black.purchase_cost/NULLIF(black.yield_units,0))+(r.color_ink_units*color.purchase_cost/NULLIF(color.yield_units,0)));
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(sheets*factor)),updated_at=NOW() WHERE supply_type='PAPER';
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(NEW.quantity*r.black_ink_units*factor)),updated_at=NOW() WHERE supply_type='BLACK_INK';
 UPDATE print_supply_settings SET remaining_units=GREATEST(0,remaining_units-(NEW.quantity*r.color_ink_units*factor)),updated_at=NOW() WHERE supply_type='COLOR_INK';
 UPDATE sale_items SET unit_cost=(pc+ic)/NULLIF(NEW.quantity,0),cost_total=pc+ic WHERE id=NEW.id;
 INSERT INTO print_jobs(sale_id,sale_item_id,product_id,service_code,printed_pages,paper_sheets,paper_cost,ink_cost,estimated_cost,revenue)
 VALUES(NEW.sale_id,NEW.id,NEW.product_id,r.service_code,NEW.quantity,sheets,pc,ic,pc+ic,NEW.total);
 RETURN NEW;
END; $$ LANGUAGE plpgsql;
