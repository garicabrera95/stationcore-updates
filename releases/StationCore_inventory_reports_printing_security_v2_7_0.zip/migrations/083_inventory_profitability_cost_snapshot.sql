ALTER TABLE sale_items
  ADD COLUMN IF NOT EXISTS unit_cost NUMERIC(12,4),
  ADD COLUMN IF NOT EXISTS cost_total NUMERIC(12,4),
  ADD COLUMN IF NOT EXISTS cost_is_estimated BOOLEAN NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION stationcore_snapshot_sale_item_cost()
RETURNS TRIGGER AS $$
DECLARE
  calculated_cost NUMERIC(12,4) := 0;
BEGIN
  IF NEW.product_id IS NULL THEN
    NEW.unit_cost := COALESCE(NEW.unit_cost, 0);
    NEW.cost_total := COALESCE(NEW.cost_total, NEW.unit_cost * NEW.quantity);
    RETURN NEW;
  END IF;

  SELECT CASE
    WHEN p.is_combo THEN COALESCE((
      SELECT SUM(COALESCE(component.cost, 0) * pcc.quantity)
      FROM product_combo_components pcc
      JOIN products component ON component.id = pcc.component_product_id
      WHERE pcc.combo_product_id = p.id
    ), COALESCE(p.cost, 0))
    ELSE COALESCE(p.cost, 0)
  END
  INTO calculated_cost
  FROM products p
  WHERE p.id = NEW.product_id;

  NEW.unit_cost := COALESCE(NEW.unit_cost, calculated_cost, 0);
  NEW.cost_total := COALESCE(NEW.cost_total, NEW.unit_cost * NEW.quantity);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sale_items_cost_snapshot ON sale_items;
CREATE TRIGGER trg_sale_items_cost_snapshot
BEFORE INSERT ON sale_items
FOR EACH ROW EXECUTE FUNCTION stationcore_snapshot_sale_item_cost();

UPDATE sale_items si
SET unit_cost = costs.unit_cost,
    cost_total = costs.unit_cost * si.quantity,
    cost_is_estimated = true
FROM (
  SELECT p.id,
         CASE
           WHEN p.is_combo THEN COALESCE((
             SELECT SUM(COALESCE(component.cost, 0) * pcc.quantity)
             FROM product_combo_components pcc
             JOIN products component ON component.id = pcc.component_product_id
             WHERE pcc.combo_product_id = p.id
           ), COALESCE(p.cost, 0))
           ELSE COALESCE(p.cost, 0)
         END::numeric(12,4) AS unit_cost
  FROM products p
) costs
WHERE si.product_id = costs.id
  AND si.unit_cost IS NULL;

UPDATE sale_items
SET unit_cost = 0,
    cost_total = 0,
    cost_is_estimated = true
WHERE unit_cost IS NULL;

CREATE INDEX IF NOT EXISTS idx_sale_items_product_profitability
  ON sale_items(product_id, sale_id)
  WHERE product_id IS NOT NULL;
