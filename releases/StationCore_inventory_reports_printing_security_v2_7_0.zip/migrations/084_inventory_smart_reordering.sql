ALTER TABLE products
  ADD COLUMN IF NOT EXISTS supplier_lead_days INT NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS reorder_cover_days INT NOT NULL DEFAULT 14;

ALTER TABLE products DROP CONSTRAINT IF EXISTS products_supplier_lead_days_check;
ALTER TABLE products ADD CONSTRAINT products_supplier_lead_days_check CHECK (supplier_lead_days BETWEEN 0 AND 90);
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_reorder_cover_days_check;
ALTER TABLE products ADD CONSTRAINT products_reorder_cover_days_check CHECK (reorder_cover_days BETWEEN 1 AND 180);

CREATE INDEX IF NOT EXISTS idx_inventory_movements_reorder_usage
  ON inventory_movements(product_id, created_at, movement_type);
