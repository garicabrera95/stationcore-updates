import { spawnSync } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';

const extensions = new Set(['.js', '.cjs', '.mjs']);
const files = [];

function collect(target) {
  if (!existsSync(target)) return;
  const stat = statSync(target);
  if (stat.isFile()) {
    if (extensions.has(path.extname(target))) files.push(target.replaceAll('\\', '/'));
    return;
  }
  for (const name of readdirSync(target)) collect(path.join(target, name));
}

['server.js', 'desktop', 'scripts', 'src', path.join('public', 'js')].forEach(collect);
files.sort();

let failed = false;
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    failed = true;
    console.error(`\n✖ ${file}`);
    if (result.stderr) console.error(result.stderr.trim());
    if (result.stdout) console.error(result.stdout.trim());
  } else {
    console.log(`✓ ${file}`);
  }
}

if (failed) process.exit(1);
console.log('\nSyntax check OK');
