import { Router } from 'express';
import * as financesController from '../controllers/finances.controller.js';
import * as payrollController from '../controllers/payroll.controller.js';
import {
  ownerDashboardAuthorizationCodes,
  ownerDashboardCreateAuthorizationCode,
  ownerDashboardCreateFamilyDiscountCode,
  ownerDashboardFamilyDiscountCodes,
  ownerDashboardLogin,
  ownerDashboardSummary,
  ownerDashboardUpdateGameRequest,
  requireOwnerDashboardAuth
} from '../controllers/ownerDashboard.controller.js';

const router = Router();

function ownerAccess(handler) {
  return (req, res, next) => {
    req.user = {
      id: req.ownerUser?.id,
      full_name: req.ownerUser?.name,
      name: req.ownerUser?.name,
      role: req.ownerUser?.role,
      permissions: ['finances']
    };
    return handler(req, res, next);
  };
}


router.post('/login', ownerDashboardLogin);
router.get('/summary', requireOwnerDashboardAuth, ownerDashboardSummary);
router.get('/authorization-codes', requireOwnerDashboardAuth, ownerDashboardAuthorizationCodes);
router.post('/authorization-codes', requireOwnerDashboardAuth, ownerDashboardCreateAuthorizationCode);
router.get('/family-discount-codes', requireOwnerDashboardAuth, ownerDashboardFamilyDiscountCodes);
router.post('/family-discount-codes', requireOwnerDashboardAuth, ownerDashboardCreateFamilyDiscountCode);
router.patch('/game-requests/:requestId', requireOwnerDashboardAuth, ownerDashboardUpdateGameRequest);


router.get('/finances/summary', requireOwnerDashboardAuth, ownerAccess(financesController.getFinanceSummary));
router.post('/finances/investments', requireOwnerDashboardAuth, ownerAccess(financesController.createInvestment));
router.delete('/finances/investments/:id', requireOwnerDashboardAuth, ownerAccess(financesController.deleteInvestment));
router.post('/finances/expenses', requireOwnerDashboardAuth, ownerAccess(financesController.createExpense));
router.delete('/finances/expenses/:id', requireOwnerDashboardAuth, ownerAccess(financesController.deleteExpense));
router.post('/finances/recurring-expenses', requireOwnerDashboardAuth, ownerAccess(financesController.createRecurringExpense));
router.delete('/finances/recurring-expenses/:id', requireOwnerDashboardAuth, ownerAccess(financesController.deleteRecurringExpense));

router.get('/payroll/summary', requireOwnerDashboardAuth, ownerAccess(payrollController.getPayrollSummary));
router.get('/payroll/employees', requireOwnerDashboardAuth, ownerAccess(payrollController.listPayrollEmployees));
router.put('/payroll/employees/:userId', requireOwnerDashboardAuth, ownerAccess(payrollController.saveEmployeePayroll));
router.post('/payroll/shifts', requireOwnerDashboardAuth, ownerAccess(payrollController.createShift));
router.delete('/payroll/shifts/:id', requireOwnerDashboardAuth, ownerAccess(payrollController.deleteShift));
router.post('/payroll/generate-rotation', requireOwnerDashboardAuth, ownerAccess(payrollController.generateRotation));
router.post('/payroll/payments', requireOwnerDashboardAuth, ownerAccess(payrollController.createPayrollPayment));

export default router;
