const ownerState = {
  token: localStorage.getItem('stationcore_owner_token') || '',
  user: JSON.parse(localStorage.getItem('stationcore_owner_user') || 'null'),
  refreshTimer: null,
  filters: {
    period: localStorage.getItem('stationcore_owner_period') || 'today',
    startDate: localStorage.getItem('stationcore_owner_start_date') || '',
    endDate: localStorage.getItem('stationcore_owner_end_date') || '',
    shiftId: localStorage.getItem('stationcore_owner_shift_id') || ''
  },
  currentSection: localStorage.getItem('stationcore_owner_panel_section') || 'overview'
};

const $ = (selector) => document.querySelector(selector);

function money(value) {
  return `RD$${Number(value || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
}

function timeLabel(value) {
  if (!value) return '';
  try {
    return new Date(value).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  } catch (_error) {
    return '';
  }
}

function dateTimeLabel(value) {
  if (!value) return '';
  try {
    return new Date(value).toLocaleString('es-DO', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch (_error) {
    return '';
  }
}

function dateOnlyInput(value) {
  if (!value) return '';
  try {
    const date = new Date(value);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  } catch (_error) {
    return '';
  }
}

function rangeLabel(data) {
  return data?.range?.label || 'Hoy';
}

function elapsedMinutes(startedAt) {
  if (!startedAt) return 0;
  return Math.max(0, Math.floor((Date.now() - new Date(startedAt).getTime()) / 60000));
}

function remainingLabel(station) {
  if (!station?.active_session_id) return 'Disponible';
  if (station.rate_type === 'PREPAID' && Number(station.prepaid_minutes || 0) > 0) {
    const remaining = Math.max(0, Number(station.prepaid_minutes || 0) - elapsedMinutes(station.started_at));
    return `${remaining} min restantes`;
  }
  return `${elapsedMinutes(station.started_at)} min en modo libre`;
}

function statusText(station) {
  const status = String(station.status || '').toUpperCase();
  if (station.active_session_id || status === 'BUSY') return 'Ocupada';
  if (status === 'MAINTENANCE') return 'Mantenimiento';
  if (status === 'OFFLINE') return 'Fuera';
  return 'Disponible';
}

function statusClass(station) {
  const status = String(station.status || '').toUpperCase();
  if (station.active_session_id || status === 'BUSY') return 'busy';
  if (status === 'MAINTENANCE') return 'maintenance';
  if (status === 'OFFLINE') return 'offline';
  return 'available';
}

function setVisible() {
  const loggedIn = Boolean(ownerState.token);
  $('#ownerLogin')?.classList.toggle('hidden', loggedIn);
  $('#ownerDashboard')?.classList.toggle('hidden', !loggedIn);
}

function setOwnerSection(section = 'overview') {
  const allowed = ['overview', 'codes', 'payments', 'requests', 'stations', 'sales'];
  ownerState.currentSection = allowed.includes(section) ? section : 'overview';
  localStorage.setItem('stationcore_owner_panel_section', ownerState.currentSection);
  document.querySelectorAll('[data-owner-section-tab]').forEach((button) => {
    button.classList.toggle('active', button.dataset.ownerSectionTab === ownerState.currentSection);
  });
  document.querySelectorAll('[data-owner-section]').forEach((sectionEl) => {
    const sections = String(sectionEl.dataset.ownerSection || '').split(/\s+/).filter(Boolean);
    sectionEl.classList.toggle('hidden', !sections.includes(ownerState.currentSection));
  });
}

async function ownerApi(path, options = {}) {
  const response = await fetch(`/api/owner-dashboard${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(ownerState.token ? { Authorization: `Bearer ${ownerState.token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || data.message || 'No se pudo completar la solicitud.');
  return data;
}

async function loginOwner(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  const errorBox = $('#ownerLoginError');
  const pin = $('#ownerPin')?.value || '';
  errorBox?.classList.add('hidden');
  button.disabled = true;
  try {
    const result = await ownerApi('/login', {
      method: 'POST',
      body: JSON.stringify({ pin })
    });
    ownerState.token = result.token;
    ownerState.user = result.user;
    localStorage.setItem('stationcore_owner_token', result.token);
    localStorage.setItem('stationcore_owner_user', JSON.stringify(result.user));
    $('#ownerPin').value = '';
    setVisible();
    await loadDashboard();
    startAutoRefresh();
  } catch (error) {
    if (errorBox) {
      errorBox.textContent = error.message;
      errorBox.classList.remove('hidden');
    }
  } finally {
    button.disabled = false;
  }
}

function logoutOwner() {
  ownerState.token = '';
  ownerState.user = null;
  localStorage.removeItem('stationcore_owner_token');
  localStorage.removeItem('stationcore_owner_user');
  clearInterval(ownerState.refreshTimer);
  setVisible();
}

function renderMetrics(data) {
  const label = rangeLabel(data);
  $('#metricTotalLabel').textContent = `Ventas · ${label}`;
  $('#metricTotal').textContent = money(data.sales?.total_sales);
  $('#metricSalesCount').textContent = `${data.sales?.sale_count || 0} ventas`;
  $('#metricCash').textContent = money(data.sales?.cash_sales);
  $('#metricCashCount').textContent = `${data.sales?.cash_count || 0} pagos`;
  $('#metricTransfer').textContent = money(data.sales?.transfer_sales);
  $('#metricTransferCount').textContent = `${data.sales?.transfer_count || 0} pagos`;
  $('#metricExpensesLabel').textContent = `Pagos · ${label}`;
  $('#metricExpenses').textContent = money(data.expenses?.total_expenses);
  $('#metricExpensesCount').textContent = `${data.expenses?.expense_count || 0} pagos`;
  $('#metricExpectedCash').textContent = money(data.drawer?.expected_cash || 0);
  const opening = money(data.drawer?.opening_amount || 0);
  const withdraw = money(data.drawer?.cash_to_withdraw || 0);
  $('#metricDrawerStatus').textContent = data.drawer?.status === 'OPEN'
    ? `Abierta · Fondo ${opening} · Retirar ${withdraw}`
    : `Historial · Fondo ${opening} · Retirar ${withdraw}`;
  $('#metricActiveStations').textContent = `${data.stationSummary?.active || 0}/${data.stationSummary?.total || 0}`;
  $('#metricStationStatus').textContent = `${data.stationSummary?.available || 0} disponibles`;
  $('#ownerPaymentsRangeLabel').textContent = label;
  $('#ownerRecentSalesRangeLabel').textContent = label;
  $('#ownerDrawerRangeLabel').textContent = label;
}

function renderStations(stations = []) {
  const container = $('#ownerStations');
  if (!container) return;
  if (!stations.length) {
    container.innerHTML = '<div class="empty-state">No hay estaciones registradas.</div>';
    return;
  }
  container.innerHTML = stations.map((station) => {
    const cls = statusClass(station);
    const active = Boolean(station.active_session_id);
    const game = station.game_name || (active ? 'Juego no indicado' : 'Lista para usar');
    const client = active ? (station.member_name || 'General') : 'Sin cliente';
    const cashier = active ? (station.cashier_name || 'Cajera') : '';
    return `
      <article class="station-live-card ${cls}">
        <div class="station-head">
          <div>
            <div class="station-name">${escapeHtml(station.name || 'Estación')}</div>
            <div class="station-console">${escapeHtml(station.console_type || '')}</div>
          </div>
          <span class="status-pill ${cls}">${statusText(station)}</span>
        </div>
        <div class="station-main">
          <strong>${escapeHtml(remainingLabel(station))}</strong>
          <p>${escapeHtml(game)}</p>
          <p>${escapeHtml(client)}${cashier ? ` · ${escapeHtml(cashier)}` : ''}</p>
        </div>
        <div class="station-foot">
          <span>Pendiente: ${money(station.pending_total)}</span>
          <span>${active ? `Inicio ${timeLabel(station.started_at)}` : 'Disponible'}</span>
        </div>
      </article>
    `;
  }).join('');
}

function renderRecentSales(sales = []) {
  const container = $('#ownerRecentSales');
  if (!container) return;
  if (!sales.length) {
    container.innerHTML = '<div class="empty-state">Todavía no hay ventas hoy.</div>';
    return;
  }
  container.innerHTML = sales.map((sale) => {
    const itemSummary = Array.isArray(sale.items)
      ? sale.items.slice(0, 3).map((item) => `${Number(item.quantity || 1)}x ${item.description}`).join(' · ')
      : '';
    const more = Array.isArray(sale.items) && sale.items.length > 3 ? ` · +${sale.items.length - 3}` : '';
    return `
      <article class="sale-row">
        <div class="sale-row-top">
          <div>
            <strong>${money(sale.total)}</strong><br>
            <span>${timeLabel(sale.created_at)} · ${paymentLabel(sale.payment_method)}</span>
          </div>
          <span>${escapeHtml(sale.cashier_name || 'Cajera')}</span>
        </div>
        <p>${escapeHtml(sale.member_name || 'General')} · ${escapeHtml(itemSummary || 'Venta')}${escapeHtml(more)}</p>
      </article>
    `;
  }).join('');
}


function codeTypeLabel(type = '') {
  return String(type).toUpperCase() === 'PAYMENT' ? 'Pago' : 'Transferencia';
}

function codeStatusLabel(code) {
  if (code.is_used) return `Usado${code.used_by_name ? ` por ${code.used_by_name}` : ''}`;
  if (new Date(code.expires_at).getTime() <= Date.now()) return 'Vencido';
  return `Activo hasta ${timeLabel(code.expires_at)}`;
}

function renderCodes(codes = []) {
  const container = $('#ownerCodesList');
  if (!container) return;
  if (!codes.length) {
    container.innerHTML = '<div class="empty-state compact">Sin códigos recientes.</div>';
    return;
  }
  container.innerHTML = codes.slice(0, 6).map((code) => `
    <div class="mini-row ${code.is_used ? 'used' : ''}">
      <span><strong>${escapeHtml(code.code)}</strong> · ${codeTypeLabel(code.code_type)}<small>${escapeHtml(codeStatusLabel(code))}${code.purpose_note ? ` · ${escapeHtml(code.purpose_note)}` : ''}</small></span>
    </div>
  `).join('');
}


function familyCodeStatusLabel(code) {
  if (code.is_active === false) return 'Inactivo';
  if (new Date(code.expires_at).getTime() <= Date.now()) return 'Vencido';
  if (Number(code.used_count || 0) >= Number(code.max_uses || 1)) return 'Usado completo';
  return `Activo · ${Number(code.used_count || 0)}/${Number(code.max_uses || 1)} uso(s)`;
}

function renderFamilyDiscountCodes(codes = []) {
  const container = $('#ownerFamilyDiscountList');
  if (!container) return;
  if (!codes.length) {
    container.innerHTML = '<div class="empty-state compact">Sin códigos familiares recientes.</div>';
    return;
  }
  container.innerHTML = codes.slice(0, 8).map((code) => `
    <div class="mini-row ${Number(code.used_count || 0) >= Number(code.max_uses || 1) ? 'used' : ''}">
      <span><strong>${escapeHtml(code.code)}</strong> · ${Number(code.discount_percent || 0)}%<small>${escapeHtml(familyCodeStatusLabel(code))} · vence ${dateTimeLabel(code.expires_at)}${code.note ? ` · ${escapeHtml(code.note)}` : ''}</small></span>
      <b>${money(code.discount_amount || 0)}</b>
    </div>
  `).join('');
}

function renderFamilyDiscountUsage(summary = {}) {
  const rows = summary.rows || [];
  $('#ownerDiscountsRangeLabel').textContent = rangeLabel(window.__ownerLastData || {});
  $('#ownerFamilyDiscountTotal').textContent = money(summary.discount_amount || 0);
  $('#ownerFamilyDiscountCount').textContent = `${Number(summary.usage_count || 0)} uso(s) · ${Number(summary.code_count || 0)} código(s)`;
  const container = $('#ownerFamilyDiscountUsageList');
  if (!container) return;
  if (!rows.length) {
    container.innerHTML = '<div class="empty-state compact">Sin descuentos familiares en este rango.</div>';
    return;
  }
  container.innerHTML = rows.map((row) => `
    <div class="mini-row payment">
      <span><strong>-${money(row.discount_amount)}</strong> · ${escapeHtml(row.code)} · ${Number(row.discount_percent || 0)}%<small>${timeLabel(row.used_at)} · ${escapeHtml(row.cashier_name || 'Cajera')} · ${escapeHtml(row.member_name || 'General')}</small></span>
    </div>
  `).join('');
}

async function loadFamilyDiscountCodes() {
  try {
    const data = await ownerApi('/family-discount-codes');
    renderFamilyDiscountCodes(data.discountCodes || []);
  } catch (_error) {
    renderFamilyDiscountCodes([]);
  }
}

async function generateOwnerFamilyDiscountCode() {
  const button = $('#generateOwnerFamilyDiscountBtn');
  const box = $('#ownerGeneratedFamilyDiscount');
  if (button) button.disabled = true;
  if (box) {
    box.classList.add('hidden');
    box.textContent = '';
  }
  try {
    const data = await ownerApi('/family-discount-codes', {
      method: 'POST',
      body: JSON.stringify({
        discountPercent: Number($('#ownerFamilyDiscountPercentSelect')?.value || 50),
        expiresDays: Number($('#ownerFamilyDiscountDaysSelect')?.value || 7),
        maxUses: Number($('#ownerFamilyDiscountUsesSelect')?.value || 1),
        code: $('#ownerFamilyDiscountCustomCodeInput')?.value?.trim() || '',
        note: $('#ownerFamilyDiscountNoteInput')?.value?.trim() || ''
      })
    });
    const code = data.discountCode;
    if (box && code) {
      box.innerHTML = `<span>Descuento familiar ${Number(code.discount_percent || 0)}%</span><strong>${escapeHtml(code.code)}</strong><small>Vence ${dateTimeLabel(code.expires_at)} · ${Number(code.max_uses || 1)} uso(s)</small>`;
      box.classList.remove('hidden');
    }
    if ($('#ownerFamilyDiscountCustomCodeInput')) $('#ownerFamilyDiscountCustomCodeInput').value = '';
    if ($('#ownerFamilyDiscountNoteInput')) $('#ownerFamilyDiscountNoteInput').value = '';
    await loadFamilyDiscountCodes();
  } catch (error) {
    if (box) {
      box.textContent = error.message;
      box.classList.remove('hidden');
    }
  } finally {
    if (button) button.disabled = false;
  }
}

function renderPayments(payments = []) {
  const container = $('#ownerPaymentsList');
  if (!container) return;
  if (!payments.length) {
    container.innerHTML = '<div class="empty-state compact">Sin pagos registrados hoy.</div>';
    return;
  }
  container.innerHTML = payments.map((payment) => `
    <div class="mini-row payment">
      <span><strong>${money(payment.amount)}</strong> · ${escapeHtml(payment.reason || 'Pago')}</span>
      <small>${timeLabel(payment.created_at)} · ${escapeHtml(payment.user_name || 'Cajera')}</small>
    </div>
  `).join('');
}

async function loadAuthorizationCodes() {
  try {
    const data = await ownerApi('/authorization-codes');
    renderCodes(data.codes || []);
  } catch (_error) {
    renderCodes([]);
  }
}

async function generateOwnerAuthorizationCode() {
  const button = $('#generateOwnerCodeBtn');
  const box = $('#ownerGeneratedCode');
  if (button) button.disabled = true;
  if (box) {
    box.classList.add('hidden');
    box.textContent = '';
  }
  try {
    const data = await ownerApi('/authorization-codes', {
      method: 'POST',
      body: JSON.stringify({
        codeType: $('#ownerCodeTypeSelect')?.value || 'TRANSFER',
        expiresMinutes: Number($('#ownerCodeMinutesSelect')?.value || 15),
        purposeNote: $('#ownerCodeNoteInput')?.value?.trim() || ''
      })
    });
    const code = data.authorizationCode;
    if (box && code) {
      box.innerHTML = `<span>${codeTypeLabel(code.code_type)}</span><strong>${escapeHtml(code.code)}</strong><small>Vence ${timeLabel(code.expires_at)}</small>`;
      box.classList.remove('hidden');
    }
    $('#ownerCodeNoteInput').value = '';
    await loadAuthorizationCodes();
    await loadFamilyDiscountCodes();
  } catch (error) {
    if (box) {
      box.textContent = error.message;
      box.classList.remove('hidden');
    }
  } finally {
    if (button) button.disabled = false;
  }
}


function requestStatusLabel(status = '') {
  const map = {
    PENDIENTE: 'Pendiente',
    ESPERANDO: 'Esperando',
    REVISADO: 'Revisado',
    COMPRADO: 'Comprado',
    DESCARTADO: 'Rechazado',
    CONVERTIDO: 'Disponible'
  };
  return map[String(status || '').toUpperCase()] || status || 'Pendiente';
}

function requestDecisionLabel(decision = '') {
  const map = {
    ESPERA: 'Espera',
    ACEPTO_OTRO: 'Aceptó otro',
    SE_FUE: 'Se fue',
    SOLO_REGISTRAR: 'Solo registrar'
  };
  return map[String(decision || '').toUpperCase()] || decision || 'Sin decisión';
}

function renderGameRequests(requests = []) {
  const container = $('#ownerGameRequestsList');
  const countLabel = $('#ownerGameRequestsCount');
  if (!container) return;
  if (countLabel) countLabel.textContent = requests.length ? `${requests.length} solicitud(es)` : 'Sin pendientes';
  if (!requests.length) {
    container.innerHTML = '<div class="empty-state compact">No hay solicitudes recientes.</div>';
    return;
  }
  container.innerHTML = requests.map((request) => {
    const status = String(request.status || 'PENDIENTE').toUpperCase();
    const title = request.requested_game_name || request.game_name || 'Juego solicitado';
    const platform = request.platform || 'Plataforma no indicada';
    const station = request.station_name ? ` · ${request.station_name}` : '';
    const customer = request.customer_name || 'Cliente';
    const note = request.admin_note || request.member_note || request.unavailable_reason || '';
    const canAct = ['PENDIENTE', 'ESPERANDO'].includes(status);
    const actionsHtml = canAct ? `
        <div class="game-request-actions">
          <button type="button" data-owner-request-action="REVISADO">Aprobar</button>
          <button type="button" data-owner-request-action="COMPRADO">Comprado</button>
          <button type="button" data-owner-request-action="DESCARTADO" class="danger-lite">Rechazar</button>
        </div>` : '<div class="game-request-actions processed">Solicitud procesada</div>';
    return `
      <article class="game-request-row status-${escapeHtml(status.toLowerCase())}" data-game-request-id="${escapeHtml(request.id)}">
        <div class="game-request-main">
          <div>
            <strong>${escapeHtml(title)}</strong>
            <span>${escapeHtml(platform)}${escapeHtml(station)} · ${escapeHtml(customer)} · ${requestDecisionLabel(request.customer_decision)}</span>
            ${note ? `<small>${escapeHtml(note)}</small>` : ''}
          </div>
          <b>${requestStatusLabel(status)}</b>
        </div>
        ${actionsHtml}
      </article>
    `;
  }).join('');
}

async function updateOwnerGameRequest(requestId, status) {
  const labels = { REVISADO: 'aprobada/revisada', COMPRADO: 'marcada como comprada', DESCARTADO: 'rechazada' };
  const adminNote = window.prompt(`Nota opcional para la solicitud ${labels[status] || ''}:`, '') || '';
  await ownerApi(`/game-requests/${encodeURIComponent(requestId)}`, {
    method: 'PATCH',
    body: JSON.stringify({ status, adminNote })
  });
  await loadDashboard();
}

function paymentLabel(method = '') {
  const map = { CASH: 'Efectivo', TRANSFER: 'Transferencia', MIXED: 'Mixto', CARD: 'Tarjeta' };
  return map[String(method).toUpperCase()] || method || 'Pago';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function syncOwnerFiltersUi() {
  const periodSelect = $('#ownerPeriodSelect');
  const startInput = $('#ownerStartDate');
  const endInput = $('#ownerEndDate');
  if (periodSelect) periodSelect.value = ownerState.filters.period || 'today';
  if (startInput) startInput.value = ownerState.filters.startDate || '';
  if (endInput) endInput.value = ownerState.filters.endDate || '';
  const custom = ownerState.filters.period === 'custom';
  document.querySelectorAll('.owner-custom-date').forEach((el) => el.classList.toggle('hidden', !custom));
}

function buildSummaryQuery() {
  const params = new URLSearchParams();
  params.set('period', ownerState.filters.period || 'today');
  if (ownerState.filters.period === 'custom') {
    if (ownerState.filters.startDate) params.set('startDate', ownerState.filters.startDate);
    if (ownerState.filters.endDate) params.set('endDate', ownerState.filters.endDate || ownerState.filters.startDate);
  }
  if (ownerState.filters.shiftId) params.set('shiftId', ownerState.filters.shiftId);
  return `?${params.toString()}`;
}

function persistOwnerFilters() {
  localStorage.setItem('stationcore_owner_period', ownerState.filters.period || 'today');
  localStorage.setItem('stationcore_owner_start_date', ownerState.filters.startDate || '');
  localStorage.setItem('stationcore_owner_end_date', ownerState.filters.endDate || '');
  localStorage.setItem('stationcore_owner_shift_id', ownerState.filters.shiftId || '');
}

function renderShiftFilter(shifts = []) {
  const select = $('#ownerShiftSelect');
  if (!select) return;
  const current = ownerState.filters.shiftId || '';
  select.innerHTML = '<option value="">Todos los turnos</option>' + shifts.map((shift) => {
    const label = `${shift.status === 'OPEN' ? 'Abierto' : 'Cerrado'} · ${dateTimeLabel(shift.opened_at)} · ${money(shift.cash_sales)} ventas`;
    return `<option value="${escapeHtml(shift.id)}">${escapeHtml(label)}</option>`;
  }).join('');
  select.value = shifts.some((shift) => shift.id === current) ? current : '';
  if (current && !select.value) {
    ownerState.filters.shiftId = '';
    persistOwnerFilters();
  }
}

function renderDrawerBreakdown(data) {
  const container = $('#ownerDrawerBreakdown');
  if (!container) return;
  const drawer = data.drawer || {};
  const opening = Number(drawer.opening_amount || 0);
  const cashSales = Number(drawer.cash_sales || data.sales?.cash_sales || 0);
  const drawerIn = Number(drawer.drawer_in || 0);
  const drawerOut = Number(drawer.drawer_out || 0);
  const expected = Number(drawer.expected_cash || 0);
  const withdraw = Number(drawer.cash_to_withdraw ?? (expected - opening));
  const status = drawer.status === 'OPEN' ? 'Caja abierta' : 'Caja cerrada / historial';
  container.innerHTML = `
    <div class="drawer-breakdown-grid">
      <div><span>Fondo inicial</span><strong>${money(opening)}</strong></div>
      <div><span>Ventas efectivo</span><strong>${money(cashSales)}</strong></div>
      <div><span>Entradas caja</span><strong>${money(drawerIn)}</strong></div>
      <div><span>Pagos / salidas</span><strong>${money(drawerOut)}</strong></div>
      <div><span>Total físico esperado</span><strong>${money(expected)}</strong></div>
      <div><span>Retirar dejando fondo</span><strong>${money(withdraw)}</strong></div>
    </div>
    <p class="drawer-breakdown-note">${escapeHtml(status)} · ${escapeHtml(drawer.opened_by_name || 'Sin cajera')} ${drawer.opened_at ? `· abrió ${dateTimeLabel(drawer.opened_at)}` : ''}${drawer.closed_at ? ` · cerró ${dateTimeLabel(drawer.closed_at)}` : ''}</p>
  `;
}

function renderShiftList(shifts = []) {
  const container = $('#ownerShiftList');
  if (!container) return;
  if (!shifts.length) {
    container.innerHTML = '<div class="empty-state compact">No hay turnos en este rango.</div>';
    return;
  }
  container.innerHTML = shifts.slice(0, 8).map((shift) => `
    <article class="owner-shift-row ${shift.status === 'OPEN' ? 'open' : ''}">
      <div>
        <strong>${shift.status === 'OPEN' ? 'Turno abierto' : 'Turno cerrado'}</strong>
        <span>${dateTimeLabel(shift.opened_at)}${shift.closed_at ? ` → ${dateTimeLabel(shift.closed_at)}` : ' → ahora'} · ${escapeHtml(shift.opened_by_name || 'Empleado')}</span>
      </div>
      <div>
        <b>${money(shift.cash_sales)}</b>
        <small>Retirar ${money(shift.cash_to_withdraw)}</small>
      </div>
    </article>
  `).join('');
}

async function loadDashboard() {
  try {
    const data = await ownerApi(`/summary${buildSummaryQuery()}`);
    window.__ownerLastData = data;
    renderMetrics(data);
    renderStations(data.stations || []);
    renderRecentSales(data.recentSales || []);
    renderPayments(data.payments || []);
    renderFamilyDiscountUsage(data.familyDiscounts || {});
    renderDrawerBreakdown(data);
    renderShiftFilter(data.shifts || []);
    renderShiftList(data.shifts || []);
    renderGameRequests(data.gameRequests || []);
    await loadAuthorizationCodes();
    await loadFamilyDiscountCodes();
    const date = new Date(data.generatedAt || Date.now());
    $('#ownerMeta').textContent = `${ownerState.user?.name || 'Owner'} · actualizado ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
    $('#stationUpdatedLabel').textContent = `Actualizado ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
  } catch (error) {
    if (String(error.message || '').toLowerCase().includes('sesión') || String(error.message || '').toLowerCase().includes('token')) {
      logoutOwner();
      const errorBox = $('#ownerLoginError');
      if (errorBox) {
        errorBox.textContent = error.message;
        errorBox.classList.remove('hidden');
      }
      return;
    }
    $('#ownerMeta').textContent = error.message;
  }
}

function startAutoRefresh() {
  clearInterval(ownerState.refreshTimer);
  ownerState.refreshTimer = setInterval(loadDashboard, 30000);
}

$('#ownerLoginForm')?.addEventListener('submit', loginOwner);
$('#logoutOwnerDashboard')?.addEventListener('click', logoutOwner);
$('#refreshOwnerDashboard')?.addEventListener('click', loadDashboard);
$('#generateOwnerCodeBtn')?.addEventListener('click', generateOwnerAuthorizationCode);
$('#generateOwnerFamilyDiscountBtn')?.addEventListener('click', generateOwnerFamilyDiscountCode);
document.querySelectorAll('[data-owner-section-tab]').forEach((button) => {
  button.addEventListener('click', () => setOwnerSection(button.dataset.ownerSectionTab));
});

$('#ownerPeriodSelect')?.addEventListener('change', async (event) => {
  ownerState.filters.period = event.target.value || 'today';
  ownerState.filters.shiftId = '';
  syncOwnerFiltersUi();
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerStartDate')?.addEventListener('change', async (event) => {
  ownerState.filters.startDate = event.target.value || '';
  ownerState.filters.shiftId = '';
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerEndDate')?.addEventListener('change', async (event) => {
  ownerState.filters.endDate = event.target.value || '';
  ownerState.filters.shiftId = '';
  persistOwnerFilters();
  await loadDashboard();
});
$('#ownerShiftSelect')?.addEventListener('change', async (event) => {
  ownerState.filters.shiftId = event.target.value || '';
  persistOwnerFilters();
  await loadDashboard();
});

$('#ownerGameRequestsList')?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-owner-request-action]');
  if (!button) return;
  const row = button.closest('[data-game-request-id]');
  const requestId = row?.dataset?.gameRequestId;
  const status = button.dataset.ownerRequestAction;
  if (!requestId || !status) return;
  button.disabled = true;
  try {
    await updateOwnerGameRequest(requestId, status);
  } catch (error) {
    alert(error.message || 'No se pudo actualizar la solicitud.');
  } finally {
    button.disabled = false;
  }
});

setVisible();
syncOwnerFiltersUi();
setOwnerSection(ownerState.currentSection);
if (ownerState.token) {
  loadDashboard();
  startAutoRefresh();
}
