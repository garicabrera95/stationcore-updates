// Club Versus POS - Reportes module (extraído de app.js en v2.0.5.6).
// Mantiene el mismo comportamiento; app.js solo llama estas funciones globales.

(function () {
  window.ClubVersusModules = window.ClubVersusModules || {};

function localDateOnly(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getWeekStartDate(date = new Date()) {
  const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = copy.getDay() || 7;
  copy.setDate(copy.getDate() - day + 1);
  return copy;
}

function getReportPresetRange(preset = 'today') {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (preset === 'yesterday') {
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    return { startDate: localDateOnly(yesterday), endDate: localDateOnly(yesterday), label: 'Ayer' };
  }

  if (preset === 'week') {
    return { startDate: localDateOnly(getWeekStartDate(today)), endDate: localDateOnly(today), label: 'Esta semana' };
  }

  if (preset === 'month') {
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    return { startDate: localDateOnly(monthStart), endDate: localDateOnly(today), label: 'Este mes' };
  }

  return { startDate: localDateOnly(today), endDate: localDateOnly(today), label: 'Hoy' };
}

function normalizeReportRange(startDate, endDate) {
  let start = String(startDate || '').trim();
  let end = String(endDate || '').trim() || start;
  if (!start) {
    const today = getReportPresetRange('today');
    start = today.startDate;
    end = today.endDate;
  }
  if (end < start) [start, end] = [end, start];
  return { startDate: start, endDate: end };
}

function formatReportDate(value) {
  const date = parseAppDate(value);
  if (!date) return '';
  return date.toLocaleDateString('es-DO', { day: '2-digit', month: 'short', year: 'numeric' });
}

function getReportRangeLabel(range = state.reportRange) {
  if (!range?.startDate || !range?.endDate) return 'Hoy';
  if (range.startDate === range.endDate) {
    const preset = getReportPresetRange(range.preset);
    if (range.preset !== 'custom' && preset.startDate === range.startDate && preset.endDate === range.endDate) return preset.label;
    return formatReportDate(range.startDate);
  }
  const preset = getReportPresetRange(range.preset);
  if (range.preset !== 'custom' && preset.startDate === range.startDate && preset.endDate === range.endDate) return preset.label;
  return `${formatReportDate(range.startDate)} - ${formatReportDate(range.endDate)}`;
}

function syncReportControls() {
  const current = state.reportRange.startDate ? state.reportRange : getReportPresetRange('today');
  if (!state.reportRange.startDate) state.reportRange = { preset: 'today', ...current };
  if ($('#reportStartDate')) $('#reportStartDate').value = state.reportRange.startDate;
  if ($('#reportEndDate')) $('#reportEndDate').value = state.reportRange.endDate;
  if ($('#reportRangeLabel')) $('#reportRangeLabel').textContent = getReportRangeLabel();
  document.querySelectorAll('[data-report-preset]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.reportPreset === state.reportRange.preset);
  });
}


function setActiveReportSection(section = 'sales') {
  const target = String(section || 'sales');
  const panels = document.querySelectorAll('#reportsModuleModal [data-report-section]');
  const tabs = document.querySelectorAll('#reportsModuleModal [data-report-section-tab]');
  const hasTarget = Array.from(panels).some((panel) => panel.dataset.reportSection === target);
  const active = hasTarget ? target : 'sales';
  panels.forEach((panel) => {
    panel.classList.toggle('active', panel.dataset.reportSection === active);
  });
  tabs.forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.reportSectionTab === active);
  });
  state.activeReportSection = active;
}

function initReportsSectionNav() {
  const modal = $('#reportsModuleModal');
  if (!modal || modal.dataset.reportNavReady === 'true') return;
  modal.dataset.reportNavReady = 'true';
  modal.addEventListener('click', (event) => {
    const tab = event.target.closest('[data-report-section-tab]');
    if (!tab || !modal.contains(tab)) return;
    event.preventDefault();
    setActiveReportSection(tab.dataset.reportSectionTab || 'sales');
  });
}

async function loadReports() {
  if (!state.reportRange.startDate || !state.reportRange.endDate) {
    state.reportRange = { preset: 'today', ...getReportPresetRange('today') };
  }

  const params = new URLSearchParams({
    startDate: state.reportRange.startDate,
    endDate: state.reportRange.endDate
  });
  const [report, employeeReport] = await Promise.all([
    api(`/reports/daily-summary?${params.toString()}`),
    api(`/reports/employee-summary?${params.toString()}`)
  ]);

  state.dailySummary = {
    sales: report.sales || {},
    sessions: report.sessions || {},
    range: report.range || {},
    drawer: report.drawer || null,
    dailySales: report.dailySales || [],
    stationSales: report.stationSales || [],
    categorySales: report.categorySales || [],
    topProducts: report.topProducts || [],
    familyDiscountSummary: report.familyDiscountSummary || {},
    familyDiscountRows: report.familyDiscountRows || [],
    recentFamilyDiscounts: report.recentFamilyDiscounts || [],
    extraSales: report.extraSales || [],
    extraStationSales: report.extraStationSales || [],
    pointsSummary: report.pointsSummary || {},
    pointsByCategory: report.pointsByCategory || [],
    recentPointMovements: report.recentPointMovements || [],
    pointRedemptions: report.pointRedemptions || [],
    rewardSummary: report.rewardSummary || {},
    rewardUsageByType: report.rewardUsageByType || [],
    cashierSales: report.cashierSales || [],
    transfers: report.transfers || [],
    bonuses: report.bonuses || {},
    memberships: report.memberships || [],
    openAccounts: report.openAccounts || [],
    pendingAccounts: report.pendingAccounts || {},
    closedSessions: report.closedSessions || [],
    expenseSummary: report.expenseSummary || {},
    financeExpenses: report.financeExpenses || [],
    recentExpenses: report.recentExpenses || [],
    tournamentReportSummary: report.tournamentReportSummary || {},
    tournamentsReport: report.tournamentsReport || [],
    tournamentAwardsReport: report.tournamentAwardsReport || [],
    tournamentEntrySalesReport: report.tournamentEntrySalesReport || [],
    gameReportSummary: report.gameReportSummary || {},
    topGamesReport: report.topGamesReport || [],
    gamePlatformReport: report.gamePlatformReport || [],
    memberGameReport: report.memberGameReport || [],
    requestedGamesReport: report.requestedGamesReport || [],
    copyRecommendationReport: report.copyRecommendationReport || [],
    stationOperationReport: report.stationOperationReport || {},
    reservationReportSummary: report.reservationReportSummary || {},
    reservationStatusReport: report.reservationStatusReport || [],
    groupEventReservationReport: report.groupEventReservationReport || [],
    demandLostReport: report.demandLostReport || [],
    waitlistOutcomeReport: report.waitlistOutcomeReport || [],
    employeeSummary: employeeReport || { totals: {}, employees: [] }
  };

  $('#todaySales').textContent = money(report.sales?.total_sales);
  $('#todaySessions').textContent = report.sessions?.session_count || 0;
  $('#todayMinutes').textContent = report.sessions?.total_minutes || 0;
  renderReportsModule();
  loadAuditEvents().catch((error) => {
    renderAuditEventsError(error.message || 'No se pudo cargar auditoría');
  });
}

async function setReportPreset(preset) {
  state.reportRange = { preset, ...getReportPresetRange(preset) };
  syncReportControls();
  try {
    await loadReports();
  } catch (error) {
    showToast(error.message || 'No se pudo aplicar el filtro');
  }
}

async function applyCustomReportRange() {
  const normalized = normalizeReportRange($('#reportStartDate')?.value, $('#reportEndDate')?.value);
  state.reportRange = { preset: 'custom', ...normalized };
  syncReportControls();
  try {
    await loadReports();
  } catch (error) {
    showToast(error.message || 'No se pudo aplicar el filtro');
  }
}

function openReportsModule() {
  if (!requirePermission('reports')) return;
  closeModuleHub();
  initReportsSectionNav();
  setActiveReportSection(state.activeReportSection || 'sales');
  syncReportControls();
  renderReportsModule();
  $('#reportsModuleModal').classList.remove('hidden');
  $('#reportsModuleModal').setAttribute('aria-hidden', 'false');
  loadReports().catch((error) => showToast(error.message || 'No se pudo cargar reportes'));
}

function closeReportsModule() {
  closeConfigModule('#reportsModuleModal');
}

function renderReportList(selector, rows, rowRenderer, emptyText = 'Sin datos') {
  const list = $(selector);
  if (!list) return;
  if (!rows || !rows.length) {
    list.innerHTML = `<div class="empty-row"><span>${emptyText}</span></div>`;
    return;
  }
  list.innerHTML = rows.map(rowRenderer).join('');
}


function employeeMetricText(row) {
  const pieces = [];
  pieces.push(`${Number(row.sale_count || 0)} ventas`);
  pieces.push(`${Number(row.stations_charged || 0)} cobros estación`);
  if (Number(row.minutes_handled || 0) > 0) pieces.push(`${Number(row.minutes_handled || 0)} min`);
  if (Number(row.combos_sold || 0) > 0) pieces.push(`${Number(row.combos_sold || 0)} combos`);
  if (Number(row.tournament_entries_sold || 0) > 0) pieces.push(`${Number(row.tournament_entries_sold || 0)} inscripciones`);
  return pieces.join(' · ');
}

function renderEmployeeReport(summary = {}) {
  const totals = summary.totals || {};
  const employees = summary.employees || [];

  setText('#employeeReportCount', Number(totals.employee_count || 0));
  setText('#employeeReportTotalSales', money(totals.total_sales || 0));
  setText('#employeeReportCash', money(totals.cash_sales || 0));
  setText('#employeeReportTransfer', money(totals.transfer_sales || 0));
  setText('#employeeReportMinutes', Number(totals.minutes_handled || 0));
  setText('#employeeReportCombos', Number(totals.combos_sold || 0));
  setText('#employeeReportEntries', Number(totals.tournament_entries_sold || 0));
  setText('#employeeReportStations', Number(totals.stations_charged || 0));

  renderReportList('#employeeReportList', employees, (row) => `
    <div class="employee-report-row">
      <div>
        <strong>${row.employee_name || 'Empleado'}</strong>
        <span>${employeeMetricText(row)}</span>
      </div>
      <div class="employee-report-money">
        <strong>${money(row.total_sales || 0)}</strong>
        <span>Efectivo ${money(row.cash_sales || 0)} · Transf. ${money(row.transfer_sales || 0)}</span>
      </div>
    </div>
  `, 'Sin actividad por empleado en este período');

  renderReportList('#employeeAuditActionList', employees, (row) => `
    <div>
      <span>${row.employee_name || 'Empleado'} · abrió ${Number(row.stations_opened || 0)} · guardó ${Number(row.station_accounts_saved || 0)} · cobró ${Number(row.stations_charged || 0)} · cerró ${Number(row.stations_closed || 0)}</span>
      <strong>${Number(row.prizes_delivered || 0)} premios</strong>
    </div>
  `, 'Sin acciones auditadas');
}


function getExtraReportTotals(summary = {}) {
  const rows = summary.extraSales || [];
  return rows.reduce((acc, row) => {
    acc.qty += Number(row.qty || 0);
    acc.total += Number(row.total || 0);
    acc.saleCount += Number(row.sale_count || 0);
    return acc;
  }, { qty: 0, total: 0, saleCount: 0 });
}


function getExpenseTypeLabel(type) {
  return String(type || '').toUpperCase() === 'FIXED' ? 'Fijo' : 'Variable';
}

function getPaymentMethodLabel(method) {
  const value = String(method || '').toUpperCase();
  if (value === 'CASH') return 'Efectivo';
  if (value === 'TRANSFER') return 'Transferencia';
  if (value === 'CARD') return 'Tarjeta';
  if (value === 'OTHER') return 'Otro';
  return value || 'Sin método';
}

function getTournamentStatusLabel(status) {
  const value = String(status || '').toUpperCase();
  if (value === 'SCHEDULED') return 'Programado';
  if (value === 'ACTIVE') return 'Activo';
  if (value === 'FINISHED') return 'Finalizado';
  if (value === 'CANCELLED') return 'Cancelado';
  return value || 'Sin estado';
}

function getPrizeStatusPieces(row = {}) {
  const pieces = [];
  if (Number(row.cash_amount || 0) > 0) pieces.push(`Efectivo ${getRewardStatusLabel(row.cash_status)}`);
  if (row.membership_tier) pieces.push(`Membresía ${getRewardStatusLabel(row.membership_status)}`);
  if (String(row.bonus_status || '').toUpperCase() !== 'NONE') pieces.push(`Bono ${getRewardStatusLabel(row.bonus_status)}`);
  if (String(row.goods_status || '').toUpperCase() !== 'NONE') pieces.push(`Físico ${getRewardStatusLabel(row.goods_status)}`);
  return pieces.length ? pieces.join(' · ') : 'Premio registrado';
}

function renderExpenseReports(summary = {}) {
  const expenses = summary.expenseSummary || {};
  const total = Number(expenses.total_expenses || 0);
  setText('#expenseReportTotal', money(total));
  setText('#expenseReportTotalCard', money(total));
  setText('#expenseReportCount', Number(expenses.expense_count || 0));
  setText('#expenseReportFixed', money(expenses.fixed_expenses || 0));
  setText('#expenseReportVariable', money(expenses.variable_expenses || 0));
  setText('#expenseReportCash', money(expenses.cash_expenses || 0));
  setText('#expenseReportTransfer', money(expenses.transfer_expenses || 0));

  renderReportList('#expenseByCategoryList', summary.financeExpenses || [], (row) => `
    <div>
      <span>${escapeHtml(row.category || 'GENERAL')} · ${Number(row.expense_count || 0)} gasto(s)</span>
      <strong>${money(row.total)}</strong>
    </div>
  `, 'Sin gastos por categoría en este período');

  renderReportList('#recentExpensesList', summary.recentExpenses || [], (row) => `
    <div>
      <span>${formatReportDate(row.expense_date)} · ${escapeHtml(row.name || 'Gasto')} · ${escapeHtml(row.category || 'GENERAL')}<br><small>${getExpenseTypeLabel(row.expense_type)} · ${getPaymentMethodLabel(row.payment_method)}${row.user_name ? ` · ${escapeHtml(row.user_name)}` : ''}</small></span>
      <strong>${money(row.amount)}</strong>
    </div>
  `, 'Sin gastos registrados en este período');
}

function renderTournamentReports(summary = {}) {
  const report = summary.tournamentReportSummary || {};
  setText('#tournamentReportTotal', Number(report.tournament_count || 0));
  setText('#tournamentReportTotalMini', `${Number(report.tournament_count || 0)} torneo(s)`);
  setText('#tournamentReportFinished', Number(report.finished_count || 0));
  setText('#tournamentReportParticipants', Number(report.participant_count || 0));
  setText('#tournamentReportPaidEntries', Number(report.paid_entry_count || 0));
  setText('#tournamentReportRevenue', money(report.entry_revenue || 0));
  setText('#tournamentReportAwards', Number(report.awards_count || 0));
  setText('#tournamentReportCashPrizes', money(report.cash_prizes || 0));

  renderReportList('#tournamentEntrySalesList', summary.tournamentEntrySalesReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.tournament_name || 'Torneo')} · ${escapeHtml(row.game || '')} · ${escapeHtml(row.platform || '')}<br><small>${Number(row.paid_entries || 0)} inscripción(es)</small></span>
      <strong>${money(row.entry_revenue)}</strong>
    </div>
  `, 'Sin inscripciones pagadas en este período');

  renderReportList('#tournamentsReportList', summary.tournamentsReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.name || 'Torneo')} · ${getTournamentStatusLabel(row.status)}<br><small>${escapeHtml(row.game || '')} · ${escapeHtml(row.platform || '')} · ${Number(row.participant_count || 0)} participante(s) · ${Number(row.paid_count || 0)} pago(s)</small></span>
      <strong>${money(row.entry_revenue)}</strong>
    </div>
  `, 'Sin torneos en este período');

  renderReportList('#tournamentAwardsReportList', summary.tournamentAwardsReport || [], (row) => `
    <div>
      <span>#${Number(row.position || 0)} · ${escapeHtml(row.player_name || 'Jugador')} · ${escapeHtml(row.tournament_name || 'Torneo')}<br><small>${getPrizeStatusPieces(row)}</small></span>
      <strong>${Number(row.cash_amount || 0) ? money(row.cash_amount) : '—'}</strong>
    </div>
  `, 'Sin premios de torneo en este período');
}


function renderGameReports(summary = {}) {
  const report = summary.gameReportSummary || {};
  setText('#gameReportPlayedSessions', Number(report.played_sessions || 0));
  setText('#gameReportPlayedSessionsMini', `${Number(report.played_sessions || 0)} partida(s)`);
  setText('#gameReportPlayedMinutes', Number(report.played_minutes || 0));
  setText('#gameReportGamesPlayed', Number(report.games_played || 0));
  setText('#gameReportRequests', Number(report.request_count || 0));
  setText('#gameReportUnavailable', Number(report.unavailable_requests || 0));
  setText('#gameReportWaited', Number(report.waited_count || 0));
  setText('#gameReportLeft', Number(report.left_count || 0));
  setText('#gameReportAcceptedOther', Number(report.accepted_other_count || 0));

  renderReportList('#topGamesReportList', summary.topGamesReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.game_name || 'Juego')} · ${Number(row.session_count || 0)} partida(s) · ${Number(row.total_minutes || 0)} min<br><small>${escapeHtml(row.platform || '')} · ${Number(row.member_count || 0)} miembro(s)</small></span>
      <strong>${Number(row.session_count || 0)}</strong>
    </div>
  `, 'Sin juegos jugados en este período');

  renderReportList('#gamePlatformReportList', summary.gamePlatformReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.console_type || 'Plataforma')} · ${Number(row.session_count || 0)} partida(s)</span>
      <strong>${Number(row.total_minutes || 0)} min</strong>
    </div>
  `, 'Sin juegos por plataforma en este período');

  renderReportList('#memberGameReportList', summary.memberGameReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.member_name || 'Miembro')} · ${escapeHtml(row.game_name || 'Juego')}<br><small>${Number(row.session_count || 0)} partida(s)</small></span>
      <strong>${Number(row.total_minutes || 0)} min</strong>
    </div>
  `, 'Sin juegos por miembro en este período');

  renderReportList('#requestedGamesReportList', summary.requestedGamesReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.game_name || 'Juego')} · ${escapeHtml(row.platform || 'Sin plataforma')}<br><small>Esperó ${Number(row.waited_count || 0)} · aceptó otro ${Number(row.accepted_other_count || 0)} · se fue ${Number(row.left_count || 0)}</small></span>
      <strong>${Number(row.request_count || 0)}</strong>
    </div>
  `, 'Sin solicitudes de juegos en este período');

  renderReportList('#copyRecommendationReportList', summary.copyRecommendationReport || [], (row) => {
    const copies = row.unlimited_copies ? 'Ilimitado' : `${Number(row.copy_quantity || 0)} copia(s)`;
    return `
      <div>
        <span>${escapeHtml(row.game_name || 'Juego')} · ${copies}<br><small>${Number(row.request_count || 0)} pedido(s) no disponible · ${Number(row.left_count || 0)} se fue · ${Number(row.session_count || 0)} partida(s)</small></span>
        <strong>${Number(row.waited_count || 0)} espera(s)</strong>
      </div>
    `;
  }, 'Sin señales para comprar otra copia todavía');

  renderStationOperationReport(summary.stationOperationReport || {});
  renderReservationDemandReports(summary);
}

function getReservationStatusLabel(status = '') {
  const value = String(status || '').toUpperCase();
  const labels = {
    WAITING: 'Esperando',
    RESERVED: 'Reservado',
    CALLED: 'Llamado',
    NOTIFIED: 'Avisado',
    ASSIGNED: 'Asignado',
    CONVERTED: 'Convertido',
    CANCELED: 'Cancelado',
    NO_SHOW: 'No llegó',
    EXPIRED: 'Venció'
  };
  return labels[value] || value || 'Sin estado';
}

function getReservationTypeLabel(row = {}) {
  if (String(row.reservation_scope || '').toUpperCase() === 'GROUP_EVENT') return 'Grupo / Evento';
  return String(row.reservation_type || '').toUpperCase() === 'WAITLIST' ? 'Lista de espera' : 'Reserva';
}

function renderReservationDemandReports(summary = {}) {
  const report = summary.reservationReportSummary || {};
  setText('#reservationReportTotal', Number(report.total_reservations || 0));
  setText('#reservationReportWaitlist', Number(report.waitlist_count || 0));
  setText('#reservationReportAssigned', Number(report.assigned_count || 0));
  setText('#reservationReportGroups', Number(report.group_event_count || 0));
  setText('#reservationReportPaid', money(report.paid_total || 0));
  setText('#reservationReportPending', money(report.pending_total || 0));
  setText('#reservationReportLost', Number(report.demand_lost_count || 0));
  setText('#reservationReportNoShow', Number(report.no_show_count || 0) + Number(report.expired_count || 0));

  renderReportList('#reservationStatusReportList', summary.reservationStatusReport || [], (row) => `
    <div>
      <span>${getReservationStatusLabel(row.status)} · ${getReservationTypeLabel(row)}<br><small>${Number(row.count || 0)} registro(s) · pagado ${money(row.paid_total || 0)}</small></span>
      <strong>${Number(row.count || 0)}</strong>
    </div>
  `, 'Sin reservas o esperas en este período');

  renderReportList('#groupEventReservationReportList', summary.groupEventReservationReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.customer_name || 'Grupo / Evento')} · ${getReservationStatusLabel(row.status)}<br><small>${Number(row.player_count || 0)} persona(s) · ${row.is_full_club ? 'Todo el club' : `${Number(row.station_count || 0)} estación(es)`} · ${Number(row.reserved_minutes || 0)} min</small></span>
      <strong>${money(row.pending_amount || 0)} pend.</strong>
    </div>
  `, 'Sin grupos, cumpleaños o eventos en este período');

  renderReportList('#demandLostReportList', summary.demandLostReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.game_name || 'Juego')} · ${escapeHtml(row.platform || 'Sin plataforma')}<br><small>Se fue ${Number(row.left_count || 0)} · aceptó otro ${Number(row.accepted_other_count || 0)}</small></span>
      <strong>${Number(row.lost_count || 0)}</strong>
    </div>
  `, 'Sin demanda perdida registrada en este período');

  renderReportList('#waitlistOutcomeReportList', summary.waitlistOutcomeReport || [], (row) => `
    <div>
      <span>${escapeHtml(row.label || 'Lista de espera')} · ${escapeHtml(row.platform || 'Sin plataforma')}<br><small>Asignados ${Number(row.assigned_count || 0)} · avisados ${Number(row.notified_count || 0)} · perdidos ${Number(row.missed_count || 0)}</small></span>
      <strong>${Number(row.waitlist_count || 0)}</strong>
    </div>
  `, 'Sin actividad de lista de espera en este período');
}

function renderStationOperationReport(report = {}) {
  setText('#stationCloseDelayTotal', Number(report.total_close_delay_minutes || 0));
  setText('#stationCloseDelayAverage', `${Number(report.avg_close_delay_minutes || 0)} min`);
  setText('#stationCloseDelayMax', `${Number(report.max_close_delay_minutes || 0)} min`);
  setText('#stationCloseDelayClosedCount', Number(report.closed_count || 0));

  renderReportList('#stationCloseDelayByStationList', report.by_station || [], (row) => `
    <div>
      <span>${escapeHtml(row.station_name || 'Estación')} · ${escapeHtml(row.console_type || '')}<br><small>${Number(row.closed_count || 0)} cierre(s) · promedio ${Number(row.avg_close_delay_minutes || 0)} min · mayor ${Number(row.max_close_delay_minutes || 0)} min</small></span>
      <strong>${Number(row.total_close_delay_minutes || 0)} min</strong>
    </div>
  `, 'Sin tiempo muerto después de terminar en este período');

  renderReportList('#stationSlowClosingsList', report.slowest_closings || [], (row) => `
    <div>
      <span>${escapeHtml(row.station_name || 'Estación')} · ${escapeHtml(row.console_type || '')}<br><small>${formatReportDate(row.ended_at) || 'Sin fecha'}</small></span>
      <strong>${Number(row.close_delay_minutes || 0)} min</strong>
    </div>
  `, 'Sin cierres lentos en este período');
}

function renderExtraReports(summary = {}) {
  const totals = getExtraReportTotals(summary);
  setText('#reportExtrasTotal', money(totals.total));
  setText('#reportExtrasTotalCard', money(totals.total));
  setText('#reportExtrasQty', Number(totals.qty || 0));
  setText('#reportExtrasSalesCount', Number(totals.saleCount || 0));

  renderReportList('#reportExtrasList', summary.extraSales || [], (row) => `
    <div>
      <span>${escapeHtml(row.extra_name || 'Extra')} · ${Number(row.qty || 0)} uso(s) · ${Number(row.sale_count || 0)} venta(s)</span>
      <strong>${money(row.total)}</strong>
    </div>
  `, 'Sin extras vendidos en este período');

  renderReportList('#reportExtrasStationList', summary.extraStationSales || [], (row) => `
    <div>
      <span>${escapeHtml(row.station_name || 'Estación')} · ${escapeHtml(row.extra_name || 'Extra')} · ${Number(row.qty || 0)} uso(s)</span>
      <strong>${money(row.total)}</strong>
    </div>
  `, 'Sin extras por estación en este período');
}

const POINT_CATEGORY_LABELS = {
  TOURNAMENT: 'Torneos',
  RAFFLE: 'Rifas',
  REDEMPTION: 'Canjes',
  VISIT: 'Visitas',
  SALE: 'Ventas',
  SESSION: 'Sesiones',
  BONUS: 'Bonos',
  ADJUSTMENT: 'Ajustes',
  LEGACY: 'Histórico',
  GENERAL: 'General'
};

const REDEMPTION_TYPE_LABELS = {
  TIME: 'Tiempo',
  SNACK: 'Snack genérico',
  DRINK: 'Bebida genérica',
  PRODUCT: 'Producto inventario',
  CUSTOM: 'Otro'
};

const REWARD_TYPE_LABELS = {
  VISIT_REWARD: 'Visitas',
  BIRTHDAY_REWARD: 'Cumpleaños',
  MANUAL: 'Manual',
  MANUAL_BONUS: 'Bono manual',
  PURCHASE_BONUS: 'Compra',
  TOURNAMENT_PRIZE: 'Torneo',
  POINT_REDEMPTION: 'Canje puntos'
};

function getPointCategoryLabel(category) {
  return POINT_CATEGORY_LABELS[String(category || '').toUpperCase()] || String(category || 'General');
}

function getRedemptionTypeLabel(type) {
  return REDEMPTION_TYPE_LABELS[String(type || '').toUpperCase()] || String(type || 'Otro');
}

function getRewardTypeLabel(type) {
  return REWARD_TYPE_LABELS[String(type || '').toUpperCase()] || String(type || 'Bono');
}

function getRewardStatusLabel(status) {
  const normalized = String(status || '').toUpperCase();
  if (normalized === 'AVAILABLE') return 'Disponible';
  if (normalized === 'USED') return 'Usado';
  if (normalized === 'EXPIRED') return 'Vencido';
  if (normalized === 'VOID') return 'Anulado';
  return status || 'Estado';
}

function renderPointsAdminReport(summary = {}) {
  const points = summary.pointsSummary || {};
  const rewards = summary.rewardSummary || {};
  setText('#pointsReportEarned', Number(points.earned_points || 0));
  setText('#pointsReportSpent', Number(points.spent_points || 0));
  setText('#pointsReportRanking', Number(points.ranking_points || 0));
  setText('#pointsReportMovements', Number(points.movement_count || 0));
  setText('#pointsReportMembers', Number(points.member_count || 0));

  setText('#rewardsReportAvailable', Number(rewards.available_count || 0));
  setText('#rewardsReportUsed', Number(rewards.used_count || 0));
  setText('#rewardsReportExpired', Number(rewards.expired_count || 0));
  setText('#rewardsReportPointRedemptions', Number(rewards.point_redemption_rewards || 0));
  setText('#rewardsReportUnits', `${Number(rewards.minutes_used || 0)} min · ${Number(rewards.snacks_used || 0)} snacks · ${Number(rewards.drinks_used || 0)} bebidas · ${Number(rewards.products_used || 0)} productos`);

  renderReportList('#pointsByCategoryList', summary.pointsByCategory || [], (row) => `
    <div>
      <span>${getPointCategoryLabel(row.category)} · ${Number(row.movement_count || 0)} mov.</span>
      <strong>+${Number(row.earned_points || 0)} / -${Number(row.spent_points || 0)}</strong>
    </div>
  `, 'Sin movimientos de puntos en este período');

  renderReportList('#pointRedemptionsList', summary.pointRedemptions || [], (row) => `
    <div>
      <span>${escapeHtml(row.option_name || 'Canje')} · ${getRedemptionTypeLabel(row.redemption_type)} · ${Number(row.redemption_count || 0)} canje(s) · ${Number(row.member_count || 0)} miembro(s)</span>
      <strong>${Number(row.points_spent || 0)} pts</strong>
    </div>
  `, 'Sin canjes por puntos en este período');

  renderReportList('#rewardUsageByTypeList', summary.rewardUsageByType || [], (row) => `
    <div>
      <span>${getRewardTypeLabel(row.reward_type)} · ${getRewardStatusLabel(row.status)} · ${Number(row.reward_count || 0)} bono(s)</span>
      <strong>${Number(row.minutes_used || 0)} min · ${Number(row.snacks_used || 0) + Number(row.drinks_used || 0) + Number(row.products_used || 0)} prod.</strong>
    </div>
  `, 'Sin bonos creados/usados en este período');

  renderReportList('#recentPointMovementsList', summary.recentPointMovements || [], (row) => {
    const pointsValue = Number(row.points || 0);
    const sign = pointsValue > 0 ? '+' : '';
    const rankingBadge = row.affects_ranking ? ' · Ranking' : ' · Saldo';
    const balance = row.balance_after === null || row.balance_after === undefined ? '' : ` · saldo ${Number(row.balance_after || 0)}`;
    return `
      <div>
        <span>${formatDateTime(row.created_at)} · ${escapeHtml(row.member_name || 'Miembro')} · ${getPointCategoryLabel(row.category)}${rankingBadge}${balance}<br><small>${escapeHtml(row.reason || '')}${row.user_name ? ` · ${escapeHtml(row.user_name)}` : ''}</small></span>
        <strong>${sign}${pointsValue} pts</strong>
      </div>
    `;
  }, 'Sin movimientos recientes en este período');
}

const AUDIT_EVENT_LABELS = {
  DRAWER_OPENED: 'Caja abierta',
  DRAWER_CLOSED: 'Caja cerrada',
  DRAWER_PAYOUT: 'Payout / salida',
  DRAWER_MOVEMENT_IN: 'Entrada de efectivo',
  QUICK_SALE_PAID: 'Venta rápida',
  STATION_OPENED: 'Estación abierta',
  STATION_ACCOUNT_SAVED: 'Cuenta guardada',
  STATION_ACCOUNT_PAID: 'Cuenta pendiente cobrada',
  STATION_CHECKOUT_PAID: 'Estación cobrada',
  STATION_CLOSED: 'Estación cerrada',
  TOURNAMENT_ENTRY_SOLD: 'Inscripción torneo',
  TOURNAMENT_PRIZE_CASH_DELIVERED: 'Premio efectivo',
  TOURNAMENT_PRIZE_MEMBERSHIP_DELIVERED: 'Premio membresía',
  TOURNAMENT_PRIZE_BONUS_DELIVERED: 'Premio bono',
  TOURNAMENT_PRIZE_GOODS_DELIVERED: 'Premio físico'
};

function getAuditEventLabel(type) {
  return AUDIT_EVENT_LABELS[type] || String(type || 'Acción');
}

function getAuditFilters() {
  const current = state.auditFilters || {};
  return {
    userId: current.userId || '',
    eventType: current.eventType || '',
    stationId: current.stationId || '',
    limit: current.limit || '100'
  };
}

function syncAuditFilterOptions() {
  const filters = getAuditFilters();
  const employeeSelect = $('#auditEmployeeFilter');
  const stationSelect = $('#auditStationFilter');
  const eventTypeSelect = $('#auditEventTypeFilter');
  const limitSelect = $('#auditLimitFilter');

  if (employeeSelect) {
    const employees = Array.isArray(state.employees) ? state.employees : [];
    const options = ['<option value="">Todos</option>'].concat(employees.map((employee) => {
      const id = escapeAttr(employee.id || '');
      const name = escapeHtml(employee.full_name || employee.name || employee.pin_name || 'Empleado');
      return `<option value="${id}">${name}</option>`;
    }));
    employeeSelect.innerHTML = options.join('');
    employeeSelect.value = filters.userId;
  }

  if (stationSelect) {
    const stations = Array.isArray(state.stations) ? state.stations : [];
    const options = ['<option value="">Todas</option>'].concat(stations.map((station) => {
      const id = escapeAttr(station.id || '');
      const name = escapeHtml(station.name || station.label || 'Estación');
      return `<option value="${id}">${name}</option>`;
    }));
    stationSelect.innerHTML = options.join('');
    stationSelect.value = filters.stationId;
  }

  if (eventTypeSelect) eventTypeSelect.value = filters.eventType;
  if (limitSelect) limitSelect.value = filters.limit;
}

function readAuditFiltersFromDom() {
  state.auditFilters = {
    userId: $('#auditEmployeeFilter')?.value || '',
    eventType: $('#auditEventTypeFilter')?.value || '',
    stationId: $('#auditStationFilter')?.value || '',
    limit: $('#auditLimitFilter')?.value || '100'
  };
  return state.auditFilters;
}

function buildAuditParams(filters = getAuditFilters()) {
  const params = new URLSearchParams({
    startDate: state.reportRange.startDate,
    endDate: state.reportRange.endDate,
    limit: filters.limit || '100'
  });
  if (filters.userId) params.set('userId', filters.userId);
  if (filters.eventType) params.set('eventType', filters.eventType);
  if (filters.stationId) params.set('stationId', filters.stationId);
  return params;
}

function getAuditAmount(event = {}) {
  const metadata = event.metadata || {};
  const amount = metadata.amount ?? metadata.total ?? metadata.total_amount ?? metadata.paid_amount ?? metadata.cash_received ?? metadata.price ?? null;
  return Number(amount || 0);
}

function getAuditDetailPieces(event = {}) {
  const metadata = event.metadata || {};
  const pieces = [];
  if (event.station_name) pieces.push(`Estación: ${event.station_name}`);
  if (event.tournament_name) pieces.push(`Torneo: ${event.tournament_name}`);
  if (metadata.payment_method) pieces.push(`Pago: ${metadata.payment_method === 'TRANSFER' ? 'Transferencia' : metadata.payment_method === 'CASH' ? 'Efectivo' : metadata.payment_method}`);
  if (metadata.description) pieces.push(metadata.description);
  if (metadata.reason) pieces.push(`Razón: ${metadata.reason}`);
  if (metadata.member_name) pieces.push(`Miembro: ${metadata.member_name}`);
  if (metadata.participant_name) pieces.push(`Participante: ${metadata.participant_name}`);
  if (metadata.minutes) pieces.push(`${metadata.minutes} min`);
  if (metadata.items_count) pieces.push(`${metadata.items_count} artículos`);
  if (metadata.combo_count) pieces.push(`${metadata.combo_count} combos`);
  return pieces.filter(Boolean).map(escapeHtml);
}

function renderAuditEvents(events = []) {
  setText('#auditEventsCount', Number(events.length || 0));
  const list = $('#auditEventsList');
  if (!list) return;
  if (!events.length) {
    list.innerHTML = '<div class="empty-row"><span>Sin eventos de auditoría en este período</span></div>';
    return;
  }

  list.innerHTML = events.map((event) => {
    const amount = getAuditAmount(event);
    const pieces = getAuditDetailPieces(event);
    const detail = pieces.length ? pieces.join(' · ') : escapeHtml(event.entity_type || 'Sin detalle adicional');
    return `
      <article class="audit-event-row">
        <div class="audit-event-main">
          <strong>${escapeHtml(getAuditEventLabel(event.event_type))}</strong>
          <span>${escapeHtml(formatDateTime(event.created_at))} · ${escapeHtml(event.user_name || 'Sin empleado asignado')}</span>
          <small>${detail}</small>
        </div>
        <div class="audit-event-side">
          ${amount ? `<strong>${money(amount)}</strong>` : '<strong>—</strong>'}
          <span>${escapeHtml(event.event_type || '')}</span>
        </div>
      </article>`;
  }).join('');
}

function renderAuditEventsError(message) {
  setText('#auditEventsCount', 0);
  const list = $('#auditEventsList');
  if (list) list.innerHTML = `<div class="empty-row"><span>${escapeHtml(message || 'No se pudo cargar auditoría')}</span></div>`;
}

async function loadAuditEvents() {
  if (!state.reportRange.startDate || !state.reportRange.endDate) {
    state.reportRange = { preset: 'today', ...getReportPresetRange('today') };
  }
  syncAuditFilterOptions();
  const filters = getAuditFilters();
  const params = buildAuditParams(filters);
  const data = await api(`/reports/audit-events?${params.toString()}`);
  state.auditEvents = data.events || [];
  renderAuditEvents(state.auditEvents);
  return data;
}

async function applyAuditFilters() {
  readAuditFiltersFromDom();
  try {
    await loadAuditEvents();
  } catch (error) {
    showToast(error.message || 'No se pudo aplicar auditoría');
    renderAuditEventsError(error.message || 'No se pudo cargar auditoría');
  }
}

function renderReportsModule() {
  const summary = state.dailySummary || {};
  const sales = summary.sales || {};
  const sessions = summary.sessions || {};
  const drawer = summary.drawer || null;
  const bonuses = summary.bonuses || {};
  const pendingAccounts = summary.pendingAccounts || {};
  const employeeSummary = summary.employeeSummary || { totals: {}, employees: [] };

  syncReportControls();

  setText('#reportSalesTotal', money(sales.total_sales));
  setText('#reportSalesTotalMini', money(sales.total_sales));
  setText('#reportCashTotal', money(sales.cash_sales));
  setText('#reportTransferTotal', money(sales.transfer_sales));
  setText('#reportSessionsTotal', sessions.session_count || 0);
  setText('#reportMinutesTotal', sessions.total_minutes || 0);
  setText('#reportBonusesUsed', bonuses.used_count || 0);
  setText('#reportFamilyDiscountTotal', money(summary.familyDiscountSummary?.discount_amount || 0));
  setText('#reportPendingTotal', money(pendingAccounts.pending_total || 0));
  setText('#reportPendingCount', pendingAccounts.account_count || 0);

  if (drawer) {
    setText('#reportDrawerStatus', drawer.status === 'OPEN' ? 'Abierta' : 'Cerrada');
    setText('#reportDrawerOpening', money(drawer.opening_amount));
    setText('#reportDrawerCash', money(drawer.cash_sales));
    setText('#reportDrawerTransfer', money(drawer.transfer_sales));
    setText('#reportDrawerIn', money(drawer.drawer_in));
    setText('#reportDrawerOut', money(drawer.drawer_out));
    setText('#reportDrawerExpected', money(drawer.expected_cash));
    setText('#reportDrawerDifference', money(drawer.cash_difference));
    renderReportList('#reportDrawerMovementsList', drawer.movements || [], (row) => `
      <div>
        <span>${formatDateTime(row.created_at)} · ${row.type === 'OUT' ? 'Pago / salida' : 'Entrada'} · ${row.reason || 'Sin razón'}</span>
        <strong>${row.type === 'OUT' ? '-' : '+'}${money(row.amount)}</strong>
      </div>
    `);
  } else {
    setText('#reportDrawerStatus', 'Sin caja');
    setText('#reportDrawerOpening', money(0));
    setText('#reportDrawerCash', money(0));
    setText('#reportDrawerTransfer', money(0));
    setText('#reportDrawerIn', money(0));
    setText('#reportDrawerOut', money(0));
    setText('#reportDrawerExpected', money(0));
    setText('#reportDrawerDifference', money(0));
    renderReportList('#reportDrawerMovementsList', [], (row) => '');
  }

  renderReportList('#reportCategoryList', summary.categorySales, (row) => `
    <div><span>${row.category || 'Otros'}</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportDailySalesList', summary.dailySales, (row) => `
    <div><span>${formatReportDate(row.sale_date)} · ${row.sale_count || 0} ventas</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportStationList', summary.stationSales, (row) => `
    <div><span>${row.station_name || 'Estación'} · ${row.session_count || 0} sesiones · ${row.total_minutes || 0} min</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportTopItemsList', summary.topProducts, (row) => `
    <div><span>${row.description || 'Artículo'} · ${Number(row.qty || 0)}</span><strong>${money(row.total)}</strong></div>
  `);

  renderExpenseReports(summary);
  renderTournamentReports(summary);
  renderGameReports(summary);
  renderExtraReports(summary);
  renderPointsAdminReport(summary);

  renderReportList('#reportCashierList', summary.cashierSales, (row) => `
    <div><span>${row.cashier_name || 'Cajero'} · ${row.sale_count || 0} ventas</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportFamilyDiscountList', summary.familyDiscountRows || [], (row) => `
    <div><span>${escapeHtml(row.code || 'Código')} · ${Number(row.discount_percent || 0)}% · ${Number(row.usage_count || 0)} uso(s)<br><small>${escapeHtml(row.note || 'Descuento familiar')}</small></span><strong>-${money(row.discount_amount || 0)}</strong></div>
  `, 'Sin descuentos familiares en este período');

  renderReportList('#reportRecentFamilyDiscountList', summary.recentFamilyDiscounts || [], (row) => `
    <div><span>${formatDateTime(row.used_at)} · ${escapeHtml(row.code || 'Código')} · ${escapeHtml(row.cashier_name || 'Cajera')} · ${escapeHtml(row.member_name || 'General')}</span><strong>-${money(row.discount_amount || 0)}</strong></div>
  `, 'Sin descuentos aplicados recientemente');

  renderReportList('#reportTransferList', summary.transfers, (row) => `
    <div><span>${formatDateTime(row.created_at)} · ${row.cashier_name || 'Cajero'}${row.member_name ? ` · ${row.member_name}` : ''}</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportMembershipList', summary.memberships, (row) => `
    <div><span>${getMembershipLabel(row.tier)} · ${row.count || 0}</span><strong>${money(row.total)}</strong></div>
  `);

  renderReportList('#reportOpenAccountsList', summary.openAccounts, (row) => `
    <div>
      <span>${row.station_name || 'Estación'} · ${row.rate_type === 'HOURLY' ? 'Modo libre' : 'Tiempo'}${row.member_name ? ` · ${row.member_name}` : ''}</span>
      <strong>${money(row.pending_total)}</strong>
    </div>
  `, 'Sin cuentas abiertas');

  renderReportList('#reportClosedSessionsList', summary.closedSessions, (row) => `
    <div>
      <span>${formatDateTime(row.ended_at)} · ${row.station_name || 'Estación'} · ${row.total_minutes || 0} min</span>
      <strong>${money(row.total_amount)}</strong>
    </div>
  `, 'Sin sesiones cerradas');

  renderEmployeeReport(employeeSummary);
}

  window.ClubVersusModules.reports = {
    localDateOnly,
    getWeekStartDate,
    getReportPresetRange,
    normalizeReportRange,
    formatReportDate,
    getReportRangeLabel,
    syncReportControls,
    loadReports,
    setReportPreset,
    applyCustomReportRange,
    openReportsModule,
    closeReportsModule,
    renderReportList,
    renderEmployeeReport,
    syncAuditFilterOptions,
    loadAuditEvents,
    applyAuditFilters,
    renderAuditEvents,
    renderExpenseReports,
    renderTournamentReports,
    renderGameReports,
    renderExtraReports,
    renderPointsAdminReport,
    setActiveReportSection,
    initReportsSectionNav,
    renderReportsModule
  };
})();
