CREATE TABLE IF NOT EXISTS family_discount_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT NOT NULL UNIQUE,
  discount_percent INT NOT NULL CHECK (discount_percent > 0 AND discount_percent <= 100),
  applies_to TEXT NOT NULL DEFAULT 'GAME_TIME' CHECK (applies_to IN ('GAME_TIME')),
  max_uses INT NOT NULL DEFAULT 1 CHECK (max_uses > 0),
  used_count INT NOT NULL DEFAULT 0 CHECK (used_count >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  expires_at TIMESTAMPTZ NOT NULL,
  note TEXT,
  created_by_user_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_family_discount_codes_active
  ON family_discount_codes (is_active, expires_at, created_at DESC);

CREATE TABLE IF NOT EXISTS family_discount_code_usages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code_id UUID NOT NULL REFERENCES family_discount_codes(id),
  sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  subtotal_before_discount NUMERIC(12,2) NOT NULL DEFAULT 0,
  discountable_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_after_discount NUMERIC(12,2) NOT NULL DEFAULT 0,
  used_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_family_discount_code_usages_used_at
  ON family_discount_code_usages (used_at DESC);

CREATE INDEX IF NOT EXISTS idx_family_discount_code_usages_code
  ON family_discount_code_usages (code_id, used_at DESC);
