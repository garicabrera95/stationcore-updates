import { Router } from 'express';
import {
  ownerDashboardAuthorizationCodes,
  ownerDashboardCreateAuthorizationCode,
  ownerDashboardCreateFamilyDiscountCode,
  ownerDashboardFamilyDiscountCodes,
  ownerDashboardLogin,
  ownerDashboardSummary,
  ownerDashboardUpdateGameRequest,
  requireOwnerDashboardAuth
} from '../controllers/ownerDashboard.controller.js';

const router = Router();

router.post('/login', ownerDashboardLogin);
router.get('/summary', requireOwnerDashboardAuth, ownerDashboardSummary);
router.get('/authorization-codes', requireOwnerDashboardAuth, ownerDashboardAuthorizationCodes);
router.post('/authorization-codes', requireOwnerDashboardAuth, ownerDashboardCreateAuthorizationCode);
router.get('/family-discount-codes', requireOwnerDashboardAuth, ownerDashboardFamilyDiscountCodes);
router.post('/family-discount-codes', requireOwnerDashboardAuth, ownerDashboardCreateFamilyDiscountCode);
router.patch('/game-requests/:requestId', requireOwnerDashboardAuth, ownerDashboardUpdateGameRequest);

export default router;
