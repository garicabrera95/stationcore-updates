import { query } from '../db/pool.js';

function toNumber(value) {
  return Number(value || 0);
}

function toDateOnly(value) {
  if (!value) return null;
  const raw = String(value).trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(raw) ? raw : null;
}

function todayDateOnly() {
  return new Date().toISOString().slice(0, 10);
}

function resolveReportRange(req) {
  const startDate = toDateOnly(req.query.startDate) || todayDateOnly();
  const endDate = toDateOnly(req.query.endDate) || startDate;

  if (endDate < startDate) {
    return { startDate: endDate, endDate: startDate };
  }

  return { startDate, endDate };
}

function formatDrawer(row) {
  if (!row || !toNumber(row.drawer_count)) return null;

  const hasOpenDrawer = toNumber(row.open_drawer_count) > 0;
  const expectedCash = toNumber(row.opening_amount) + toNumber(row.cash_sales) + toNumber(row.drawer_in) - toNumber(row.drawer_out);
  const cashDifference = toNumber(row.cash_difference);

  return {
    status: hasOpenDrawer ? 'OPEN' : 'CLOSED',
    drawer_count: toNumber(row.drawer_count),
    open_drawer_count: toNumber(row.open_drawer_count),
    opening_amount: toNumber(row.opening_amount),
    closing_amount: toNumber(row.closing_amount),
    expected_cash: expectedCash,
    cash_difference: cashDifference,
    cash_sales: toNumber(row.cash_sales),
    transfer_sales: toNumber(row.transfer_sales),
    drawer_in: toNumber(row.drawer_in),
    drawer_out: toNumber(row.drawer_out),
    movements: row.movements || [],
    opened_at: row.first_opened_at,
    closed_at: row.last_closed_at,
    opened_by_name: row.opened_by_name,
    closed_by_name: row.closed_by_name
  };
}

async function getDrawerReport(startDate, endDate) {
  const drawerResult = await query(
    `WITH report_window AS (
       SELECT $1::date AS start_date, ($2::date + INTERVAL '1 day') AS end_date
     ), range_sales AS (
       SELECT
         COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales
       FROM sales s, report_window rw
       WHERE s.status = 'PAID'
         AND s.created_at >= rw.start_date
         AND s.created_at < rw.end_date
     ), range_drawers AS (
       SELECT d.*
       FROM cash_drawers d, report_window rw
       WHERE d.opened_at < rw.end_date
         AND COALESCE(d.closed_at, NOW()) >= rw.start_date
     ), range_movements AS (
       SELECT
         COALESCE(SUM(CASE WHEN dm.type = 'IN' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
         COALESCE(SUM(CASE WHEN dm.type = 'OUT' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
       FROM drawer_movements dm
       JOIN range_drawers d ON d.id = dm.drawer_id
       JOIN report_window rw ON true
       WHERE dm.created_at >= rw.start_date
         AND dm.created_at < rw.end_date
     ), range_movement_rows AS (
       SELECT COALESCE(jsonb_agg(to_jsonb(movement_rows) ORDER BY movement_rows.created_at DESC), '[]'::jsonb) AS movements
       FROM (
         SELECT dm.id, dm.type, dm.amount, dm.reason, dm.created_at, u.full_name AS user_name
         FROM drawer_movements dm
         JOIN range_drawers d ON d.id = dm.drawer_id
         JOIN users u ON u.id = dm.user_id
         JOIN report_window rw ON true
         WHERE dm.created_at >= rw.start_date
           AND dm.created_at < rw.end_date
         ORDER BY dm.created_at DESC
         LIMIT 50
       ) movement_rows
     )
     SELECT
       COUNT(d.id)::int AS drawer_count,
       COUNT(*) FILTER (WHERE d.status = 'OPEN')::int AS open_drawer_count,
       COALESCE(SUM(d.opening_amount), 0)::numeric(12,2) AS opening_amount,
       COALESCE(SUM(d.closing_amount), 0)::numeric(12,2) AS closing_amount,
       COALESCE(SUM(CASE WHEN d.status = 'CLOSED' THEN d.cash_difference ELSE 0 END), 0)::numeric(12,2) AS cash_difference,
       MIN(d.opened_at) AS first_opened_at,
       MAX(d.closed_at) AS last_closed_at,
       MAX(ou.full_name) AS opened_by_name,
       MAX(cu.full_name) AS closed_by_name,
       rs.cash_sales,
       rs.transfer_sales,
       rm.drawer_in,
       rm.drawer_out,
       rmr.movements
     FROM range_drawers d
     LEFT JOIN users ou ON ou.id = d.opened_by_user_id
     LEFT JOIN users cu ON cu.id = d.closed_by_user_id
     CROSS JOIN range_sales rs
     CROSS JOIN range_movements rm
     CROSS JOIN range_movement_rows rmr
     GROUP BY rs.cash_sales, rs.transfer_sales, rm.drawer_in, rm.drawer_out, rmr.movements`,
    [startDate, endDate]
  );

  return formatDrawer(drawerResult.rows[0]);
}

export async function dailySummary(req, res) {
  try {
  const { startDate, endDate } = resolveReportRange(req);
  const params = [startDate, endDate];
  const salesRangeFilter = `s.created_at >= $1::date AND s.created_at < ($2::date + INTERVAL '1 day')`;

  const sales = await query(
    `SELECT
      COUNT(s.id)::int AS sale_count,
      COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales,
      COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
      COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales,
      COALESCE(SUM(s.discount_total), 0)::numeric(12,2) AS discount_total,
      COUNT(s.id) FILTER (WHERE s.payment_method = 'CASH')::int AS cash_count,
      COUNT(s.id) FILTER (WHERE s.payment_method = 'TRANSFER')::int AS transfer_count
    FROM sales s
    WHERE ${salesRangeFilter} AND s.status = 'PAID'`,
    params
  );

  const sessions = await query(
    `SELECT
      COUNT(*)::int AS session_count,
      COALESCE(SUM(total_minutes), 0)::int AS total_minutes,
      COALESCE(SUM(total_amount), 0)::numeric(12,2) AS game_sales
    FROM game_sessions
    WHERE started_at >= $1::date AND started_at < ($2::date + INTERVAL '1 day')`,
    params
  );

  const dailySales = await query(
    `SELECT
      s.created_at::date AS sale_date,
      COUNT(s.id)::int AS sale_count,
      COALESCE(SUM(s.total), 0)::numeric(12,2) AS total,
      COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_total,
      COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_total
    FROM sales s
    WHERE ${salesRangeFilter} AND s.status = 'PAID'
    GROUP BY s.created_at::date
    ORDER BY s.created_at::date DESC`,
    params
  );

  const stationSales = await query(
    `SELECT
      st.name AS station_name,
      st.console_type,
      COUNT(gs.id)::int AS session_count,
      COALESCE(SUM(gs.total_minutes), 0)::int AS total_minutes,
      COALESCE(SUM(gs.total_amount), 0)::numeric(12,2) AS total
    FROM game_sessions gs
    JOIN stations st ON st.id = gs.station_id
    WHERE gs.started_at >= $1::date AND gs.started_at < ($2::date + INTERVAL '1 day')
      AND gs.status <> 'VOID'
    GROUP BY st.name, st.console_type
    ORDER BY COALESCE(SUM(gs.total_amount), 0) DESC`,
    params
  );

  const categorySales = await query(
    `SELECT
      grouped.category,
      COALESCE(SUM(grouped.quantity), 0)::numeric(12,2) AS qty,
      COALESCE(SUM(grouped.total), 0)::numeric(12,2) AS total
    FROM (
      SELECT
        CASE
          WHEN si.item_type = 'GAME_TIME' THEN 'Horas'
          WHEN si.item_type = 'EXTRA' THEN 'Extras'
          WHEN p.category = 'DRINK' THEN 'Bebidas'
          WHEN p.category = 'SNACK' THEN 'Snacks'
          WHEN p.category = 'COMBO' THEN 'Combos'
          WHEN p.category = 'MEMBERSHIP' THEN 'Membresías'
          ELSE 'Otros'
        END AS category,
        si.quantity,
        si.total
      FROM sale_items si
      JOIN sales s ON s.id = si.sale_id
      LEFT JOIN products p ON p.id = si.product_id
      WHERE ${salesRangeFilter} AND s.status = 'PAID'
    ) grouped
    GROUP BY grouped.category
    ORDER BY COALESCE(SUM(grouped.total), 0) DESC`,
    params
  );

  const topProducts = await query(
    `SELECT si.description, SUM(si.quantity)::numeric(12,2) AS qty, SUM(si.total)::numeric(12,2) AS total
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    WHERE ${salesRangeFilter} AND s.status = 'PAID'
    GROUP BY si.description
    ORDER BY SUM(si.total) DESC
    LIMIT 10`,
    params
  );

  const familyDiscountSummary = await query(
    `SELECT
       COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount,
       COUNT(u.id)::int AS usage_count,
       COUNT(DISTINCT u.code_id)::int AS code_count,
       COUNT(DISTINCT s.user_id)::int AS cashier_count
     FROM family_discount_code_usages u
     JOIN sales s ON s.id = u.sale_id
     WHERE s.status = 'PAID'
       AND s.created_at >= $1::date
       AND s.created_at < ($2::date + INTERVAL '1 day')`,
    params
  );

  const familyDiscountRows = await query(
    `SELECT c.code, c.discount_percent, c.note,
            COUNT(u.id)::int AS usage_count,
            COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount,
            COALESCE(SUM(u.discountable_amount), 0)::numeric(12,2) AS discountable_amount
     FROM family_discount_code_usages u
     JOIN family_discount_codes c ON c.id = u.code_id
     JOIN sales s ON s.id = u.sale_id
     WHERE s.status = 'PAID'
       AND s.created_at >= $1::date
       AND s.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY c.code, c.discount_percent, c.note
     ORDER BY COALESCE(SUM(u.discount_amount), 0) DESC, COUNT(u.id) DESC
     LIMIT 20`,
    params
  );

  const recentFamilyDiscounts = await query(
    `SELECT u.id, u.discount_amount, u.discountable_amount, u.total_after_discount, u.used_at,
            c.code, c.discount_percent, c.note,
            cashier.full_name AS cashier_name,
            COALESCE(m.full_name, 'General') AS member_name
     FROM family_discount_code_usages u
     JOIN family_discount_codes c ON c.id = u.code_id
     JOIN sales s ON s.id = u.sale_id
     LEFT JOIN users cashier ON cashier.id = u.user_id
     LEFT JOIN members m ON m.id = s.member_id
     WHERE s.status = 'PAID'
       AND s.created_at >= $1::date
       AND s.created_at < ($2::date + INTERVAL '1 day')
     ORDER BY u.used_at DESC
     LIMIT 30`,
    params
  );

  const extraSales = await query(
    `SELECT
      REGEXP_REPLACE(si.description, '^Extra estación - ', '') AS extra_name,
      SUM(si.quantity)::numeric(12,2) AS qty,
      SUM(si.total)::numeric(12,2) AS total,
      COUNT(DISTINCT s.id)::int AS sale_count
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    WHERE ${salesRangeFilter}
      AND s.status = 'PAID'
      AND si.item_type = 'EXTRA'
    GROUP BY REGEXP_REPLACE(si.description, '^Extra estación - ', '')
    ORDER BY SUM(si.total) DESC, SUM(si.quantity) DESC
    LIMIT 20`,
    params
  );

  const extraStationSales = await query(
    `SELECT
      st.name AS station_name,
      st.console_type,
      REGEXP_REPLACE(ssi.description, '^Extra estación - ', '') AS extra_name,
      SUM(ssi.quantity)::numeric(12,2) AS qty,
      SUM(ssi.total)::numeric(12,2) AS total,
      COUNT(DISTINCT COALESCE(ssi.sale_id, ssi.session_id))::int AS usage_count
    FROM station_session_items ssi
    JOIN game_sessions gs ON gs.id = ssi.session_id
    JOIN stations st ON st.id = gs.station_id
    WHERE ssi.line_type = 'EXTRA'
      AND COALESCE(ssi.paid_at, ssi.created_at) >= $1::date
      AND COALESCE(ssi.paid_at, ssi.created_at) < ($2::date + INTERVAL '1 day')
      AND ssi.payment_status = 'PAID'
    GROUP BY st.name, st.console_type, REGEXP_REPLACE(ssi.description, '^Extra estación - ', '')
    ORDER BY SUM(ssi.total) DESC, SUM(ssi.quantity) DESC
    LIMIT 30`,
    params
  );

  const pointsSummary = await query(
    `SELECT
       COALESCE(SUM(CASE WHEN l.points > 0 THEN l.points ELSE 0 END), 0)::int AS earned_points,
       ABS(COALESCE(SUM(CASE WHEN l.points < 0 THEN l.points ELSE 0 END), 0))::int AS spent_points,
       COALESCE(SUM(CASE WHEN l.affects_ranking = true AND l.points > 0 THEN l.points ELSE 0 END), 0)::int AS ranking_points,
       COUNT(l.id)::int AS movement_count,
       COUNT(DISTINCT l.member_id)::int AS member_count
     FROM member_points_ledger l
     WHERE l.created_at >= $1::date
       AND l.created_at < ($2::date + INTERVAL '1 day')`,
    params
  );

  const pointsByCategory = await query(
    `SELECT
       l.category,
       COALESCE(SUM(CASE WHEN l.points > 0 THEN l.points ELSE 0 END), 0)::int AS earned_points,
       ABS(COALESCE(SUM(CASE WHEN l.points < 0 THEN l.points ELSE 0 END), 0))::int AS spent_points,
       COUNT(l.id)::int AS movement_count
     FROM member_points_ledger l
     WHERE l.created_at >= $1::date
       AND l.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY l.category
     ORDER BY ABS(COALESCE(SUM(l.points), 0)) DESC, COUNT(l.id) DESC
     LIMIT 20`,
    params
  );

  const recentPointMovements = await query(
    `SELECT
       l.id,
       l.points,
       l.movement_type,
       l.category,
       l.reason,
       l.affects_ranking,
       l.balance_after,
       l.created_at,
       m.full_name AS member_name,
       u.full_name AS user_name
     FROM member_points_ledger l
     JOIN members m ON m.id = l.member_id
     LEFT JOIN users u ON u.id = l.created_by_user_id
     WHERE l.created_at >= $1::date
       AND l.created_at < ($2::date + INTERVAL '1 day')
     ORDER BY l.created_at DESC
     LIMIT 30`,
    params
  );

  const pointRedemptions = await query(
    `SELECT
       COALESCE(o.name, 'Canje por puntos') AS option_name,
       COALESCE(o.redemption_type, 'CUSTOM') AS redemption_type,
       COALESCE(SUM(r.points_spent), 0)::int AS points_spent,
       COUNT(r.id)::int AS redemption_count,
       COUNT(DISTINCT r.member_id)::int AS member_count
     FROM member_point_redemptions r
     LEFT JOIN member_point_redemption_options o ON o.id = r.option_id
     WHERE r.status <> 'VOID'
       AND r.created_at >= $1::date
       AND r.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY COALESCE(o.name, 'Canje por puntos'), COALESCE(o.redemption_type, 'CUSTOM')
     ORDER BY COALESCE(SUM(r.points_spent), 0) DESC, COUNT(r.id) DESC
     LIMIT 20`,
    params
  );

  const rewardSummary = await query(
    `SELECT
       COALESCE(SUM(CASE WHEN mr.status = 'AVAILABLE' THEN 1 ELSE 0 END), 0)::int AS available_count,
       COALESCE(SUM(CASE WHEN mr.status = 'USED' THEN 1 ELSE 0 END), 0)::int AS used_count,
       COALESCE(SUM(CASE WHEN mr.status = 'EXPIRED' THEN 1 ELSE 0 END), 0)::int AS expired_count,
       COALESCE(SUM(CASE WHEN mr.reward_type = 'POINT_REDEMPTION' THEN 1 ELSE 0 END), 0)::int AS point_redemption_rewards,
       COALESCE(SUM(CASE WHEN mr.status = 'USED' THEN COALESCE(mr.used_reward_minutes, 0) ELSE 0 END), 0)::int AS minutes_used,
       COALESCE(SUM(CASE WHEN mr.status = 'USED' THEN COALESCE(mr.used_prize_snack_qty, 0) ELSE 0 END), 0)::int AS snacks_used,
       COALESCE(SUM(CASE WHEN mr.status = 'USED' THEN COALESCE(mr.used_prize_drink_qty, 0) ELSE 0 END), 0)::int AS drinks_used,
       COALESCE(SUM(CASE WHEN mr.status = 'USED' THEN COALESCE(mr.used_prize_product_qty, 0) ELSE 0 END), 0)::int AS products_used
     FROM member_rewards mr
     WHERE COALESCE(mr.used_at, mr.created_at) >= $1::date
       AND COALESCE(mr.used_at, mr.created_at) < ($2::date + INTERVAL '1 day')`,
    params
  );

  const rewardUsageByType = await query(
    `SELECT
       mr.reward_type,
       mr.status,
       COUNT(mr.id)::int AS reward_count,
       COALESCE(SUM(COALESCE(mr.used_reward_minutes, 0)), 0)::int AS minutes_used,
       COALESCE(SUM(COALESCE(mr.used_prize_snack_qty, 0)), 0)::int AS snacks_used,
       COALESCE(SUM(COALESCE(mr.used_prize_drink_qty, 0)), 0)::int AS drinks_used,
       COALESCE(SUM(COALESCE(mr.used_prize_product_qty, 0)), 0)::int AS products_used
     FROM member_rewards mr
     WHERE COALESCE(mr.used_at, mr.created_at) >= $1::date
       AND COALESCE(mr.used_at, mr.created_at) < ($2::date + INTERVAL '1 day')
     GROUP BY mr.reward_type, mr.status
     ORDER BY COUNT(mr.id) DESC, mr.reward_type ASC
     LIMIT 20`,
    params
  );

  const cashierSales = await query(
    `SELECT
      u.full_name AS cashier_name,
      COUNT(s.id)::int AS sale_count,
      COALESCE(SUM(s.total), 0)::numeric(12,2) AS total,
      COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_total,
      COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_total
    FROM sales s
    JOIN users u ON u.id = s.user_id
    WHERE ${salesRangeFilter} AND s.status = 'PAID'
    GROUP BY u.full_name
    ORDER BY COALESCE(SUM(s.total), 0) DESC`,
    params
  );

  const transfers = await query(
    `SELECT
      s.id,
      s.total,
      s.notes,
      s.created_at,
      u.full_name AS cashier_name,
      m.full_name AS member_name
    FROM sales s
    JOIN users u ON u.id = s.user_id
    LEFT JOIN members m ON m.id = s.member_id
    WHERE ${salesRangeFilter}
      AND s.status = 'PAID'
      AND s.payment_method = 'TRANSFER'
    ORDER BY s.created_at DESC
    LIMIT 25`,
    params
  );

  const bonuses = await query(
    `SELECT
      COALESCE(SUM(used_count), 0)::int AS used_count,
      COALESCE(SUM(minutes), 0)::int AS minutes
    FROM (
      SELECT COUNT(*)::int AS used_count, COALESCE(SUM(bonus_minutes), 0)::int AS minutes
      FROM member_bonuses
      WHERE status = 'USED' AND used_at >= $1::date AND used_at < ($2::date + INTERVAL '1 day')
      UNION ALL
      SELECT COUNT(*)::int AS used_count, COALESCE(SUM(reward_minutes), 0)::int AS minutes
      FROM member_rewards
      WHERE status = 'USED' AND used_at >= $1::date AND used_at < ($2::date + INTERVAL '1 day')
    ) bonus_usage`,
    params
  );

  const memberships = await query(
    `SELECT
      mh.tier,
      COUNT(mh.id)::int AS count,
      COALESCE(SUM(mh.amount), 0)::numeric(12,2) AS total
    FROM member_membership_history mh
    WHERE mh.created_at >= $1::date AND mh.created_at < ($2::date + INTERVAL '1 day')
    GROUP BY mh.tier
    ORDER BY COALESCE(SUM(mh.amount), 0) DESC`,
    params
  );

  const openAccounts = await query(
    `SELECT
      gs.id,
      st.name AS station_name,
      st.console_type,
      gs.rate_type,
      gs.started_at,
      m.full_name AS member_name,
      COALESCE(account.item_count, 0)::int AS item_count,
      COALESCE(account.pending_total, 0)::numeric(12,2) AS pending_total,
      COALESCE(account.paid_total, 0)::numeric(12,2) AS paid_total,
      COALESCE(account.session_total, 0)::numeric(12,2) AS session_total
    FROM game_sessions gs
    JOIN stations st ON st.id = gs.station_id
    LEFT JOIN members m ON m.id = gs.member_id
    LEFT JOIN LATERAL (
      SELECT
        COUNT(ssi.id)::int AS item_count,
        COALESCE(SUM(CASE WHEN ssi.payment_status = 'PENDING' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS pending_total,
        COALESCE(SUM(CASE WHEN ssi.payment_status = 'PAID' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS paid_total,
        COALESCE(SUM(ssi.total), 0)::numeric(12,2) AS session_total
      FROM station_session_items ssi
      WHERE ssi.session_id = gs.id
    ) account ON true
    WHERE gs.status = 'ACTIVE'
    ORDER BY COALESCE(account.pending_total, 0) DESC, gs.started_at ASC`,
    []
  );

  const pendingAccounts = await query(
    `SELECT
      COUNT(*) FILTER (WHERE pending_total > 0)::int AS account_count,
      COALESCE(SUM(pending_total), 0)::numeric(12,2) AS pending_total,
      COALESCE(SUM(paid_total), 0)::numeric(12,2) AS paid_total
    FROM (
      SELECT
        gs.id,
        COALESCE(SUM(CASE WHEN ssi.payment_status = 'PENDING' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS pending_total,
        COALESCE(SUM(CASE WHEN ssi.payment_status = 'PAID' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS paid_total
      FROM game_sessions gs
      LEFT JOIN station_session_items ssi ON ssi.session_id = gs.id
      WHERE gs.status = 'ACTIVE'
      GROUP BY gs.id
    ) account_totals`,
    []
  );

  const closedSessions = await query(
    `SELECT
      gs.id,
      st.name AS station_name,
      st.console_type,
      gs.rate_type,
      gs.total_minutes,
      gs.total_amount,
      gs.started_at,
      gs.ended_at,
      m.full_name AS member_name
    FROM game_sessions gs
    JOIN stations st ON st.id = gs.station_id
    LEFT JOIN members m ON m.id = gs.member_id
    WHERE gs.status = 'CLOSED'
      AND gs.ended_at >= $1::date
      AND gs.ended_at < ($2::date + INTERVAL '1 day')
    ORDER BY gs.ended_at DESC
    LIMIT 25`,
    params
  );

  const financeExpenses = await query(
    `SELECT
       fe.category,
       COALESCE(SUM(fe.amount), 0)::numeric(12,2) AS total,
       COUNT(fe.id)::int AS expense_count
     FROM finance_expenses fe
     WHERE fe.is_active = true
       AND fe.expense_date >= $1::date
       AND fe.expense_date <= $2::date
     GROUP BY fe.category
     ORDER BY COALESCE(SUM(fe.amount), 0) DESC
     LIMIT 20`,
    params
  );

  const recentExpenses = await query(
    `SELECT
       fe.id,
       fe.name,
       fe.category,
       fe.expense_type,
       fe.amount,
       fe.expense_date,
       fe.payment_method,
       fe.notes,
       u.full_name AS user_name
     FROM finance_expenses fe
     LEFT JOIN users u ON u.id = fe.created_by_user_id
     WHERE fe.is_active = true
       AND fe.expense_date >= $1::date
       AND fe.expense_date <= $2::date
     ORDER BY fe.expense_date DESC, fe.created_at DESC
     LIMIT 30`,
    params
  );

  const expenseSummary = await query(
    `SELECT
       COALESCE(SUM(fe.amount), 0)::numeric(12,2) AS total_expenses,
       COUNT(fe.id)::int AS expense_count,
       COALESCE(SUM(CASE WHEN fe.expense_type = 'FIXED' THEN fe.amount ELSE 0 END), 0)::numeric(12,2) AS fixed_expenses,
       COALESCE(SUM(CASE WHEN fe.expense_type = 'VARIABLE' THEN fe.amount ELSE 0 END), 0)::numeric(12,2) AS variable_expenses,
       COALESCE(SUM(CASE WHEN fe.payment_method = 'CASH' THEN fe.amount ELSE 0 END), 0)::numeric(12,2) AS cash_expenses,
       COALESCE(SUM(CASE WHEN fe.payment_method = 'TRANSFER' THEN fe.amount ELSE 0 END), 0)::numeric(12,2) AS transfer_expenses
     FROM finance_expenses fe
     WHERE fe.is_active = true
       AND fe.expense_date >= $1::date
       AND fe.expense_date <= $2::date`,
    params
  );

  const tournamentReportSummary = await query(
    `WITH report_window AS (
       SELECT $1::date AS start_date, ($2::date + INTERVAL '1 day') AS end_date
     ), tournaments_in_range AS (
       SELECT t.*
       FROM tournaments t, report_window rw
       WHERE COALESCE(t.finished_at, t.started_at, t.scheduled_at, t.created_at) >= rw.start_date
         AND COALESCE(t.finished_at, t.started_at, t.scheduled_at, t.created_at) < rw.end_date
     ), participants_in_range AS (
       SELECT tp.*
       FROM tournament_participants tp, report_window rw
       WHERE tp.created_at >= rw.start_date
         AND tp.created_at < rw.end_date
     ), paid_entries AS (
       SELECT tp.*, t.entry_fee
       FROM tournament_participants tp
       JOIN tournaments t ON t.id = tp.tournament_id
       JOIN report_window rw ON true
       WHERE tp.is_paid = true
         AND COALESCE(tp.paid_at, tp.created_at) >= rw.start_date
         AND COALESCE(tp.paid_at, tp.created_at) < rw.end_date
     ), awards_in_range AS (
       SELECT ta.*
       FROM tournament_awards ta, report_window rw
       WHERE ta.created_at >= rw.start_date
         AND ta.created_at < rw.end_date
     )
     SELECT
       (SELECT COUNT(*) FROM tournaments_in_range)::int AS tournament_count,
       (SELECT COUNT(*) FROM tournaments_in_range WHERE status = 'FINISHED')::int AS finished_count,
       (SELECT COUNT(*) FROM tournaments_in_range WHERE status = 'ACTIVE')::int AS active_count,
       (SELECT COUNT(*) FROM tournaments_in_range WHERE status = 'SCHEDULED')::int AS scheduled_count,
       (SELECT COUNT(*) FROM participants_in_range)::int AS participant_count,
       (SELECT COUNT(*) FROM paid_entries)::int AS paid_entry_count,
       COALESCE((SELECT SUM(entry_fee) FROM paid_entries), 0)::numeric(12,2) AS entry_revenue,
       (SELECT COUNT(*) FROM awards_in_range)::int AS awards_count,
       COALESCE((SELECT SUM(cash_amount) FROM awards_in_range), 0)::numeric(12,2) AS cash_prizes`,
    params
  );

  const tournamentsReport = await query(
    `SELECT
       t.id,
       t.name,
       t.game,
       t.platform,
       t.status,
       t.entry_fee,
       t.scheduled_at,
       t.started_at,
       t.finished_at,
       COUNT(tp.id)::int AS participant_count,
       COUNT(tp.id) FILTER (WHERE tp.is_paid = true)::int AS paid_count,
       COALESCE(COUNT(tp.id) FILTER (WHERE tp.is_paid = true) * t.entry_fee, 0)::numeric(12,2) AS entry_revenue
     FROM tournaments t
     LEFT JOIN tournament_participants tp ON tp.tournament_id = t.id
     WHERE COALESCE(t.finished_at, t.started_at, t.scheduled_at, t.created_at) >= $1::date
       AND COALESCE(t.finished_at, t.started_at, t.scheduled_at, t.created_at) < ($2::date + INTERVAL '1 day')
     GROUP BY t.id
     ORDER BY COALESCE(t.finished_at, t.started_at, t.scheduled_at, t.created_at) DESC
     LIMIT 25`,
    params
  );

  const tournamentAwardsReport = await query(
    `SELECT
       ta.id,
       ta.position,
       ta.cash_amount,
       ta.cash_status,
       ta.membership_tier,
       ta.membership_status,
       ta.bonus_status,
       ta.goods_status,
       ta.created_at,
       t.name AS tournament_name,
       COALESCE(m.full_name, tp.player_name, tp.nickname, 'Jugador') AS player_name
     FROM tournament_awards ta
     JOIN tournaments t ON t.id = ta.tournament_id
     JOIN tournament_participants tp ON tp.id = ta.participant_id
     LEFT JOIN members m ON m.id = ta.member_id
     WHERE ta.created_at >= $1::date
       AND ta.created_at < ($2::date + INTERVAL '1 day')
     ORDER BY ta.created_at DESC, ta.position ASC
     LIMIT 25`,
    params
  );

  const tournamentEntrySalesReport = await query(
    `SELECT
       t.name AS tournament_name,
       t.game,
       t.platform,
       COUNT(tp.id)::int AS paid_entries,
       COALESCE(COUNT(tp.id) * t.entry_fee, 0)::numeric(12,2) AS entry_revenue
     FROM tournament_participants tp
     JOIN tournaments t ON t.id = tp.tournament_id
     WHERE tp.is_paid = true
       AND COALESCE(tp.paid_at, tp.created_at) >= $1::date
       AND COALESCE(tp.paid_at, tp.created_at) < ($2::date + INTERVAL '1 day')
     GROUP BY t.id, t.name, t.game, t.platform, t.entry_fee
     ORDER BY COALESCE(COUNT(tp.id) * t.entry_fee, 0) DESC, COUNT(tp.id) DESC
     LIMIT 20`,
    params
  );

  const gameReportSummary = await query(
    `WITH report_window AS (
       SELECT $1::date AS start_date, ($2::date + INTERVAL '1 day') AS end_date
     ), played AS (
       SELECT gs.*
       FROM game_sessions gs, report_window rw
       WHERE gs.status <> 'VOID'
         AND gs.game_id IS NOT NULL
         AND gs.started_at >= rw.start_date
         AND gs.started_at < rw.end_date
     ), requested AS (
       SELECT gr.*
       FROM game_requests gr, report_window rw
       WHERE gr.created_at >= rw.start_date
         AND gr.created_at < rw.end_date
     )
     SELECT
       COUNT(DISTINCT played.id)::int AS played_sessions,
       COALESCE(SUM(CASE WHEN played.rate_type = 'PREPAID' AND COALESCE(played.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(played.total_minutes, 0), played.prepaid_minutes), played.prepaid_minutes) ELSE COALESCE(NULLIF(played.total_minutes, 0), played.prepaid_minutes, 0) END), 0)::int AS played_minutes,
       COUNT(DISTINCT played.game_id)::int AS games_played,
       COUNT(DISTINCT requested.id)::int AS request_count,
       COUNT(DISTINCT requested.id) FILTER (WHERE requested.request_type = 'NEW_GAME')::int AS new_game_requests,
       COUNT(DISTINCT requested.id) FILTER (WHERE requested.request_type = 'EXISTING')::int AS unavailable_requests,
       COUNT(DISTINCT requested.id) FILTER (WHERE requested.customer_decision = 'ESPERA')::int AS waited_count,
       COUNT(DISTINCT requested.id) FILTER (WHERE requested.customer_decision = 'ACEPTO_OTRO')::int AS accepted_other_count,
       COUNT(DISTINCT requested.id) FILTER (WHERE requested.customer_decision = 'SE_FUE')::int AS left_count
     FROM played
     FULL JOIN requested ON false`,
    params
  );

  const topGamesReport = await query(
    `SELECT
       g.id,
       g.name AS game_name,
       g.platform,
       COUNT(gs.id)::int AS session_count,
       COUNT(DISTINCT gs.member_id) FILTER (WHERE gs.member_id IS NOT NULL)::int AS member_count,
       COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0)::int AS total_minutes
     FROM game_sessions gs
     JOIN station_games g ON g.id = gs.game_id
     WHERE gs.status <> 'VOID'
       AND gs.started_at >= $1::date
       AND gs.started_at < ($2::date + INTERVAL '1 day')
     GROUP BY g.id, g.name, g.platform
     ORDER BY COUNT(gs.id) DESC, COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0) DESC, g.name ASC
     LIMIT 20`,
    params
  );

  const gamePlatformReport = await query(
    `SELECT
       st.console_type,
       COUNT(gs.id)::int AS session_count,
       COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0)::int AS total_minutes
     FROM game_sessions gs
     JOIN stations st ON st.id = gs.station_id
     WHERE gs.status <> 'VOID'
       AND gs.game_id IS NOT NULL
       AND gs.started_at >= $1::date
       AND gs.started_at < ($2::date + INTERVAL '1 day')
     GROUP BY st.console_type
     ORDER BY COUNT(gs.id) DESC, COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0) DESC`,
    params
  );

  const memberGameReport = await query(
    `SELECT
       m.id AS member_id,
       m.full_name AS member_name,
       g.name AS game_name,
       COUNT(gs.id)::int AS session_count,
       COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0)::int AS total_minutes
     FROM game_sessions gs
     JOIN station_games g ON g.id = gs.game_id
     JOIN members m ON m.id = gs.member_id
     WHERE gs.status <> 'VOID'
       AND gs.started_at >= $1::date
       AND gs.started_at < ($2::date + INTERVAL '1 day')
     GROUP BY m.id, m.full_name, g.name
     ORDER BY COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0) DESC, COUNT(gs.id) DESC
     LIMIT 20`,
    params
  );

  const requestedGamesReport = await query(
    `SELECT
       COALESCE(g.name, gr.requested_game_name, 'Juego solicitado') AS game_name,
       COALESCE(gr.platform, g.platform, 'Sin plataforma') AS platform,
       COUNT(gr.id)::int AS request_count,
       COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ESPERA')::int AS waited_count,
       COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ACEPTO_OTRO')::int AS accepted_other_count,
       COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE')::int AS left_count,
       COUNT(gr.id) FILTER (WHERE gr.request_type = 'NEW_GAME')::int AS new_game_count
     FROM game_requests gr
     LEFT JOIN station_games g ON g.id = gr.game_id
     WHERE gr.created_at >= $1::date
       AND gr.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY COALESCE(g.name, gr.requested_game_name, 'Juego solicitado'), COALESCE(gr.platform, g.platform, 'Sin plataforma')
     ORDER BY COUNT(gr.id) DESC, COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE') DESC
     LIMIT 20`,
    params
  );


  const reservationReportSummary = await query(
    `WITH report_window AS (
       SELECT $1::date AS start_date, ($2::date + INTERVAL '1 day') AS end_date
     ), reservations AS (
       SELECT gr.*
       FROM game_reservations gr, report_window rw
       WHERE gr.created_at >= rw.start_date
         AND gr.created_at < rw.end_date
     ), lost_requests AS (
       SELECT req.*
       FROM game_requests req, report_window rw
       WHERE req.created_at >= rw.start_date
         AND req.created_at < rw.end_date
         AND req.customer_decision IN ('SE_FUE', 'ACEPTO_OTRO')
     )
     SELECT
       COUNT(DISTINCT reservations.id)::int AS total_reservations,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.reservation_type = 'WAITLIST')::int AS waitlist_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.reservation_type = 'RESERVATION')::int AS reservation_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.reservation_scope = 'GROUP_EVENT')::int AS group_event_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.status = 'ASSIGNED')::int AS assigned_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.status = 'NOTIFIED')::int AS notified_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.status = 'CANCELED')::int AS canceled_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.status = 'NO_SHOW')::int AS no_show_count,
       COUNT(DISTINCT reservations.id) FILTER (WHERE reservations.status = 'EXPIRED')::int AS expired_count,
       COALESCE(SUM(reservations.estimated_total_amount), 0)::numeric(12,2) AS estimated_total,
       COALESCE(SUM(reservations.paid_amount), 0)::numeric(12,2) AS paid_total,
       COALESCE(SUM(GREATEST(COALESCE(reservations.estimated_total_amount, 0) - COALESCE(reservations.paid_amount, 0), 0)), 0)::numeric(12,2) AS pending_total,
       COUNT(DISTINCT lost_requests.id)::int AS demand_lost_count,
       COUNT(DISTINCT lost_requests.id) FILTER (WHERE lost_requests.customer_decision = 'SE_FUE')::int AS left_count,
       COUNT(DISTINCT lost_requests.id) FILTER (WHERE lost_requests.customer_decision = 'ACEPTO_OTRO')::int AS accepted_other_count
     FROM reservations
     FULL JOIN lost_requests ON false`,
    params
  );

  const reservationStatusReport = await query(
    `SELECT
       status,
       reservation_type,
       reservation_scope,
       COUNT(id)::int AS count,
       COALESCE(SUM(estimated_total_amount), 0)::numeric(12,2) AS estimated_total,
       COALESCE(SUM(paid_amount), 0)::numeric(12,2) AS paid_total
     FROM game_reservations
     WHERE created_at >= $1::date
       AND created_at < ($2::date + INTERVAL '1 day')
     GROUP BY status, reservation_type, reservation_scope
     ORDER BY COUNT(id) DESC, status ASC
     LIMIT 20`,
    params
  );

  const groupEventReservationReport = await query(
    `SELECT
       gr.id,
       COALESCE(gr.customer_name, m.full_name, 'Grupo / Evento') AS customer_name,
       gr.status,
       gr.player_count,
       gr.station_count,
       gr.is_full_club,
       gr.reserved_minutes,
       gr.desired_start_at,
       gr.estimated_total_amount,
       gr.paid_amount,
       GREATEST(COALESCE(gr.estimated_total_amount, 0) - COALESCE(gr.paid_amount, 0), 0)::numeric(12,2) AS pending_amount
     FROM game_reservations gr
     LEFT JOIN members m ON m.id = gr.member_id
     WHERE gr.reservation_scope = 'GROUP_EVENT'
       AND gr.created_at >= $1::date
       AND gr.created_at < ($2::date + INTERVAL '1 day')
     ORDER BY gr.created_at DESC
     LIMIT 20`,
    params
  );

  const demandLostReport = await query(
    `SELECT
       COALESCE(g.name, gr.requested_game_name, 'Juego solicitado') AS game_name,
       COALESCE(gr.platform, g.platform, 'Sin plataforma') AS platform,
       COUNT(gr.id)::int AS lost_count,
       COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE')::int AS left_count,
       COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ACEPTO_OTRO')::int AS accepted_other_count,
       MAX(gr.created_at) AS last_request_at
     FROM game_requests gr
     LEFT JOIN station_games g ON g.id = gr.game_id
     WHERE gr.customer_decision IN ('SE_FUE', 'ACEPTO_OTRO')
       AND gr.created_at >= $1::date
       AND gr.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY COALESCE(g.name, gr.requested_game_name, 'Juego solicitado'), COALESCE(gr.platform, g.platform, 'Sin plataforma')
     ORDER BY COUNT(gr.id) DESC, COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE') DESC
     LIMIT 20`,
    params
  );

  const waitlistOutcomeReport = await query(
    `SELECT
       COALESCE(g.name, gr.customer_name, 'Lista de espera') AS label,
       COALESCE(gr.platform, g.platform, 'Sin plataforma') AS platform,
       COUNT(gr.id)::int AS waitlist_count,
       COUNT(gr.id) FILTER (WHERE gr.status = 'ASSIGNED')::int AS assigned_count,
       COUNT(gr.id) FILTER (WHERE gr.status = 'NOTIFIED')::int AS notified_count,
       COUNT(gr.id) FILTER (WHERE gr.status IN ('CANCELED', 'NO_SHOW', 'EXPIRED'))::int AS missed_count
     FROM game_reservations gr
     LEFT JOIN station_games g ON g.id = gr.game_id
     WHERE gr.reservation_type = 'WAITLIST'
       AND gr.created_at >= $1::date
       AND gr.created_at < ($2::date + INTERVAL '1 day')
     GROUP BY COALESCE(g.name, gr.customer_name, 'Lista de espera'), COALESCE(gr.platform, g.platform, 'Sin plataforma')
     ORDER BY COUNT(gr.id) DESC, COUNT(gr.id) FILTER (WHERE gr.status = 'ASSIGNED') DESC
     LIMIT 20`,
    params
  );

  const copyRecommendationReport = await query(
    `WITH played AS (
       SELECT gs.game_id,
              COUNT(gs.id)::int AS session_count,
              COALESCE(SUM(CASE WHEN gs.rate_type = 'PREPAID' AND COALESCE(gs.prepaid_minutes, 0) > 0 THEN LEAST(COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes), gs.prepaid_minutes) ELSE COALESCE(NULLIF(gs.total_minutes, 0), gs.prepaid_minutes, 0) END), 0)::int AS total_minutes
       FROM game_sessions gs
       WHERE gs.status <> 'VOID'
         AND gs.game_id IS NOT NULL
         AND gs.started_at >= $1::date
         AND gs.started_at < ($2::date + INTERVAL '1 day')
       GROUP BY gs.game_id
     ), requests AS (
       SELECT gr.game_id,
              COUNT(gr.id)::int AS request_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'ESPERA')::int AS waited_count,
              COUNT(gr.id) FILTER (WHERE gr.customer_decision = 'SE_FUE')::int AS left_count
       FROM game_requests gr
       WHERE gr.request_type = 'EXISTING'
         AND gr.game_id IS NOT NULL
         AND gr.created_at >= $1::date
         AND gr.created_at < ($2::date + INTERVAL '1 day')
       GROUP BY gr.game_id
     )
     SELECT
       g.name AS game_name,
       g.platform,
       COALESCE(g.copy_quantity, 0)::int AS copy_quantity,
       COALESCE(g.unlimited_copies, false) AS unlimited_copies,
       COALESCE(p.session_count, 0)::int AS session_count,
       COALESCE(p.total_minutes, 0)::int AS total_minutes,
       COALESCE(r.request_count, 0)::int AS request_count,
       COALESCE(r.waited_count, 0)::int AS waited_count,
       COALESCE(r.left_count, 0)::int AS left_count
     FROM station_games g
     LEFT JOIN played p ON p.game_id = g.id
     LEFT JOIN requests r ON r.game_id = g.id
     WHERE COALESCE(r.request_count, 0) > 0 OR COALESCE(p.session_count, 0) > 0
     ORDER BY COALESCE(r.request_count, 0) DESC, COALESCE(r.left_count, 0) DESC, COALESCE(p.session_count, 0) DESC
     LIMIT 20`,
    params
  );

  const stationOperationReport = await query(
    `WITH closed AS (
       SELECT
         gs.id,
         st.name AS station_name,
         st.console_type,
         gs.started_at,
         gs.ended_at,
         COALESCE(
           gs.close_delay_minutes,
           CASE
             WHEN gs.rate_type = 'PREPAID'
              AND COALESCE(gs.prepaid_minutes, 0) > 0
              AND gs.ended_at IS NOT NULL
              AND gs.ended_at > (gs.started_at + (gs.prepaid_minutes || ' minutes')::INTERVAL)
             THEN CEIL(EXTRACT(EPOCH FROM (gs.ended_at - (gs.started_at + (gs.prepaid_minutes || ' minutes')::INTERVAL))) / 60.0)::INT
             ELSE 0
           END
         )::INT AS close_delay_minutes
       FROM game_sessions gs
       JOIN stations st ON st.id = gs.station_id
       WHERE gs.status = 'CLOSED'
         AND gs.ended_at >= $1::date
         AND gs.ended_at < ($2::date + INTERVAL '1 day')
     ), by_station AS (
       SELECT
         station_name,
         console_type,
         COUNT(*)::int AS closed_count,
         COALESCE(SUM(close_delay_minutes), 0)::int AS total_close_delay_minutes,
         ROUND(COALESCE(AVG(close_delay_minutes), 0), 1)::numeric(10,1) AS avg_close_delay_minutes,
         COALESCE(MAX(close_delay_minutes), 0)::int AS max_close_delay_minutes
       FROM closed
       GROUP BY station_name, console_type
     )
     SELECT
       COALESCE((SELECT COUNT(*) FROM closed), 0)::int AS closed_count,
       COALESCE((SELECT SUM(close_delay_minutes) FROM closed), 0)::int AS total_close_delay_minutes,
       ROUND(COALESCE((SELECT AVG(close_delay_minutes) FROM closed), 0), 1)::numeric(10,1) AS avg_close_delay_minutes,
       COALESCE((SELECT MAX(close_delay_minutes) FROM closed), 0)::int AS max_close_delay_minutes,
       COALESCE((
         SELECT json_agg(row_to_json(by_station) ORDER BY total_close_delay_minutes DESC, avg_close_delay_minutes DESC, station_name ASC)
         FROM by_station
       ), '[]'::json) AS by_station,
       COALESCE((
         SELECT json_agg(row_to_json(slowest) ORDER BY close_delay_minutes DESC, ended_at DESC)
         FROM (
           SELECT station_name, console_type, close_delay_minutes, ended_at
           FROM closed
           WHERE close_delay_minutes > 0
           ORDER BY close_delay_minutes DESC, ended_at DESC
           LIMIT 10
         ) slowest
       ), '[]'::json) AS slowest_closings
     `,
    params
  );

  const drawer = await getDrawerReport(startDate, endDate);

  res.json({
    range: { startDate, endDate },
    sales: sales.rows[0],
    sessions: sessions.rows[0],
    drawer,
    familyDiscountSummary: familyDiscountSummary.rows[0] || {},
    familyDiscountRows: familyDiscountRows.rows,
    recentFamilyDiscounts: recentFamilyDiscounts.rows,
    dailySales: dailySales.rows,
    stationSales: stationSales.rows,
    categorySales: categorySales.rows,
    topProducts: topProducts.rows,
    extraSales: extraSales.rows,
    extraStationSales: extraStationSales.rows,
    pointsSummary: pointsSummary.rows[0] || {},
    pointsByCategory: pointsByCategory.rows,
    recentPointMovements: recentPointMovements.rows,
    pointRedemptions: pointRedemptions.rows,
    rewardSummary: rewardSummary.rows[0] || {},
    rewardUsageByType: rewardUsageByType.rows,
    cashierSales: cashierSales.rows,
    transfers: transfers.rows,
    bonuses: bonuses.rows[0],
    memberships: memberships.rows,
    openAccounts: openAccounts.rows,
    pendingAccounts: pendingAccounts.rows[0],
    closedSessions: closedSessions.rows,
    expenseSummary: expenseSummary.rows[0] || {},
    financeExpenses: financeExpenses.rows,
    recentExpenses: recentExpenses.rows,
    tournamentReportSummary: tournamentReportSummary.rows[0] || {},
    tournamentsReport: tournamentsReport.rows,
    tournamentAwardsReport: tournamentAwardsReport.rows,
    tournamentEntrySalesReport: tournamentEntrySalesReport.rows,
    gameReportSummary: gameReportSummary.rows[0] || {},
    topGamesReport: topGamesReport.rows,
    gamePlatformReport: gamePlatformReport.rows,
    memberGameReport: memberGameReport.rows,
    requestedGamesReport: requestedGamesReport.rows,
    copyRecommendationReport: copyRecommendationReport.rows,
    stationOperationReport: stationOperationReport.rows[0] || {},
    reservationReportSummary: reservationReportSummary.rows[0] || {},
    reservationStatusReport: reservationStatusReport.rows,
    groupEventReservationReport: groupEventReservationReport.rows,
    demandLostReport: demandLostReport.rows,
    waitlistOutcomeReport: waitlistOutcomeReport.rows
  });
  } catch (error) {
    console.error('Reportes error controlado:', error.message);
    res.status(500).json({
      message: 'No se pudo cargar el reporte.',
      detail: error.message
    });
  }
}


export async function employeeSummary(req, res) {
  try {
    const { startDate, endDate } = resolveReportRange(req);
    const params = [startDate, endDate];

    const { rows } = await query(
      `WITH report_window AS (
         SELECT $1::date AS start_date, ($2::date + INTERVAL '1 day') AS end_date
       ), paid_sales AS (
         SELECT s.*
         FROM sales s, report_window rw
         WHERE s.status = 'PAID'
           AND s.created_at >= rw.start_date
           AND s.created_at < rw.end_date
       ), sale_totals AS (
         SELECT
           s.user_id,
           COUNT(s.id)::int AS sale_count,
           COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales,
           COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
           COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales
         FROM paid_sales s
         GROUP BY s.user_id
       ), item_totals AS (
         SELECT
           s.user_id,
           COALESCE(SUM(CASE WHEN si.item_type = 'PRODUCT' THEN si.quantity ELSE 0 END), 0)::numeric(12,2) AS products_sold,
           COALESCE(SUM(CASE WHEN si.item_type = 'COMBO' THEN si.quantity ELSE 0 END), 0)::numeric(12,2) AS combos_sold,
           COALESCE(SUM(CASE WHEN si.item_type = 'TOURNAMENT_ENTRY' THEN si.quantity ELSE 0 END), 0)::numeric(12,2) AS tournament_entries_sold,
           COALESCE(SUM(CASE WHEN si.item_type = 'GAME_TIME' THEN si.total ELSE 0 END), 0)::numeric(12,2) AS game_time_sales
         FROM paid_sales s
         JOIN sale_items si ON si.sale_id = s.id
         GROUP BY s.user_id
       ), audit_totals AS (
         SELECT
           ae.user_id,
           COUNT(*) FILTER (WHERE ae.event_type = 'QUICK_SALE_PAID')::int AS quick_sales,
           COUNT(*) FILTER (WHERE ae.event_type = 'STATION_OPENED')::int AS stations_opened,
           COUNT(*) FILTER (WHERE ae.event_type = 'STATION_ACCOUNT_SAVED')::int AS station_accounts_saved,
           COUNT(*) FILTER (WHERE ae.event_type IN ('STATION_CHECKOUT_PAID', 'STATION_ACCOUNT_PAID'))::int AS stations_charged,
           COUNT(*) FILTER (WHERE ae.event_type = 'STATION_CLOSED')::int AS stations_closed,
           COUNT(*) FILTER (WHERE ae.event_type = 'TOURNAMENT_ENTRY_SOLD')::int AS tournament_entry_events,
           COUNT(*) FILTER (WHERE ae.event_type LIKE 'TOURNAMENT_PRIZE_%_DELIVERED')::int AS prizes_delivered,
           COUNT(*) FILTER (WHERE ae.event_type = 'DRAWER_PAYOUT')::int AS payouts_count,
           COALESCE(SUM(CASE WHEN ae.event_type = 'DRAWER_PAYOUT' THEN NULLIF(ae.metadata->>'amount', '')::numeric ELSE 0 END), 0)::numeric(12,2) AS payouts_total,
           COALESCE(SUM(CASE WHEN ae.event_type IN ('STATION_CHECKOUT_PAID', 'STATION_ACCOUNT_SAVED', 'STATION_CLOSED') THEN NULLIF(ae.metadata->>'minutes', '')::numeric ELSE 0 END), 0)::int AS minutes_handled
         FROM audit_events ae, report_window rw
         WHERE ae.created_at >= rw.start_date
           AND ae.created_at < rw.end_date
         GROUP BY ae.user_id
       ), users_in_range AS (
         SELECT user_id FROM sale_totals
         UNION
         SELECT user_id FROM item_totals
         UNION
         SELECT user_id FROM audit_totals
       )
       SELECT
         u.user_id AS user_id,
         COALESCE(usr.full_name, 'Sin empleado asignado') AS employee_name,
         COALESCE(usr.role, '') AS role,
         COALESCE(st.sale_count, 0)::int AS sale_count,
         COALESCE(st.total_sales, 0)::numeric(12,2) AS total_sales,
         COALESCE(st.cash_sales, 0)::numeric(12,2) AS cash_sales,
         COALESCE(st.transfer_sales, 0)::numeric(12,2) AS transfer_sales,
         COALESCE(it.products_sold, 0)::numeric(12,2) AS products_sold,
         COALESCE(it.combos_sold, 0)::numeric(12,2) AS combos_sold,
         COALESCE(it.tournament_entries_sold, 0)::numeric(12,2) AS tournament_entries_sold,
         COALESCE(it.game_time_sales, 0)::numeric(12,2) AS game_time_sales,
         COALESCE(at.quick_sales, 0)::int AS quick_sales,
         COALESCE(at.stations_opened, 0)::int AS stations_opened,
         COALESCE(at.station_accounts_saved, 0)::int AS station_accounts_saved,
         COALESCE(at.stations_charged, 0)::int AS stations_charged,
         COALESCE(at.stations_closed, 0)::int AS stations_closed,
         COALESCE(at.tournament_entry_events, 0)::int AS tournament_entry_events,
         COALESCE(at.prizes_delivered, 0)::int AS prizes_delivered,
         COALESCE(at.payouts_count, 0)::int AS payouts_count,
         COALESCE(at.payouts_total, 0)::numeric(12,2) AS payouts_total,
         COALESCE(at.minutes_handled, 0)::int AS minutes_handled
       FROM users_in_range u
       LEFT JOIN users usr ON usr.id = u.user_id
       LEFT JOIN sale_totals st ON st.user_id = u.user_id
       LEFT JOIN item_totals it ON it.user_id = u.user_id
       LEFT JOIN audit_totals at ON at.user_id = u.user_id
       ORDER BY COALESCE(st.total_sales, 0) DESC, COALESCE(at.stations_charged, 0) DESC, COALESCE(usr.full_name, 'Empleado') ASC`,
      params
    );

    const totals = rows.reduce((acc, row) => {
      acc.employee_count += 1;
      acc.sale_count += toNumber(row.sale_count);
      acc.total_sales += toNumber(row.total_sales);
      acc.cash_sales += toNumber(row.cash_sales);
      acc.transfer_sales += toNumber(row.transfer_sales);
      acc.products_sold += toNumber(row.products_sold);
      acc.combos_sold += toNumber(row.combos_sold);
      acc.tournament_entries_sold += toNumber(row.tournament_entries_sold);
      acc.minutes_handled += toNumber(row.minutes_handled);
      acc.stations_opened += toNumber(row.stations_opened);
      acc.stations_charged += toNumber(row.stations_charged);
      acc.payouts_total += toNumber(row.payouts_total);
      return acc;
    }, {
      employee_count: 0,
      sale_count: 0,
      total_sales: 0,
      cash_sales: 0,
      transfer_sales: 0,
      products_sold: 0,
      combos_sold: 0,
      tournament_entries_sold: 0,
      minutes_handled: 0,
      stations_opened: 0,
      stations_charged: 0,
      payouts_total: 0
    });

    res.json({ range: { startDate, endDate }, totals, employees: rows });
  } catch (error) {
    console.error('Reporte por empleado error controlado:', error.message);
    res.status(500).json({ message: 'No se pudo cargar el reporte por empleado.', detail: error.message });
  }
}

function toPositiveLimit(value, fallback = 150, max = 500) {
  const parsed = Number.parseInt(String(value || ''), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.min(parsed, max);
}

export async function auditEvents(req, res) {
  try {
    const { startDate, endDate } = resolveReportRange(req);
    const limit = toPositiveLimit(req.query.limit);
    const eventType = String(req.query.eventType || '').trim() || null;
    const userId = String(req.query.userId || '').trim() || null;
    const stationId = String(req.query.stationId || '').trim() || null;

    const { rows } = await query(
      `SELECT
         ae.*,
         u.full_name AS user_name,
         st.name AS station_name,
         t.name AS tournament_name,
         cd.opened_at AS drawer_opened_at
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.user_id
       LEFT JOIN stations st ON st.id = ae.station_id
       LEFT JOIN tournaments t ON t.id = ae.tournament_id
       LEFT JOIN cash_drawers cd ON cd.id = ae.drawer_id
       WHERE ae.created_at >= $1::date
         AND ae.created_at < ($2::date + INTERVAL '1 day')
         AND ($3::text IS NULL OR ae.event_type = $3)
         AND ($4::uuid IS NULL OR ae.user_id = $4::uuid)
         AND ($5::uuid IS NULL OR ae.station_id = $5::uuid)
       ORDER BY ae.created_at DESC
       LIMIT $6`,
      [startDate, endDate, eventType, userId || null, stationId || null, limit]
    );

    res.json({ range: { startDate, endDate }, events: rows });
  } catch (error) {
    console.error('Auditoría error controlado:', error.message);
    res.status(500).json({ message: 'No se pudo cargar la auditoría.', detail: error.message });
  }
}
