import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../db/pool.js';
import { env } from '../config/env.js';

const OWNER_DASHBOARD_TOKEN_PURPOSE = 'owner_dashboard';

function toNumber(value) {
  return Number(value || 0);
}



function pad2(value) {
  return String(value).padStart(2, '0');
}

function dateOnlyLocal(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function addDaysLocal(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function startOfWeekMonday(date) {
  const start = new Date(date);
  const day = start.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  start.setDate(start.getDate() + diff);
  return start;
}

function normalizeOwnerPeriod(value = 'today') {
  const period = String(value || 'today').trim().toLowerCase();
  const allowed = ['today', 'yesterday', 'before_yesterday', 'week', 'month', 'custom'];
  return allowed.includes(period) ? period : 'today';
}

function resolveOwnerDateRange(queryParams = {}) {
  const period = normalizeOwnerPeriod(queryParams.period);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let start = new Date(today);
  let end = addDaysLocal(today, 1);
  let label = 'Hoy';

  if (period === 'yesterday') {
    start = addDaysLocal(today, -1);
    end = new Date(today);
    label = 'Ayer';
  } else if (period === 'before_yesterday') {
    start = addDaysLocal(today, -2);
    end = addDaysLocal(today, -1);
    label = 'Antes de ayer';
  } else if (period === 'week') {
    start = startOfWeekMonday(today);
    end = addDaysLocal(today, 1);
    label = 'Esta semana';
  } else if (period === 'month') {
    start = new Date(today.getFullYear(), today.getMonth(), 1);
    end = addDaysLocal(today, 1);
    label = 'Este mes';
  } else if (period === 'custom') {
    const customStart = String(queryParams.startDate || '').trim();
    const customEnd = String(queryParams.endDate || '').trim();
    const validStart = /^\d{4}-\d{2}-\d{2}$/.test(customStart) ? customStart : dateOnlyLocal(today);
    const validEnd = /^\d{4}-\d{2}-\d{2}$/.test(customEnd) ? customEnd : validStart;
    const orderedStart = validEnd < validStart ? validEnd : validStart;
    const orderedEnd = validEnd < validStart ? validStart : validEnd;
    return {
      period,
      startParam: orderedStart,
      endParam: dateOnlyLocal(addDaysLocal(new Date(`${orderedEnd}T00:00:00`), 1)),
      startDate: orderedStart,
      endDate: orderedEnd,
      isShift: false,
      label: orderedStart === orderedEnd ? orderedStart : `${orderedStart} a ${orderedEnd}`
    };
  }

  return {
    period,
    startParam: dateOnlyLocal(start),
    endParam: dateOnlyLocal(end),
    startDate: dateOnlyLocal(start),
    endDate: dateOnlyLocal(addDaysLocal(end, -1)),
    isShift: false,
    label
  };
}

async function resolveOwnerDashboardRange(queryParams = {}) {
  const baseRange = resolveOwnerDateRange(queryParams);
  const shiftId = String(queryParams.shiftId || '').trim();
  if (!shiftId) return baseRange;

  const { rows } = await query(
    `SELECT cd.*, ou.full_name AS opened_by_name, cu.full_name AS closed_by_name
     FROM cash_drawers cd
     LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
     LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
     WHERE cd.id = $1
     LIMIT 1`,
    [shiftId]
  );

  const drawer = rows[0];
  if (!drawer) return baseRange;

  return {
    ...baseRange,
    isShift: true,
    shiftId: drawer.id,
    shift: drawer,
    startParam: drawer.opened_at,
    endParam: drawer.closed_at || new Date(),
    label: `Turno ${drawer.opened_at ? new Date(drawer.opened_at).toLocaleString('es-DO', { dateStyle: 'short', timeStyle: 'short' }) : ''}`
  };
}

function salesTimeFilter(alias = 's', range) {
  return range.isShift
    ? `${alias}.created_at >= $1::timestamptz AND ${alias}.created_at < $2::timestamptz`
    : `${alias}.created_at >= $1::date AND ${alias}.created_at < $2::date`;
}

function movementTimeFilter(alias = 'dm', range) {
  return range.isShift
    ? `${alias}.created_at >= $1::timestamptz AND ${alias}.created_at < $2::timestamptz`
    : `${alias}.created_at >= $1::date AND ${alias}.created_at < $2::date`;
}

async function getOwnerShiftRows(range) {
  const params = range.isShift ? [range.shiftId] : [range.startParam, range.endParam];
  const whereClause = range.isShift
    ? 'cd.id = $1'
    : 'cd.opened_at >= $1::date AND cd.opened_at < $2::date';

  const { rows } = await query(
    `SELECT
       cd.id,
       cd.status,
       cd.opening_amount,
       cd.closing_amount,
       cd.expected_cash,
       cd.cash_difference,
       cd.opened_at,
       cd.closed_at,
       ou.full_name AS opened_by_name,
       cu.full_name AS closed_by_name,
       COALESCE(sales.cash_sales, 0)::numeric(12,2) AS cash_sales,
       COALESCE(sales.transfer_sales, 0)::numeric(12,2) AS transfer_sales,
       COALESCE(sales.total_sales, 0)::numeric(12,2) AS total_sales,
       COALESCE(movements.drawer_in, 0)::numeric(12,2) AS drawer_in,
       COALESCE(movements.drawer_out, 0)::numeric(12,2) AS drawer_out,
       (COALESCE(cd.opening_amount, 0) + COALESCE(sales.cash_sales, 0) + COALESCE(movements.drawer_in, 0) - COALESCE(movements.drawer_out, 0))::numeric(12,2) AS expected_cash_live,
       (COALESCE(sales.cash_sales, 0) + COALESCE(movements.drawer_in, 0) - COALESCE(movements.drawer_out, 0))::numeric(12,2) AS cash_to_withdraw
     FROM cash_drawers cd
     LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
     LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
     LEFT JOIN LATERAL (
       SELECT
         COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales
       FROM sales s
       WHERE s.status = 'PAID'
         AND s.created_at >= cd.opened_at
         AND s.created_at < COALESCE(cd.closed_at, NOW())
     ) sales ON true
     LEFT JOIN LATERAL (
       SELECT
         COALESCE(SUM(CASE WHEN dm.type = 'IN' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
         COALESCE(SUM(CASE WHEN dm.type = 'OUT' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
       FROM drawer_movements dm
       WHERE dm.drawer_id = cd.id
     ) movements ON true
     WHERE ${whereClause}
     ORDER BY cd.opened_at DESC
     LIMIT 60`,
    params
  );

  return rows.map((row) => ({
    id: row.id,
    status: row.status || 'CLOSED',
    opening_amount: toNumber(row.opening_amount),
    closing_amount: toNumber(row.closing_amount),
    expected_cash: toNumber(row.expected_cash_live || row.expected_cash),
    cash_difference: toNumber(row.cash_difference),
    cash_sales: toNumber(row.cash_sales),
    transfer_sales: toNumber(row.transfer_sales),
    total_sales: toNumber(row.total_sales),
    drawer_in: toNumber(row.drawer_in),
    drawer_out: toNumber(row.drawer_out),
    cash_to_withdraw: toNumber(row.cash_to_withdraw),
    opened_at: row.opened_at,
    closed_at: row.closed_at,
    opened_by_name: row.opened_by_name,
    closed_by_name: row.closed_by_name
  }));
}

function normalizeCodeType(value) {
  const type = String(value || 'TRANSFER').trim().toUpperCase();
  return type === 'PAYMENT' ? 'PAYMENT' : 'TRANSFER';
}


function normalizeGameRequestStatus(value = '') {
  const status = String(value || '').trim().toUpperCase();
  const allowed = ['PENDIENTE', 'ESPERANDO', 'REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO'];
  return allowed.includes(status) ? status : '';
}

function normalizeOwnerText(value = '', max = 220) {
  return String(value || '').trim().slice(0, max) || null;
}

async function createOwnerUniqueCode() {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const { rowCount } = await query(
      `SELECT id FROM admin_one_time_codes WHERE code = $1 AND is_used = false AND expires_at > NOW() LIMIT 1`,
      [code]
    );
    if (rowCount === 0) return code;
  }
  const error = new Error('No se pudo generar el código. Intenta de nuevo.');
  error.status = 500;
  throw error;
}

export async function ownerDashboardCreateAuthorizationCode(req, res) {
  try {
    const codeType = normalizeCodeType(req.body?.codeType);
    const expiresMinutes = Math.min(60, Math.max(1, Number(req.body?.expiresMinutes || 15)));
    const purposeNote = String(req.body?.purposeNote || '').trim().slice(0, 160) || null;
    const code = await createOwnerUniqueCode();
    const { rows } = await query(
      `INSERT INTO admin_one_time_codes (code, code_type, created_by_user_id, expires_at, purpose_note)
       VALUES ($1, $2, $3, NOW() + ($4::int * INTERVAL '1 minute'), $5)
       RETURNING id, code, code_type, purpose_note, expires_at, created_at`,
      [code, codeType, req.ownerUser.id, expiresMinutes, purposeNote]
    );
    res.status(201).json({ authorizationCode: rows[0] });
  } catch (error) {
    console.error('Owner dashboard create code error:', error.message);
    res.status(error.status || 500).json({ error: error.message || 'No se pudo generar el código.' });
  }
}

export async function ownerDashboardAuthorizationCodes(_req, res) {
  try {
    const { rows } = await query(
      `SELECT c.id, c.code, c.code_type, c.purpose_note, c.is_used, c.expires_at, c.used_at, c.created_at,
              creator.full_name AS created_by_name,
              used_by.full_name AS used_by_name
       FROM admin_one_time_codes c
       LEFT JOIN users creator ON creator.id = c.created_by_user_id
       LEFT JOIN users used_by ON used_by.id = c.used_by_user_id
       ORDER BY c.created_at DESC
       LIMIT 20`
    );
    res.json({ codes: rows });
  } catch (error) {
    console.error('Owner dashboard codes error:', error.message);
    res.status(500).json({ error: 'No se pudieron cargar los códigos.' });
  }
}


function normalizeFamilyDiscountCode(value = '') {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 20);
}

function normalizeFamilyDiscountPercent(value) {
  const percent = Number.parseInt(String(value || 0), 10);
  return [50, 100].includes(percent) ? percent : 50;
}

function normalizeFamilyDiscountExpiresDays(value) {
  const days = Number.parseInt(String(value || 7), 10);
  return [1, 7, 15, 30].includes(days) ? days : 7;
}

async function createOwnerFamilyDiscountUniqueCode(prefix = 'FAM') {
  const cleanPrefix = normalizeFamilyDiscountCode(prefix || 'FAM').slice(0, 8) || 'FAM';
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const suffix = String(Math.floor(1000 + Math.random() * 9000));
    const code = `${cleanPrefix}${suffix}`;
    const { rowCount } = await query(`SELECT id FROM family_discount_codes WHERE code = $1 LIMIT 1`, [code]);
    if (rowCount === 0) return code;
  }
  const error = new Error('No se pudo generar el código familiar. Intenta de nuevo.');
  error.status = 500;
  throw error;
}

export async function ownerDashboardCreateFamilyDiscountCode(req, res) {
  try {
    const discountPercent = normalizeFamilyDiscountPercent(req.body?.discountPercent || req.body?.discount_percent);
    const expiresDays = normalizeFamilyDiscountExpiresDays(req.body?.expiresDays || req.body?.expires_days);
    const maxUsesRaw = Number.parseInt(String(req.body?.maxUses || req.body?.max_uses || 1), 10);
    const maxUses = Number.isFinite(maxUsesRaw) ? Math.max(1, Math.min(50, maxUsesRaw)) : 1;
    const note = String(req.body?.note || req.body?.purposeNote || '').trim().slice(0, 180) || null;
    let code = normalizeFamilyDiscountCode(req.body?.code || '');
    if (!code) code = await createOwnerFamilyDiscountUniqueCode('FAM');
    if (code.length < 4) return res.status(400).json({ error: 'El código debe tener al menos 4 caracteres.' });

    const { rows } = await query(
      `INSERT INTO family_discount_codes
         (code, discount_percent, max_uses, expires_at, note, created_by_user_id)
       VALUES ($1, $2, $3, NOW() + ($4::int * INTERVAL '1 day'), $5, $6)
       RETURNING id, code, discount_percent, applies_to, max_uses, used_count, is_active, expires_at, note, created_at`,
      [code, discountPercent, maxUses, expiresDays, note, req.ownerUser.id]
    );

    res.status(201).json({ discountCode: rows[0] });
  } catch (error) {
    console.error('Owner dashboard family discount create error:', error.message);
    const message = error.code === '23505' ? 'Ese código ya existe. Usa otro nombre.' : (error.message || 'No se pudo generar el código de descuento.');
    res.status(error.status || (error.code === '23505' ? 409 : 500)).json({ error: message });
  }
}

export async function ownerDashboardFamilyDiscountCodes(_req, res) {
  try {
    const { rows } = await query(
      `SELECT c.id, c.code, c.discount_percent, c.applies_to, c.max_uses, c.used_count, c.is_active,
              c.expires_at, c.note, c.created_at,
              creator.full_name AS created_by_name,
              COALESCE(usage_summary.discount_amount, 0)::numeric(12,2) AS discount_amount,
              COALESCE(usage_summary.usage_count, 0)::int AS usage_count
       FROM family_discount_codes c
       LEFT JOIN users creator ON creator.id = c.created_by_user_id
       LEFT JOIN LATERAL (
         SELECT COUNT(u.id)::int AS usage_count,
                COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount
         FROM family_discount_code_usages u
         WHERE u.code_id = c.id
       ) usage_summary ON true
       ORDER BY c.created_at DESC
       LIMIT 40`
    );
    res.json({ discountCodes: rows });
  } catch (error) {
    console.error('Owner dashboard family discount list error:', error.message);
    res.status(500).json({ error: 'No se pudieron cargar los códigos familiares.' });
  }
}

function normalizeStationStatus(row = {}) {
  if (row.active_session_id) return 'BUSY';
  return row.status || 'AVAILABLE';
}

function buildOwnerToken(user) {
  return jwt.sign(
    {
      purpose: OWNER_DASHBOARD_TOKEN_PURPOSE,
      id: user.id,
      name: user.full_name,
      role: user.role
    },
    env.jwtSecret,
    { expiresIn: '12h' }
  );
}

function getBearerToken(req) {
  const header = String(req.headers.authorization || '');
  return header.startsWith('Bearer ') ? header.slice(7) : null;
}

export function requireOwnerDashboardAuth(req, res, next) {
  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Inicia sesión para ver el panel owner.' });

  try {
    const payload = jwt.verify(token, env.jwtSecret);
    if (payload?.purpose !== OWNER_DASHBOARD_TOKEN_PURPOSE) {
      return res.status(401).json({ error: 'Sesión inválida para este panel.' });
    }
    if (!['OWNER', 'MANAGER'].includes(String(payload.role || '').toUpperCase())) {
      return res.status(403).json({ error: 'No tienes permiso para ver el panel owner.' });
    }
    req.ownerUser = payload;
    next();
  } catch (_error) {
    return res.status(401).json({ error: 'Sesión expirada. Vuelve a iniciar sesión.' });
  }
}

export async function ownerDashboardLogin(req, res) {
  try {
    const pin = String(req.body?.pin || '').trim();
    if (!pin) return res.status(400).json({ error: 'Ingresa el PIN owner/admin.' });

    const { rows } = await query(
      `SELECT id, full_name, role, pin_hash, is_active
       FROM users
       WHERE is_active = true
       ORDER BY created_at ASC`
    );

    const user = rows.find((row) => bcrypt.compareSync(pin, row.pin_hash));
    if (!user) return res.status(401).json({ error: 'PIN incorrecto.' });

    const role = String(user.role || '').toUpperCase();
    if (!['OWNER', 'MANAGER'].includes(role)) {
      return res.status(403).json({ error: 'Este PIN no tiene permiso para reportes remotos.' });
    }

    res.json({
      token: buildOwnerToken(user),
      user: {
        id: user.id,
        name: user.full_name,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Owner dashboard login error:', error.message);
    res.status(500).json({ error: 'No se pudo iniciar sesión en el panel owner.' });
  }
}

export async function ownerDashboardSummary(req, res) {
  try {
    const range = await resolveOwnerDashboardRange(req.query || {});
    const rangeParams = [range.startParam, range.endParam];
    const saleFilter = salesTimeFilter('s', range);
    const drawerMovementFilter = movementTimeFilter('dm', range);
    const shifts = await getOwnerShiftRows(range);
    const salesResult = await query(
      `SELECT
         COUNT(s.id)::int AS sale_count,
         COALESCE(SUM(s.total), 0)::numeric(12,2) AS total_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales,
         COALESCE(SUM(CASE WHEN s.payment_method = 'MIXED' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS mixed_sales,
         COALESCE(SUM(s.discount_total), 0)::numeric(12,2) AS discount_total,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'CASH')::int AS cash_count,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'TRANSFER')::int AS transfer_count,
         COUNT(s.id) FILTER (WHERE s.payment_method = 'MIXED')::int AS mixed_count
       FROM sales s
       WHERE s.status = 'PAID'
         AND ${saleFilter}` ,
      rangeParams
    );

    const familyDiscountsResult = await query(
      `SELECT
         COALESCE(SUM(u.discount_amount), 0)::numeric(12,2) AS discount_amount,
         COUNT(u.id)::int AS usage_count,
         COUNT(DISTINCT u.code_id)::int AS code_count
       FROM family_discount_code_usages u
       JOIN sales s ON s.id = u.sale_id
       WHERE s.status = 'PAID'
         AND ${saleFilter}`,
      rangeParams
    );

    const familyDiscountRowsResult = await query(
      `SELECT u.id, u.discount_amount, u.discountable_amount, u.total_after_discount, u.used_at,
              c.code, c.discount_percent, c.note,
              cashier.full_name AS cashier_name,
              COALESCE(m.full_name, 'General') AS member_name
       FROM family_discount_code_usages u
       JOIN family_discount_codes c ON c.id = u.code_id
       JOIN sales s ON s.id = u.sale_id
       LEFT JOIN users cashier ON cashier.id = u.user_id
       LEFT JOIN members m ON m.id = s.member_id
       WHERE s.status = 'PAID'
         AND ${saleFilter.replaceAll('s.', 's.')}
       ORDER BY u.used_at DESC
       LIMIT 25`,
      rangeParams
    );

    const recentSalesResult = await query(
      `SELECT
         s.id,
         s.total,
         s.payment_method,
         s.created_at,
         u.full_name AS cashier_name,
         COALESCE(m.full_name, 'General') AS member_name,
         COALESCE(items.items, '[]'::json) AS items
       FROM sales s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN members m ON m.id = s.member_id
       LEFT JOIN LATERAL (
         SELECT json_agg(json_build_object(
           'description', si.description,
           'quantity', si.quantity,
           'total', si.total,
           'item_type', si.item_type
         ) ORDER BY si.created_at ASC, si.id ASC) AS items
         FROM sale_items si
         WHERE si.sale_id = s.id
       ) items ON true
       WHERE s.status = 'PAID'
         AND ${saleFilter}
       ORDER BY s.created_at DESC
       LIMIT 20`,
      rangeParams
    );

    const stationsResult = await query(
      `SELECT
         st.id,
         st.name,
         st.console_type,
         st.status,
         gs.id AS active_session_id,
         gs.started_at,
         gs.rate_type,
         gs.prepaid_minutes,
         gs.total_amount,
         gs.player_count,
         sg.name AS game_name,
         COALESCE(m.full_name, 'General') AS member_name,
         u.full_name AS cashier_name,
         COALESCE(account.pending_total, 0)::numeric(12,2) AS pending_total,
         COALESCE(account.paid_total, 0)::numeric(12,2) AS paid_total,
         COALESCE(account.item_count, 0)::int AS item_count
       FROM stations st
       LEFT JOIN game_sessions gs ON gs.station_id = st.id AND gs.status = 'ACTIVE'
       LEFT JOIN station_games sg ON sg.id = gs.game_id
       LEFT JOIN members m ON m.id = gs.member_id
       LEFT JOIN users u ON u.id = gs.started_by_user_id
       LEFT JOIN LATERAL (
         SELECT
           COUNT(ssi.id)::int AS item_count,
           COALESCE(SUM(CASE WHEN ssi.payment_status = 'PENDING' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS pending_total,
           COALESCE(SUM(CASE WHEN ssi.payment_status = 'PAID' THEN ssi.total ELSE 0 END), 0)::numeric(12,2) AS paid_total
         FROM station_session_items ssi
         WHERE ssi.session_id = gs.id
       ) account ON true
       WHERE st.deleted_at IS NULL
       ORDER BY st.sort_order, st.name`
    );

    const drawerResult = await query(
      `WITH range_sales AS (
         SELECT
           COALESCE(SUM(CASE WHEN s.payment_method = 'CASH' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS cash_sales,
           COALESCE(SUM(CASE WHEN s.payment_method = 'TRANSFER' THEN s.total ELSE 0 END), 0)::numeric(12,2) AS transfer_sales
         FROM sales s
         WHERE s.status = 'PAID'
           AND ${saleFilter}
       ), range_drawers AS (
         SELECT cd.*, ou.full_name AS opened_by_name, cu.full_name AS closed_by_name
         FROM cash_drawers cd
         LEFT JOIN users ou ON ou.id = cd.opened_by_user_id
         LEFT JOIN users cu ON cu.id = cd.closed_by_user_id
         WHERE ${range.isShift ? 'cd.id = $3' : 'cd.opened_at >= $1::date AND cd.opened_at < $2::date'}
       ), range_movements AS (
         SELECT
           COALESCE(SUM(CASE WHEN dm.type = 'IN' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_in,
           COALESCE(SUM(CASE WHEN dm.type = 'OUT' THEN dm.amount ELSE 0 END), 0)::numeric(12,2) AS drawer_out
         FROM drawer_movements dm
         JOIN range_drawers cd ON cd.id = dm.drawer_id
         WHERE ${range.isShift ? 'dm.drawer_id = $3' : drawerMovementFilter}
       )
       SELECT
         COUNT(rd.id)::int AS drawer_count,
         COUNT(*) FILTER (WHERE rd.status = 'OPEN')::int AS open_drawer_count,
         MAX(rd.id::text) FILTER (WHERE rd.status = 'OPEN') AS open_drawer_id,
         COALESCE(SUM(rd.opening_amount), 0)::numeric(12,2) AS opening_amount,
         COALESCE(SUM(rd.closing_amount), 0)::numeric(12,2) AS closing_amount,
         MIN(rd.opened_at) AS opened_at,
         MAX(rd.closed_at) AS closed_at,
         MAX(rd.opened_by_name) AS opened_by_name,
         MAX(rd.closed_by_name) AS closed_by_name,
         rs.cash_sales,
         rs.transfer_sales,
         rm.drawer_in,
         rm.drawer_out,
         (COALESCE(SUM(rd.opening_amount), 0) + COALESCE(rs.cash_sales, 0) + COALESCE(rm.drawer_in, 0) - COALESCE(rm.drawer_out, 0))::numeric(12,2) AS expected_cash,
         (COALESCE(rs.cash_sales, 0) + COALESCE(rm.drawer_in, 0) - COALESCE(rm.drawer_out, 0))::numeric(12,2) AS cash_to_withdraw
       FROM range_sales rs
       CROSS JOIN range_movements rm
       LEFT JOIN range_drawers rd ON true
       GROUP BY rs.cash_sales, rs.transfer_sales, rm.drawer_in, rm.drawer_out`,
      range.isShift ? [...rangeParams, range.shiftId] : rangeParams
    );

    const expensesResult = await query(
      `SELECT
         COALESCE(SUM(amount), 0)::numeric(12,2) AS total_expenses,
         COUNT(id)::int AS expense_count,
         COALESCE(SUM(CASE WHEN payment_method = 'CASH' THEN amount ELSE 0 END), 0)::numeric(12,2) AS cash_expenses,
         COALESCE(SUM(CASE WHEN payment_method = 'TRANSFER' THEN amount ELSE 0 END), 0)::numeric(12,2) AS transfer_expenses
       FROM finance_expenses
       WHERE is_active = true
         AND expense_date >= $1::date
         AND expense_date < $2::date`,
      [range.startDate, dateOnlyLocal(addDaysLocal(new Date(`${range.endDate}T00:00:00`), 1))]
    );

    const todayPaymentsResult = await query(
      `SELECT dm.id, dm.amount, dm.reason, dm.created_at, u.full_name AS user_name
       FROM drawer_movements dm
       JOIN cash_drawers cd ON cd.id = dm.drawer_id
       LEFT JOIN users u ON u.id = dm.user_id
       WHERE dm.type = 'OUT'
         AND ${range.isShift ? 'dm.drawer_id = $3' : drawerMovementFilter}
       ORDER BY dm.created_at DESC
       LIMIT 30`,
      range.isShift ? [...rangeParams, range.shiftId] : rangeParams
    );

    const gameRequestsResult = await query(
      `SELECT
         gr.id,
         gr.request_type,
         gr.request_scope,
         gr.requested_game_name,
         gr.platform,
         gr.unavailable_reason,
         gr.customer_decision,
         gr.status,
         gr.eta_text,
         gr.member_note,
         gr.admin_note,
         gr.purchase_method,
         gr.purchased_at,
         gr.reviewed_at,
         gr.created_at,
         gr.updated_at,
         sg.name AS game_name,
         st.name AS station_name,
         COALESCE(m.full_name, gr.customer_name, 'Cliente') AS customer_name,
         u.full_name AS cashier_name
       FROM game_requests gr
       LEFT JOIN station_games sg ON sg.id = gr.game_id
       LEFT JOIN stations st ON st.id = gr.station_id
       LEFT JOIN members m ON m.id = gr.member_id
       LEFT JOIN users u ON u.id = gr.cashier_id
       WHERE gr.status IN ('PENDIENTE', 'ESPERANDO', 'REVISADO', 'COMPRADO')
          OR gr.created_at >= CURRENT_DATE - INTERVAL '7 days'
       ORDER BY
         CASE gr.status
           WHEN 'PENDIENTE' THEN 1
           WHEN 'ESPERANDO' THEN 2
           WHEN 'REVISADO' THEN 3
           WHEN 'COMPRADO' THEN 4
           ELSE 9
         END,
         gr.created_at DESC
       LIMIT 30`
    );

    const activeStations = stationsResult.rows.filter((row) => row.active_session_id);
    const sales = salesResult.rows[0] || {};
    const expenses = expensesResult.rows[0] || {};
    const drawer = drawerResult.rows[0] || null;
    const drawerOutToday = toNumber(drawer?.drawer_out);

    res.json({
      generatedAt: new Date().toISOString(),
      range: {
        period: range.period,
        label: range.label,
        startDate: range.startDate,
        endDate: range.endDate,
        shiftId: range.shiftId || null,
        isShift: Boolean(range.isShift)
      },
      shifts,
      sales: {
        sale_count: toNumber(sales.sale_count),
        total_sales: toNumber(sales.total_sales),
        cash_sales: toNumber(sales.cash_sales),
        transfer_sales: toNumber(sales.transfer_sales),
        mixed_sales: toNumber(sales.mixed_sales),
        discount_total: toNumber(sales.discount_total),
        cash_count: toNumber(sales.cash_count),
        transfer_count: toNumber(sales.transfer_count),
        mixed_count: toNumber(sales.mixed_count)
      },
      familyDiscounts: {
        discount_amount: toNumber(familyDiscountsResult.rows[0]?.discount_amount),
        usage_count: toNumber(familyDiscountsResult.rows[0]?.usage_count),
        code_count: toNumber(familyDiscountsResult.rows[0]?.code_count),
        rows: familyDiscountRowsResult.rows.map((row) => ({
          ...row,
          discount_amount: toNumber(row.discount_amount),
          discountable_amount: toNumber(row.discountable_amount),
          total_after_discount: toNumber(row.total_after_discount)
        }))
      },
      expenses: {
        total_expenses: drawerOutToday || toNumber(expenses.total_expenses),
        expense_count: todayPaymentsResult.rows.length || toNumber(expenses.expense_count),
        cash_expenses: drawerOutToday || toNumber(expenses.cash_expenses),
        transfer_expenses: toNumber(expenses.transfer_expenses),
        drawer_out: drawerOutToday
      },
      payments: todayPaymentsResult.rows,
      drawer: drawer ? {
        id: drawer.id,
        status: toNumber(drawer.open_drawer_count) > 0 ? 'OPEN' : 'CLOSED',
        drawer_count: toNumber(drawer.drawer_count),
        open_drawer_count: toNumber(drawer.open_drawer_count),
        opening_amount: toNumber(drawer.opening_amount),
        closing_amount: toNumber(drawer.closing_amount),
        cash_sales: toNumber(drawer.cash_sales),
        transfer_sales: toNumber(drawer.transfer_sales),
        drawer_in: toNumber(drawer.drawer_in),
        drawer_out: toNumber(drawer.drawer_out),
        expected_cash: toNumber(drawer.expected_cash),
        cash_to_withdraw: toNumber(drawer.cash_to_withdraw),
        opened_at: drawer.opened_at,
        closed_at: drawer.closed_at,
        opened_by_name: drawer.opened_by_name,
        closed_by_name: drawer.closed_by_name
      } : null,
      stations: stationsResult.rows.map((row) => ({
        id: row.id,
        name: row.name,
        console_type: row.console_type,
        status: normalizeStationStatus(row),
        active_session_id: row.active_session_id,
        started_at: row.started_at,
        rate_type: row.rate_type,
        prepaid_minutes: row.prepaid_minutes,
        total_amount: toNumber(row.total_amount),
        player_count: row.player_count,
        game_name: row.game_name,
        member_name: row.member_name,
        cashier_name: row.cashier_name,
        pending_total: toNumber(row.pending_total),
        paid_total: toNumber(row.paid_total),
        item_count: toNumber(row.item_count)
      })),
      stationSummary: {
        total: stationsResult.rows.length,
        active: activeStations.length,
        available: stationsResult.rows.filter((row) => !row.active_session_id && row.status === 'AVAILABLE').length,
        maintenance: stationsResult.rows.filter((row) => row.status === 'MAINTENANCE').length,
        offline: stationsResult.rows.filter((row) => row.status === 'OFFLINE').length
      },
      gameRequests: gameRequestsResult.rows,
      recentSales: recentSalesResult.rows
    });
  } catch (error) {
    console.error('Owner dashboard summary error:', error.message);
    res.status(500).json({ error: 'No se pudo cargar el panel owner.', detail: error.message });
  }
}


export async function ownerDashboardUpdateGameRequest(req, res) {
  try {
    const { requestId } = req.params;
    const status = normalizeGameRequestStatus(req.body?.status);
    const adminNote = normalizeOwnerText(req.body?.adminNote, 260);
    const etaText = normalizeOwnerText(req.body?.etaText, 80);
    const purchaseMethodInput = String(req.body?.purchaseMethod || '').trim().toUpperCase();
    const purchaseMethod = ['DIGITAL', 'FISICO', 'PENDIENTE'].includes(purchaseMethodInput) ? purchaseMethodInput : null;

    if (!status) return res.status(400).json({ error: 'Estado inválido para solicitud.' });

    const { rows } = await query(
      `UPDATE game_requests
       SET status = $2,
           admin_note = COALESCE($3::text, admin_note),
           eta_text = CASE WHEN $4::text IS NULL THEN eta_text ELSE $4::text END,
           purchase_method = CASE WHEN $2 = 'COMPRADO' THEN COALESCE($5::text, purchase_method, 'PENDIENTE') ELSE purchase_method END,
           purchased_at = CASE WHEN $2 = 'COMPRADO' THEN COALESCE(purchased_at, NOW()) ELSE purchased_at END,
           reviewed_at = CASE WHEN $2 IN ('REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO') THEN COALESCE(reviewed_at, NOW()) ELSE reviewed_at END,
           updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [requestId, status, adminNote, etaText, purchaseMethod]
    );

    if (!rows[0]) return res.status(404).json({ error: 'Solicitud no encontrada.' });
    res.json({ request: rows[0] });
  } catch (error) {
    console.error('Owner dashboard update game request error:', error.message);
    res.status(500).json({ error: 'No se pudo actualizar la solicitud.' });
  }
}
