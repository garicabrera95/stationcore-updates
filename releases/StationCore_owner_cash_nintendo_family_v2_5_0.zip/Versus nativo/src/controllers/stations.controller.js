import { query, withTransaction } from '../db/pool.js';
import { validateTransferAuthorizationCode } from './authorizationCodes.controller.js';
import { logAuditEvent } from '../services/audit.service.js';
import { recordMemberPointMovement } from '../services/member-points.service.js';
import { syncMemberAchievements } from '../services/member-achievements.service.js';
function normalizeBooleanSetting(value, fallback = true) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  const normalized = String(value).trim().toLowerCase();
  if (['false', '0', 'no', 'off', 'disabled', 'inactive'].includes(normalized)) return false;
  if (['true', '1', 'yes', 'on', 'enabled', 'active'].includes(normalized)) return true;
  return fallback;
}


function sendControllerError(res, error) {
  const status = error.status || 500;
  if (status >= 500) console.error(error);
  else console.warn(error.message);
  return res.status(status).json({
    error: status === 500 ? 'Error interno del servidor' : error.message
  });
}


function isRewardFullyUsed(reward) {
  return Number(reward.reward_minutes || 0) <= Number(reward.used_reward_minutes || 0)
    && Number(reward.prize_snack_qty || 0) <= Number(reward.used_prize_snack_qty || 0)
    && Number(reward.prize_drink_qty || 0) <= Number(reward.used_prize_drink_qty || 0)
    && Number(reward.prize_product_qty || 0) <= Number(reward.used_prize_product_qty || 0);
}

function getRewardRemaining(reward, field, usedField) {
  return Math.max(0, Number(reward[field] || 0) - Number(reward[usedField] || 0));
}



const ALLOWED_CONSOLES = ['PlayStation 4', 'PlayStation 5', 'Xbox One', 'Xbox Series', 'Nintendo Switch'];
const DEFAULT_GAME_COMPATIBILITY = ALLOWED_CONSOLES;
const ALLOWED_STATION_STATUS = ['AVAILABLE', 'MAINTENANCE', 'OFFLINE'];
const ALLOWED_GAME_LOCATION_TYPES = ['Instalado en consola', 'Disco físico', 'Cartucho', 'SSD externo', 'Disco duro externo', 'Micro SD', 'Cuenta/perfil específico', 'No instalado'];
const ALLOWED_GAME_LOCATION_STATUSES = ['Disponible', 'En uso', 'No instalado', 'Actualización pendiente'];
const ALLOWED_GAME_DEVICE_TYPES = ['SSD externo', 'Disco duro externo', 'Micro SD', 'Disco físico', 'Cartucho', 'Cuenta/perfil específico'];
const ALLOWED_GAME_REQUEST_TYPES = ['EXISTING', 'NEW_GAME'];
const ALLOWED_GAME_REQUEST_SCOPES = ['SUGGESTION', 'OFFICIAL'];
const ALLOWED_GAME_REQUEST_DECISIONS = ['ESPERA', 'ACEPTO_OTRO', 'SE_FUE', 'SOLO_REGISTRAR'];
const ALLOWED_GAME_REQUEST_STATUSES = ['PENDIENTE', 'ESPERANDO', 'REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO'];
const ALLOWED_GAME_RESERVATION_TYPES = ['WAITLIST', 'RESERVATION'];
const ALLOWED_GAME_RESERVATION_STATUSES = ['WAITING', 'RESERVED', 'CALLED', 'NOTIFIED', 'ASSIGNED', 'CONVERTED', 'CANCELED', 'NO_SHOW', 'EXPIRED'];
const ACTIVE_BLOCKING_RESERVATION_STATUSES = ['RESERVED', 'CALLED', 'NOTIFIED'];
const DEFAULT_WAITLIST_RESPONSE_WINDOW_MINUTES = 5;
const MEMBERSHIP_WAITLIST_RESPONSE_WINDOWS = {
  GAMER: 7,
  GAMER_PRO: 10,
  CHAMPION: 15
};
const ALLOWED_GAME_RESERVATION_PAYMENT_METHODS = ['CASH', 'TRANSFER'];

const DEFAULT_TIME_PRICE_ROWS = [
  { label: '15 min', minutes: 15, price: 30, sortOrder: 10 },
  { label: '30 min', minutes: 30, price: 60, sortOrder: 20 },
  { label: '1 hora', minutes: 60, price: 100, sortOrder: 30 },
  { label: '2 horas', minutes: 120, price: 180, sortOrder: 40 },
  { label: '3 horas', minutes: 180, price: 250, sortOrder: 50 }
];

function normalizeReservationMembershipTier(tier = '') {
  const value = String(tier || '').trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_');
  if (!value) return '';
  if (value.includes('CHAMPION')) return 'CHAMPION';
  if (value.includes('PRO')) return 'GAMER_PRO';
  if (value.includes('GAMER')) return 'GAMER';
  return value;
}

function getMembershipWaitlistResponseWindow(tier = '', active = false) {
  if (!active) return DEFAULT_WAITLIST_RESPONSE_WINDOW_MINUTES;
  const normalized = normalizeReservationMembershipTier(tier);
  return MEMBERSHIP_WAITLIST_RESPONSE_WINDOWS[normalized] || 7;
}

async function getReservationResponseWindowMinutes(reservationId, requestedMinutes = null) {
  const requested = Number.parseInt(String(requestedMinutes || ''), 10);
  if (Number.isFinite(requested) && requested > 0) {
    return Math.min(120, Math.max(1, requested));
  }
  const { rows } = await query(
    `SELECT m.membership_tier, m.membership_active
       FROM game_reservations gr
       LEFT JOIN members m ON m.id = gr.member_id
      WHERE gr.id = $1
      LIMIT 1`,
    [reservationId]
  );
  const member = rows[0] || {};
  return getMembershipWaitlistResponseWindow(member.membership_tier, member.membership_active === true);
}

function normalizeGameCompatibility(value, legacyPlatform = 'Multiplataforma') {
  const rawList = Array.isArray(value) ? value : [];
  const selected = rawList
    .map((item) => String(item || '').trim())
    .filter((item) => ALLOWED_CONSOLES.includes(item));

  if (selected.length) return [...new Set(selected)];

  const platform = String(legacyPlatform || '').toLowerCase();
  if (platform.includes('playstation 4') || platform.includes('ps4')) return ['PlayStation 4'];
  if (platform.includes('playstation 5') || platform.includes('ps5')) return ['PlayStation 5'];
  if (platform.includes('playstation')) return ['PlayStation 4', 'PlayStation 5'];
  if (platform.includes('xbox')) return ['Xbox One', 'Xbox Series'];
  if (platform.includes('switch') || platform.includes('nintendo')) return ['Nintendo Switch'];
  return [...DEFAULT_GAME_COMPATIBILITY];
}

function isGameCompatibleWithConsole(game = {}, consoleType = '') {
  const compatible = Array.isArray(game.compatible_consoles) && game.compatible_consoles.length
    ? game.compatible_consoles
    : normalizeGameCompatibility([], game.platform);
  return compatible.includes(consoleType);
}

async function getActiveGameUsage(client, gameId) {
  if (!gameId) return 0;
  const { rows } = await client.query(
    `SELECT COUNT(*)::int AS active_count
     FROM game_sessions
     WHERE game_id = $1
       AND status = 'ACTIVE'`,
    [gameId]
  );
  return Number(rows[0]?.active_count || 0);
}

async function ensureGameCanBeUsed(client, { game, station, stationId }) {
  if (!game) return;
  if (!isGameCompatibleWithConsole(game, station.console_type)) {
    const error = new Error('Este juego no es compatible con esta estación');
    error.status = 400;
    throw error;
  }

  if (game.unlimited_copies === true) return;

  const activeSameStation = await client.query(
    `SELECT id FROM game_sessions WHERE station_id = $1 AND game_id = $2 AND status = 'ACTIVE' LIMIT 1`,
    [stationId, game.id]
  );
  if (activeSameStation.rowCount > 0) return;

  const activeCount = await getActiveGameUsage(client, game.id);
  const copies = Math.max(0, Number(game.copy_quantity || 0));
  if (activeCount >= copies) {
    const error = new Error('Ese juego está en uso y no quedan copias disponibles');
    error.status = 409;
    throw error;
  }
}


function normalizeTimePriceRow(row) {
  const label = String(row.label || '').trim();
  const minutes = Number.parseInt(String(row.minutes || 0), 10);
  const price = Number(row.price ?? 0);
  const playerCount = normalizePlayerCount(row.playerCount ?? row.player_count ?? 1);
  const sortOrder = Number.parseInt(String(row.sortOrder ?? row.sort_order ?? minutes), 10);
  const isActive = row.isActive ?? row.is_active ?? true;

  if (!label) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(minutes) || minutes <= 0) {
    const error = new Error('Tiempo inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(price) || price < 0) {
    const error = new Error('Precio inválido');
    error.status = 400;
    throw error;
  }

  return {
    label,
    minutes,
    price: Number(price.toFixed(2)),
    playerCount,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : minutes,
    isActive: Boolean(isActive)
  };
}

function normalizeGroupEventPriceRow(row = {}, index = 0) {
  const priceType = String(row.priceType || row.price_type || 'GROUP').trim().toUpperCase();
  const name = String(row.name || '').trim();
  const minPlayers = Number.parseInt(String(row.minPlayers ?? row.min_players ?? 5), 10);
  const stationCount = Number.parseInt(String(row.stationCount ?? row.station_count ?? 1), 10);
  const isFullClub = normalizeBooleanSetting(row.isFullClub ?? row.is_full_club ?? false, false);
  const durationMinutes = Number.parseInt(String(row.durationMinutes ?? row.duration_minutes ?? 0), 10);
  const price = Number(row.price ?? 0);
  const depositPercent = Number(row.depositPercent ?? row.deposit_percent ?? 50);
  const minDepositAmount = Number(row.minDepositAmount ?? row.min_deposit_amount ?? 0);
  const extraPlayerPrice = Number(row.extraPlayerPrice ?? row.extra_player_price ?? 0);
  const extraStationPrice = Number(row.extraStationPrice ?? row.extra_station_price ?? 0);
  const sortOrder = Number.parseInt(String(row.sortOrder ?? row.sort_order ?? ((index + 1) * 10)), 10);
  const notes = String(row.notes || '').trim();

  if (!['GROUP', 'BIRTHDAY', 'PRIVATE_EVENT'].includes(priceType)) {
    const error = new Error('Tipo de precio grupal inválido');
    error.status = 400;
    throw error;
  }
  if (!name) {
    const error = new Error('Nombre requerido para precio grupal');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(minPlayers) || minPlayers < 1 || minPlayers > 200) {
    const error = new Error('Cantidad mínima de personas inválida');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(stationCount) || stationCount < 0 || stationCount > 50) {
    const error = new Error('Cantidad de estaciones inválida');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(durationMinutes) || durationMinutes < 30) {
    const error = new Error('Duración grupal inválida');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(price) || price < 0) {
    const error = new Error('Precio grupal inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(depositPercent) || depositPercent < 0 || depositPercent > 100) {
    const error = new Error('Porcentaje de depósito inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(minDepositAmount) || minDepositAmount < 0) {
    const error = new Error('Depósito mínimo inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(extraPlayerPrice) || extraPlayerPrice < 0) {
    const error = new Error('Costo por persona extra inválido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(extraStationPrice) || extraStationPrice < 0) {
    const error = new Error('Costo por estación extra inválido');
    error.status = 400;
    throw error;
  }

  return {
    id: String(row.id || '').trim() || null,
    priceType,
    name,
    minPlayers,
    stationCount: isFullClub ? 0 : stationCount,
    isFullClub,
    durationMinutes,
    price: Number(price.toFixed(2)),
    depositPercent: Number(depositPercent.toFixed(2)),
    minDepositAmount: Number(minDepositAmount.toFixed(2)),
    extraPlayerPrice: Number(extraPlayerPrice.toFixed(2)),
    extraStationPrice: Number(extraStationPrice.toFixed(2)),
    isActive: normalizeBooleanSetting(row.isActive ?? row.is_active ?? true, true),
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : ((index + 1) * 10),
    notes: notes || null
  };
}

function applyPromotionToPrice(baseAmount, promotion) {
  const base = Number(baseAmount || 0);
  if (!promotion || base <= 0) {
    return {
      baseAmount: Number(base.toFixed(2)),
      finalAmount: Number(base.toFixed(2)),
      discountAmount: 0,
      promotion: null
    };
  }

  let finalAmount = base;
  if (promotion.discount_type === 'PERCENT') {
    finalAmount = base - (base * Number(promotion.discount_value || 0) / 100);
  } else if (promotion.discount_type === 'FIXED_PRICE') {
    finalAmount = Number(promotion.discount_value || 0);
  }

  finalAmount = Math.max(0, Number(finalAmount.toFixed(2)));
  const discountAmount = Math.max(0, Number((base - finalAmount).toFixed(2)));

  return {
    baseAmount: Number(base.toFixed(2)),
    finalAmount,
    discountAmount,
    promotion: {
      id: promotion.id,
      name: promotion.name,
      discount_type: promotion.discount_type,
      discount_value: promotion.discount_value
    }
  };
}

async function getBestActivePromotion(client, station, baseAmount) {
  const { rows } = await client.query(
    `SELECT *
     FROM station_promotions
     WHERE is_active = true
       AND starts_on <= CURRENT_DATE
       AND (ends_on IS NULL OR ends_on >= CURRENT_DATE)
       AND EXTRACT(DOW FROM CURRENT_DATE)::int = ANY(days_of_week)
       AND (
         all_day = true
         OR (
           start_time IS NOT NULL
           AND end_time IS NOT NULL
           AND (
             (start_time <= end_time AND LOCALTIME >= start_time AND LOCALTIME <= end_time)
             OR (start_time > end_time AND (LOCALTIME >= start_time OR LOCALTIME <= end_time))
           )
         )
       )
       AND (
         scope_type = 'ALL'
         OR (scope_type = 'CONSOLE' AND console_type = $1)
         OR (scope_type = 'STATION' AND station_id = $2)
       )
     ORDER BY
       CASE scope_type WHEN 'STATION' THEN 1 WHEN 'CONSOLE' THEN 2 ELSE 3 END,
       sort_order,
       created_at DESC`,
    [station.console_type, station.id]
  );

  if (!rows.length) return null;

  return rows
    .map((promotion) => ({
      promotion,
      price: applyPromotionToPrice(baseAmount, promotion).finalAmount
    }))
    .sort((a, b) => a.price - b.price)[0].promotion;
}

async function getMemberTierForPrice(client, memberId) {
  if (!memberId) return null;

  const { rows } = await client.query(
    `SELECT membership_tier
     FROM members
     WHERE id = $1
       AND is_active = true
       AND membership_active = true
       AND membership_tier IS NOT NULL
     LIMIT 1`,
    [memberId]
  );

  return rows[0]?.membership_tier || null;
}

async function getGameTimePrice(client, station, minutes, memberId = null, playerCount = 1, options = {}) {
  const normalizedMinutes = Number.parseInt(String(minutes || 0), 10);
  if (!Number.isFinite(normalizedMinutes) || normalizedMinutes <= 0) {
    return { baseAmount: 0, finalAmount: 0, discountAmount: 0, promotion: null, source: 'GENERAL' };
  }

  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  const allowInactiveExtension = Boolean(options.allowInactiveExtension && normalizedMinutes === 15);
  let baseAmount = null;
  let priceSource = 'GENERAL';
  const memberTier = await getMemberTierForPrice(client, memberId);

  if (memberTier) {
    const memberPrice = await client.query(
      `SELECT price
       FROM membership_time_prices
       WHERE membership_tier = $1
         AND minutes = $2
         AND player_count = $3
         AND is_active = true
       LIMIT 1`,
      [memberTier, normalizedMinutes, normalizedPlayerCount]
    );

    if (memberPrice.rowCount > 0) {
      baseAmount = Number(memberPrice.rows[0].price || 0);
      priceSource = memberTier;
    }
  }

  if (baseAmount === null) {
    const stationPrice = await client.query(
      `SELECT price
       FROM station_time_prices
       WHERE station_id = $1
         AND minutes = $2
         AND player_count = $3
         AND ($4 = true OR is_active = true)
       LIMIT 1`,
      [station.id, normalizedMinutes, normalizedPlayerCount, allowInactiveExtension]
    );

    if (stationPrice.rowCount > 0) baseAmount = Number(stationPrice.rows[0].price || 0);
  }

  if (baseAmount === null) {
    const consolePrice = await client.query(
      `SELECT price
       FROM station_time_prices
       WHERE station_id IS NULL
         AND console_type = $1
         AND minutes = $2
         AND player_count = $3
         AND ($4 = true OR is_active = true)
       LIMIT 1`,
      [station.console_type, normalizedMinutes, normalizedPlayerCount, allowInactiveExtension]
    );

    if (consolePrice.rowCount > 0) baseAmount = Number(consolePrice.rows[0].price || 0);
  }

  if (baseAmount === null && normalizedMinutes === 15) {
    for (const fallbackMinutes of [30, 60]) {
      try {
        const fallback = await getGameTimePrice(client, station, fallbackMinutes, memberId, normalizedPlayerCount);
        const factor = normalizedMinutes / fallbackMinutes;
        baseAmount = Number((Number(fallback.baseAmount || fallback.finalAmount || 0) * factor).toFixed(2));
        priceSource = fallback.source || priceSource;
        break;
      } catch (_error) {
        // Intenta el siguiente precio base.
      }
    }
  }

  if (baseAmount === null) {
    const error = new Error('Precio de tiempo no configurado');
    error.status = 400;
    throw error;
  }

  const promotion = await getBestActivePromotion(client, station, baseAmount);
  return {
    ...applyPromotionToPrice(baseAmount, promotion),
    source: priceSource,
    playerCount: normalizedPlayerCount
  };
}



async function getOpenSessionPricingPackages(client, station, session) {
  const wantedMinutes = [30, 60, 120, 180];
  const packages = [];

  for (const minutes of wantedMinutes) {
    try {
      const price = await getGameTimePrice(client, station, minutes, session.member_id, session.player_count || 1);
      const amount = Number(price.finalAmount ?? price.baseAmount ?? 0);
      if (Number.isFinite(amount) && amount >= 0) {
        packages.push({ minutes, amount });
      }
    } catch (_error) {
      // Si falta un paquete, sigue con los demás configurados.
    }
  }

  return packages;
}

function calculateOpenSessionPackageAmount(chargeableMinutes, packages = [], hourlyRate = 0) {
  const minutes = Math.max(0, Number(chargeableMinutes || 0));
  if (minutes <= 0) return 0;

  const anchors = buildOpenSessionPricingAnchors(packages, hourlyRate);
  if (anchors.length <= 1) return 0;

  const largest = anchors[anchors.length - 1];
  if (!largest?.minutes || largest.minutes <= 0) return 0;

  const fullBlocks = Math.floor(minutes / largest.minutes);
  const remainder = minutes - (fullBlocks * largest.minutes);
  const baseAmount = fullBlocks * largest.amount;

  if (remainder <= 0.0001) return Number(baseAmount.toFixed(2));
  return Number((baseAmount + interpolateOpenSessionAmount(remainder, anchors)).toFixed(2));
}

function buildOpenSessionPricingAnchors(packages = [], hourlyRate = 0) {
  const byMinutes = new Map([[0, 0]]);

  [...packages]
    .map((pkg) => ({ minutes: Number(pkg.minutes || 0), amount: Number(pkg.amount || 0) }))
    .filter((pkg) => pkg.minutes > 0 && Number.isFinite(pkg.amount) && pkg.amount >= 0)
    .sort((a, b) => a.minutes - b.minutes)
    .forEach((pkg) => {
      if (!byMinutes.has(pkg.minutes) || pkg.amount < byMinutes.get(pkg.minutes)) {
        byMinutes.set(pkg.minutes, pkg.amount);
      }
    });

  const safeHourlyRate = Number(hourlyRate || 0);
  if (safeHourlyRate > 0 && !byMinutes.has(60)) {
    byMinutes.set(60, safeHourlyRate);
  }

  return Array.from(byMinutes.entries())
    .map(([minutes, amount]) => ({ minutes: Number(minutes), amount: Number(amount) }))
    .filter((row) => Number.isFinite(row.minutes) && Number.isFinite(row.amount))
    .sort((a, b) => a.minutes - b.minutes);
}

function interpolateOpenSessionAmount(minutes, anchors = []) {
  const target = Math.max(0, Number(minutes || 0));
  if (target <= 0) return 0;

  const sorted = [...anchors].sort((a, b) => a.minutes - b.minutes);
  let previous = sorted[0] || { minutes: 0, amount: 0 };

  for (const next of sorted.slice(1)) {
    if (target <= next.minutes) {
      const spanMinutes = Math.max(1, next.minutes - previous.minutes);
      const spanAmount = next.amount - previous.amount;
      const progress = (target - previous.minutes) / spanMinutes;
      return previous.amount + (spanAmount * Math.max(0, Math.min(1, progress)));
    }
    previous = next;
  }

  const safeRatePerMinute = previous.minutes > 0 ? previous.amount / previous.minutes : 0;
  return previous.amount + ((target - previous.minutes) * safeRatePerMinute);
}

async function getOpenSessionHourlyAmount(client, station, session, elapsedMinutes) {
  const exactPlayedMinutes = Math.max(0, Number(elapsedMinutes || 0));
  const playedMinutes = Math.max(1, Math.ceil(exactPlayedMinutes));
  const prepaidMinutes = Math.max(0, Number(session.prepaid_minutes || 0));
  const chargeableMinutes = Math.max(0, exactPlayedMinutes - prepaidMinutes);

  if (chargeableMinutes <= 0) {
    return { amount: 0, chargeableMinutes, hourlyRate: 0, packages: [] };
  }

  let hourlyRate = Number(station.hourly_rate || 0);
  try {
    const price = await getGameTimePrice(client, station, 60, session.member_id, session.player_count || 1);
    if (Number(price.finalAmount || 0) > 0) hourlyRate = Number(price.finalAmount || 0);
  } catch (_error) {
    // Si no hay precio de 1 hora configurado, usa el precio por hora guardado en la estación.
  }

  const packages = await getOpenSessionPricingPackages(client, station, session);
  const amount = calculateOpenSessionPackageAmount(chargeableMinutes, packages, hourlyRate);
  return { amount, chargeableMinutes: Math.ceil(chargeableMinutes), exactChargeableMinutes: chargeableMinutes, hourlyRate, packages };
}

function canManageStations(req) {
  return req.user?.role === 'OWNER' || req.user?.role === 'MANAGER';
}

function normalizeStationPayload(body) {
  const name = String(body.name || '').trim();
  const consoleType = String(body.consoleType || body.console_type || '').trim();
  const hourlyRate = Number(body.hourlyRate ?? body.hourly_rate ?? 0);
  const sortOrder = Number.parseInt(String(body.sortOrder ?? body.sort_order ?? 0), 10);
  const status = String(body.status || 'AVAILABLE').toUpperCase();

  if (!name) {
    const error = new Error('Nombre requerido');
    error.status = 400;
    throw error;
  }

  if (!ALLOWED_CONSOLES.includes(consoleType)) {
    const error = new Error('Modelo inválido');
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(hourlyRate) || hourlyRate < 0) {
    const error = new Error('Precio inválido');
    error.status = 400;
    throw error;
  }

  if (!ALLOWED_STATION_STATUS.includes(status)) {
    const error = new Error('Estado inválido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    consoleType,
    hourlyRate: Number(hourlyRate.toFixed(2)),
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    status
  };
}

function getMembershipTier(product) {
  const planCode = String(product.membership_plan_code || '').trim().toUpperCase();
  if (planCode) return planCode;

  const sku = String(product.sku || '').toUpperCase();
  const name = String(product.name || '').toUpperCase();

  if (sku.includes('CHAMPION') || name.includes('CHAMPION')) return 'CHAMPION';
  if (sku.includes('GAMER-PRO') || sku.includes('GAMER_PRO') || name.includes('GAMER PRO')) return 'GAMER_PRO';
  if (sku.includes('GAMER') || name.includes('GAMER')) return 'GAMER';

  return null;
}


function normalizePaymentMethod(value) {
  const method = String(value || 'CASH').toUpperCase();
  if (!['CASH', 'TRANSFER'].includes(method)) {
    const error = new Error('Método de pago inválido');
    error.status = 400;
    throw error;
  }
  return method;
}




async function getMemberForTournamentDiscount(client, memberId) {
  if (!memberId) return null;
  const { rows } = await client.query('SELECT id, full_name, membership_tier, membership_active FROM members WHERE id = $1 LIMIT 1', [memberId]);
  return rows[0] || null;
}

async function calculateTournamentEntryPrice(client, tournament, memberId, participant = null) {
  const baseAmount = Number(tournament.entry_fee || 0);
  if (participant && participant.entry_fee_amount !== null && participant.entry_fee_amount !== undefined) {
    const storedTotal = Number(participant.entry_fee_amount || 0);
    const storedDiscount = Number(participant.entry_discount_amount || Math.max(0, baseAmount - storedTotal));
    return { baseAmount, total: storedTotal, discountAmount: storedDiscount, discountType: participant.entry_discount_type || 'NONE', label: participant.entry_discount_label || '' };
  }
  const effectiveMemberId = memberId || participant?.member_id || null;
  const member = await getMemberForTournamentDiscount(client, effectiveMemberId);
  if (!member?.membership_active || !member.membership_tier) {
    return { baseAmount, total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  }
  const tier = String(member.membership_tier || '').toUpperCase();
  const { rows } = await client.query('SELECT * FROM tournament_entry_discounts WHERE membership_tier = $1 AND is_active = true LIMIT 1', [tier]);
  const rule = rows[0];
  if (!rule || rule.discount_type === 'NONE') return { baseAmount, total: baseAmount, discountAmount: 0, discountType: 'NONE', label: '' };
  let total = baseAmount;
  if (rule.discount_type === 'PERCENT') total = baseAmount - (baseAmount * Number(rule.discount_value || 0) / 100);
  if (rule.discount_type === 'FIXED_AMOUNT') total = baseAmount - Number(rule.discount_value || 0);
  if (rule.discount_type === 'FREE') total = 0;
  total = Math.max(0, Number(total.toFixed(2)));
  const discountAmount = Math.max(0, Number((baseAmount - total).toFixed(2)));
  const label = rule.discount_type === 'FREE' ? `${tier} gratis` : rule.discount_type === 'PERCENT' ? `${tier} ${Number(rule.discount_value || 0)}%` : `${tier} -RD$${Number(rule.discount_value || 0).toFixed(2)}`;
  return { baseAmount, total, discountAmount, discountType: rule.discount_type, label };
}

function normalizeTournamentEntryList(value) {
  return Array.isArray(value) ? value : [];
}

async function buildTournamentEntryLines(client, tournamentEntries = []) {
  const safeEntries = normalizeTournamentEntryList(tournamentEntries);
  const lines = [];

  for (const entry of safeEntries) {
    const tournamentId = entry.tournamentId || entry.tournament_id;
    if (!tournamentId) {
      const error = new Error('Torneo requerido');
      error.status = 400;
      throw error;
    }

    const tournamentResult = await client.query('SELECT * FROM tournaments WHERE id = $1 FOR UPDATE', [tournamentId]);
    if (tournamentResult.rowCount === 0) {
      const error = new Error('Torneo no encontrado');
      error.status = 404;
      throw error;
    }

    const tournament = tournamentResult.rows[0];
    if (!['SCHEDULED', 'ACTIVE'].includes(tournament.status)) {
      const error = new Error('Este torneo no acepta inscripción');
      error.status = 409;
      throw error;
    }

    const entryFee = Number(tournament.entry_fee || 0);
    let participant = null;
    const participantId = entry.participantId || entry.participant_id;

    if (participantId) {
      const participantResult = await client.query(
        `SELECT * FROM tournament_participants WHERE id = $1 AND tournament_id = $2 FOR UPDATE`,
        [participantId, tournamentId]
      );
      if (participantResult.rowCount === 0) {
        const error = new Error('Participante no encontrado');
        error.status = 404;
        throw error;
      }
      participant = participantResult.rows[0];
      if (participant.is_paid) {
        const error = new Error('Ese participante ya pagó inscripción');
        error.status = 409;
        throw error;
      }
      if (participant.payment_status === 'EXPIRED') {
        const error = new Error('Inscripción vencida. Requiere autorización admin.');
        error.status = 409;
        throw error;
      }
    } else {
      const playerName = String(entry.playerName || entry.player_name || '').trim();
      if (!playerName) {
        const error = new Error('Nombre del participante requerido');
        error.status = 400;
        throw error;
      }
      const count = await client.query(
        `SELECT COUNT(*)::int AS total
         FROM tournament_participants
         WHERE tournament_id = $1
           AND COALESCE(payment_status, CASE WHEN is_paid THEN 'PAID' ELSE 'PENDING' END) <> 'CANCELLED'`,
        [tournamentId]
      );
      if (tournament.max_players && Number(count.rows[0].total || 0) >= Number(tournament.max_players)) {
        const error = new Error('El torneo llegó al máximo de jugadores');
        error.status = 409;
        throw error;
      }
      const pricing = await calculateTournamentEntryPrice(client, tournament, entry.memberId || entry.member_id || null, null);
      const created = await client.query(
        `INSERT INTO tournament_participants (tournament_id, member_id, player_name, phone, nickname, payment_deadline_at, payment_status, entry_fee_amount, entry_discount_amount, entry_discount_type, entry_discount_label)
         VALUES ($1, $2, $3, $4, $5, $6, 'PENDING', $7, $8, $9, $10)
         RETURNING *`,
        [tournamentId, entry.memberId || entry.member_id || null, playerName, String(entry.phone || '').trim() || null, String(entry.nickname || '').trim() || null, tournament.payment_deadline_at || null, pricing.total, pricing.discountAmount, pricing.discountType, pricing.label]
      );
      participant = created.rows[0];
    }

    const pricing = await calculateTournamentEntryPrice(client, tournament, entry.memberId || entry.member_id || participant.member_id || null, participant);
    lines.push({
      tournament,
      participant,
      unitPrice: pricing.baseAmount,
      total: pricing.total,
      discountAmount: pricing.discountAmount,
      description: `Inscripción torneo · ${tournament.name} · ${participant.player_name}${pricing.label ? ' · ' + pricing.label : ''}`
    });
  }

  return lines;
}

async function insertTournamentEntrySaleLines(client, { saleId, lines, userId }) {
  for (const line of lines || []) {
    await client.query(
      `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
       VALUES ($1, NULL, 'TOURNAMENT_ENTRY', $2, 1, $3, $4)`,
      [saleId, line.description, line.unitPrice, line.total]
    );
    await client.query(
      `UPDATE tournament_participants
       SET is_paid = true, payment_status = 'PAID', paid_at = NOW(), paid_by_user_id = $3, sale_id = $4, updated_at = NOW()
       WHERE id = $1 AND tournament_id = $2`,
      [line.participant.id, line.tournament.id, userId, saleId]
    );
    await logAuditEvent(client, {
      eventType: 'TOURNAMENT_ENTRY_SOLD',
      userId,
      entityType: 'tournament_participant',
      entityId: line.participant.id,
      saleId,
      tournamentId: line.tournament.id,
      metadata: { playerName: line.participant.player_name, amount: Number(line.total || 0), source: 'station' }
    });
  }
}

function normalizePlayerCount(value) {
  const playerCount = Number.parseInt(String(value || 1), 10);
  return playerCount === 2 ? 2 : 1;
}

function normalizeReservationPlayerCount(value) {
  const playerCount = Number.parseInt(String(value || 1), 10);
  if (!Number.isFinite(playerCount) || playerCount < 1) return 1;
  return Math.min(20, playerCount);
}

function buildSaleNotes(paymentMethod, paymentReference, baseNote = '') {
  const reference = String(paymentReference || '').trim();
  if (paymentMethod !== 'TRANSFER') return baseNote || null;
  const transferNote = reference ? `Transferencia Felicia: ${reference}` : 'Transferencia Felicia confirmada';
  return baseNote ? `${baseNote} · ${transferNote}` : transferNote;
}

function getMembershipTierLabel(tier) {
  if (tier === 'GAMER') return 'Gamer';
  if (tier === 'GAMER_PRO') return 'Gamer Pro';
  if (tier === 'CHAMPION') return 'Champion';
  return tier ? String(tier).replace(/_/g, ' ') : 'General';
}


function normalizeModifierOptionIds(value) {
  const source = Array.isArray(value) ? value : [];
  return [...new Set(source.map((item) => String(item || '').trim()).filter(Boolean))];
}

async function resolveProductModifiers(client, productId, modifierOptionIds = []) {
  const selectedIds = normalizeModifierOptionIds(modifierOptionIds);

  const groupsResult = await client.query(
    `SELECT pmg.*
     FROM product_modifier_assignments pma
     JOIN product_modifier_groups pmg ON pmg.id = pma.group_id
     WHERE pma.product_id = $1
       AND pmg.is_active = true
     ORDER BY pma.sort_order, pmg.sort_order, pmg.name`,
    [productId]
  ).catch(() => ({ rows: [] }));

  const groups = groupsResult.rows || [];
  if (!groups.length) return { modifiers: [], priceDelta: 0, descriptionSuffix: '' };

  const optionsResult = await client.query(
    `SELECT pmo.*, pmg.name AS group_name, pmg.is_required, pmg.allow_multiple
     FROM product_modifier_options pmo
     JOIN product_modifier_groups pmg ON pmg.id = pmo.group_id
     JOIN product_modifier_assignments pma ON pma.group_id = pmg.id AND pma.product_id = $1
     WHERE pmo.is_active = true
       AND pmg.is_active = true
     ORDER BY pmg.sort_order, pmo.sort_order, pmo.name`,
    [productId]
  ).catch(() => ({ rows: [] }));

  const options = optionsResult.rows || [];
  const selected = selectedIds.length
    ? options.filter((option) => selectedIds.includes(String(option.id)))
    : [];

  if (selected.length !== selectedIds.length) {
    const error = new Error('Modificador inválido para este producto');
    error.status = 400;
    throw error;
  }

  for (const group of groups) {
    const groupOptions = options.filter((option) => String(option.group_id) === String(group.id));
    if (!groupOptions.length) continue;
    const selectedForGroup = selected.filter((option) => String(option.group_id) === String(group.id));
    if (group.is_required && selectedForGroup.length === 0) {
      const error = new Error(`Selecciona ${group.name}`);
      error.status = 400;
      throw error;
    }
    if (!group.allow_multiple && selectedForGroup.length > 1) {
      const error = new Error(`Solo una opción en ${group.name}`);
      error.status = 400;
      throw error;
    }
  }

  const modifiers = selected.map((option) => ({
    groupId: option.group_id,
    groupName: option.group_name,
    optionId: option.id,
    optionName: option.name,
    priceDelta: Number(option.price_delta || 0)
  }));
  const priceDelta = modifiers.reduce((sum, modifier) => sum + Number(modifier.priceDelta || 0), 0);
  const descriptionSuffix = modifiers.length ? ` (${modifiers.map((modifier) => modifier.optionName).join(', ')})` : '';

  return { modifiers, priceDelta, descriptionSuffix };
}

async function ensureOpenDrawer(client) {
  try {
    const settings = await client.query(`SELECT value FROM app_settings WHERE key = 'drawer_workflow_enabled' LIMIT 1`);
    if (settings.rowCount && normalizeBooleanSetting(settings.rows[0].value, true) === false) return;
  } catch (error) {
    if (error.code !== '42P01') throw error;
  }

  const { rowCount } = await client.query(`SELECT id FROM cash_drawers WHERE status = 'OPEN' LIMIT 1`);
  if (rowCount === 0) {
    const error = new Error('Debes abrir la caja antes de iniciar ventas.');
    error.status = 409;
    throw error;
  }
}


async function deductInventoryForLine(client, line, userId, saleId) {
  const product = line.product;
  const quantity = Number(line.quantity || 1);

  if (product.is_combo) {
    const componentResult = await client.query(
      `SELECT pcc.quantity AS component_qty, p.*
       FROM product_combo_components pcc
       JOIN products p ON p.id = pcc.component_product_id
       WHERE pcc.combo_product_id = $1`,
      [product.id]
    );

    if (componentResult.rowCount > 0) {
      for (const component of componentResult.rows) {
        if (!component.track_stock) continue;

        const requiredQty = Math.max(1, Number(component.component_qty || 1)) * quantity;
        const lockedResult = await client.query(`SELECT * FROM products WHERE id = $1 FOR UPDATE`, [component.id]);
        const locked = lockedResult.rows[0];
        const before = Number(locked.stock_qty || 0);
        const after = before - requiredQty;

        if (after < 0) {
          const error = new Error(`Inventario insuficiente para ${locked.name}`);
          error.status = 409;
          throw error;
        }

        await client.query(`UPDATE products SET stock_qty = $2, updated_at = NOW() WHERE id = $1`, [component.id, after]);
        await client.query(
          `INSERT INTO inventory_movements (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reference_id, reason)
           VALUES ($1, $2, 'COMBO_COMPONENT', $3, $4, $5, 'SALE', $6, $7)`,
          [component.id, userId, -requiredQty, before, after, saleId, `Combo ${product.name}`]
        );
      }
      return;
    }
  }

  if (!product.track_stock) return;

  const lockedResult = await client.query(`SELECT * FROM products WHERE id = $1 FOR UPDATE`, [product.id]);
  const locked = lockedResult.rows[0];
  const before = Number(locked.stock_qty || 0);
  const after = before - quantity;

  if (after < 0) {
    const error = new Error(`Inventario insuficiente para ${locked.name}`);
    error.status = 409;
    throw error;
  }

  await client.query(`UPDATE products SET stock_qty = $2, updated_at = NOW() WHERE id = $1`, [product.id, after]);
  await client.query(
    `INSERT INTO inventory_movements (product_id, user_id, movement_type, quantity_change, quantity_before, quantity_after, reference_type, reference_id, reason)
     VALUES ($1, $2, 'SALE', $3, $4, $5, 'SALE', $6, $7)`,
    [product.id, userId, -quantity, before, after, saleId, product.name]
  );
}


async function getActiveBonusRule(client, ruleKey) {
  const { rows } = await client.query(
    `SELECT *
     FROM bonus_rules
     WHERE rule_key = $1
       AND is_active = true
     LIMIT 1`,
    [ruleKey]
  );

  return rows[0] || null;
}

function tierMatchesRule(rule, member) {
  if (!rule || rule.applies_to_tier === 'ALL') return true;
  if (rule.applies_to_tier === 'GENERAL') return !member?.membership_active;
  if (rule.applies_to_tier === 'PAID_MEMBERS') return Boolean(member?.membership_active);
  return member?.membership_active && member?.membership_tier === rule.applies_to_tier;
}

async function getValidWelcomeBonus(client, memberId, welcomeBonusId) {
  if (!memberId || !welcomeBonusId) return null;

  const bonusResult = await client.query(
    `SELECT *
     FROM member_bonuses
     WHERE id = $1
       AND member_id = $2
       AND bonus_type = 'WELCOME_MEMBERSHIP'
       AND status = 'AVAILABLE'
       AND expires_at >= NOW()
     LIMIT 1`,
    [welcomeBonusId, memberId]
  );

  if (bonusResult.rowCount === 0) {
    const error = new Error('Bono no disponible');
    error.status = 409;
    throw error;
  }

  return bonusResult.rows[0];
}

async function getValidVisitReward(client, memberId, visitRewardId) {
  if (!memberId || !visitRewardId) return null;

  const rewardResult = await client.query(
    `SELECT *
     FROM member_rewards
     WHERE id = $1
       AND member_id = $2
       AND reward_type IN ('VISIT_REWARD', 'MANUAL', 'MANUAL_BONUS', 'PURCHASE_BONUS', 'TOURNAMENT_PRIZE', 'POINT_REDEMPTION')
       AND status = 'AVAILABLE'
       AND expires_at >= NOW()
       AND (reward_minutes > COALESCE(used_reward_minutes, 0)
         OR prize_snack_qty > COALESCE(used_prize_snack_qty, 0)
         OR prize_drink_qty > COALESCE(used_prize_drink_qty, 0)
         OR prize_product_qty > COALESCE(used_prize_product_qty, 0))
     LIMIT 1`,
    [visitRewardId, memberId]
  );

  if (rewardResult.rowCount === 0) {
    const error = new Error('Recompensa no disponible');
    error.status = 409;
    throw error;
  }

  return rewardResult.rows[0];
}

async function createVisitRewardIfEligible(client, memberId, sessionId, playedMinutes = 0) {
  if (!memberId) return null;

  const memberInfo = await client.query(
    `SELECT id, membership_tier, membership_active
     FROM members
     WHERE id = $1`,
    [memberId]
  );
  if (!memberInfo.rows[0]) return null;

  const visitSourceKey = `visit:${sessionId || memberId}:member:${memberId}:points`;
  const existingVisit = await client.query(
    `SELECT id FROM member_points_ledger WHERE source_key = $1 LIMIT 1`,
    [visitSourceKey]
  );

  let visitCount = Number(memberInfo.rows[0]?.visit_count || 0);
  if (existingVisit.rowCount === 0) {
    const memberResult = await client.query(
      `UPDATE members
       SET visit_count = COALESCE(visit_count, 0) + 1,
           reward_points = COALESCE(reward_points, 0) + 1,
           updated_at = NOW()
       WHERE id = $1
       RETURNING visit_count`,
      [memberId]
    );
    visitCount = Number(memberResult.rows[0]?.visit_count || 0);

    await recordMemberPointMovement(client, {
      memberId,
      points: 1,
      category: 'VISIT',
      reason: '1 punto por visita/sesión de juego',
      affectsRanking: false,
      referenceType: 'SESSION',
      referenceId: sessionId || null,
      sourceKey: visitSourceKey,
      userId: null
    });
  }

  const rule = await getActiveBonusRule(client, 'VISIT_REWARD');
  if (!rule || Number(rule.required_visits || 0) <= 0 || Number(rule.reward_minutes || 0) <= 0) return null;

  if (!tierMatchesRule(rule, memberInfo.rows[0])) return null;

  const minimumMinutes = Number(rule.min_game_minutes || 0);
  if (minimumMinutes > 0 && Number(playedMinutes || 0) < minimumMinutes) return null;

  const requiredVisits = Number(rule.required_visits || 0);
  if (visitCount <= 0 || requiredVisits <= 0 || visitCount % requiredVisits !== 0) return null;

  const rewardResult = await client.query(
    `INSERT INTO member_rewards (member_id, source_session_id, reward_type, reward_minutes, status, expires_at, source_rule_id)
     VALUES ($1, $2, 'VISIT_REWARD', $3, 'AVAILABLE', NOW() + ($4 || ' days')::interval, $5)
     ON CONFLICT DO NOTHING
     RETURNING *`,
    [memberId, sessionId, Number(rule.reward_minutes || 0), Number(rule.expires_days || 0), rule.id]
  );

  return rewardResult.rows[0] || null;
}




function normalizeGameDevicePayload(body = {}) {
  const name = String(body.name || '').trim();
  const deviceType = String(body.deviceType || body.device_type || 'SSD externo').trim();
  const platform = String(body.platform || 'Multiplataforma').trim() || 'Multiplataforma';
  const notes = String(body.notes || '').trim();
  const isActive = body.isActive ?? body.is_active ?? true;

  if (!name) {
    const error = new Error('Nombre del dispositivo requerido');
    error.status = 400;
    throw error;
  }
  if (!ALLOWED_GAME_DEVICE_TYPES.includes(deviceType)) {
    const error = new Error('Tipo de dispositivo inválido');
    error.status = 400;
    throw error;
  }

  return { name, deviceType, platform, notes: notes || null, isActive: Boolean(isActive) };
}

function normalizeGameLocationsPayload(value = []) {
  const rawLocations = Array.isArray(value) ? value : [];
  return rawLocations
    .map((item) => {
      const locationType = String(item.locationType || item.location_type || 'No instalado').trim();
      const status = String(item.status || 'Disponible').trim();
      const stationId = String(item.stationId || item.station_id || '').trim();
      const deviceId = String(item.deviceId || item.device_id || '').trim();
      const quantity = Number.parseInt(String(item.quantity || 1), 10);
      const accountLabel = String(item.accountLabel || item.account_label || '').trim();
      const notes = String(item.notes || '').trim();

      if (!ALLOWED_GAME_LOCATION_TYPES.includes(locationType)) return null;
      if (!ALLOWED_GAME_LOCATION_STATUSES.includes(status)) return null;

      return {
        locationType,
        status,
        stationId: stationId || null,
        deviceId: deviceId || null,
        quantity: Number.isFinite(quantity) && quantity > 0 ? quantity : 1,
        accountLabel: accountLabel || null,
        notes: notes || null
      };
    })
    .filter(Boolean);
}

async function replaceGameLocations(client, gameId, locations = []) {
  await client.query('DELETE FROM station_game_locations WHERE game_id = $1', [gameId]);
  for (const location of locations) {
    await client.query(
      `INSERT INTO station_game_locations (game_id, location_type, station_id, device_id, quantity, account_label, status, notes, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)`,
      [gameId, location.locationType, location.stationId, location.deviceId, location.quantity, location.accountLabel, location.status, location.notes]
    );
  }
}

function normalizeStationGamePayload(body = {}) {
  const name = String(body.name || '').trim();
  const platform = String(body.platform || 'Multiplataforma').trim() || 'Multiplataforma';
  const coverUrl = String(body.coverUrl || body.cover_url || '').trim();
  const sortOrder = Number.parseInt(String(body.sortOrder ?? body.sort_order ?? 0), 10);
  const isActive = body.isActive ?? body.is_active ?? true;
  const isStoryMode = body.isStoryMode ?? body.is_story_mode ?? false;
  const requiresProfileAlert = body.requiresProfileAlert ?? body.requires_profile_alert ?? false;
  const isFeatured = body.isFeatured ?? body.is_featured ?? false;
  const highlightType = String(body.highlightType || body.highlight_type || (isFeatured ? 'DESTACADO' : 'NORMAL')).trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_') || 'NORMAL';
  const priorityEnabled = Boolean(body.priorityEnabled ?? body.priority_enabled ?? false);
  const compatibleConsoles = normalizeGameCompatibility(body.compatibleConsoles || body.compatible_consoles, platform);
  const unlimitedCopies = body.unlimitedCopies ?? body.unlimited_copies ?? true;
  const copyQuantity = Number.parseInt(String(body.copyQuantity ?? body.copy_quantity ?? 1), 10);
  const allowsExtraControllers = normalizeBooleanSetting(body.allowsExtraControllers ?? body.allows_extra_controllers ?? false, false);
  const maxExtraControllersRaw = Number.parseInt(String(body.maxExtraControllers ?? body.max_extra_controllers ?? 2), 10);
  const extraControllerPriceRaw = Number(body.extraControllerPrice ?? body.extra_controller_price ?? 0);

  if (!name) {
    const error = new Error('Nombre del juego requerido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    platform,
    coverUrl: coverUrl || null,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    isActive: Boolean(isActive),
    isStoryMode: Boolean(isStoryMode),
    requiresProfileAlert: Boolean(requiresProfileAlert),
    isFeatured: Boolean(isFeatured) || highlightType !== 'NORMAL',
    highlightType,
    priorityEnabled,
    compatibleConsoles,
    unlimitedCopies: Boolean(unlimitedCopies),
    copyQuantity: Number.isFinite(copyQuantity) && copyQuantity > 0 ? copyQuantity : 1,
    allowsExtraControllers,
    maxExtraControllers: Number.isFinite(maxExtraControllersRaw) ? Math.max(0, Math.min(4, maxExtraControllersRaw)) : 2,
    extraControllerPrice: Number.isFinite(extraControllerPriceRaw) && extraControllerPriceRaw >= 0 ? Number(extraControllerPriceRaw.toFixed(2)) : 0,
    locations: normalizeGameLocationsPayload(body.locations || body.gameLocations || body.game_locations || [])
  };
}

async function getActiveStationGame(client, gameId) {
  if (!gameId) return null;
  const { rows } = await client.query(
    `SELECT * FROM station_games WHERE id = $1 AND is_active = true LIMIT 1`,
    [gameId]
  );
  return rows[0] || null;
}

function buildExtraControllerLine({ station, game, playerCount = 1, extraControllerCount = 0 } = {}) {
  const requested = Math.max(0, Math.floor(Number(extraControllerCount || 0)));
  if (!requested) return null;
  if (!station || !game) return null;
  if (String(station.console_type || '').trim() !== 'Nintendo Switch') {
    const error = new Error('Los controles extra solo aplican para Nintendo Switch');
    error.status = 400;
    throw error;
  }
  if (normalizePlayerCount(playerCount) !== 2) {
    const error = new Error('Selecciona 2 jugadores para agregar controles extra');
    error.status = 400;
    throw error;
  }
  if (game.allows_extra_controllers !== true) {
    const error = new Error('Este juego no permite controles extra');
    error.status = 400;
    throw error;
  }
  const max = Math.max(0, Math.min(4, Number(game.max_extra_controllers || 2)));
  const quantity = Math.min(requested, max);
  if (quantity <= 0) return null;
  const unitPrice = Math.max(0, Number(game.extra_controller_price || 0));
  return {
    quantity,
    unitPrice,
    total: Number((quantity * unitPrice).toFixed(2)),
    label: quantity === 1 ? 'Control extra' : 'Controles extra',
    playerTotal: 2 + quantity
  };
}


function normalizeFamilyDiscountCodeInput(value = '') {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 20);
}

async function getValidFamilyDiscountCode(client, codeValue, { lock = false } = {}) {
  const code = normalizeFamilyDiscountCodeInput(codeValue);
  if (!code) return null;
  if (code.length < 4) {
    const error = new Error('Código de descuento inválido');
    error.status = 400;
    throw error;
  }
  const { rows } = await client.query(
    `SELECT id, code, discount_percent, applies_to, max_uses, used_count, is_active, expires_at, note
     FROM family_discount_codes
     WHERE code = $1
     ORDER BY created_at DESC
     LIMIT 1
     ${lock ? 'FOR UPDATE' : ''}`,
    [code]
  );
  const record = rows[0];
  if (!record) {
    const error = new Error('Código de descuento no encontrado');
    error.status = 404;
    throw error;
  }
  if (record.is_active !== true) {
    const error = new Error('Código de descuento inactivo');
    error.status = 403;
    throw error;
  }
  if (new Date(record.expires_at).getTime() <= Date.now()) {
    const error = new Error('Código de descuento vencido');
    error.status = 403;
    throw error;
  }
  if (Number(record.used_count || 0) >= Number(record.max_uses || 1)) {
    const error = new Error('Código de descuento ya alcanzó su límite de uso');
    error.status = 403;
    throw error;
  }
  return record;
}

function calculateFamilyDiscountAmount(record, discountableAmount = 0) {
  const base = Math.max(0, Number(discountableAmount || 0));
  const percent = Math.max(0, Math.min(100, Number(record?.discount_percent || 0)));
  return Number((base * percent / 100).toFixed(2));
}

export async function previewFamilyDiscountCode(req, res) {
  try {
    const { code = '', discountableAmount = 0 } = req.body || {};
    const record = await withTransaction(async (client) => getValidFamilyDiscountCode(client, code, { lock: false }));
    const amount = calculateFamilyDiscountAmount(record, discountableAmount);
    res.json({
      discountCode: {
        id: record.id,
        code: record.code,
        discount_percent: Number(record.discount_percent || 0),
        expires_at: record.expires_at,
        note: record.note,
        discount_amount: amount
      }
    });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

async function applyFamilyDiscountCodeToSale(client, { codeValue, userId, saleId, subtotal, discountableAmount, totalAfterDiscount }) {
  const record = await getValidFamilyDiscountCode(client, codeValue, { lock: true });
  const discountAmount = calculateFamilyDiscountAmount(record, discountableAmount);
  if (discountAmount <= 0) {
    const error = new Error('Este código solo aplica a tiempo de juego con monto mayor a RD$0');
    error.status = 400;
    throw error;
  }
  await client.query(
    `UPDATE family_discount_codes
     SET used_count = used_count + 1,
         updated_at = NOW()
     WHERE id = $1`,
    [record.id]
  );
  await client.query(
    `INSERT INTO family_discount_code_usages
       (code_id, sale_id, user_id, discount_amount, subtotal_before_discount, discountable_amount, total_after_discount)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [record.id, saleId, userId, discountAmount.toFixed(2), Number(subtotal || 0).toFixed(2), Number(discountableAmount || 0).toFixed(2), Number(totalAfterDiscount || 0).toFixed(2)]
  );
  return { record, discountAmount };
}

function normalizeStationExtraPayload(body = {}) {
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim();
  const price = Number(body.price ?? 0);
  const pricingType = String(body.pricingType || body.pricing_type || 'SESSION').toUpperCase();
  const sortOrder = Number.parseInt(String(body.sortOrder ?? body.sort_order ?? 0), 10);
  const isActive = body.isActive ?? body.is_active ?? true;
  const stationIds = Array.isArray(body.stationIds || body.station_ids)
    ? [...new Set((body.stationIds || body.station_ids).map((id) => String(id || '').trim()).filter(Boolean))]
    : [];

  if (!name) {
    const error = new Error('Nombre del extra requerido');
    error.status = 400;
    throw error;
  }
  if (!Number.isFinite(price) || price < 0) {
    const error = new Error('Precio del extra inválido');
    error.status = 400;
    throw error;
  }
  if (!['FIXED', 'HOURLY', 'SESSION'].includes(pricingType)) {
    const error = new Error('Tipo de cobro inválido');
    error.status = 400;
    throw error;
  }

  return {
    name,
    description: description || null,
    price: Number(price.toFixed(2)),
    pricingType,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    isActive: Boolean(isActive),
    stationIds
  };
}


export async function listGameStorageDevices(_req, res) {
  try {
    const { rows } = await query(
      `SELECT *
       FROM game_storage_devices
       ORDER BY is_active DESC, device_type, name`
    );
    res.json({ devices: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function createGameStorageDevice(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const device = normalizeGameDevicePayload(req.body);
    const { rows } = await query(
      `INSERT INTO game_storage_devices (name, device_type, platform, notes, is_active)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [device.name, device.deviceType, device.platform, device.notes, device.isActive]
    );
    res.status(201).json({ device: rows[0] });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateGameStorageDevice(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const { deviceId } = req.params;
    const device = normalizeGameDevicePayload(req.body);
    const { rows } = await query(
      `UPDATE game_storage_devices
       SET name = $2,
           device_type = $3,
           platform = $4,
           notes = $5,
           is_active = $6,
           updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [deviceId, device.name, device.deviceType, device.platform, device.notes, device.isActive]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Dispositivo no encontrado' });
    res.json({ device: rows[0] });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteGameStorageDevice(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const { deviceId } = req.params;
    const { rowCount } = await query(`UPDATE game_storage_devices SET is_active = false, updated_at = NOW() WHERE id = $1`, [deviceId]);
    if (rowCount === 0) return res.status(404).json({ error: 'Dispositivo no encontrado' });
    res.status(204).send();
  } catch (error) {
    return sendControllerError(res, error);
  }
}


function normalizeGameRequestPayload(body = {}) {
  const requestType = String(body.requestType || body.request_type || 'EXISTING').trim().toUpperCase();
  const gameId = String(body.gameId || body.game_id || '').trim();
  const requestedGameName = String(body.requestedGameName || body.requested_game_name || '').trim();
  const platform = String(body.platform || '').trim();
  const stationId = String(body.stationId || body.station_id || '').trim();
  const memberId = String(body.memberId || body.member_id || '').trim();
  const customerName = String(body.customerName || body.customer_name || '').trim();
  const unavailableReason = String(body.unavailableReason || body.unavailable_reason || '').trim();
  const customerDecision = String(body.customerDecision || body.customer_decision || 'SOLO_REGISTRAR').trim().toUpperCase();
  const requestScope = String(body.requestScope || body.request_scope || 'SUGGESTION').trim().toUpperCase();
  const statusInput = String(body.status || '').trim().toUpperCase();
  const estimatedWaitMinutes = Number.parseInt(String(body.estimatedWaitMinutes ?? body.estimated_wait_minutes ?? ''), 10);
  const notes = String(body.notes || '').trim();

  if (!ALLOWED_GAME_REQUEST_TYPES.includes(requestType)) {
    const error = new Error('Tipo de solicitud inválido');
    error.status = 400;
    throw error;
  }
  if (!ALLOWED_GAME_REQUEST_DECISIONS.includes(customerDecision)) {
    const error = new Error('Decisión del cliente inválida');
    error.status = 400;
    throw error;
  }
  if (!ALLOWED_GAME_REQUEST_SCOPES.includes(requestScope)) {
    const error = new Error('Tipo de solicitud inválido');
    error.status = 400;
    throw error;
  }
  if (requestScope === 'OFFICIAL' && !memberId) {
    const error = new Error('La solicitud oficial requiere un miembro seleccionado');
    error.status = 400;
    throw error;
  }
  if (requestType === 'EXISTING' && !gameId) {
    const error = new Error('Selecciona el juego solicitado');
    error.status = 400;
    throw error;
  }
  if (requestType === 'NEW_GAME' && !requestedGameName) {
    const error = new Error('Escribe el juego solicitado');
    error.status = 400;
    throw error;
  }

  const automaticStatus = customerDecision === 'ESPERA' ? 'ESPERANDO' : 'PENDIENTE';
  const status = ALLOWED_GAME_REQUEST_STATUSES.includes(statusInput) ? statusInput : automaticStatus;

  return {
    requestType,
    gameId: gameId || null,
    requestedGameName: requestedGameName || null,
    platform: platform || null,
    stationId: stationId || null,
    memberId: memberId || null,
    customerName: customerName || null,
    unavailableReason: unavailableReason || null,
    customerDecision,
    requestScope,
    status,
    estimatedWaitMinutes: Number.isFinite(estimatedWaitMinutes) && estimatedWaitMinutes > 0 ? estimatedWaitMinutes : null,
    notes: notes || null
  };
}


function normalizeGameReservationPayload(body = {}) {
  const reservationType = String(body.reservationType || body.reservation_type || 'WAITLIST').trim().toUpperCase();
  const status = String(body.status || (reservationType === 'RESERVATION' ? 'RESERVED' : 'WAITING')).trim().toUpperCase();
  const gameId = String(body.gameId || body.game_id || '').trim() || null;
  const stationId = String(body.stationId || body.station_id || '').trim() || null;
  const memberId = String(body.memberId || body.member_id || '').trim() || null;
  const customerName = String(body.customerName || body.customer_name || '').trim();
  const customerPhone = String(body.customerPhone || body.customer_phone || '').trim();
  const platform = String(body.platform || '').trim();
  const desiredStartAt = String(body.desiredStartAt || body.desired_start_at || '').trim() || null;
  const minMinutes = Math.max(0, Number.parseInt(String(body.minMinutes || body.min_minutes || 0), 10) || 0);
  const reservedMinutesInput = Number.parseInt(String(body.reservedMinutes ?? body.reserved_minutes ?? body.minMinutes ?? body.min_minutes ?? 0), 10) || 0;
  const reservedMinutes = Math.max(0, reservedMinutesInput);
  const playerCount = normalizeReservationPlayerCount(body.playerCount ?? body.player_count ?? 1);
  const paidAmount = Math.max(0, Number(body.paidAmount ?? body.paid_amount ?? 0) || 0);
  const paymentMethodRaw = String(body.paymentMethod || body.payment_method || '').trim().toUpperCase();
  const paymentMethod = ALLOWED_GAME_RESERVATION_PAYMENT_METHODS.includes(paymentMethodRaw) ? paymentMethodRaw : (paidAmount > 0 ? 'CASH' : null);
  const paymentReference = String(body.paymentReference || body.payment_reference || '').trim();
  const transferAuthorizationCode = String(body.transferAuthorizationCode || body.transfer_authorization_code || '').trim();
  const priorityLevel = Math.max(0, Number.parseInt(String(body.priorityLevel || body.priority_level || 0), 10) || 0);
  const notes = String(body.notes || '').trim();
  const reservationScopeRaw = String(body.reservationScope || body.reservation_scope || 'STANDARD').trim().toUpperCase();
  const reservationScope = reservationScopeRaw === 'GROUP_EVENT' ? 'GROUP_EVENT' : 'STANDARD';
  const groupEventPriceId = String(body.groupEventPriceId || body.group_event_price_id || '').trim() || null;
  const stationCount = Math.max(1, Number.parseInt(String(body.stationCount || body.station_count || 1), 10) || 1);
  const isFullClub = body.isFullClub === true || body.is_full_club === true || String(body.isFullClub || body.is_full_club || '').toLowerCase() === 'true';

  if (!ALLOWED_GAME_RESERVATION_TYPES.includes(reservationType)) {
    const error = new Error('Tipo de reserva inválido');
    error.status = 400;
    throw error;
  }
  if (!ALLOWED_GAME_RESERVATION_STATUSES.includes(status)) {
    const error = new Error('Estado de reserva inválido');
    error.status = 400;
    throw error;
  }
  if (!gameId && !customerName) {
    const error = new Error('Selecciona un juego o escribe el cliente');
    error.status = 400;
    throw error;
  }
  if (reservationType === 'RESERVATION') {
    if (!desiredStartAt) {
      const error = new Error('La reserva necesita fecha y hora');
      error.status = 400;
      throw error;
    }
    if (reservedMinutes <= 0 && minMinutes <= 0) {
      const error = new Error('La reserva necesita tiempo reservado');
      error.status = 400;
      throw error;
    }
  }
  return { reservationType, status, gameId, stationId, memberId, customerName, customerPhone, platform, desiredStartAt, minMinutes, reservedMinutes: reservedMinutes || minMinutes, playerCount, paidAmount, paymentMethod, paymentReference, transferAuthorizationCode, priorityLevel, notes, reservationScope, groupEventPriceId, stationCount, isFullClub };
}

async function getReservationGameAvailability(client, gameId) {
  if (!gameId) return { game: null, stationIds: null, genericAvailable: false };
  const { rows } = await client.query(`SELECT * FROM station_games WHERE id = $1 AND is_active = true LIMIT 1`, [gameId]);
  const game = rows[0] || null;
  if (!game) return { game: null, stationIds: null, genericAvailable: false };
  const locationsResult = await client.query(
    `SELECT sgl.*, s.console_type AS station_console_type, gsd.platform AS device_platform
     FROM station_game_locations sgl
     LEFT JOIN stations s ON s.id = sgl.station_id
     LEFT JOIN game_storage_devices gsd ON gsd.id = sgl.device_id
     WHERE sgl.game_id = $1
       AND sgl.is_active = true
       AND LOWER(COALESCE(sgl.status, '')) <> 'no instalado'`,
    [gameId]
  );
  const stationIds = locationsResult.rows.map((row) => row.station_id).filter(Boolean);
  const genericAvailable = locationsResult.rows.some((row) => !row.station_id && String(row.location_type || '').toLowerCase() !== 'no instalado');
  return {
    game,
    stationIds: stationIds.length ? new Set(stationIds.map(String)) : null,
    genericAvailable
  };
}

async function getReservationCandidateStations(client, payload) {
  const availability = await getReservationGameAvailability(client, payload.gameId);
  const game = availability.game;

  if (payload.stationId) {
    const { rows } = await client.query(`SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL LIMIT 1`, [payload.stationId]);
    const station = rows[0];
    if (!station) {
      const error = new Error('Estación no encontrada');
      error.status = 404;
      throw error;
    }
    if (payload.platform && station.console_type !== payload.platform) {
      const error = new Error('La estación no coincide con la plataforma seleccionada');
      error.status = 400;
      throw error;
    }
    if (game && !isGameCompatibleWithConsole(game, station.console_type)) {
      const error = new Error('Ese juego no es compatible con esa estación');
      error.status = 400;
      throw error;
    }
    if (availability.stationIds && !availability.stationIds.has(String(station.id))) {
      const error = new Error('Ese juego no está disponible en la estación seleccionada');
      error.status = 400;
      throw error;
    }
    return rows;
  }

  const { rows } = await client.query(
    `SELECT *
     FROM stations
     WHERE deleted_at IS NULL
       AND status <> 'OFFLINE'
     ORDER BY sort_order, name`
  );

  return rows.filter((station) => {
    if (payload.platform && station.console_type !== payload.platform) return false;
    if (game && !isGameCompatibleWithConsole(game, station.console_type)) return false;
    if (availability.stationIds && !availability.stationIds.has(String(station.id))) return false;
    return true;
  });
}

async function getWaitlistAvailability(client, reservation = {}) {
  const payload = {
    gameId: reservation.game_id || null,
    stationId: reservation.station_id || reservation.blocked_station_id || null,
    platform: reservation.platform || '',
    reservationType: 'WAITLIST'
  };

  let candidates = [];
  try {
    candidates = await getReservationCandidateStations(client, payload);
  } catch (error) {
    return {
      available: false,
      stationId: null,
      stationName: null,
      message: error.message || 'No hay estación compatible disponible'
    };
  }

  const availableStations = candidates.filter((station) => String(station.status || '').toUpperCase() === 'AVAILABLE');
  if (!availableStations.length) {
    return {
      available: false,
      stationId: null,
      stationName: null,
      message: 'Estación/juego todavía ocupado'
    };
  }

  if (reservation.game_id) {
    const gameResult = await client.query(
      `SELECT id, name, platform, compatible_consoles, unlimited_copies, copy_quantity
       FROM station_games
       WHERE id = $1 AND is_active = true
       LIMIT 1`,
      [reservation.game_id]
    );
    const game = gameResult.rows[0] || null;
    if (!game) {
      return { available: false, stationId: null, stationName: null, message: 'Juego no disponible en catálogo' };
    }
    if (game.unlimited_copies !== true) {
      const activeCount = await getActiveGameUsage(client, game.id);
      const copies = Math.max(0, Number(game.copy_quantity || 0));
      if (copies <= 0 || activeCount >= copies) {
        return {
          available: false,
          stationId: null,
          stationName: null,
          message: 'El juego sigue ocupado o sin copia libre'
        };
      }
    }
  }

  const station = availableStations[0];
  return {
    available: true,
    stationId: station.id,
    stationName: station.name,
    message: `${station.name || 'Estación disponible'} lista para asignar`
  };
}

function formatReservationConflictTime(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return 'la hora reservada';
  return date.toLocaleTimeString('es-DO', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function getSessionExpectedEndReference(session = null) {
  if (!session) return new Date();
  const prepaidMinutes = Math.max(0, Number(session.prepaid_minutes || 0));
  if (prepaidMinutes <= 0 || !session.started_at) return new Date();
  const expected = new Date(new Date(session.started_at).getTime() + prepaidMinutes * 60000);
  if (Number.isNaN(expected.getTime())) return new Date();
  return expected > new Date() ? expected : new Date();
}

async function assertStationReservationWindowAvailable(client, { stationId, addedMinutes = 0, activeSession = null, freeMode = false }) {
  const normalizedMinutes = Math.max(0, Number(addedMinutes || 0));
  const startReference = getSessionExpectedEndReference(activeSession);

  const nextResult = await client.query(
    `SELECT gr.id,
            gr.desired_start_at,
            gr.reserved_minutes,
            gr.customer_name,
            sg.name AS game_name,
            s.name AS station_name
     FROM game_reservations gr
     LEFT JOIN station_games sg ON sg.id = gr.game_id
     LEFT JOIN stations s ON s.id = COALESCE(gr.blocked_station_id, gr.station_id)
     WHERE gr.reservation_type = 'RESERVATION'
       AND gr.status = ANY($2::text[])
       AND COALESCE(gr.blocked_station_id, gr.station_id) = $1
       AND gr.desired_start_at > NOW()
     ORDER BY gr.desired_start_at ASC
     LIMIT 1`,
    [stationId, ACTIVE_BLOCKING_RESERVATION_STATUSES]
  );

  const nextReservation = nextResult.rows[0];
  if (!nextReservation) return null;

  const reservationStart = new Date(nextReservation.desired_start_at);
  const availableMinutes = Math.max(0, Math.floor((reservationStart.getTime() - startReference.getTime()) / 60000));
  const proposedEnd = new Date(startReference.getTime() + normalizedMinutes * 60000);
  const blocksFixedTime = normalizedMinutes > 0 && proposedEnd > reservationStart;
  const blocksFreeMode = freeMode === true && reservationStart > new Date();

  if (!blocksFixedTime && !blocksFreeMode) {
    return { nextReservation, availableMinutes };
  }

  const gameText = nextReservation.game_name ? ` para ${nextReservation.game_name}` : '';
  const timeText = formatReservationConflictTime(reservationStart);
  const maxText = availableMinutes > 0 ? `Puedes vender máximo ${availableMinutes} minutos.` : 'No queda tiempo disponible antes de la reserva.';
  const error = new Error(`${nextReservation.station_name || 'Esta estación'} tiene una reserva${gameText} a las ${timeText}. ${maxText}`);
  error.status = 409;
  throw error;
}

async function findReservationStationConflict(client, { stationId, startAt, endAt, ignoreReservationId = null }) {
  const activeSession = await client.query(
    `SELECT gs.id, s.name AS station_name,
            GREATEST(
              COALESCE(gs.scheduled_end_at, '-infinity'::timestamptz),
              COALESCE(CASE WHEN COALESCE(gs.prepaid_minutes, 0) > 0 THEN gs.started_at + (gs.prepaid_minutes || ' minutes')::INTERVAL ELSE NULL END, '-infinity'::timestamptz)
            ) AS expected_end_at
     FROM game_sessions gs
     LEFT JOIN stations s ON s.id = gs.station_id
     WHERE gs.station_id = $1
       AND gs.status = 'ACTIVE'
       AND gs.started_at < $3::timestamptz
       AND CASE
             WHEN COALESCE(gs.prepaid_minutes, 0) <= 0 AND gs.scheduled_end_at IS NULL THEN 'infinity'::timestamptz
             ELSE GREATEST(
               COALESCE(gs.scheduled_end_at, '-infinity'::timestamptz),
               COALESCE(CASE WHEN COALESCE(gs.prepaid_minutes, 0) > 0 THEN gs.started_at + (gs.prepaid_minutes || ' minutes')::INTERVAL ELSE NULL END, '-infinity'::timestamptz)
             )
           END > $2::timestamptz
     LIMIT 1`,
    [stationId, startAt, endAt]
  );
  if (activeSession.rowCount > 0) {
    return { type: 'SESSION', message: `${activeSession.rows[0].station_name || 'La estación'} está ocupada en ese horario` };
  }

  const blockedReservation = await client.query(
    `SELECT gr.id, gr.customer_name, gr.desired_start_at, gr.reserved_end_at, s.name AS station_name
     FROM game_reservations gr
     LEFT JOIN stations s ON s.id = COALESCE(gr.blocked_station_id, gr.station_id)
     WHERE gr.reservation_type = 'RESERVATION'
       AND gr.status = ANY($4)
       AND COALESCE(gr.blocked_station_id, gr.station_id) = $1
       AND ($5::uuid IS NULL OR gr.id <> $5::uuid)
       AND gr.desired_start_at < $3::timestamptz
       AND COALESCE(gr.reserved_end_at, gr.desired_start_at + (GREATEST(COALESCE(gr.reserved_minutes, 0), COALESCE(gr.min_minutes, 0), 15) || ' minutes')::INTERVAL) > $2::timestamptz
     LIMIT 1`,
    [stationId, startAt, endAt, ACTIVE_BLOCKING_RESERVATION_STATUSES, ignoreReservationId]
  );
  if (blockedReservation.rowCount > 0) {
    return { type: 'RESERVATION', message: `${blockedReservation.rows[0].station_name || 'La estación'} ya tiene una reserva en ese horario` };
  }

  return null;
}

async function prepareSmartReservation(client, payload) {
  if (payload.reservationType !== 'RESERVATION') {
    return {
      ...payload,
      reservedStartAt: payload.desiredStartAt,
      reservedEndAt: null,
      estimatedTotalAmount: 0,
      requiredDepositAmount: 0,
      paymentStatus: 'NO_REQUIERE',
      blockedStationId: payload.stationId,
      blockReason: null
    };
  }

  let groupEventRule = null;
  if (payload.reservationScope === 'GROUP_EVENT') {
    if (!payload.groupEventPriceId) {
      const error = new Error('Selecciona un precio grupal configurado');
      error.status = 400;
      throw error;
    }
    const groupResult = await client.query(
      `SELECT *
       FROM reservation_group_event_prices
       WHERE id = $1 AND is_active = true
       LIMIT 1`,
      [payload.groupEventPriceId]
    );
    groupEventRule = groupResult.rows[0] || null;
    if (!groupEventRule) {
      const error = new Error('El precio grupal seleccionado no está activo');
      error.status = 400;
      throw error;
    }
    payload.reservedMinutes = Number(groupEventRule.duration_minutes || payload.reservedMinutes || payload.minMinutes || 0);
    payload.minMinutes = payload.reservedMinutes;
  }

  const reservedMinutes = Math.max(15, Number(payload.reservedMinutes || payload.minMinutes || 0));
  const candidates = await getReservationCandidateStations(client, payload);
  if (!candidates.length) {
    const error = new Error('No hay estaciones compatibles para esa reserva');
    error.status = 409;
    throw error;
  }

  const startAt = payload.desiredStartAt;
  const endAt = new Date(new Date(startAt).getTime() + reservedMinutes * 60000).toISOString();
  let selectedStation = null;
  let lastConflict = null;
  for (const station of candidates) {
    const conflict = await findReservationStationConflict(client, { stationId: station.id, startAt, endAt });
    if (!conflict) {
      selectedStation = station;
      break;
    }
    lastConflict = conflict;
  }

  if (!selectedStation) {
    const error = new Error(lastConflict?.message || 'Ese horario ya está ocupado');
    error.status = 409;
    throw error;
  }

  let estimatedTotalAmount = 0;
  let requiredDepositAmount = 0;

  if (payload.reservationScope === 'GROUP_EVENT') {
    if (payload.playerCount < Number(groupEventRule.min_players || 1)) {
      const error = new Error(`Ese paquete requiere mínimo ${Number(groupEventRule.min_players || 1)} personas`);
      error.status = 400;
      throw error;
    }
    const basePlayers = Number(groupEventRule.min_players || 1);
    const baseStations = groupEventRule.is_full_club ? 0 : Math.max(1, Number(groupEventRule.station_count || 1));
    const requestedStations = groupEventRule.is_full_club ? 0 : Math.max(baseStations, Number(payload.stationCount || baseStations));
    const extraPlayers = Math.max(0, Number(payload.playerCount || 0) - basePlayers);
    const extraStations = groupEventRule.is_full_club ? 0 : Math.max(0, requestedStations - baseStations);
    const extraPlayerAmount = extraPlayers * Number(groupEventRule.extra_player_price || 0);
    const extraStationAmount = extraStations * Number(groupEventRule.extra_station_price || 0);
    estimatedTotalAmount = Number((Number(groupEventRule.price || 0) + extraPlayerAmount + extraStationAmount).toFixed(2));
    payload.stationCount = requestedStations;
    const percentDeposit = estimatedTotalAmount * (Number(groupEventRule.deposit_percent || 0) / 100);
    requiredDepositAmount = Number(Math.max(percentDeposit, Number(groupEventRule.min_deposit_amount || 0)).toFixed(2));
  } else {
    const pricePlayerCount = payload.playerCount >= 2 ? 2 : 1;
    const price = await getGameTimePrice(client, selectedStation, reservedMinutes, payload.memberId, pricePlayerCount);
    estimatedTotalAmount = Number(price.finalAmount || price.baseAmount || 0);
    requiredDepositAmount = Number((payload.playerCount <= 1 ? estimatedTotalAmount : estimatedTotalAmount * 0.5).toFixed(2));
  }

  if (requiredDepositAmount > 0 && payload.paidAmount + 0.009 < requiredDepositAmount) {
    const label = payload.reservationScope === 'GROUP_EVENT' ? 'depósito mínimo del paquete' : (payload.playerCount <= 1 ? 'pago completo' : 'depósito mínimo del 50%');
    const error = new Error(`La reserva requiere ${label}: RD$${requiredDepositAmount.toFixed(2)}`);
    error.status = 400;
    throw error;
  }

  return {
    ...payload,
    reservedMinutes,
    reservedStartAt: startAt,
    reservedEndAt: endAt,
    estimatedTotalAmount,
    requiredDepositAmount,
    paymentStatus: payload.paidAmount >= estimatedTotalAmount ? 'PAGADO' : (payload.paidAmount >= requiredDepositAmount ? 'DEPOSITO' : 'PENDIENTE'),
    blockedStationId: selectedStation.id,
    stationId: payload.stationId || selectedStation.id,
    blockReason: `Bloqueado automáticamente para ${selectedStation.name || 'estación'} de ${startAt} a ${endAt}`,
    groupEventPriceId: groupEventRule?.id || payload.groupEventPriceId || null,
    stationCount: groupEventRule?.is_full_club ? 0 : Math.max(1, Number(payload.stationCount || groupEventRule?.station_count || 1)),
    isFullClub: Boolean(groupEventRule?.is_full_club || payload.isFullClub),
    reservationScope: payload.reservationScope || 'STANDARD'
  };
}

export async function listGameReservations(_req, res) {
  try {
    const { rows } = await query(
      `SELECT gr.*,
              sg.name AS game_name,
              sg.cover_url AS game_cover_url,
              sg.platform AS game_platform,
              sg.highlight_type AS game_highlight_type,
              sg.priority_enabled AS game_priority_enabled,
              s.name AS station_name,
              s.console_type AS station_console_type,
              m.full_name AS member_name,
              m.phone AS member_phone,
              m.membership_tier AS member_membership_tier,
              m.membership_active AS member_membership_active,
              blocked_station.name AS blocked_station_name,
              blocked_station.console_type AS blocked_station_console_type,
              u.full_name AS cashier_name
       FROM game_reservations gr
       LEFT JOIN station_games sg ON sg.id = gr.game_id
       LEFT JOIN stations s ON s.id = gr.station_id
       LEFT JOIN stations blocked_station ON blocked_station.id = COALESCE(gr.blocked_station_id, gr.station_id)
       LEFT JOIN members m ON m.id = gr.member_id
       LEFT JOIN users u ON u.id = gr.created_by_user_id
       WHERE gr.status IN ('WAITING', 'RESERVED', 'CALLED', 'NOTIFIED')
       ORDER BY gr.priority_level DESC, COALESCE(gr.desired_start_at, gr.created_at) ASC
       LIMIT 150`
    );

    const reservations = [];
    for (const row of rows) {
      if (String(row.reservation_type || '').toUpperCase() === 'WAITLIST' && ['WAITING', 'NOTIFIED'].includes(String(row.status || '').toUpperCase())) {
        const availability = await getWaitlistAvailability({ query }, row);
        reservations.push({
          ...row,
          waitlist_available: availability.available,
          waitlist_available_station_id: availability.stationId,
          waitlist_available_station_name: availability.stationName,
          waitlist_availability_message: availability.message
        });
      } else {
        reservations.push(row);
      }
    }

    res.json({ reservations });
  } catch (error) {
    sendControllerError(res, error);
  }
}

export async function createGameReservation(req, res) {
  try {
    const payload = await withTransaction(async (client) => {
      const normalized = normalizeGameReservationPayload(req.body || {});
      const prepared = await prepareSmartReservation(client, normalized);
      let reservationSaleId = null;
      if (prepared.reservationType === 'RESERVATION' && Number(prepared.paidAmount || 0) > 0) {
        if (prepared.paymentMethod === 'TRANSFER') {
          await validateTransferAuthorizationCode(client, prepared.transferAuthorizationCode, req.user.id);
        }
        const saleNotes = buildSaleNotes(
          prepared.paymentMethod || 'CASH',
          prepared.paymentReference || '',
          prepared.reservationScope === 'GROUP_EVENT' ? `Reserva grupo/evento - ${prepared.reservedMinutes} min · ${prepared.playerCount} personas` : `Reserva - ${prepared.reservedMinutes} min${prepared.playerCount > 1 ? ` · grupo ${prepared.playerCount}` : ''}`
        );
        const saleResult = await client.query(
          `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
           VALUES ($1, $2, $3, 0, 0, $3, $4, 'PAID', $5)
           RETURNING *`,
          [req.user.id, prepared.memberId, Number(prepared.paidAmount || 0).toFixed(2), prepared.paymentMethod || 'CASH', saleNotes]
        );
        reservationSaleId = saleResult.rows[0]?.id || null;
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, $3, $3)`,
          [reservationSaleId, prepared.reservationScope === 'GROUP_EVENT' ? `Depósito grupo/evento - ${prepared.reservedMinutes} minutos` : `Depósito reserva - ${prepared.reservedMinutes} minutos`, Number(prepared.paidAmount || 0).toFixed(2)]
        );
      }
      const { rows } = await client.query(
        `INSERT INTO game_reservations (
           reservation_type, status, game_id, station_id, member_id, customer_name, customer_phone, platform,
           desired_start_at, min_minutes, reserved_minutes, reserved_end_at, player_count,
           estimated_total_amount, required_deposit_amount, paid_amount, payment_method, payment_status,
           blocked_station_id, block_reason, priority_level, notes, created_by_user_id, sale_id,
           reservation_scope, group_event_price_id, station_count, is_full_club
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)
         RETURNING *`,
        [
          prepared.reservationType,
          prepared.status,
          prepared.gameId,
          prepared.stationId,
          prepared.memberId,
          prepared.customerName,
          prepared.customerPhone,
          prepared.platform,
          prepared.desiredStartAt,
          prepared.minMinutes,
          prepared.reservedMinutes,
          prepared.reservedEndAt,
          prepared.playerCount,
          prepared.estimatedTotalAmount,
          prepared.requiredDepositAmount,
          prepared.paidAmount,
          prepared.paymentMethod,
          prepared.paymentStatus,
          prepared.blockedStationId,
          prepared.blockReason,
          prepared.priorityLevel,
          prepared.notes,
          req.user.id,
          reservationSaleId,
          prepared.reservationScope || 'STANDARD',
          prepared.groupEventPriceId || null,
          prepared.stationCount || 1,
          Boolean(prepared.isFullClub)
        ]
      );
      return rows[0];
    });
    res.status(201).json({ reservation: payload });
  } catch (error) {
    sendControllerError(res, error);
  }
}


export async function assignGameReservation(req, res) {
  try {
    const { reservationId } = req.params;
    const result = await withTransaction(async (client) => {
      const reservationResult = await client.query(
        `SELECT gr.*,
                sg.name AS game_name,
                sg.platform AS game_platform,
                sg.compatible_consoles AS game_compatible_consoles,
                sg.unlimited_copies AS game_unlimited_copies,
                sg.copy_quantity AS game_copy_quantity,
                s.name AS blocked_station_name,
                s.console_type AS blocked_station_console_type
         FROM game_reservations gr
         LEFT JOIN station_games sg ON sg.id = gr.game_id
         LEFT JOIN stations s ON s.id = COALESCE(gr.blocked_station_id, gr.station_id)
         WHERE gr.id = $1
         FOR UPDATE OF gr`,
        [reservationId]
      );

      if (reservationResult.rowCount === 0) {
        const error = new Error('Reserva no encontrada');
        error.status = 404;
        throw error;
      }

      const reservation = reservationResult.rows[0];
      const currentStatus = String(reservation.status || '').toUpperCase();
      if (!['WAITING', 'RESERVED', 'CALLED', 'NOTIFIED'].includes(currentStatus)) {
        const error = new Error('Esta reserva ya no está disponible para asignar');
        error.status = 409;
        throw error;
      }

      const minutes = Math.max(0, Number(reservation.reserved_minutes || reservation.min_minutes || 0));
      const selectedGame = reservation.game_id ? {
        id: reservation.game_id,
        name: reservation.game_name,
        platform: reservation.game_platform || reservation.platform,
        compatible_consoles: reservation.game_compatible_consoles,
        unlimited_copies: reservation.game_unlimited_copies,
        copy_quantity: reservation.game_copy_quantity
      } : null;

      const stationRowsResult = await client.query(
        `SELECT * FROM stations WHERE deleted_at IS NULL AND status = 'AVAILABLE' ORDER BY sort_order NULLS LAST, name ASC`
      );
      const availableStations = stationRowsResult.rows || [];

      const baseStationId = reservation.blocked_station_id || reservation.station_id || null;
      const wantedCount = reservation.is_full_club
        ? availableStations.length
        : Math.max(1, Number(reservation.station_count || 1));

      const matchesReservation = (station) => {
        if (!station) return false;
        if (reservation.platform && station.console_type !== reservation.platform) return false;
        if (selectedGame && !isGameCompatibleWithConsole(selectedGame, station.console_type)) return false;
        return true;
      };

      let selectedStations = [];
      if (reservation.is_full_club) {
        selectedStations = availableStations.slice();
      } else {
        const baseStation = baseStationId ? availableStations.find((station) => String(station.id) === String(baseStationId)) : null;
        if (baseStation) selectedStations.push(baseStation);
        const remaining = availableStations
          .filter((station) => !selectedStations.some((selected) => String(selected.id) === String(station.id)))
          .filter(matchesReservation);
        selectedStations = [...selectedStations, ...remaining].slice(0, wantedCount);
      }

      if (!selectedStations.length) {
        const error = new Error('No hay estaciones libres para asignar esta reserva');
        error.status = 409;
        throw error;
      }

      if (!reservation.is_full_club && selectedStations.length < wantedCount) {
        const error = new Error(`Solo hay ${selectedStations.length} estación(es) libre(s) compatible(s). Esta reserva necesita ${wantedCount}.`);
        error.status = 409;
        throw error;
      }

      const sessions = [];
      for (const station of selectedStations) {
        if (selectedGame) await ensureGameCanBeUsed(client, { game: selectedGame, station, stationId: station.id });
        await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [station.id]);
        const sessionResult = await client.query(
          `INSERT INTO game_sessions (station_id, member_id, started_by_user_id, rate_type, prepaid_minutes, total_amount, player_count, game_id, status, scheduled_end_at)
           VALUES ($1, $2, $3, 'PREPAID', $4, 0, $5, $6, 'ACTIVE', CASE WHEN $4::int > 0 THEN NOW() + ($4 || ' minutes')::INTERVAL ELSE NULL END)
           RETURNING *`,
          [station.id, reservation.member_id || null, req.user.id, minutes, Number(reservation.player_count || 1) > 1 ? 2 : 1, selectedGame?.id || null]
        );
        const session = sessionResult.rows[0];
        sessions.push({ session, station });

        const totalAmount = Number(reservation.estimated_total_amount || 0);
        const paidAmount = Number(reservation.paid_amount || 0);
        const pendingAmount = Math.max(0, Number((totalAmount - paidAmount).toFixed(2)));
        const isGroupEventReservation = String(reservation.reservation_scope || '').toUpperCase() === 'GROUP_EVENT';
        const perStationPaid = selectedStations.length ? Number((paidAmount / selectedStations.length).toFixed(2)) : paidAmount;
        const perStationPending = selectedStations.length ? Number((pendingAmount / selectedStations.length).toFixed(2)) : pendingAmount;
        if (minutes > 0 || perStationPaid > 0) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: reservation.sale_id || null,
            lineType: 'GAME_TIME',
            description: `${isGroupEventReservation ? 'Reserva grupo/evento' : 'Reserva'} - ${minutes || 0} minutos`,
            quantity: 1,
            unitPrice: perStationPaid,
            total: perStationPaid,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
        if (!isGroupEventReservation && perStationPending > 0) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: null,
            lineType: 'GAME_TIME',
            description: 'Pendiente de reserva',
            quantity: 1,
            unitPrice: perStationPending,
            total: perStationPending,
            paymentStatus: 'PENDING',
            userId: req.user.id
          });
        }

        await logAuditEvent(client, {
          eventType: 'RESERVATION_ASSIGNED',
          userId: req.user.id,
          entityType: 'game_reservation',
          entityId: reservation.id,
          stationId: station.id,
          metadata: { sessionId: session.id, minutes, reservationScope: reservation.reservation_scope, gameId: selectedGame?.id || null }
        });
      }

      const updatedReservation = await client.query(
        `UPDATE game_reservations
         SET status = 'ASSIGNED', assigned_at = NOW(), updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [reservation.id]
      );

      return {
        reservation: updatedReservation.rows[0],
        assignedStations: sessions.map(({ station, session }) => ({ id: station.id, name: station.name, sessionId: session.id })),
        pendingAmount: Math.max(0, Number(reservation.estimated_total_amount || 0) - Number(reservation.paid_amount || 0))
      };
    });

    res.json(result);
  } catch (error) {
    sendControllerError(res, error);
  }
}


export async function payGameReservationPending(req, res) {
  try {
    const { reservationId } = req.params;
    const { paymentMethod = 'CASH', paymentReference = '', transferAuthorizationCode = '' } = req.body || {};
    const normalizedPaymentMethod = normalizePaymentMethod(paymentMethod);

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);
      if (normalizedPaymentMethod === 'TRANSFER') await validateTransferAuthorizationCode(client, transferAuthorizationCode, req.user.id);

      const reservationResult = await client.query(
        `SELECT gr.*, m.full_name AS member_name
         FROM game_reservations gr
         LEFT JOIN members m ON m.id = gr.member_id
         WHERE gr.id = $1
         FOR UPDATE OF gr`,
        [reservationId]
      );
      if (reservationResult.rowCount === 0) {
        const error = new Error('Reserva no encontrada');
        error.status = 404;
        throw error;
      }

      const reservation = reservationResult.rows[0];
      if (String(reservation.reservation_scope || '').toUpperCase() !== 'GROUP_EVENT') {
        const error = new Error('El cobro único aplica solo para grupo/cumpleaños/evento');
        error.status = 400;
        throw error;
      }

      const totalAmount = Number(reservation.estimated_total_amount || 0);
      const paidAmount = Number(reservation.paid_amount || 0);
      const pendingAmount = Math.max(0, Number((totalAmount - paidAmount).toFixed(2)));
      if (pendingAmount <= 0) {
        const error = new Error('Esta reserva no tiene balance pendiente');
        error.status = 400;
        throw error;
      }

      const saleResult = await client.query(
        `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
         VALUES ($1, $2, $3, 0, 0, $3, $4, 'PAID', $5)
         RETURNING *`,
        [
          req.user.id,
          reservation.member_id || null,
          pendingAmount.toFixed(2),
          normalizedPaymentMethod,
          buildSaleNotes(normalizedPaymentMethod, paymentReference, `Pendiente reserva grupo/evento - ${reservation.customer_name || 'Cliente'}`)
        ]
      );
      const sale = saleResult.rows[0];

      await client.query(
        `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
         VALUES ($1, NULL, 'GAME_TIME', $2, 1, $3, $3)`,
        [sale.id, `Saldo pendiente reserva grupo/evento - ${reservation.customer_name || 'Cliente'}`, pendingAmount.toFixed(2)]
      );

      const updatedReservation = await client.query(
        `UPDATE game_reservations
         SET paid_amount = estimated_total_amount,
             payment_status = 'PAGADO',
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [reservation.id]
      );

      if (reservation.member_id) {
        await syncMemberAchievements(client, { memberId: reservation.member_id, userId: req.user?.id || null });
      }

      await logAuditEvent(client, {
        eventType: 'RESERVATION_PENDING_PAID',
        userId: req.user.id,
        entityType: 'game_reservation',
        entityId: reservation.id,
        saleId: sale.id,
        metadata: { reservationScope: reservation.reservation_scope, paymentMethod: normalizedPaymentMethod, total: Number(sale.total || 0) }
      });

      return { sale, reservation: updatedReservation.rows[0], paidAmount: pendingAmount };
    });

    res.json(result);
  } catch (error) {
    sendControllerError(res, error);
  }
}

export async function updateGameReservation(req, res) {
  try {
    const { reservationId } = req.params;
    const status = String(req.body?.status || '').trim().toUpperCase();
    if (!ALLOWED_GAME_RESERVATION_STATUSES.includes(status)) {
      const error = new Error('Estado de reserva inválido');
      error.status = 400;
      throw error;
    }
    const timestampColumn = ['CALLED', 'NOTIFIED'].includes(status) ? 'called_at'
      : ['ASSIGNED', 'CONVERTED'].includes(status) ? 'assigned_at'
      : ['CANCELED', 'NO_SHOW', 'EXPIRED'].includes(status) ? 'canceled_at'
      : null;
    const responseWindowMinutes = status === 'NOTIFIED'
      ? await getReservationResponseWindowMinutes(reservationId, req.body?.responseWindowMinutes)
      : DEFAULT_WAITLIST_RESPONSE_WINDOW_MINUTES;
    const setTimestamp = timestampColumn ? `, ${timestampColumn} = NOW()` : '';
    const deadlineSql = status === 'NOTIFIED' ? `, notified_at = NOW(), response_deadline_at = NOW() + ($3::int * INTERVAL '1 minute')` : '';
    const params = status === 'NOTIFIED' ? [reservationId, status, responseWindowMinutes] : [reservationId, status];
    const { rows, rowCount } = await query(
      `UPDATE game_reservations SET status = $2, updated_at = NOW()${setTimestamp}${deadlineSql} WHERE id = $1 RETURNING *`,
      params
    );
    if (!rowCount) return res.status(404).json({ error: 'Reserva no encontrada' });
    res.json({ reservation: rows[0] });
  } catch (error) {
    sendControllerError(res, error);
  }
}

export async function listGameRequests(_req, res) {
  try {
    const { rows } = await query(
      `SELECT gr.*,
              sg.name AS game_name,
              sg.cover_url AS game_cover_url,
              s.name AS station_name,
              m.full_name AS member_name,
              m.phone AS member_phone,
              u.full_name AS cashier_name
       FROM game_requests gr
       LEFT JOIN station_games sg ON sg.id = gr.game_id
       LEFT JOIN stations s ON s.id = gr.station_id
       LEFT JOIN members m ON m.id = gr.member_id
       LEFT JOIN users u ON u.id = gr.cashier_id
       ORDER BY gr.created_at DESC
       LIMIT 250`
    );
    res.json({ requests: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function createGameRequest(req, res) {
  try {
    const payload = normalizeGameRequestPayload(req.body);
    const { rows } = await query(
      `INSERT INTO game_requests (
         request_type, request_scope, game_id, requested_game_name, platform, station_id, member_id, customer_name,
         cashier_id, unavailable_reason, customer_decision, status, estimated_wait_minutes, notes
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
       RETURNING *`,
      [
        payload.requestType,
        payload.requestScope,
        payload.gameId,
        payload.requestedGameName,
        payload.platform,
        payload.stationId,
        payload.memberId,
        payload.customerName,
        req.user?.id || null,
        payload.unavailableReason,
        payload.customerDecision,
        payload.status,
        payload.estimatedWaitMinutes,
        payload.notes
      ]
    );
    res.status(201).json({ request: rows[0] });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

function normalizeGameRequestAvailabilityPayload(body = {}, request = {}) {
  const source = body && typeof body === 'object' ? body : {};
  const requestedName = String(request.requested_game_name || request.game_name || '').trim();
  const name = String(source.name || source.gameName || requestedName).trim();
  const platform = String(source.platform || request.platform || 'Multiplataforma').trim() || 'Multiplataforma';
  const compatibleConsoles = normalizeGameCompatibility(source.compatibleConsoles || source.compatible_consoles, platform);
  const normalizedPlatform = compatibleConsoles.length === 1 ? compatibleConsoles[0] : (platform || 'Multiplataforma');
  const copyQuantityRaw = Number.parseInt(String(source.copyQuantity ?? source.copy_quantity ?? 1), 10);
  const unlimitedCopies = source.unlimitedCopies ?? source.unlimited_copies ?? false;
  const locationTypeInput = String(source.locationType || source.location_type || '').trim();
  const locationType = ALLOWED_GAME_LOCATION_TYPES.includes(locationTypeInput) ? locationTypeInput : 'Instalado en consola';
  const requiresDevice = ['SSD externo', 'Disco duro externo', 'Micro SD'].includes(locationType);
  const deviceId = requiresDevice ? (String(source.deviceId || source.device_id || '').trim() || null) : null;
  const stationIds = Array.isArray(source.stationIds || source.station_ids)
    ? [...new Set((source.stationIds || source.station_ids).map((id) => String(id || '').trim()).filter(Boolean))]
    : [];
  const notes = String(source.notes || '').trim() || null;
  const coverUrl = String(source.coverUrl || source.cover_url || '').trim() || null;

  return {
    name,
    platform: normalizedPlatform,
    compatibleConsoles,
    copyQuantity: Number.isFinite(copyQuantityRaw) && copyQuantityRaw > 0 ? copyQuantityRaw : 1,
    unlimitedCopies: Boolean(unlimitedCopies),
    locationType,
    deviceId,
    stationIds,
    coverUrl,
    notes
  };
}

function buildGameLocationsForAvailableGame(availability = {}) {
  const stationIds = Array.isArray(availability.stationIds) ? availability.stationIds : [];
  if (stationIds.length) {
    return stationIds.map((stationId) => ({
      locationType: availability.locationType || 'Instalado en consola',
      status: 'Disponible',
      stationId,
      deviceId: availability.deviceId || null,
      quantity: 1,
      accountLabel: null,
      notes: availability.notes || 'Agregado desde solicitud marcada disponible'
    }));
  }

  return [{
    locationType: availability.locationType || 'Instalado en consola',
    status: 'Disponible',
    stationId: null,
    deviceId: availability.deviceId || null,
    quantity: availability.copyQuantity || 1,
    accountLabel: null,
    notes: availability.notes || 'Agregado desde solicitud marcada disponible'
  }];
}

async function ensureStationGameFromRequest(client, request, availabilityInput = null) {
  const availability = normalizeGameRequestAvailabilityPayload(availabilityInput || {}, request);
  const requestedName = String(availability.name || request.requested_game_name || request.game_name || '').trim();
  if (!requestedName) return null;

  const existing = await client.query(
    `SELECT *
     FROM station_games
     WHERE LOWER(name) = LOWER($1)
     ORDER BY is_active DESC, created_at ASC
     LIMIT 1`,
    [requestedName]
  );

  let savedGame = null;
  if (existing.rows[0]) {
    const game = existing.rows[0];
    const updated = await client.query(
      `UPDATE station_games
       SET name = $2,
           is_active = true,
           platform = $3,
           compatible_consoles = $4,
           copy_quantity = $5,
           unlimited_copies = $6,
           cover_url = COALESCE($7, cover_url),
           updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      [game.id, requestedName, availability.platform, availability.compatibleConsoles, availability.copyQuantity, availability.unlimitedCopies, availability.coverUrl]
    );
    savedGame = updated.rows[0] || game;
  } else {
    const maxSort = await client.query(`SELECT COALESCE(MAX(sort_order), 0)::int AS max_sort FROM station_games`);
    const sortOrder = Number(maxSort.rows[0]?.max_sort || 0) + 10;
    const inserted = await client.query(
      `INSERT INTO station_games (
         name, platform, cover_url, is_story_mode, requires_profile_alert, is_featured, is_active, sort_order,
         compatible_consoles, copy_quantity, unlimited_copies, highlight_type, priority_enabled
       )
       VALUES ($1, $2, $3, false, false, false, true, $4, $5, $6, $7, 'NORMAL', false)
       RETURNING *`,
      [requestedName, availability.platform, availability.coverUrl, sortOrder, availability.compatibleConsoles, availability.copyQuantity, availability.unlimitedCopies]
    );
    savedGame = inserted.rows[0] || null;
  }

  if (savedGame?.id) {
    await replaceGameLocations(client, savedGame.id, buildGameLocationsForAvailableGame(availability));
  }
  return savedGame;
}

export async function updateGameRequest(req, res) {
  try {
    const { requestId } = req.params;
    const status = String(req.body.status || '').trim().toUpperCase();
    const notes = String(req.body.notes || '').trim();
    const etaText = String(req.body.etaText || '').trim();
    const memberNote = String(req.body.memberNote || '').trim();
    const adminNote = String(req.body.adminNote || '').trim();
    const purchaseMethodInput = String(req.body.purchaseMethod || '').trim().toUpperCase();
    const purchaseMethod = ['DIGITAL', 'FISICO', 'PENDIENTE'].includes(purchaseMethodInput) ? purchaseMethodInput : null;
    const availableNotified = req.body.availableNotified === true;
    const availableNotificationNote = String(req.body.availableNotificationNote || '').trim();
    const availabilityInput = req.body.availability && typeof req.body.availability === 'object' ? req.body.availability : null;
    if (!ALLOWED_GAME_REQUEST_STATUSES.includes(status)) {
      return res.status(400).json({ error: 'Estado inválido' });
    }

    const result = await withTransaction(async (client) => {
      const currentRequest = await client.query(
        `SELECT gr.*, sg.name AS game_name
         FROM game_requests gr
         LEFT JOIN station_games sg ON sg.id = gr.game_id
         WHERE gr.id = $1
         FOR UPDATE OF gr`,
        [requestId]
      );
      if (!currentRequest.rows[0]) return null;

      let availableGame = null;
      if (status === 'CONVERTIDO') {
        availableGame = await ensureStationGameFromRequest(client, currentRequest.rows[0], availabilityInput);
      }

      const updated = await client.query(
        `UPDATE game_requests
         SET status = $2,
             game_id = COALESCE($7, game_id),
             notes = COALESCE(NULLIF($3, ''), notes),
             eta_text = NULLIF($4, ''),
             member_note = NULLIF($5, ''),
             admin_note = NULLIF($6, ''),
             purchase_method = CASE WHEN $2 = 'COMPRADO' THEN COALESCE($8, purchase_method) ELSE purchase_method END,
             purchased_at = CASE WHEN $2 = 'COMPRADO' THEN COALESCE(purchased_at, NOW()) ELSE purchased_at END,
             available_notified_at = CASE WHEN $9 = true THEN NOW() ELSE available_notified_at END,
             available_notification_note = CASE WHEN $9 = true THEN COALESCE(NULLIF($10, ''), available_notification_note) ELSE available_notification_note END,
             reviewed_at = CASE WHEN $2 IN ('REVISADO', 'COMPRADO', 'DESCARTADO', 'CONVERTIDO') THEN COALESCE(reviewed_at, NOW()) ELSE reviewed_at END,
             converted_at = CASE WHEN $2 = 'CONVERTIDO' THEN COALESCE(converted_at, NOW()) ELSE converted_at END,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [requestId, status, notes, etaText, memberNote, adminNote, availableGame?.id || null, purchaseMethod, availableNotified, availableNotificationNote]
      );
      return { request: updated.rows[0], game: availableGame };
    });

    if (!result?.request) return res.status(404).json({ error: 'Solicitud no encontrada' });
    res.json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function listStationGames(_req, res) {
  try {
    const { rows } = await query(
      `SELECT sg.*,
              COALESCE(active_usage.active_count, 0)::int AS active_sessions_count,
              CASE
                WHEN sg.unlimited_copies = true THEN NULL
                ELSE GREATEST(COALESCE(sg.copy_quantity, 0) - COALESCE(active_usage.active_count, 0), 0)
              END AS available_copies,
              COALESCE(locations.locations, '[]'::json) AS locations
       FROM station_games sg
       LEFT JOIN LATERAL (
         SELECT COUNT(*)::int AS active_count
         FROM game_sessions gs
         WHERE gs.game_id = sg.id
           AND gs.status = 'ACTIVE'
       ) active_usage ON true
       LEFT JOIN LATERAL (
         SELECT json_agg(json_build_object(
           'id', sgl.id,
           'location_type', sgl.location_type,
           'station_id', sgl.station_id,
           'station_name', s.name,
           'station_console_type', s.console_type,
           'device_id', sgl.device_id,
           'device_name', gsd.name,
           'device_type', gsd.device_type,
           'device_platform', gsd.platform,
           'quantity', sgl.quantity,
           'account_label', sgl.account_label,
           'status', sgl.status,
           'notes', sgl.notes
         ) ORDER BY sgl.created_at, sgl.id) AS locations
         FROM station_game_locations sgl
         LEFT JOIN stations s ON s.id = sgl.station_id
         LEFT JOIN game_storage_devices gsd ON gsd.id = sgl.device_id
         WHERE sgl.game_id = sg.id
           AND sgl.is_active = true
       ) locations ON true
       ORDER BY sg.is_active DESC, sg.is_featured DESC, sg.sort_order, sg.name`
    );
    res.json({ games: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function createStationGame(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const game = normalizeStationGamePayload(req.body);
    const savedGame = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `INSERT INTO station_games (
           name, platform, cover_url, is_story_mode, requires_profile_alert, is_featured, is_active, sort_order,
           compatible_consoles, copy_quantity, unlimited_copies, highlight_type, priority_enabled,
           allows_extra_controllers, max_extra_controllers, extra_controller_price
         )
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
         RETURNING *`,
        [
          game.name, game.platform, game.coverUrl, game.isStoryMode, game.requiresProfileAlert, game.isFeatured, game.isActive, game.sortOrder,
          game.compatibleConsoles, game.copyQuantity, game.unlimitedCopies, game.highlightType, game.priorityEnabled,
          game.allowsExtraControllers, game.maxExtraControllers, game.extraControllerPrice
        ]
      );
      await replaceGameLocations(client, rows[0].id, game.locations);
      return rows[0];
    });
    res.status(201).json({ game: savedGame });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateStationGame(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const { gameId } = req.params;
    const game = normalizeStationGamePayload(req.body);
    const savedGame = await withTransaction(async (client) => {
      const { rows } = await client.query(
        `UPDATE station_games
         SET name = $2,
             platform = $3,
             cover_url = $4,
             is_story_mode = $5,
             requires_profile_alert = $6,
             is_featured = $7,
             is_active = $8,
             sort_order = $9,
             compatible_consoles = $10,
             copy_quantity = $11,
             unlimited_copies = $12,
             highlight_type = $13,
             priority_enabled = $14,
             allows_extra_controllers = $15,
             max_extra_controllers = $16,
             extra_controller_price = $17,
             updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [
          gameId, game.name, game.platform, game.coverUrl, game.isStoryMode, game.requiresProfileAlert, game.isFeatured, game.isActive, game.sortOrder,
          game.compatibleConsoles, game.copyQuantity, game.unlimitedCopies, game.highlightType, game.priorityEnabled,
          game.allowsExtraControllers, game.maxExtraControllers, game.extraControllerPrice
        ]
      );
      if (!rows[0]) return null;
      await replaceGameLocations(client, gameId, game.locations);
      return rows[0];
    });
    if (!savedGame) return res.status(404).json({ error: 'Juego no encontrado' });
    res.json({ game: savedGame });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteStationGame(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const { gameId } = req.params;
    const { rowCount } = await query(`UPDATE station_games SET is_active = false, updated_at = NOW() WHERE id = $1`, [gameId]);
    if (rowCount === 0) return res.status(404).json({ error: 'Juego no encontrado' });
    res.status(204).send();
  } catch (error) {
    return sendControllerError(res, error);
  }
}

async function saveStationExtraAssignments(client, extraId, stationIds = []) {
  await client.query(`DELETE FROM station_extra_assignments WHERE extra_id = $1`, [extraId]);
  for (const stationId of stationIds) {
    await client.query(
      `INSERT INTO station_extra_assignments (extra_id, station_id)
       SELECT $1, id FROM stations WHERE id = $2 AND deleted_at IS NULL
       ON CONFLICT DO NOTHING`,
      [extraId, stationId]
    );
  }
}

async function buildStationExtraLines(client, stationId, extras = []) {
  if (!Array.isArray(extras) || extras.length === 0) return [];
  const normalized = extras
    .map((item) => ({ extraId: String(item.extraId || item.extra_id || '').trim(), quantity: Math.max(1, Number(item.quantity || 1)) }))
    .filter((item) => item.extraId);
  if (!normalized.length) return [];

  const lines = [];
  for (const item of normalized) {
    const result = await client.query(
      `SELECT se.*
       FROM station_extras se
       JOIN station_extra_assignments sea ON sea.extra_id = se.id
       WHERE se.id = $1
         AND sea.station_id = $2
         AND se.is_active = true
       LIMIT 1`,
      [item.extraId, stationId]
    );
    if (result.rowCount === 0) {
      const error = new Error('Extra no disponible para esta estación');
      error.status = 400;
      throw error;
    }
    const extra = result.rows[0];
    const quantity = item.quantity;
    const unitPrice = Number(extra.price || 0);
    const total = Number((unitPrice * quantity).toFixed(2));
    lines.push({
      id: extra.id,
      name: extra.name,
      description: extra.description,
      pricingType: extra.pricing_type,
      quantity,
      unitPrice,
      total,
      label: `${extra.name}${extra.pricing_type === 'HOURLY' ? ' · por hora' : ''}`
    });
  }
  return lines;
}

export async function listStationExtras(_req, res) {
  try {
    const { rows } = await query(
      `SELECT se.*,
              COALESCE(json_agg(sea.station_id ORDER BY sea.station_id) FILTER (WHERE sea.station_id IS NOT NULL), '[]') AS station_ids
       FROM station_extras se
       LEFT JOIN station_extra_assignments sea ON sea.extra_id = se.id
       GROUP BY se.id
       ORDER BY se.sort_order, se.name`
    );
    res.json({ extras: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function createStationExtra(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const payload = normalizeStationExtraPayload(req.body);
    const result = await withTransaction(async (client) => {
      const inserted = await client.query(
        `INSERT INTO station_extras (name, description, price, pricing_type, is_active, sort_order)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
        [payload.name, payload.description, payload.price, payload.pricingType, payload.isActive, payload.sortOrder]
      );
      await saveStationExtraAssignments(client, inserted.rows[0].id, payload.stationIds);
      await logAuditEvent(client, {
        eventType: 'STATION_EXTRA_CREATED',
        userId: req.user.id,
        entityType: 'station_extra',
        entityId: inserted.rows[0].id,
        metadata: { name: payload.name, price: payload.price, stationCount: payload.stationIds.length }
      });
      return inserted.rows[0];
    });
    res.status(201).json({ extra: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateStationExtra(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const payload = normalizeStationExtraPayload(req.body);
    const { extraId } = req.params;
    const result = await withTransaction(async (client) => {
      const updated = await client.query(
        `UPDATE station_extras
         SET name = $2, description = $3, price = $4, pricing_type = $5, is_active = $6, sort_order = $7, updated_at = NOW()
         WHERE id = $1
         RETURNING *`,
        [extraId, payload.name, payload.description, payload.price, payload.pricingType, payload.isActive, payload.sortOrder]
      );
      if (updated.rowCount === 0) {
        const error = new Error('Extra no encontrado');
        error.status = 404;
        throw error;
      }
      await saveStationExtraAssignments(client, extraId, payload.stationIds);
      await logAuditEvent(client, {
        eventType: 'STATION_EXTRA_UPDATED',
        userId: req.user.id,
        entityType: 'station_extra',
        entityId: extraId,
        metadata: { name: payload.name, price: payload.price, active: payload.isActive, stationCount: payload.stationIds.length }
      });
      return updated.rows[0];
    });
    res.json({ extra: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function deleteStationExtra(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const { extraId } = req.params;
    await query(`UPDATE station_extras SET is_active = false, updated_at = NOW() WHERE id = $1`, [extraId]);
    res.status(204).send();
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function listStations(_req, res) {
  try {
    const { rows } = await query(`
      SELECT
        s.*,
        gs.id AS active_session_id,
        gs.started_at,
        COALESCE(account.account_items, '[]'::json) AS active_session_items,
        COALESCE(account.pending_total, 0) AS active_session_pending_total,
        COALESCE(account.paid_total, 0) AS active_session_paid_total,
        COALESCE(account.session_total, 0) AS active_session_account_total,
        gs.member_id,
        gs.rate_type,
        gs.prepaid_minutes,
        gs.player_count AS session_player_count,
        gs.total_amount AS session_total_amount,
        gs.game_id AS session_game_id,
        sg.name AS session_game_name,
        sg.platform AS session_game_platform,
        sg.cover_url AS session_game_cover_url,
        sg.is_story_mode AS session_game_is_story_mode,
        sg.requires_profile_alert AS session_game_requires_profile_alert,
        gs.started_by_user_id AS session_started_by_user_id,
        gs.ended_by_user_id AS session_ended_by_user_id,
        started_user.full_name AS session_started_by_name,
        ended_user.full_name AS session_ended_by_name,
        m.full_name AS member_name,
        m.phone AS member_phone,
        m.date_of_birth AS member_date_of_birth,
        m.visit_count AS member_visit_count,
        m.reward_points AS member_reward_points,
        m.membership_tier AS member_membership_tier,
        m.membership_active AS member_membership_active,
        m.membership_started_at AS member_membership_started_at,
        mr.id AS member_visit_reward_id,
        mr.reward_type AS member_visit_reward_type,
        mr.reward_minutes AS member_visit_reward_minutes,
        mr.used_reward_minutes AS member_visit_reward_minutes_used,
        mr.prize_snack_qty AS member_visit_reward_snack_qty,
        mr.used_prize_snack_qty AS member_visit_reward_snack_used,
        mr.prize_drink_qty AS member_visit_reward_drink_qty,
        mr.used_prize_drink_qty AS member_visit_reward_drink_used,
        mr.prize_product_id AS member_visit_reward_product_id,
        mr.prize_product_qty AS member_visit_reward_product_qty,
        mr.used_prize_product_qty AS member_visit_reward_product_used,
        mr.prize_product_name AS member_visit_reward_product_name,
        mr.prize_product_category AS member_visit_reward_product_category,
        mr.expires_at AS member_visit_reward_expires_at,
        tm.id AS tournament_match_id,
        tm.round_number AS tournament_round_number,
        tm.match_number AS tournament_match_number,
        tm.match_type AS tournament_match_type,
        tm.placement_position AS tournament_placement_position,
        round_meta.total_bracket_rounds AS tournament_total_bracket_rounds,
        tm.tournament_id AS tournament_id,
        tm.player1_participant_id AS tournament_player1_participant_id,
        tm.player2_participant_id AS tournament_player2_participant_id,
        t.name AS tournament_name,
        p1.player_name AS tournament_player1_name,
        p2.player_name AS tournament_player2_name
      FROM stations s
      LEFT JOIN game_sessions gs ON gs.station_id = s.id AND gs.status = 'ACTIVE'
      LEFT JOIN members m ON m.id = gs.member_id
      LEFT JOIN station_games sg ON sg.id = gs.game_id
      LEFT JOIN users started_user ON started_user.id = gs.started_by_user_id
      LEFT JOIN users ended_user ON ended_user.id = gs.ended_by_user_id
      LEFT JOIN LATERAL (
        SELECT
          json_agg(
            json_build_object(
              'id', ssi.id,
              'line_type', ssi.line_type,
              'description', ssi.description,
              'quantity', ssi.quantity,
              'unit_price', ssi.unit_price,
              'total', ssi.total,
              'payment_status', ssi.payment_status,
              'product_id', ssi.product_id,
              'sale_id', ssi.sale_id,
              'created_at', ssi.created_at
            )
            ORDER BY ssi.created_at, ssi.id
          ) AS account_items,
          COALESCE(SUM(CASE WHEN ssi.payment_status = 'PENDING' THEN ssi.total ELSE 0 END), 0) AS pending_total,
          COALESCE(SUM(CASE WHEN ssi.payment_status = 'PAID' THEN ssi.total ELSE 0 END), 0) AS paid_total,
          COALESCE(SUM(ssi.total), 0) AS session_total
        FROM station_session_items ssi
        WHERE ssi.session_id = gs.id
      ) account ON true
      LEFT JOIN LATERAL (
        SELECT mr.id, mr.reward_type, mr.reward_minutes, mr.used_reward_minutes,
               mr.prize_snack_qty, mr.used_prize_snack_qty,
               mr.prize_drink_qty, mr.used_prize_drink_qty,
               mr.prize_product_id, mr.prize_product_qty, mr.used_prize_product_qty,
               p.name AS prize_product_name, p.category AS prize_product_category,
               mr.expires_at
        FROM member_rewards mr
        LEFT JOIN products p ON p.id = mr.prize_product_id
        WHERE mr.member_id = m.id
          AND mr.reward_type IN ('VISIT_REWARD', 'MANUAL', 'MANUAL_BONUS', 'PURCHASE_BONUS', 'TOURNAMENT_PRIZE', 'POINT_REDEMPTION')
          AND mr.status = 'AVAILABLE'
          AND mr.expires_at >= NOW()
          AND (mr.reward_minutes > COALESCE(mr.used_reward_minutes, 0)
            OR mr.prize_snack_qty > COALESCE(mr.used_prize_snack_qty, 0)
            OR mr.prize_drink_qty > COALESCE(mr.used_prize_drink_qty, 0)
            OR mr.prize_product_qty > COALESCE(mr.used_prize_product_qty, 0))
        ORDER BY mr.expires_at ASC
        LIMIT 1
      ) mr ON true
      LEFT JOIN tournament_matches tm ON tm.station_id = s.id
        AND tm.station_started_at IS NOT NULL
        AND tm.station_finished_at IS NULL
        AND tm.status = 'SCHEDULED'
      LEFT JOIN tournaments t ON t.id = tm.tournament_id
      LEFT JOIN LATERAL (
        SELECT MAX(tm_round.round_number) AS total_bracket_rounds
        FROM tournament_matches tm_round
        WHERE tm_round.tournament_id = tm.tournament_id
          AND COALESCE(tm_round.match_type, 'BRACKET') = 'BRACKET'
      ) round_meta ON true
      LEFT JOIN tournament_participants p1 ON p1.id = tm.player1_participant_id
      LEFT JOIN tournament_participants p2 ON p2.id = tm.player2_participant_id
      WHERE s.deleted_at IS NULL
      ORDER BY s.sort_order, s.name
    `);
    const activeTournament = await query(`
      SELECT t.*, wp.player_name AS winner_name
      FROM tournaments t
      LEFT JOIN tournament_participants wp ON wp.id = t.winner_participant_id
      WHERE ((t.status = 'ACTIVE' AND t.versus_closed_at IS NULL)
         OR (t.status = 'FINISHED' AND t.versus_closed_at IS NULL AND (t.versus_visible_until IS NULL OR t.versus_visible_until >= NOW())))
      ORDER BY CASE WHEN t.status = 'ACTIVE' THEN 1 ELSE 2 END, COALESCE(t.started_at, t.scheduled_at, t.created_at) DESC
      LIMIT 1
    `);

    let versus = null;
    if (activeTournament.rowCount > 0) {
      const tournament = activeTournament.rows[0];
      const matchesResult = await query(
        `SELECT tm.*,
                p1.player_name AS player1_name,
                p2.player_name AS player2_name,
                wp.player_name AS winner_name,
                s.name AS station_name,
                s.console_type AS station_console_type
         FROM tournament_matches tm
         LEFT JOIN tournament_participants p1 ON p1.id = tm.player1_participant_id
         LEFT JOIN tournament_participants p2 ON p2.id = tm.player2_participant_id
         LEFT JOIN tournament_participants wp ON wp.id = tm.winner_participant_id
         LEFT JOIN stations s ON s.id = tm.station_id
         WHERE tm.tournament_id = $1
         ORDER BY tm.round_number ASC, tm.match_number ASC`,
        [tournament.id]
      );
      const matches = matchesResult.rows;
      const awardsResult = await query(
        `SELECT ta.*, tp.player_name, tp.phone, tp.nickname, m.full_name AS member_name
         FROM tournament_awards ta
         JOIN tournament_participants tp ON tp.id = ta.participant_id
         LEFT JOIN members m ON m.id = ta.member_id
         WHERE ta.tournament_id = $1
         ORDER BY ta.position ASC`,
        [tournament.id]
      );
      const activeMatches = matches.filter((match) => match.station_started_at && !match.station_finished_at && match.status !== 'FINISHED');
      const pendingMatches = matches.filter((match) => match.status === 'SCHEDULED' && !match.winner_participant_id && match.player1_participant_id && match.player2_participant_id && (!match.station_started_at || match.station_finished_at));
      const lastResults = matches.filter((match) => match.status === 'FINISHED' && match.winner_participant_id).slice(-5).reverse();
      const waitingAdvancers = [];
      const rounds = new Map();
      for (const match of matches) {
        const key = Number(match.round_number || 1);
        if (!rounds.has(key)) rounds.set(key, []);
        rounds.get(key).push(match);
      }
      for (const [roundNumber, roundMatches] of rounds.entries()) {
        const ordered = roundMatches.sort((a, b) => Number(a.match_number || 0) - Number(b.match_number || 0));
        for (let index = 0; index < ordered.length; index += 2) {
          const first = ordered[index];
          const second = ordered[index + 1];
          if (!second) continue;
          const firstDone = first.status === 'FINISHED' && first.winner_participant_id;
          const secondDone = second.status === 'FINISHED' && second.winner_participant_id;
          if (firstDone && !secondDone) {
            waitingAdvancers.push({
              player_name: first.winner_name,
              message: `${first.winner_name} espera ganador de ${second.player1_name || 'Jugador'} vs ${second.player2_name || 'Jugador'}`,
              round_number: roundNumber
            });
          }
          if (secondDone && !firstDone) {
            waitingAdvancers.push({
              player_name: second.winner_name,
              message: `${second.winner_name} espera ganador de ${first.player1_name || 'Jugador'} vs ${first.player2_name || 'Jugador'}`,
              round_number: roundNumber
            });
          }
        }
      }
      versus = { tournament, matches, activeMatches, pendingMatches, lastResults, waitingAdvancers, awards: awardsResult.rows };
    }

    res.json({ stations: rows, versus });

  } catch (error) {
    return sendControllerError(res, error);
  }
}


async function insertSessionAccountLine(client, { sessionId, saleId = null, productId = null, lineType = 'PRODUCT', description, quantity = 1, unitPrice = 0, total = 0, paymentStatus = 'PENDING', userId }) {
  await client.query(
    `INSERT INTO station_session_items (session_id, sale_id, product_id, line_type, description, quantity, unit_price, total, payment_status, created_by_user_id, paid_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CASE WHEN $9 = 'PAID' THEN NOW() ELSE NULL END)`,
    [sessionId, saleId, productId, lineType, description, quantity, Number(unitPrice || 0).toFixed(2), Number(total || 0).toFixed(2), paymentStatus, userId]
  );
}

async function getOrCreateStationSessionForAccount(client, { stationId, station, memberId, userId, totalSessionMinutes, timeAmount, playerCount, freeMode, gameId = null }) {
  const active = await client.query(
    `SELECT * FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
    [stationId]
  );

  await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [stationId]);

  if (active.rowCount === 0) {
    const rateType = freeMode ? 'HOURLY' : 'PREPAID';
    const sessionResult = await client.query(
      `INSERT INTO game_sessions (station_id, member_id, started_by_user_id, rate_type, prepaid_minutes, total_amount, player_count, game_id, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'ACTIVE')
       RETURNING *`,
      [stationId, memberId, userId, rateType, totalSessionMinutes || 0, timeAmount || 0, playerCount, gameId || null]
    );
    return sessionResult.rows[0];
  }

  const current = active.rows[0];
  const sessionResult = await client.query(
    `UPDATE game_sessions
     SET prepaid_minutes = COALESCE(prepaid_minutes, 0) + $1,
         total_amount = COALESCE(total_amount, 0) + $2,
         rate_type = CASE WHEN $3 = true THEN 'HOURLY' ELSE rate_type END,
         player_count = COALESCE($4, player_count),
         member_id = COALESCE($5, member_id),
         game_id = COALESCE($6, game_id)
     WHERE id = $7
     RETURNING *`,
    [totalSessionMinutes || 0, timeAmount || 0, freeMode === true, playerCount, memberId, gameId || null, current.id]
  );
  return sessionResult.rows[0];
}

async function buildStationOrderForAccount(client, { station, memberId, gameMinutes = 0, playerCount = 1, items = [], allowExtension15 = false }) {
  const normalizedGameMinutes = Math.max(0, Number(gameMinutes || 0));
  const normalizedPlayerCount = normalizePlayerCount(playerCount);
  const productLines = [];
  let comboIncludedMinutes = 0;
  let subtotal = 0;
  let discountTotal = 0;
  const timePrice = normalizedGameMinutes > 0
    ? await getGameTimePrice(client, station, normalizedGameMinutes, memberId, normalizedPlayerCount, { allowInactiveExtension: allowExtension15 })
    : { baseAmount: 0, finalAmount: 0, discountAmount: 0, promotion: null, source: 'GENERAL' };

  if (normalizedGameMinutes > 0) {
    subtotal += timePrice.baseAmount;
    discountTotal += timePrice.discountAmount;
  }

  for (const item of items) {
    const productResult = await client.query(
      `SELECT id, name, sku, price, stock_qty, track_stock, category, is_combo, membership_plan_code, combo_included_minutes, combo_player_count
       FROM products
       WHERE id = $1 AND is_active = true`,
      [item.productId]
    );
    if (productResult.rowCount === 0) {
      const error = new Error(`Producto no encontrado: ${item.productId}`);
      error.status = 404;
      throw error;
    }
    const product = productResult.rows[0];
    const quantity = Math.max(1, Number(item.quantity || 1));
    const modifierInfo = await resolveProductModifiers(client, product.id, item.modifierOptionIds || item.modifiers || []);
    const comboMinutes = product.is_combo ? Math.max(0, Number(product.combo_included_minutes || 0)) * quantity : 0;
    if (comboMinutes > 0) comboIncludedMinutes += comboMinutes;
    const comboTimeSuffix = comboMinutes > 0 ? ` · ${comboMinutes} min` : '';
    const description = `${product.name}${modifierInfo.descriptionSuffix}${comboTimeSuffix}`;
    if (product.category === 'MEMBERSHIP' && !memberId) {
      const error = new Error('Selecciona o crea un miembro para vender una membresía');
      error.status = 400;
      throw error;
    }
    if (product.track_stock && !product.is_combo && Number(product.stock_qty) < quantity) {
      const error = new Error(`Inventario insuficiente para ${product.name}`);
      error.status = 409;
      throw error;
    }
    const unitPrice = Number((Number(product.price) + Number(modifierInfo.priceDelta || 0)).toFixed(2));
    const total = Number((quantity * unitPrice).toFixed(2));
    productLines.push({ product, quantity, unitPrice, total, description, modifiers: modifierInfo.modifiers, paidQuantity: quantity, freeQuantity: 0, paidTotal: total });
    subtotal += total;
  }

  const total = Number((subtotal - discountTotal).toFixed(2));
  return { normalizedGameMinutes, normalizedPlayerCount, comboIncludedMinutes, productLines, subtotal, discountTotal, total, timePrice, timeAmount: Number(timePrice.finalAmount || 0) };
}

async function applyRewardToAccountProductLines({ productLines, visitReward, requestedSnackQty = 0, requestedDrinkQty = 0, requestedProductId = null, requestedProductQty = 0 }) {
  if (!visitReward || (requestedSnackQty <= 0 && requestedDrinkQty <= 0 && requestedProductQty <= 0)) {
    return { requestedSnackQty: 0, requestedDrinkQty: 0, requestedProductQty: 0 };
  }

  const snackAvailable = getRewardRemaining(visitReward, 'prize_snack_qty', 'used_prize_snack_qty');
  const drinkAvailable = getRewardRemaining(visitReward, 'prize_drink_qty', 'used_prize_drink_qty');
  const productAvailable = getRewardRemaining(visitReward, 'prize_product_qty', 'used_prize_product_qty');

  if (requestedSnackQty > snackAvailable) {
    const error = new Error('No tienes suficientes bonos de snack disponibles');
    error.status = 409;
    throw error;
  }
  if (requestedDrinkQty > drinkAvailable) {
    const error = new Error('No tienes suficientes bonos de bebida disponibles');
    error.status = 409;
    throw error;
  }
  if (requestedProductQty > 0) {
    if (!requestedProductId || String(visitReward.prize_product_id || '') !== String(requestedProductId)) {
      const error = new Error('Ese bono no corresponde a este producto');
      error.status = 409;
      throw error;
    }
    if (requestedProductQty > productAvailable) {
      const error = new Error('No tienes suficientes bonos de producto disponibles');
      error.status = 409;
      throw error;
    }
    let remainingProduct = requestedProductQty;
    for (const line of productLines) {
      if (String(line.product.id) !== String(requestedProductId) || remainingProduct <= 0) continue;
      const freeQty = Math.min(line.quantity, remainingProduct);
      line.freeQuantity += freeQty;
      line.paidQuantity = Math.max(0, line.quantity - line.freeQuantity);
      line.paidTotal = Number((line.paidQuantity * line.unitPrice).toFixed(2));
      remainingProduct -= freeQty;
    }
    if (remainingProduct > 0) {
      const error = new Error('Agrega el producto del bono a la orden');
      error.status = 400;
      throw error;
    }
  }

  const requestedByCategory = { SNACK: requestedSnackQty, DRINK: requestedDrinkQty };
  for (const category of ['SNACK', 'DRINK']) {
    let remaining = requestedByCategory[category];
    if (remaining <= 0) continue;
    for (const line of productLines) {
      if (line.product.category !== category || remaining <= 0) continue;
      const freeQty = Math.min(line.quantity - line.freeQuantity, remaining);
      if (freeQty <= 0) continue;
      line.freeQuantity += freeQty;
      line.paidQuantity = Math.max(0, line.quantity - line.freeQuantity);
      line.paidTotal = Number((line.paidQuantity * line.unitPrice).toFixed(2));
      remaining -= freeQty;
    }
    if (remaining > 0) {
      const error = new Error(category === 'SNACK' ? 'Agrega snacks para aplicar el bono' : 'Agrega bebidas para aplicar el bono');
      error.status = 400;
      throw error;
    }
  }

  return { requestedSnackQty, requestedDrinkQty, requestedProductQty };
}

async function markRewardUsage(client, { visitReward, rewardMinutes = 0, requestedSnackQty = 0, requestedDrinkQty = 0, requestedProductQty = 0, saleId = null }) {
  if (!visitReward || (rewardMinutes <= 0 && requestedSnackQty <= 0 && requestedDrinkQty <= 0 && requestedProductQty <= 0)) return null;
  const updatedRewardResult = await client.query(
    `UPDATE member_rewards
     SET used_reward_minutes = LEAST(reward_minutes, COALESCE(used_reward_minutes, 0) + $2),
         used_prize_snack_qty = LEAST(prize_snack_qty, COALESCE(used_prize_snack_qty, 0) + $3),
         used_prize_drink_qty = LEAST(prize_drink_qty, COALESCE(used_prize_drink_qty, 0) + $4),
         used_prize_product_qty = LEAST(prize_product_qty, COALESCE(used_prize_product_qty, 0) + $5),
         used_sale_id = COALESCE(used_sale_id, $6),
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [visitReward.id, rewardMinutes, requestedSnackQty, requestedDrinkQty, requestedProductQty, saleId]
  );
  const updatedReward = updatedRewardResult.rows[0];
  if (updatedReward && isRewardFullyUsed(updatedReward)) {
    await client.query(
      `UPDATE member_rewards
       SET status = 'USED', used_at = COALESCE(used_at, NOW()), updated_at = NOW()
       WHERE id = $1`,
      [visitReward.id]
    );
  }
  return updatedReward;
}

export async function checkoutStation(req, res) {
  try {
    const { stationId } = req.params;
    const {
      memberId = null,
      paymentMethod = 'CASH',
      paymentReference = '',
      transferAuthorizationCode = '',
      gameMinutes = 0,
      playerCount = 1,
      welcomeBonusId = null,
      visitRewardId = null,
      rewardMinutesRequested = 0,
      rewardSnackQty = 0,
      rewardDrinkQty = 0,
      rewardProductId = null,
      rewardProductQty = 0,
      items = [],
      extras = [],
      extraControllerCount = 0,
      familyDiscountCode = '',
      tournamentEntries = [],
      gameId = null
    } = req.body;

    const normalizedPaymentMethod = normalizePaymentMethod(paymentMethod);
    const normalizedGameMinutes = Math.max(0, Number(gameMinutes || 0));
    const normalizedPlayerCount = normalizePlayerCount(playerCount);
    const requestedRewardMinutes = Math.max(0, Number.parseInt(String(rewardMinutesRequested || 0), 10) || 0);
    const requestedSnackQty = Math.max(0, Number.parseInt(String(rewardSnackQty || 0), 10) || 0);
    const requestedDrinkQty = Math.max(0, Number.parseInt(String(rewardDrinkQty || 0), 10) || 0);
    const requestedProductId = rewardProductId || null;
    const requestedProductQty = Math.max(0, Number.parseInt(String(rewardProductQty || 0), 10) || 0);
    const selectedGameId = gameId ? String(gameId).trim() : null;

    if (!Array.isArray(items)) {
      return res.status(400).json({ error: 'Los artículos deben ser una lista' });
    }
    if (!Array.isArray(extras)) {
      return res.status(400).json({ error: 'Los extras deben ser una lista' });
    }

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);
      if (normalizedPaymentMethod === 'TRANSFER') {
        await validateTransferAuthorizationCode(client, transferAuthorizationCode, req.user.id);
      }

      const stationResult = await client.query(
        `SELECT * FROM stations WHERE id = $1`,
        [stationId]
      );

      if (stationResult.rowCount === 0) {
        const error = new Error('Estación no encontrada');
        error.status = 404;
        throw error;
      }

      const station = stationResult.rows[0];
      const selectedGame = selectedGameId ? await getActiveStationGame(client, selectedGameId) : null;
      if (selectedGameId && !selectedGame) {
        const error = new Error('Juego no disponible');
        error.status = 400;
        throw error;
      }
      await ensureGameCanBeUsed(client, { game: selectedGame, station, stationId });

      const activeResult = await client.query(
        `SELECT * FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [stationId]
      );

      const activeSession = activeResult.rows[0] || null;
      const extraLines = await buildStationExtraLines(client, stationId, extras);
      const extraControllerLine = buildExtraControllerLine({ station, game: selectedGame, playerCount: normalizedPlayerCount, extraControllerCount });
      const extraControllerTotal = Number(extraControllerLine?.total || 0);
      const extraTotal = extraLines.reduce((sum, line) => sum + Number(line.total || 0), 0) + extraControllerTotal;
      const welcomeBonus = await getValidWelcomeBonus(client, memberId, welcomeBonusId);
      const visitReward = await getValidVisitReward(client, memberId, visitRewardId);
      const bonusMinutes = welcomeBonus ? Number(welcomeBonus.bonus_minutes || 0) : 0;
      const rewardMinutesAvailable = visitReward ? getRewardRemaining(visitReward, 'reward_minutes', 'used_reward_minutes') : 0;
      const rewardMinutes = visitReward && requestedRewardMinutes > 0 ? Math.min(requestedRewardMinutes, rewardMinutesAvailable) : 0;
      let totalSessionMinutes = normalizedGameMinutes + bonusMinutes + rewardMinutes;

      const productLines = [];
      const membershipLines = [];
      let subtotal = 0;
      const tournamentLines = await buildTournamentEntryLines(client, tournamentEntries);
      let discountTotal = 0;
      const timePrice = normalizedGameMinutes > 0
        ? await getGameTimePrice(client, station, normalizedGameMinutes, memberId, normalizedPlayerCount, { allowInactiveExtension: Boolean(activeSession && normalizedGameMinutes === 15) })
        : { baseAmount: 0, finalAmount: 0, discountAmount: 0, promotion: null };
      const timeAmount = timePrice.finalAmount;
      subtotal += timePrice.baseAmount;
      subtotal += extraControllerTotal;
      discountTotal += timePrice.discountAmount;

      for (const item of items) {
        const productResult = await client.query(
          `SELECT id, name, sku, price, stock_qty, track_stock, category, is_combo, membership_plan_code, combo_included_minutes, combo_player_count
           FROM products
           WHERE id = $1 AND is_active = true`,
          [item.productId]
        );

        if (productResult.rowCount === 0) {
          const error = new Error(`Producto no encontrado: ${item.productId}`);
          error.status = 404;
          throw error;
        }

        const product = productResult.rows[0];
        const quantity = Math.max(1, Number(item.quantity || 1));
        const modifierInfo = await resolveProductModifiers(client, product.id, item.modifierOptionIds || item.modifiers || []);
        const unitPrice = Number((Number(product.price) + Number(modifierInfo.priceDelta || 0)).toFixed(2));
        const total = Number((quantity * unitPrice).toFixed(2));
        const comboMinutes = product.is_combo ? Math.max(0, Number(product.combo_included_minutes || 0)) * quantity : 0;
        const comboTimeSuffix = comboMinutes > 0 ? ` · ${comboMinutes} min` : '';
        const description = `${product.name}${modifierInfo.descriptionSuffix}${comboTimeSuffix}`;

        if (product.category === 'MEMBERSHIP' && !memberId) {
          const error = new Error('Selecciona o crea un miembro para vender una membresía');
          error.status = 400;
          throw error;
        }

        if (product.track_stock && !product.is_combo && Number(product.stock_qty) < quantity) {
          const error = new Error(`Inventario insuficiente para ${product.name}`);
          error.status = 409;
          throw error;
        }

        const line = { product, quantity, unitPrice, total, description, modifiers: modifierInfo.modifiers, freeQuantity: 0, paidQuantity: quantity, paidTotal: total };
        productLines.push(line);

        if (product.category === 'MEMBERSHIP') {
          membershipLines.push(line);
        }
      }

      totalSessionMinutes += productLines.reduce((sum, line) => sum + (line.product?.is_combo ? Math.max(0, Number(line.product.combo_included_minutes || 0)) * Number(line.quantity || 1) : 0), 0);
      for (const line of tournamentLines) {
        subtotal += Number(line.unitPrice || line.total || 0);
        discountTotal += Number(line.discountAmount || 0);
      }
      subtotal += extraTotal;

      const familyDiscountRecord = familyDiscountCode
        ? await getValidFamilyDiscountCode(client, familyDiscountCode, { lock: true })
        : null;
      const familyDiscountAmount = familyDiscountRecord
        ? calculateFamilyDiscountAmount(familyDiscountRecord, timeAmount)
        : 0;
      if (familyDiscountRecord && familyDiscountAmount <= 0) {
        const error = new Error('El código familiar solo aplica a tiempo de juego con monto mayor a RD$0');
        error.status = 400;
        throw error;
      }
      discountTotal += familyDiscountAmount;

      if (!activeSession && totalSessionMinutes <= 0 && !tournamentLines.length) {
        const error = new Error('Selecciona tiempo antes de iniciar la estación');
        error.status = 400;
        throw error;
      }

      await applyRewardToAccountProductLines({ productLines, visitReward, requestedSnackQty, requestedDrinkQty, requestedProductId, requestedProductQty });

      for (const line of productLines) {
        subtotal += line.total;
        discountTotal += Number(((line.freeQuantity || 0) * line.unitPrice).toFixed(2));
      }

      if (membershipLines.some((line) => Number(line.quantity || 1) > 1)) {
        const error = new Error('Solo puedes vender una membresía por miembro en la misma orden');
        error.status = 400;
        throw error;
      }

      if (membershipLines.length > 1) {
        const error = new Error('Solo puedes seleccionar una membresía por orden');
        error.status = 400;
        throw error;
      }

      if (subtotal <= 0 && !welcomeBonus && !visitReward) {
        const error = new Error('No hay nada para cobrar');
        error.status = 400;
        throw error;
      }

      const total = Number((subtotal - discountTotal).toFixed(2));

      if (totalSessionMinutes > 0) {
        await assertStationReservationWindowAvailable(client, { stationId, addedMinutes: totalSessionMinutes, activeSession });
      }

      const saleResult = await client.query(
        `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
         VALUES ($1, $2, $3, 0, $4, $5, $6, 'PAID', $7)
         RETURNING *`,
        [req.user.id, memberId, subtotal.toFixed(2), discountTotal.toFixed(2), total.toFixed(2), normalizedPaymentMethod, buildSaleNotes(normalizedPaymentMethod, paymentReference, `Estación - ${station.name}`)]
      );

      const sale = saleResult.rows[0];

      if (familyDiscountRecord && familyDiscountAmount > 0) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'ADJUSTMENT', $2, 1, $3, $4)`,
          [sale.id, `Descuento familiar ${familyDiscountRecord.discount_percent}% · ${familyDiscountRecord.code}`, -familyDiscountAmount, -familyDiscountAmount]
        );
        await client.query(
          `UPDATE family_discount_codes SET used_count = used_count + 1, updated_at = NOW() WHERE id = $1`,
          [familyDiscountRecord.id]
        );
        await client.query(
          `INSERT INTO family_discount_code_usages
             (code_id, sale_id, user_id, discount_amount, subtotal_before_discount, discountable_amount, total_after_discount)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [familyDiscountRecord.id, sale.id, req.user.id, familyDiscountAmount.toFixed(2), subtotal.toFixed(2), Number(timeAmount || 0).toFixed(2), total.toFixed(2)]
        );
      }

      if (normalizedGameMinutes > 0) {
        const priceSourceText = timePrice.source && timePrice.source !== 'GENERAL'
          ? ` · ${getMembershipTierLabel(timePrice.source)}`
          : '';
        const playerText = normalizedPlayerCount === 2 ? ' · 2 jugadores' : ' · 1 jugador';
        const timeDescription = timePrice.promotion
          ? `Tiempo de juego - ${normalizedGameMinutes} minutos${playerText}${priceSourceText} · ${timePrice.promotion.name}`
          : `Tiempo de juego - ${normalizedGameMinutes} minutos${playerText}${priceSourceText}`;

        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, $3, $4)`,
          [sale.id, timeDescription, timePrice.baseAmount, timeAmount]
        );
      }

      const comboIncludedMinutes = productLines.reduce((sum, line) => sum + (line.product?.is_combo ? Math.max(0, Number(line.product.combo_included_minutes || 0)) * Number(line.quantity || 1) : 0), 0);
      if (comboIncludedMinutes > 0) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, 0, 0)`,
          [sale.id, `Tiempo incluido en combo - ${comboIncludedMinutes} minutos`]
        );
      }

      if (welcomeBonus) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, 0, 0)`,
          [sale.id, `Bono de bienvenida - ${bonusMinutes} minutos`]
        );

        await client.query(
          `UPDATE member_bonuses
           SET status = 'USED', used_at = NOW(), used_sale_id = $1, updated_at = NOW()
           WHERE id = $2`,
          [sale.id, welcomeBonus.id]
        );
      }

      if (visitReward && rewardMinutes > 0) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, 0, 0)`,
          [sale.id, `${visitReward.reward_type === 'VISIT_REWARD' ? 'Recompensa por visitas' : 'Bono'} - ${rewardMinutes} minutos`]
        );
      }

      for (const extra of extraLines) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'EXTRA', $2, $3, $4, $5)`,
          [sale.id, `Extra estación - ${extra.label}`, extra.quantity, extra.unitPrice, extra.total]
        );
      }

      if (extraControllerLine) {
        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'EXTRA', $2, $3, $4, $5)`,
          [sale.id, `${extraControllerLine.label} Nintendo Switch · ${extraControllerLine.playerTotal} jugadores`, extraControllerLine.quantity, extraControllerLine.unitPrice, extraControllerLine.total]
        );
      }

      for (const line of productLines) {
        if (line.paidQuantity > 0) {
          await client.query(
            `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [
              sale.id,
              line.product.id,
              line.product.is_combo ? 'COMBO' : 'PRODUCT',
              line.description || line.product.name,
              line.paidQuantity,
              line.unitPrice,
              line.paidTotal
            ]
          );
        }

        if (line.freeQuantity > 0) {
          await client.query(
            `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
             VALUES ($1, $2, $3, $4, $5, 0, 0)`,
            [
              sale.id,
              line.product.id,
              line.product.is_combo ? 'COMBO' : 'PRODUCT',
              visitReward?.prize_product_id ? `Bono producto - ${line.product.name}` : `Bono ${line.product.category === 'DRINK' ? 'bebida' : 'snack'} - ${line.product.name}`,
              line.freeQuantity
            ]
          );
        }

        await deductInventoryForLine(client, line, req.user.id, sale.id);
      }

      await insertTournamentEntrySaleLines(client, { saleId: sale.id, lines: tournamentLines, userId: req.user.id });

      await markRewardUsage(client, { visitReward, rewardMinutes, requestedSnackQty, requestedDrinkQty, requestedProductQty, saleId: sale.id });

      await logAuditEvent(client, {
        eventType: 'STATION_CHECKOUT_PAID',
        userId: req.user.id,
        entityType: 'sale',
        entityId: sale.id,
        stationId,
        saleId: sale.id,
        metadata: {
          stationName: station.name,
          memberId,
          paymentMethod: normalizedPaymentMethod,
          total: Number(sale.total || 0),
          minutes: totalSessionMinutes,
          gameId: selectedGame?.id || activeSession?.game_id || null,
          gameName: selectedGame?.name || null,
          gameMinutes: normalizedGameMinutes,
          playerCount: normalizedPlayerCount,
          productCount: productLines.filter((line) => !line.product.is_combo).reduce((sum, line) => sum + Number(line.quantity || 0), 0),
          comboCount: productLines.filter((line) => line.product.is_combo).reduce((sum, line) => sum + Number(line.quantity || 0), 0),
          tournamentEntryCount: tournamentLines.length,
          extraCount: extraLines.reduce((sum, line) => sum + Number(line.quantity || 0), 0) + Number(extraControllerLine?.quantity || 0),
          extraControllerCount: Number(extraControllerLine?.quantity || 0),
          extraTotal,
          familyDiscountCode: familyDiscountRecord?.code || null,
          familyDiscountAmount
        }
      });

      for (const line of membershipLines) {
        const tier = getMembershipTier(line.product);
        if (!tier) continue;

        const historyResult = await client.query(
          `SELECT id FROM member_membership_history WHERE member_id = $1 LIMIT 1`,
          [memberId]
        );
        const isRenewal = historyResult.rowCount > 0;

        await client.query(
          `INSERT INTO member_membership_history (member_id, sale_id, tier, amount, is_renewal)
           VALUES ($1, $2, $3, $4, $5)`,
          [memberId, sale.id, tier, line.total, isRenewal]
        );

        await client.query(
          `UPDATE members
           SET membership_tier = $1,
               membership_active = true,
               membership_started_at = COALESCE(membership_started_at, NOW()),
               membership_updated_at = NOW(),
               updated_at = NOW()
           WHERE id = $2`,
          [tier, memberId]
        );

        if (!isRenewal) {
          const welcomeRule = await getActiveBonusRule(client, 'WELCOME_MEMBERSHIP');
          if (welcomeRule && Number(welcomeRule.reward_minutes || 0) > 0) {
            const memberInfo = await client.query(
              `SELECT id, membership_tier, membership_active FROM members WHERE id = $1`,
              [memberId]
            );

            if (tierMatchesRule(welcomeRule, memberInfo.rows[0])) {
              await client.query(
                `INSERT INTO member_bonuses (member_id, source_sale_id, bonus_type, bonus_minutes, status, expires_at, source_rule_id)
                 VALUES ($1, $2, 'WELCOME_MEMBERSHIP', $3, 'AVAILABLE', NOW() + ($4 || ' days')::interval, $5)
                 ON CONFLICT (member_id, bonus_type) DO NOTHING`,
                [memberId, sale.id, Number(welcomeRule.reward_minutes || 0), Number(welcomeRule.expires_days || 0), welcomeRule.id]
              );
            }
          }
        }
      }

      let session = activeSession;

      if (!activeSession && totalSessionMinutes > 0) {
        await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [stationId]);
        const sessionResult = await client.query(
          `INSERT INTO game_sessions (station_id, member_id, started_by_user_id, rate_type, prepaid_minutes, total_amount, player_count, game_id, status)
           VALUES ($1, $2, $3, 'PREPAID', $4, $5, $6, $7, 'ACTIVE')
           RETURNING *`,
          [stationId, memberId, req.user.id, totalSessionMinutes, timeAmount, normalizedPlayerCount, selectedGame?.id || null]
        );
        session = sessionResult.rows[0];
      } else if (totalSessionMinutes > 0 || memberId) {
        const updatedSession = await client.query(
          `UPDATE game_sessions
           SET prepaid_minutes = COALESCE(prepaid_minutes, 0) + $1,
               total_amount = total_amount + $2,
               member_id = COALESCE($3, member_id),
               game_id = COALESCE($4, game_id)
           WHERE id = $5
           RETURNING *`,
          [totalSessionMinutes, timeAmount, memberId, selectedGame?.id || null, activeSession.id]
        );
        session = updatedSession.rows[0];
      }

      if (session) {
        if (normalizedGameMinutes > 0) {
          const playerText = normalizedPlayerCount === 2 ? ' · 2 jugadores' : ' · 1 jugador';
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: sale.id,
            lineType: 'GAME_TIME',
            description: `Tiempo de juego - ${normalizedGameMinutes} minutos${playerText}`,
            quantity: 1,
            unitPrice: timePrice.baseAmount,
            total: timeAmount,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
        if (welcomeBonus) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: sale.id,
            lineType: 'BONUS',
            description: `Bono bienvenida - ${bonusMinutes} minutos`,
            quantity: 1,
            unitPrice: 0,
            total: 0,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
        if (visitReward && rewardMinutes > 0) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: sale.id,
            lineType: 'BONUS',
            description: `${visitReward.reward_type === 'VISIT_REWARD' ? 'Recompensa por visitas' : 'Bono'} - ${rewardMinutes} minutos`,
            quantity: 1,
            unitPrice: 0,
            total: 0,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
        for (const extra of extraLines) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            saleId: sale.id,
            lineType: 'EXTRA',
            description: `Extra estación - ${extra.label}`,
            quantity: extra.quantity,
            unitPrice: extra.unitPrice,
            total: extra.total,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
        for (const line of productLines) {
          if (line.paidQuantity > 0) {
            await insertSessionAccountLine(client, {
              sessionId: session.id,
              saleId: sale.id,
              productId: line.product.id,
              lineType: line.product.is_combo ? 'COMBO' : 'PRODUCT',
              description: line.product.name,
              quantity: line.paidQuantity,
              unitPrice: line.unitPrice,
              total: line.paidTotal,
              paymentStatus: 'PAID',
              userId: req.user.id
            });
          }
          if (line.freeQuantity > 0) {
            await insertSessionAccountLine(client, {
              sessionId: session.id,
              saleId: sale.id,
              productId: line.product.id,
              lineType: 'BONUS',
              description: visitReward?.prize_product_id ? `Bono producto - ${line.product.name}` : `Bono ${line.product.category === 'DRINK' ? 'bebida' : 'snack'} - ${line.product.name}`,
              quantity: line.freeQuantity,
              unitPrice: 0,
              total: 0,
              paymentStatus: 'PAID',
              userId: req.user.id
            });
          }
        }
      }

      if (memberId) {
        await client.query(
          `UPDATE members SET reward_points = reward_points + 1, updated_at = NOW() WHERE id = $1`,
          [memberId]
        );
        await recordMemberPointMovement(client, {
          memberId,
          points: 1,
          category: 'SESSION',
          reason: '1 punto por pago de estación',
          affectsRanking: false,
          referenceType: 'SESSION',
          referenceId: session.id,
          sourceKey: `session:${session.id}:member:${memberId}:points`,
          userId: req.user?.id || null
        });
      }

      return {
        sale,
        session,
        bonusApplied: welcomeBonus ? { minutes: bonusMinutes } : null,
        rewardApplied: visitReward ? { minutes: rewardMinutes } : null
      };
    });

    res.status(201).json(result);

  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function saveStationAccount(req, res) {
  try {
    const { stationId } = req.params;
    const {
      memberId = null,
      gameMinutes = 0,
      playerCount = 1,
      freeMode = false,
      welcomeBonusId = null,
      visitRewardId = null,
      rewardMinutesRequested = 0,
      rewardSnackQty = 0,
      rewardDrinkQty = 0,
      rewardProductId = null,
      rewardProductQty = 0,
      items = [],
      extras = [],
      extraControllerCount = 0,
      familyDiscountCode = '',
      tournamentEntries = [],
      gameId = null
    } = req.body;

    if (!Array.isArray(items)) return res.status(400).json({ error: 'Los artículos deben ser una lista' });
    if (!Array.isArray(extras)) return res.status(400).json({ error: 'Los extras deben ser una lista' });
    if (familyDiscountCode) return res.status(400).json({ error: 'El código familiar debe usarse con Pagar ahora, no Guardar cuenta.' });

    const requestedRewardMinutes = Math.max(0, Number.parseInt(String(rewardMinutesRequested || 0), 10) || 0);
    const requestedSnackQty = Math.max(0, Number.parseInt(String(rewardSnackQty || 0), 10) || 0);
    const requestedDrinkQty = Math.max(0, Number.parseInt(String(rewardDrinkQty || 0), 10) || 0);
    const requestedProductId = rewardProductId || null;
    const requestedProductQty = Math.max(0, Number.parseInt(String(rewardProductQty || 0), 10) || 0);
    const selectedGameId = gameId ? String(gameId).trim() : null;

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);

      const stationResult = await client.query(`SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL`, [stationId]);
      if (stationResult.rowCount === 0) {
        const error = new Error('Estación no encontrada');
        error.status = 404;
        throw error;
      }
      const station = stationResult.rows[0];
      const selectedGame = selectedGameId ? await getActiveStationGame(client, selectedGameId) : null;
      if (selectedGameId && !selectedGame) {
        const error = new Error('Juego no disponible');
        error.status = 400;
        throw error;
      }
      await ensureGameCanBeUsed(client, { game: selectedGame, station, stationId });
      const active = await client.query(`SELECT * FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`, [stationId]);

      const welcomeBonus = await getValidWelcomeBonus(client, memberId, welcomeBonusId);
      const visitReward = await getValidVisitReward(client, memberId, visitRewardId);
      const bonusMinutes = welcomeBonus ? Number(welcomeBonus.bonus_minutes || 0) : 0;
      const rewardMinutesAvailable = visitReward ? getRewardRemaining(visitReward, 'reward_minutes', 'used_reward_minutes') : 0;
      const rewardMinutes = visitReward && requestedRewardMinutes > 0 ? Math.min(requestedRewardMinutes, rewardMinutesAvailable) : 0;
      const freeMinutes = bonusMinutes + rewardMinutes;

      const built = await buildStationOrderForAccount(client, { station, memberId, gameMinutes, playerCount, items, allowExtension15: active.rowCount > 0 });
      const extraLines = await buildStationExtraLines(client, stationId, extras);
      const extraControllerLine = buildExtraControllerLine({ station, game: selectedGame, playerCount, extraControllerCount });
      const extraControllerTotal = Number(extraControllerLine?.total || 0);
      const extraTotal = extraLines.reduce((sum, line) => sum + Number(line.total || 0), 0) + extraControllerTotal;
      await applyRewardToAccountProductLines({ productLines: built.productLines, visitReward, requestedSnackQty, requestedDrinkQty, requestedProductId, requestedProductQty });

      const pendingProductTotal = built.productLines.reduce((sum, line) => sum + Number(line.paidTotal || 0), 0);
      const hasFreeRewardProduct = built.productLines.some((line) => Number(line.freeQuantity || 0) > 0);
      const totalSessionMinutes = built.normalizedGameMinutes + freeMinutes + Number(built.comboIncludedMinutes || 0);
      if (totalSessionMinutes > 0 || freeMode) {
        await assertStationReservationWindowAvailable(client, { stationId, addedMinutes: totalSessionMinutes, activeSession: active.rows[0] || null, freeMode });
      }

      if (extraTotal > 0 && active.rowCount === 0 && !freeMode && totalSessionMinutes <= 0) {
        const error = new Error('Selecciona tiempo o modo libre antes de agregar extras');
        error.status = 400;
        throw error;
      }
      if (built.timeAmount <= 0 && pendingProductTotal <= 0 && extraTotal <= 0 && !freeMode && totalSessionMinutes <= 0 && !hasFreeRewardProduct) {
        const error = new Error('Agrega tiempo, productos, extras o modo libre');
        error.status = 400;
        throw error;
      }

      const session = await getOrCreateStationSessionForAccount(client, {
        stationId,
        station,
        memberId,
        userId: req.user.id,
        totalSessionMinutes,
        timeAmount: built.timeAmount,
        playerCount: built.normalizedPlayerCount,
        freeMode,
        gameId: selectedGame?.id || null
      });

      if (built.normalizedGameMinutes > 0) {
        const playerText = built.normalizedPlayerCount === 2 ? ' · 2 jugadores' : ' · 1 jugador';
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'GAME_TIME',
          description: `Tiempo de juego - ${built.normalizedGameMinutes} minutos${playerText}`,
          quantity: 1,
          unitPrice: built.timePrice.baseAmount,
          total: built.timeAmount,
          paymentStatus: 'PENDING',
          userId: req.user.id
        });
      }

      if (Number(built.comboIncludedMinutes || 0) > 0) {
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'BONUS',
          description: `Tiempo incluido en combo - ${Number(built.comboIncludedMinutes || 0)} minutos`,
          quantity: 1,
          unitPrice: 0,
          total: 0,
          paymentStatus: 'PAID',
          userId: req.user.id
        });
      }

      if (welcomeBonus) {
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'BONUS',
          description: `Bono bienvenida - ${bonusMinutes} minutos`,
          quantity: 1,
          unitPrice: 0,
          total: 0,
          paymentStatus: 'PAID',
          userId: req.user.id
        });
        await client.query(
          `UPDATE member_bonuses
           SET status = 'USED', used_at = NOW(), updated_at = NOW()
           WHERE id = $1`,
          [welcomeBonus.id]
        );
      }

      if (visitReward && rewardMinutes > 0) {
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'BONUS',
          description: `${visitReward.reward_type === 'VISIT_REWARD' ? 'Recompensa por visitas' : 'Bono'} - ${rewardMinutes} minutos`,
          quantity: 1,
          unitPrice: 0,
          total: 0,
          paymentStatus: 'PAID',
          userId: req.user.id
        });
      }

      for (const extra of extraLines) {
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'EXTRA',
          description: `Extra estación - ${extra.label}`,
          quantity: extra.quantity,
          unitPrice: extra.unitPrice,
          total: extra.total,
          paymentStatus: 'PENDING',
          userId: req.user.id
        });
      }

      if (extraControllerLine) {
        await insertSessionAccountLine(client, {
          sessionId: session.id,
          lineType: 'EXTRA',
          description: `${extraControllerLine.label} Nintendo Switch · ${extraControllerLine.playerTotal} jugadores`,
          quantity: extraControllerLine.quantity,
          unitPrice: extraControllerLine.unitPrice,
          total: extraControllerLine.total,
          paymentStatus: 'PENDING',
          userId: req.user.id
        });
      }

      for (const line of built.productLines) {
        await deductInventoryForLine(client, line, req.user.id, null);
        if (line.paidQuantity > 0) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            productId: line.product.id,
            lineType: line.product.is_combo ? 'COMBO' : 'PRODUCT',
            description: line.description || line.product.name,
            quantity: line.paidQuantity,
            unitPrice: line.unitPrice,
            total: line.paidTotal,
            paymentStatus: 'PENDING',
            userId: req.user.id
          });
        }
        if (line.freeQuantity > 0) {
          await insertSessionAccountLine(client, {
            sessionId: session.id,
            productId: line.product.id,
            lineType: 'BONUS',
            description: visitReward?.prize_product_id ? `Bono producto - ${line.product.name}` : `Bono ${line.product.category === 'DRINK' ? 'bebida' : 'snack'} - ${line.product.name}`,
            quantity: line.freeQuantity,
            unitPrice: 0,
            total: 0,
            paymentStatus: 'PAID',
            userId: req.user.id
          });
        }
      }

      await markRewardUsage(client, { visitReward, rewardMinutes, requestedSnackQty, requestedDrinkQty, requestedProductQty });

      await logAuditEvent(client, {
        eventType: 'STATION_ACCOUNT_SAVED',
        userId: req.user.id,
        entityType: 'game_session',
        entityId: session.id,
        stationId,
        metadata: {
          stationName: station.name,
          memberId,
          minutes: totalSessionMinutes,
          gameMinutes: built.normalizedGameMinutes,
          playerCount: built.normalizedPlayerCount,
          freeMode: Boolean(freeMode),
          pendingProductTotal,
          extraTotal,
          extraCount: extraLines.reduce((sum, line) => sum + Number(line.quantity || 0), 0) + Number(extraControllerLine?.quantity || 0),
          extraControllerCount: Number(extraControllerLine?.quantity || 0),
          comboMinutes: Number(built.comboIncludedMinutes || 0)
        }
      });

      return { session };
    });

    res.status(201).json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function payStationAccount(req, res) {
  try {
    const { stationId } = req.params;
    const { paymentMethod = 'CASH', paymentReference = '', transferAuthorizationCode = '' } = req.body;
    const normalizedPaymentMethod = normalizePaymentMethod(paymentMethod);

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);
      if (normalizedPaymentMethod === 'TRANSFER') await validateTransferAuthorizationCode(client, transferAuthorizationCode, req.user.id);

      const active = await client.query(
        `SELECT gs.*, s.name AS station_name
         FROM game_sessions gs
         JOIN stations s ON s.id = gs.station_id
         WHERE gs.station_id = $1 AND gs.status = 'ACTIVE'
         LIMIT 1`,
        [stationId]
      );
      if (active.rowCount === 0) {
        const error = new Error('No hay cuenta abierta en esta estación');
        error.status = 404;
        throw error;
      }
      const session = active.rows[0];
      const pending = await client.query(
        `SELECT * FROM station_session_items WHERE session_id = $1 AND payment_status = 'PENDING' ORDER BY created_at, id FOR UPDATE`,
        [session.id]
      );
      if (pending.rowCount === 0) {
        const error = new Error('No hay balance pendiente');
        error.status = 400;
        throw error;
      }

      const subtotal = pending.rows.reduce((sum, line) => sum + Number(line.total || 0), 0);
      const total = Number(subtotal.toFixed(2));
      if (total <= 0) {
        const error = new Error('No hay balance pendiente');
        error.status = 400;
        throw error;
      }

      const saleResult = await client.query(
        `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
         VALUES ($1, $2, $3, 0, 0, $3, $4, 'PAID', $5)
         RETURNING *`,
        [req.user.id, session.member_id, total.toFixed(2), normalizedPaymentMethod, buildSaleNotes(normalizedPaymentMethod, paymentReference, `Cuenta pendiente - ${session.station_name}`)]
      );
      const sale = saleResult.rows[0];

      for (const line of pending.rows) {
        await client.query(
          `INSERT INTO sale_items (sale_id, product_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [sale.id, line.product_id, line.line_type === 'GAME_TIME' ? 'GAME_TIME' : (line.line_type === 'COMBO' ? 'COMBO' : (line.line_type === 'EXTRA' ? 'EXTRA' : 'PRODUCT')), line.description, line.quantity, line.unit_price, line.total]
        );
      }

      await client.query(
        `UPDATE station_session_items SET payment_status = 'PAID', sale_id = $2, paid_at = NOW() WHERE session_id = $1 AND payment_status = 'PENDING'`,
        [session.id, sale.id]
      );

      if (session.member_id) {
        await syncMemberAchievements(client, { memberId: session.member_id, userId: req.user?.id || null });
      }

      await logAuditEvent(client, {
        eventType: 'STATION_ACCOUNT_PAID',
        userId: req.user.id,
        entityType: 'sale',
        entityId: sale.id,
        stationId,
        saleId: sale.id,
        metadata: { stationName: session.station_name, sessionId: session.id, paymentMethod: normalizedPaymentMethod, total: Number(sale.total || 0) }
      });

      return { sale };
    });

    res.status(201).json(result);
  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function enableFreeMode(req, res) {
  try {
    const { stationId } = req.params;
    const { memberId = null, playerCount = 1 } = req.body;
    const normalizedPlayerCount = normalizePlayerCount(playerCount);

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);

      const stationResult = await client.query(
        `SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL`,
        [stationId]
      );

      if (stationResult.rowCount === 0) {
        const error = new Error('Estación no encontrada');
        error.status = 404;
        throw error;
      }

      const active = await client.query(
        `SELECT * FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [stationId]
      );
      await assertStationReservationWindowAvailable(client, { stationId, addedMinutes: 0, activeSession: active.rows[0] || null, freeMode: true });

      await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [stationId]);

      if (active.rowCount === 0) {
        const session = await client.query(
          `INSERT INTO game_sessions (station_id, member_id, started_by_user_id, rate_type, prepaid_minutes, total_amount, player_count, status)
           VALUES ($1, $2, $3, 'HOURLY', 0, 0, $4, 'ACTIVE')
           RETURNING *`,
          [stationId, memberId, req.user.id, normalizedPlayerCount]
        );
        return session.rows[0];
      }

      const current = active.rows[0];
      const session = await client.query(
        `UPDATE game_sessions
         SET rate_type = 'HOURLY',
             prepaid_minutes = COALESCE(prepaid_minutes, 0),
             total_amount = COALESCE(total_amount, 0),
             player_count = COALESCE($2, player_count),
             member_id = COALESCE($3, member_id)
         WHERE id = $1
         RETURNING *`,
        [current.id, normalizedPlayerCount, memberId]
      );
      return session.rows[0];
    });

    res.status(201).json({ session: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function startSession(req, res) {
  try {
    const { stationId } = req.params;
    const { memberId = null, rateType = 'HOURLY', prepaidMinutes = null, playerCount = 1, gameId = null } = req.body;
    const selectedGameId = gameId ? String(gameId).trim() : null;
    const normalizedPlayerCount = normalizePlayerCount(playerCount);

    const result = await withTransaction(async (client) => {
      await ensureOpenDrawer(client);

      const active = await client.query(
        `SELECT id FROM game_sessions WHERE station_id = $1 AND status = 'ACTIVE'`,
        [stationId]
      );
      if (active.rowCount > 0) {
        const error = new Error('Esta estación ya tiene una sesión activa');
        error.status = 409;
        throw error;
      }

      const stationResult = await client.query(`SELECT * FROM stations WHERE id = $1 AND deleted_at IS NULL`, [stationId]);
      if (stationResult.rowCount === 0) {
        const error = new Error('Estación no encontrada');
        error.status = 404;
        throw error;
      }
      const station = stationResult.rows[0];
      const selectedGame = selectedGameId ? await getActiveStationGame(client, selectedGameId) : null;
      if (selectedGameId && !selectedGame) {
        const error = new Error('Juego no disponible');
        error.status = 400;
        throw error;
      }
      await ensureGameCanBeUsed(client, { game: selectedGame, station, stationId });
      await assertStationReservationWindowAvailable(client, { stationId, addedMinutes: Number(prepaidMinutes || 0), freeMode: String(rateType || '').toUpperCase() !== 'PREPAID' });

      await client.query(`UPDATE stations SET status = 'BUSY' WHERE id = $1`, [stationId]);
      const session = await client.query(
        `INSERT INTO game_sessions (station_id, member_id, started_by_user_id, rate_type, prepaid_minutes, player_count, game_id, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, 'ACTIVE')
         RETURNING *`,
        [stationId, memberId, req.user.id, rateType, prepaidMinutes, normalizedPlayerCount, selectedGame?.id || null]
      );
      await logAuditEvent(client, {
        eventType: 'STATION_OPENED',
        userId: req.user.id,
        entityType: 'game_session',
        entityId: session.rows[0].id,
        stationId,
        metadata: { memberId, rateType, prepaidMinutes, playerCount: normalizedPlayerCount, gameId: selectedGame?.id || null, gameName: selectedGame?.name || null }
      });
      return session.rows[0];
    });

    res.status(201).json({ session: result });

  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function endSession(req, res) {
  try {
    const { stationId } = req.params;
    const { paymentMethod = 'CASH', paymentReference = '', transferAuthorizationCode = '' } = req.body;
    const normalizedPaymentMethod = normalizePaymentMethod(paymentMethod);

    const result = await withTransaction(async (client) => {
      const active = await client.query(
        `SELECT gs.*, s.id AS station_id, s.name AS station_name, s.console_type, s.hourly_rate
         FROM game_sessions gs
         JOIN stations s ON s.id = gs.station_id
         WHERE gs.station_id = $1 AND gs.status = 'ACTIVE'
         LIMIT 1`,
        [stationId]
      );

      if (active.rowCount === 0) {
        const error = new Error('No hay sesión activa en esta estación');
        error.status = 404;
        throw error;
      }

      const session = active.rows[0];
      const pendingAccount = await client.query(
        `SELECT COALESCE(SUM(total), 0) AS total
         FROM station_session_items
         WHERE session_id = $1 AND payment_status = 'PENDING'`,
        [session.id]
      );
      if (Number(pendingAccount.rows[0]?.total || 0) > 0) {
        const error = new Error('Esta estación tiene balance pendiente');
        error.status = 409;
        throw error;
      }

      const elapsedMinutesExact = Math.max(0, (Date.now() - new Date(session.started_at).getTime()) / 60000);
      const elapsedMinutes = Math.max(1, Math.ceil(elapsedMinutesExact));
      const prepaidMinutes = Math.max(0, Number(session.prepaid_minutes || 0));
      const isStrictPrepaid = session.rate_type === 'PREPAID';
      const playedMinutes = isStrictPrepaid && prepaidMinutes > 0
        ? Math.max(1, Math.min(elapsedMinutes, prepaidMinutes))
        : elapsedMinutes;
      const closeDelayMinutes = isStrictPrepaid && prepaidMinutes > 0
        ? Math.max(0, elapsedMinutes - prepaidMinutes)
        : 0;
      const scheduledEndAt = isStrictPrepaid && prepaidMinutes > 0
        ? new Date(new Date(session.started_at).getTime() + prepaidMinutes * 60000)
        : null;
      const openCharge = isStrictPrepaid
        ? { amount: 0, chargeableMinutes: 0, hourlyRate: 0, packages: [] }
        : await getOpenSessionHourlyAmount(client, session, session, elapsedMinutesExact);
      const amount = isStrictPrepaid ? Number(session.total_amount || 0) : Math.round(Number(openCharge.amount || 0));

      if (!isStrictPrepaid && amount > 0) {
        await ensureOpenDrawer(client);
        if (normalizedPaymentMethod === 'TRANSFER') {
          await validateTransferAuthorizationCode(client, transferAuthorizationCode, req.user.id);
        }
      }

      const updated = await client.query(
        `UPDATE game_sessions
         SET ended_at = NOW(),
             ended_by_user_id = $1,
             total_minutes = $2,
             total_amount = $3,
             status = 'CLOSED',
             scheduled_end_at = COALESCE(scheduled_end_at, $4),
             close_delay_minutes = $5
         WHERE id = $6
         RETURNING *`,
        [req.user.id, playedMinutes, amount, scheduledEndAt, closeDelayMinutes, session.id]
      );

      await client.query(`UPDATE stations SET status = 'AVAILABLE' WHERE id = $1`, [stationId]);

      let sale = null;

      if (!isStrictPrepaid && amount > 0) {
        const saleResult = await client.query(
          `INSERT INTO sales (user_id, member_id, subtotal, tax_total, discount_total, total, payment_method, status, notes)
           VALUES ($1, $2, $3, 0, 0, $3, $4, 'PAID', $5)
           RETURNING *`,
          [req.user.id, session.member_id, amount, normalizedPaymentMethod, buildSaleNotes(normalizedPaymentMethod, paymentReference, `Modo libre - ${session.station_name || 'Estación'}`)]
        );

        sale = saleResult.rows[0];
        const prepaidText = Number(session.prepaid_minutes || 0) > 0 ? ` · luego de ${Number(session.prepaid_minutes || 0)} min prepagos` : '';

        await client.query(
          `INSERT INTO sale_items (sale_id, item_type, description, quantity, unit_price, total)
           VALUES ($1, 'GAME_TIME', $2, 1, $3, $3)`,
          [sale.id, `Modo libre - ${openCharge.chargeableMinutes} minutos${prepaidText}`, amount]
        );
      }

      const rewardCreated = session.member_id
        ? await createVisitRewardIfEligible(client, session.member_id, session.id, playedMinutes)
        : null;

      if (session.member_id) {
        await syncMemberAchievements(client, { memberId: session.member_id, userId: req.user?.id || null });
      }

      await logAuditEvent(client, {
        eventType: 'STATION_CLOSED',
        userId: req.user.id,
        entityType: 'game_session',
        entityId: updated.rows[0].id,
        stationId,
        saleId: sale?.id || null,
        metadata: { stationName: session.station_name, minutes: playedMinutes, elapsedMinutes, closeDelayMinutes, amount, paymentMethod: amount > 0 ? normalizedPaymentMethod : null }
      });

      return { session: updated.rows[0], sale, rewardCreated };
    });

    res.json(result);

  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function createStation(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });

    const station = normalizeStationPayload(req.body);
    const { rows } = await query(
      `INSERT INTO stations (name, console_type, screen_label, hourly_rate, status, sort_order)
       VALUES ($1, $2, $2, $3, $4, $5)
       RETURNING *`,
      [station.name, station.consoleType, station.hourlyRate, station.status, station.sortOrder]
    );

    res.status(201).json({ station: rows[0] });

  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function updateStation(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });

    const { stationId } = req.params;
    const station = normalizeStationPayload(req.body);

    const currentResult = await query(
      `SELECT s.*, gs.id AS active_session_id
       FROM stations s
       LEFT JOIN game_sessions gs ON gs.station_id = s.id AND gs.status = 'ACTIVE'
       WHERE s.id = $1 AND s.deleted_at IS NULL`,
      [stationId]
    );

    if (currentResult.rowCount === 0) return res.status(404).json({ error: 'Estación no encontrada' });

    const current = currentResult.rows[0];
    const nextStatus = current.active_session_id ? 'BUSY' : station.status;

    const { rows } = await query(
      `UPDATE stations
       SET name = $2,
           console_type = $3,
           screen_label = $3,
           hourly_rate = $4,
           status = $5,
           sort_order = $6,
           updated_at = NOW()
       WHERE id = $1 AND deleted_at IS NULL
       RETURNING *`,
      [stationId, station.name, station.consoleType, station.hourlyRate, nextStatus, station.sortOrder]
    );

    res.json({ station: rows[0] });

  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function deleteStation(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });

    const { stationId } = req.params;
    const currentResult = await query(
      `SELECT s.*, gs.id AS active_session_id
       FROM stations s
       LEFT JOIN game_sessions gs ON gs.station_id = s.id AND gs.status = 'ACTIVE'
       WHERE s.id = $1 AND s.deleted_at IS NULL`,
      [stationId]
    );

    if (currentResult.rowCount === 0) return res.status(404).json({ error: 'Estación no encontrada' });

    const current = currentResult.rows[0];
    if (current.active_session_id || current.status === 'BUSY') {
      return res.status(409).json({ error: 'No puedes eliminar una estación ocupada' });
    }

    const { rows } = await query(
      `UPDATE stations
       SET status = 'OFFLINE',
           deleted_at = NOW(),
           updated_at = NOW()
       WHERE id = $1 AND deleted_at IS NULL
       RETURNING *`,
      [stationId]
    );

    res.json({ station: rows[0] });

  } catch (error) {
    return sendControllerError(res, error);
  }
}


export async function listGroupEventPrices(_req, res) {
  try {
    const { rows } = await query(
      `SELECT *
       FROM reservation_group_event_prices
       ORDER BY sort_order, price_type, min_players, is_full_club DESC, station_count, duration_minutes`
    );
    res.json({ prices: rows });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function saveGroupEventPrices(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });
    const prices = Array.isArray(req.body.prices) ? req.body.prices.map((row, index) => normalizeGroupEventPriceRow(row, index)) : [];
    if (!prices.length) return res.status(400).json({ error: 'Agrega al menos un precio grupal' });

    const result = await withTransaction(async (client) => {
      const saved = [];
      const incomingIds = prices.map((row) => row.id).filter(Boolean);

      if (incomingIds.length) {
        await client.query(
          `UPDATE reservation_group_event_prices
           SET is_active = false,
               updated_at = NOW()
           WHERE id <> ALL($1::uuid[])`,
          [incomingIds]
        );
      } else {
        await client.query(`UPDATE reservation_group_event_prices SET is_active = false, updated_at = NOW()`);
      }

      for (const row of prices) {
        if (row.id) {
          const updateResult = await client.query(
            `UPDATE reservation_group_event_prices
             SET price_type = $2,
                 name = $3,
                 min_players = $4,
                 station_count = $5,
                 is_full_club = $6,
                 duration_minutes = $7,
                 price = $8,
                 deposit_percent = $9,
                 min_deposit_amount = $10,
                 extra_player_price = $11,
                 extra_station_price = $12,
                 is_active = $13,
                 sort_order = $14,
                 notes = $15,
                 updated_at = NOW()
             WHERE id = $1
             RETURNING *`,
            [row.id, row.priceType, row.name, row.minPlayers, row.stationCount, row.isFullClub, row.durationMinutes, row.price, row.depositPercent, row.minDepositAmount, row.extraPlayerPrice, row.extraStationPrice, row.isActive, row.sortOrder, row.notes]
          );
          if (updateResult.rowCount > 0) {
            saved.push(updateResult.rows[0]);
            continue;
          }
        }

        const insertResult = await client.query(
          `INSERT INTO reservation_group_event_prices (
             price_type, name, min_players, station_count, is_full_club, duration_minutes,
             price, deposit_percent, min_deposit_amount, extra_player_price, extra_station_price, is_active, sort_order, notes
           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
           ON CONFLICT (price_type, min_players, station_count, is_full_club, duration_minutes)
           DO UPDATE SET
             name = EXCLUDED.name,
             price = EXCLUDED.price,
             deposit_percent = EXCLUDED.deposit_percent,
             min_deposit_amount = EXCLUDED.min_deposit_amount,
             extra_player_price = EXCLUDED.extra_player_price,
             extra_station_price = EXCLUDED.extra_station_price,
             is_active = EXCLUDED.is_active,
             sort_order = EXCLUDED.sort_order,
             notes = EXCLUDED.notes,
             updated_at = NOW()
           RETURNING *`,
          [row.priceType, row.name, row.minPlayers, row.stationCount, row.isFullClub, row.durationMinutes, row.price, row.depositPercent, row.minDepositAmount, row.extraPlayerPrice, row.extraStationPrice, row.isActive, row.sortOrder, row.notes]
        );
        saved.push(insertResult.rows[0]);
      }
      return saved;
    });

    res.json({ prices: result });
  } catch (error) {
    return sendControllerError(res, error);
  }
}

export async function listTimePrices(_req, res) {
  try {
    const { rows } = await query(`
      SELECT
        stp.*,
        s.name AS station_name,
        s.console_type AS station_console_type
      FROM station_time_prices stp
      LEFT JOIN stations s ON s.id = stp.station_id
      WHERE stp.station_id IS NULL OR s.deleted_at IS NULL
      ORDER BY
        CASE WHEN stp.station_id IS NULL THEN 0 ELSE 1 END,
        COALESCE(stp.console_type, s.name),
        stp.player_count,
        stp.sort_order,
        stp.minutes
    `);

    res.json({ prices: rows });

  } catch (error) {
    return sendControllerError(res, error);
  }
}

async function upsertTimePricesForScope(client, { stationId = null, consoleType = null, prices = [] }) {
  const saved = [];
  for (const row of prices) {
    const savedResult = await client.query(
      `INSERT INTO station_time_prices (station_id, console_type, label, minutes, player_count, price, is_active, sort_order)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT DO NOTHING
       RETURNING *`,
      [stationId, consoleType, row.label, row.minutes, row.playerCount, row.price, row.isActive, row.sortOrder]
    );

    if (savedResult.rowCount > 0) {
      saved.push(savedResult.rows[0]);
      continue;
    }

    const updateResult = stationId
      ? await client.query(
          `UPDATE station_time_prices
           SET label = $4,
               price = $5,
               is_active = $6,
               sort_order = $7,
               updated_at = NOW()
           WHERE station_id = $1
             AND minutes = $2
             AND player_count = $3
           RETURNING *`,
          [stationId, row.minutes, row.playerCount, row.label, row.price, row.isActive, row.sortOrder]
        )
      : await client.query(
          `UPDATE station_time_prices
           SET label = $4,
               price = $5,
               is_active = $6,
               sort_order = $7,
               updated_at = NOW()
           WHERE station_id IS NULL
             AND console_type = $1
             AND minutes = $2
             AND player_count = $3
           RETURNING *`,
          [consoleType, row.minutes, row.playerCount, row.label, row.price, row.isActive, row.sortOrder]
        );

    saved.push(updateResult.rows[0]);
  }
  return saved;
}

export async function saveTimePrices(req, res) {
  try {
    if (!canManageStations(req)) return res.status(403).json({ error: 'No tienes permiso' });

    const scopeType = String(req.body.scopeType || req.body.scope_type || '').toLowerCase();
    const stationId = req.body.stationId || req.body.station_id || null;
    const consoleType = String(req.body.consoleType || req.body.console_type || '').trim();
    const prices = Array.isArray(req.body.prices) ? req.body.prices.map(normalizeTimePriceRow) : [];

    if (!prices.length) return res.status(400).json({ error: 'Agrega precios' });

    const result = await withTransaction(async (client) => {
      if (scopeType === 'all') {
        const stationResult = await client.query(`SELECT id FROM stations WHERE deleted_at IS NULL ORDER BY sort_order, name`);
        const saved = [];

        for (const allowedConsoleType of ALLOWED_CONSOLES) {
          saved.push(...await upsertTimePricesForScope(client, { consoleType: allowedConsoleType, prices }));
        }

        for (const station of stationResult.rows) {
          saved.push(...await upsertTimePricesForScope(client, { stationId: station.id, prices }));
        }

        return saved;
      }

      let scopeStationId = null;
      let scopeConsoleType = null;

      if (scopeType === 'station') {
        const stationResult = await client.query(`SELECT id, console_type FROM stations WHERE id = $1 AND deleted_at IS NULL`, [stationId]);
        if (stationResult.rowCount === 0) {
          const error = new Error('Estación no encontrada');
          error.status = 404;
          throw error;
        }
        scopeStationId = stationResult.rows[0].id;
      } else if (scopeType === 'console') {
        if (!ALLOWED_CONSOLES.includes(consoleType)) {
          const error = new Error('Modelo inválido');
          error.status = 400;
          throw error;
        }
        scopeConsoleType = consoleType;
      } else {
        const error = new Error('Selecciona alcance');
        error.status = 400;
        throw error;
      }

      return upsertTimePricesForScope(client, { stationId: scopeStationId, consoleType: scopeConsoleType, prices });
    });

    res.json({ prices: result });

  } catch (error) {
    return sendControllerError(res, error);
  }
}
